import { useMemo } from 'react';
import { DollarSign, TrendingDown, AlertTriangle, CheckCircle } from 'lucide-react';

function fmt$(cents) {
  if (!cents) return '$0';
  return '$' + (cents / 100).toLocaleString('en-US', { maximumFractionDigits: 0 });
}
function fmtPct(v) {
  if (v === null || v === undefined) return '—';
  return (v * 100).toFixed(1) + '%';
}

function StatCard({ label, value, sub, icon: Icon, color }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">{label}</div>
          <div className={`text-2xl font-bold ${color || 'text-slate-800'}`}>{value}</div>
          {sub && <div className="text-xs text-slate-400 mt-0.5">{sub}</div>}
        </div>
        {Icon && <Icon className={`w-5 h-5 ${color || 'text-slate-400'}`} />}
      </div>
    </div>
  );
}

export default function ProfitOverviewTab({ jobs, signals }) {
  const stats = useMemo(() => {
    const recognized = jobs.filter(j => j.recognitionStatus === 'RECOGNIZED' && j.contractValueCents > 0);
    const totalContract = recognized.reduce((s, j) => s + (j.contractValueCents || 0), 0);
    const totalCost = recognized.reduce((s, j) => s + (j.directCostCents || 0), 0);
    const netProfit = totalContract - totalCost;
    const margin = totalContract > 0 ? netProfit / totalContract : null;
    const breaches = recognized.filter(j => {
      const m = j.contractValueCents > 0 ? (j.contractValueCents - (j.directCostCents || 0)) / j.contractValueCents : null;
      return m !== null && m < 0.25;
    });
    const reworks = jobs.filter(j => j.reworkFlag);
    const changeOrders = jobs.filter(j => (j.changeOrdersCount || 0) >= 2);
    return { recognized, totalContract, totalCost, netProfit, margin, breaches, reworks, changeOrders };
  }, [jobs]);

  // Top leaks = jobs with lowest margin (recognized only)
  const topLeaks = useMemo(() => {
    return jobs
      .filter(j => j.recognitionStatus === 'RECOGNIZED' && j.contractValueCents > 0)
      .map(j => ({ ...j, _margin: (j.contractValueCents - (j.directCostCents || 0)) / j.contractValueCents }))
      .sort((a, b) => a._margin - b._margin)
      .slice(0, 5);
  }, [jobs]);

  const criticalSignals = signals.filter(s => s.severity === 'critical' && !s.acknowledgedAt);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Revenue" value={fmt$(stats.totalContract)} sub={`${stats.recognized.length} recognized jobs`} icon={DollarSign} color="text-blue-600" />
        <StatCard label="Net Profit" value={fmt$(stats.netProfit)} icon={DollarSign} color={stats.netProfit >= 0 ? 'text-green-600' : 'text-red-500'} />
        <StatCard label="Avg Net Margin" value={fmtPct(stats.margin)} icon={TrendingDown} color={stats.margin !== null && stats.margin >= 0.25 ? 'text-green-600' : 'text-red-500'} />
        <StatCard label="Margin Breaches" value={stats.breaches.length} sub="Jobs below 25% floor" icon={AlertTriangle} color={stats.breaches.length > 0 ? 'text-amber-600' : 'text-green-600'} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Rework Flags" value={stats.reworks.length} icon={AlertTriangle} color={stats.reworks.length > 0 ? 'text-orange-500' : 'text-slate-400'} />
        <StatCard label="Change Order Risk" value={stats.changeOrders.length} sub="≥2 change orders" icon={AlertTriangle} color={stats.changeOrders.length > 0 ? 'text-amber-500' : 'text-slate-400'} />
        <StatCard label="Critical Signals" value={criticalSignals.length} sub="Unacknowledged" icon={AlertTriangle} color={criticalSignals.length > 0 ? 'text-red-500' : 'text-green-600'} />
      </div>

      {topLeaks.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-red-400" />
            <span className="font-semibold text-slate-800 text-sm">Top 5 Margin Leaks</span>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase text-slate-500 border-b border-slate-100">
                <th className="text-left px-4 py-2">Job</th>
                <th className="text-right px-4 py-2">Revenue</th>
                <th className="text-right px-4 py-2">Cost</th>
                <th className="text-right px-4 py-2">Net Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {topLeaks.map(j => (
                <tr key={j.id} className="hover:bg-slate-50">
                  <td className="px-4 py-2">
                    <div className="font-medium text-slate-700">{j.customerName || j.jobNumber}</div>
                    <div className="text-xs text-slate-400">{j.jobNumber} · {j.fenceCategory || '—'}</div>
                  </td>
                  <td className="px-4 py-2 text-right text-slate-700">{fmt$(j.contractValueCents)}</td>
                  <td className="px-4 py-2 text-right text-slate-500">{fmt$(j.directCostCents)}</td>
                  <td className={`px-4 py-2 text-right font-semibold ${j._margin < 0 ? 'text-red-500' : j._margin < 0.25 ? 'text-amber-600' : 'text-green-600'}`}>
                    {fmtPct(j._margin)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}