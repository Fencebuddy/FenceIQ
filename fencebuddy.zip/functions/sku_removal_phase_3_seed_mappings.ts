import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * SKU REMOVAL — PHASE 3: SEED COMPANYSKUMAP
 * 
 * Idempotent seeding of CompanySkuMap for all active MaterialCatalog items
 * Creates mappings: canonical_key → materialCatalogId
 * 
 * Ensures CompanySkuMap is fully populated before pricing cutover
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin required' }, { status: 403 });
    }

    const result = await seedCompanySkuMapForAllCatalog(base44, user);
    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function seedCompanySkuMapForAllCatalog(base44, user) {
  const companyId = await getCompanyIdFromContext(base44);

  if (!companyId) {
    return { error: 'Company ID not found' };
  }

  console.log('[SkuMapSeeding] Starting for company:', companyId);

  // STEP 1: Fetch all active catalog items
  const catalogItems = await base44.entities.MaterialCatalog.filter({
    active: true
  });

  console.log(`[SkuMapSeeding] Found ${catalogItems.length} active catalog items`);

  // STEP 2: Fetch existing mappings
  const existingMappings = await base44.entities.CompanySkuMap.filter({
    companyId
  });

  const existingUcks = new Set(existingMappings.map(m => m.uck));

  console.log(`[SkuMapSeeding] Found ${existingMappings.length} existing mappings`);

  // STEP 3: Identify items to create
  const toCreate = [];
  const skipped = [];
  const categories = ['post', 'panel', 'rail', 'fabric', 'hardware', 'gate'];

  for (const item of catalogItems) {
    // Only seed priority categories for fast coverage
    if (!categories.includes(item.category)) {
      skipped.push({
        catalog_id: item.id,
        canonical_key: item.canonical_key,
        category: item.category,
        reason: 'NON_PRIORITY_CATEGORY'
      });
      continue;
    }

    // Use existing canonical_key as UCK
    const uck = item.canonical_key;

    if (!uck) {
      skipped.push({
        catalog_id: item.id,
        crm_name: item.crm_name,
        reason: 'NO_CANONICAL_KEY'
      });
      continue;
    }

    if (existingUcks.has(uck)) {
      skipped.push({
        catalog_id: item.id,
        uck,
        reason: 'ALREADY_MAPPED'
      });
      continue;
    }

    toCreate.push({
      companyId,
      uck,
      materialCatalogId: item.id,
      materialType: item.material_type || 'general',
      displayName: item.crm_name,
      status: 'mapped',
      locked: false,
      lastSeenAt: new Date().toISOString()
    });
  }

  console.log(`[SkuMapSeeding] Will create ${toCreate.length} new mappings, skipping ${skipped.length}`);

  // STEP 4: Bulk create mappings
  let createdCount = 0;
  let errorCount = 0;

  if (toCreate.length > 0) {
    try {
      // Create in batches to avoid timeouts
      const batchSize = 100;
      for (let i = 0; i < toCreate.length; i += batchSize) {
        const batch = toCreate.slice(i, i + batchSize);
        await base44.entities.CompanySkuMap.bulkCreate(batch);
        createdCount += batch.length;
        console.log(`[SkuMapSeeding] Created ${createdCount}/${toCreate.length} mappings`);
      }
    } catch (error) {
      errorCount = toCreate.length - createdCount;
      console.error('[SkuMapSeeding] Bulk create error:', error.message);
    }
  }

  // STEP 5: Verify coverage
  const updatedMappings = await base44.entities.CompanySkuMap.filter({
    companyId
  });

  const mappedUcks = new Set(updatedMappings.map(m => m.uck));
  const priorityCatalogItems = catalogItems.filter(item => categories.includes(item.category));
  const priorityWithUck = priorityCatalogItems.filter(item => item.canonical_key);
  const coverage = priorityWithUck.length > 0 
    ? (updatedMappings.length / priorityWithUck.length) * 100 
    : 0;

  console.log(`[SkuMapSeeding] Coverage: ${coverage.toFixed(1)}% (${updatedMappings.length}/${priorityWithUck.length})`);

  return {
    status: 'MAPPING_SEED_COMPLETE',
    timestamp: new Date().toISOString(),
    companyId,
    summary: {
      catalog_items_total: catalogItems.length,
      priority_categories: categories.length,
      priority_items: priorityCatalogItems.length,
      priority_with_canonical_key: priorityWithUck.length,
      mappings_created: createdCount,
      mappings_existing: existingMappings.length,
      mappings_total: updatedMappings.length,
      skipped: skipped.length,
      errors: errorCount,
      coverage_percent: coverage.toFixed(1)
    },
    coverage_by_category: generateCoverageByCategory(catalogItems, updatedMappings),
    skipped_items: skipped.slice(0, 10), // Show first 10
    next_steps: [
      'Run Gate Mapping Coverage Test',
      'Verify 100% coverage for critical categories',
      'Test pricing with CompanySkuMap resolver',
      'Deploy shared resolver to production'
    ]
  };
}

function generateCoverageByCategory(catalogItems, mappings) {
  const categories = ['post', 'panel', 'rail', 'fabric', 'hardware', 'gate'];
  const result = {};

  for (const category of categories) {
    const itemsInCategory = catalogItems.filter(item => item.category === category);
    const itemsWithKey = itemsInCategory.filter(item => item.canonical_key);
    const mappedInCategory = mappings.filter(m => {
      const catalogItem = catalogItems.find(ci => ci.id === m.materialCatalogId);
      return catalogItem?.category === category;
    });

    result[category] = {
      total_items: itemsInCategory.length,
      items_with_canonical_key: itemsWithKey.length,
      mapped_items: mappedInCategory.length,
      coverage_percent: itemsWithKey.length > 0 
        ? ((mappedInCategory.length / itemsWithKey.length) * 100).toFixed(1)
        : '0'
    };
  }

  return result;
}

async function getCompanyIdFromContext(base44) {
  // Try to get from first active company
  const companies = await base44.entities.CompanySettings.filter({ isPrimary: true });
  if (companies.length > 0) {
    return companies[0].id;
  }

  // Fallback to first company
  const allCompanies = await base44.entities.CompanySettings.filter({});
  if (allCompanies.length > 0) {
    return allCompanies[0].id;
  }

  return null;
}