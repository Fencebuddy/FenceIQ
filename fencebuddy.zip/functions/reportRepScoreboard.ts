import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }
        
        // Get company settings
        const settings = await base44.entities.CompanySettings.filter({});
        const company = settings[0];
        
        if (!company) {
            return Response.json({ error: 'Company settings not found' }, { status: 404 });
        }
        
        // Check CRM and reporting enabled
        if (!company.crmEnabled || !company.reportingEnabled) {
            return Response.json({ error: 'Reporting not enabled' }, { status: 403 });
        }
        
        const companyId = company.id;
        
        // Parse query params
        const url = new URL(req.url);
        const start = url.searchParams.get('start');
        const end = url.searchParams.get('end');
        const fenceCategory = url.searchParams.get('fenceCategory') || undefined;
        const source = url.searchParams.get('source') || undefined;
        
        if (!start || !end) {
            return Response.json({ error: 'Missing required params: start, end' }, { status: 400 });
        }
        
        // Log report run
        const logEntry = await base44.asServiceRole.entities.ReportRunLog.create({
            companyId,
            reportType: 'dashboard_query',
            status: 'started',
            startedAt: new Date().toISOString(),
            rangeStart: start,
            rangeEnd: end,
            triggeredBy: 'api',
            triggeredByUserId: user.id
        });
        
        try {
            // Get signed records
            const signedRecords = await base44.asServiceRole.entities.SignatureRecord.filter({ companyId });
            const filteredSigs = signedRecords.filter(sig => {
                const signedAt = new Date(sig.signedAt);
                return signedAt >= new Date(start) && signedAt <= new Date(end);
            });
            
            // Get proposals
            const allProposals = await base44.asServiceRole.entities.ProposalSnapshot.filter({ companyId });
            const filteredProps = allProposals.filter(prop => {
                if (!prop.sentAt) return false;
                const sentAt = new Date(prop.sentAt);
                return sentAt >= new Date(start) && sentAt <= new Date(end);
            });
            
            // Build rep map
            const repMap = new Map();
            
            // Process signed deals
            for (const sig of filteredSigs) {
                const pricingSnapshots = sig.pricingSnapshotId 
                    ? await base44.asServiceRole.entities.PricingSnapshot.filter({ id: sig.pricingSnapshotId })
                    : [];
                const pricingSnapshot = pricingSnapshots[0];
                if (!pricingSnapshot) continue;
                
                const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: sig.jobId });
                const crmJob = crmJobs[0];
                if (!crmJob) continue;
                
                if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                if (source && crmJob.source !== source) continue;
                
                const repId = crmJob.assignedRepUserId || 'unassigned';
                if (!repMap.has(repId)) {
                    repMap.set(repId, {
                        wonRevenue: 0,
                        signedCount: 0,
                        netProfitAmount: 0,
                        proposalsSentCount: 0,
                        proposalsSignedCount: 0
                    });
                }
                
                const rep = repMap.get(repId);
                rep.wonRevenue += pricingSnapshot.totalPrice || 0;
                rep.signedCount += 1;
                rep.netProfitAmount += pricingSnapshot.netProfitAmount || 0;
            }
            
            // Process proposals
            for (const prop of filteredProps) {
                const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: prop.jobId });
                const crmJob = crmJobs[0];
                if (!crmJob) continue;
                
                if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                if (source && crmJob.source !== source) continue;
                
                const repId = crmJob.assignedRepUserId || 'unassigned';
                if (!repMap.has(repId)) {
                    repMap.set(repId, {
                        wonRevenue: 0,
                        signedCount: 0,
                        netProfitAmount: 0,
                        proposalsSentCount: 0,
                        proposalsSignedCount: 0
                    });
                }
                
                const rep = repMap.get(repId);
                const validStatuses = ['sent', 'viewed', 'signed'];
                if (validStatuses.includes(prop.status)) {
                    rep.proposalsSentCount += 1;
                }
                if (prop.status === 'signed') {
                    rep.proposalsSignedCount += 1;
                }
            }
            
            // Load user names
            const users = await base44.asServiceRole.entities.User.filter({});
            const userMap = new Map(users.map(u => [u.id, u.full_name || u.email]));
            
            // Build scoreboard
            const rows = Array.from(repMap.entries()).map(([repId, data]) => ({
                repUserId: repId,
                repName: repId === 'unassigned' ? 'Unassigned' : userMap.get(repId) || 'Unknown',
                wonRevenue: data.wonRevenue,
                signedCount: data.signedCount,
                avgTicket: data.signedCount > 0 ? data.wonRevenue / data.signedCount : 0,
                netMarginPercent: data.wonRevenue > 0 ? (data.netProfitAmount / data.wonRevenue) * 100 : 0,
                proposalsSentCount: data.proposalsSentCount,
                closeRatePercent: data.proposalsSentCount > 0 
                    ? (data.proposalsSignedCount / data.proposalsSentCount) * 100 
                    : 0
            }));
            
            // Sort by net margin desc, close rate desc, avg ticket desc
            rows.sort((a, b) => {
                if (Math.abs(a.netMarginPercent - b.netMarginPercent) > 0.01) {
                    return b.netMarginPercent - a.netMarginPercent;
                }
                if (Math.abs(a.closeRatePercent - b.closeRatePercent) > 0.01) {
                    return b.closeRatePercent - a.closeRatePercent;
                }
                return b.avgTicket - a.avgTicket;
            });
            
            // Mark log as success
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'success',
                finishedAt: new Date().toISOString()
            });
            
            return Response.json({ rows });
        } catch (error) {
            // Mark log as failed
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'failed',
                finishedAt: new Date().toISOString(),
                errorMessage: error.message,
                errorStack: error.stack
            });
            
            throw error;
        }
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});