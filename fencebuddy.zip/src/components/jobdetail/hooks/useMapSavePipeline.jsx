import { base44 } from '@/api/base44Client';
import { buildTakeoff } from '@/components/materials/canonicalTakeoffEngine';
import { saveCurrentSnapshot } from '@/components/materials/MaterialSwitchHandler';
import { getOrCreateTakeoffSnapshot } from '@/components/pricing/snapshotService';

/**
 * Collects all canvas objects from window globals.
 * Matches the pattern used consistently throughout JobDetail.
 */
export function collectCanvasItems() {
  return {
    gates: window.gates || [],
    doubleGates: window.doubleGates || [],
    houses: window.houses || [],
    pools: window.pools || [],
    garages: window.garages || [],
    dogs: window.dogs || [],
    driveways: window.driveways || [],
    decks: window.decks || [],
    bushes: window.bushes || [],
    porches: window.porches || [],
    grasses: window.grasses || [],
    endPosts: window.endPosts || [],
    beds: window.beds || [],
  };
}

/**
 * Executes the full map save + snapshot pipeline.
 * Called by handleManualSave in JobDetail.
 */
export async function executeMapSave({
  jobId,
  job,
  fenceLines,
  trees,
  rotation,
  annotations,
  surfaceMountedPosts,
  runs,
  gates,
  jobPosts,
  rendererConfig,
  takeoff,
  setMapSaveStatus,
  setTakeoff,
  updateJobMutation,
}) {
  if (!job) return;
  setMapSaveStatus('saving');

  const canvasItems = collectCanvasItems();
  const currentSnapshot = saveCurrentSnapshot(job, fenceLines, trees, annotations, canvasItems, takeoff, rendererConfig);
  const updatedMaterialStates = { ...(job.materialStates || {}), [job.materialType]: currentSnapshot };
  const linesWithAssignments = fenceLines.map(line => ({
    ...line,
    lineId: line.lineId || crypto.randomUUID(),
    assignedRunId: line.assignedRunId || null,
  }));

  updateJobMutation.mutate(
    {
      id: jobId,
      data: {
        mapData: {
          fenceLines: linesWithAssignments,
          trees,
          rotation,
          surfaceMountedPosts,
          ...canvasItems,
        },
        mapAnnotations: annotations,
        materialStates: updatedMaterialStates,
      },
    },
    {
      onSuccess: () => {
        setMapSaveStatus('saved');
        // Fire-and-forget snapshot creation
        (async () => {
          try {
            const takeoffResult = buildTakeoff(job, linesWithAssignments, runs, gates || [], jobPosts);
            if (takeoffResult?.lineItems?.length > 0) {
              setTakeoff(jobId, takeoffResult.lineItems, {
                materialType: job.materialType,
                total_lf: linesWithAssignments.reduce((sum, line) => sum + (line.manualLengthFt || 0), 0),
                postCounts: takeoffResult.postCounts,
                source: 'MAP_DRIVEN',
              });
              const snapshot = await getOrCreateTakeoffSnapshot({
                jobId, job, fenceLines: linesWithAssignments, runs, gates, takeoffResult,
              });
              await base44.entities.Job.update(jobId, {
                active_takeoff_snapshot_id: snapshot.id,
                map_state_hash: snapshot.map_state_hash,
              });
            }
          } catch (err) {
            console.warn('[useMapSavePipeline] Failed to create snapshots on save:', err);
          }
        })();
      },
      onError: () => {
        setMapSaveStatus('unsaved');
        alert('Failed to save map. Please try again.');
      },
    }
  );
}

/**
 * Saves map data inline (used after run assignment, without the full snapshot pipeline).
 * Also accepts annotations for auto-save scenarios.
 * Accepts explicit canvasItems to avoid reading from window globals after unmount.
 * Falls back to window globals if canvasItems not provided (e.g. inline calls during active session).
 */
export async function saveMapDataInline({ jobId, fenceLines, trees, rotation, annotations, canvasItems }) {
  const items = canvasItems || collectCanvasItems();
  const update = {
    mapData: { fenceLines, trees, rotation, ...items },
  };
  if (annotations !== undefined) {
    update.mapAnnotations = annotations;
  }
  await base44.entities.Job.update(jobId, update);
}