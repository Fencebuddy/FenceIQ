import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user || user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const { companyId } = await req.json();
        if (!companyId) {
            return Response.json({ error: 'Missing companyId' }, { status: 400 });
        }

        // Load all catalog items to find test items
        const allCatalog = await base44.asServiceRole.entities.MaterialCatalog.filter({ active: true });
        
        // Find a simple item with cost > 0
        const post = allCatalog.find(i => i.crm_name?.toLowerCase().includes('post') && i.cost > 0);
        const panel = allCatalog.find(i => i.crm_name?.toLowerCase().includes('panel') && i.cost > 0);
        const hardware = allCatalog.find(i => i.crm_name?.toLowerCase().includes('hardware') && i.cost > 0);
        
        if (!post || !panel) {
            return Response.json({ 
                error: 'Not enough catalog items with cost > 0. Need at least posts and panels.',
                available: { post: !!post, panel: !!panel, hardware: !!hardware }
            }, { status: 400 });
        }

        // Create a test vinyl 6ft white set
        const set = await base44.asServiceRole.entities.MaterialSelectionSet.create({
            companyId,
            materialType: 'vinyl',
            fenceHeight: '6ft',
            colorKey: 'white',
            colorLabel: 'White',
            coating: null,
            selectionKey: 'vinyl|6ft|white',
            name: 'Vinyl 6ft White',
            isActive: true
        });

        // Create lines
        const lines = [];
        
        // Post
        lines.push(await base44.asServiceRole.entities.MaterialSelectionLine.create({
            companyId,
            selectionSetId: set.id,
            materialCatalogId: post.id,
            qtyRuleType: 'POSTS_TOTAL',
            qtyMultiplier: 1,
            sortOrder: 10,
            status: 'OK'
        }));

        // Panel
        lines.push(await base44.asServiceRole.entities.MaterialSelectionLine.create({
            companyId,
            selectionSetId: set.id,
            materialCatalogId: panel.id,
            qtyRuleType: 'PANELS_BY_LF',
            qtyRuleValue: 6,
            qtyMultiplier: 1,
            sortOrder: 20,
            status: 'OK'
        }));

        // Optional hardware
        if (hardware) {
            lines.push(await base44.asServiceRole.entities.MaterialSelectionLine.create({
                companyId,
                selectionSetId: set.id,
                materialCatalogId: hardware.id,
                qtyRuleType: 'POSTS_TOTAL',
                qtyMultiplier: 1,
                sortOrder: 30,
                status: 'OK'
            }));
        }

        return Response.json({
            setId: set.id,
            selectionKey: set.selectionKey,
            linesCreated: lines.length,
            usedCatalogItems: {
                post: post.crm_name,
                panel: panel.crm_name,
                hardware: hardware?.crm_name || null
            }
        });

    } catch (error) {
        console.error('Error in seedTestMaterialSelectionSet:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});