import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { tenantId, companyKey, projectedAnnualRevenue, computedOverheadPct, totalAnnualOverhead, manualOverridePct, action } = body;

    // Determine companyId to use
    const companyId = tenantId || companyKey;
    if (!companyId) {
      return Response.json({ error: 'Missing tenantId or companyKey' }, { status: 400 });
    }

    // Try to find existing record
    let existing = null;
    try {
      const results = await base44.entities.OverheadSettings.filter({ companyId });
      existing = results.length > 0 ? results[0] : null;
    } catch (e) {
      console.warn('[upsertOverheadSettings] Filter failed:', e.message);
    }

    // Handle lock action
    if (action === 'lock') {
      const updateData = {
        isLocked: true,
        lockedAt: new Date().toISOString(),
        lockedBy: user.email
      };
      if (existing) {
        const record = await base44.entities.OverheadSettings.update(existing.id, updateData);
        return Response.json({ success: true, record, message: 'Overhead locked successfully' });
      } else {
        return Response.json({ error: 'Cannot lock non-existent overhead settings' }, { status: 400 });
      }
    }

    if (action === 'unlock') {
      if (existing) {
        const record = await base44.entities.OverheadSettings.update(existing.id, { isLocked: false });
        return Response.json({ success: true, record, message: 'Overhead unlocked' });
      } else {
        return Response.json({ error: 'Cannot unlock non-existent overhead settings' }, { status: 400 });
      }
    }

    // Build update data with canonical fields
    const updateData = {};
    if (projectedAnnualRevenue !== undefined) updateData.projectedAnnualRevenue = projectedAnnualRevenue;
    if (computedOverheadPct !== undefined) updateData.computedOverheadPct = computedOverheadPct;
    if (totalAnnualOverhead !== undefined) updateData.totalAnnualOverhead = totalAnnualOverhead;
    if (manualOverridePct !== undefined) updateData.manualOverridePct = manualOverridePct;

    // Convert to canonical cents-based fields
    const annualDollars = totalAnnualOverhead !== undefined ? totalAnnualOverhead : (existing?.totalAnnualOverhead || 0);
    const annualCents = Math.round(annualDollars * 100);
    updateData.annualOverheadCents = annualCents;
    updateData.monthlyOverheadCents = Math.round(annualCents / 12);

    let record;
    if (existing) {
      // Update existing
      record = await base44.entities.OverheadSettings.update(existing.id, updateData);
    } else {
      // Create new with canonical tenantId
      const createData = {
        companyId: tenantId || companyKey,
        projectedAnnualRevenue: projectedAnnualRevenue || 1000000,
        computedOverheadPct: computedOverheadPct || 0,
        totalAnnualOverhead: totalAnnualOverhead || 0,
        annualOverheadCents: updateData.annualOverheadCents,
        monthlyOverheadCents: updateData.monthlyOverheadCents,
        manualOverridePct: manualOverridePct || null
      };
      record = await base44.entities.OverheadSettings.create(createData);
    }

    return Response.json({ success: true, record });
  } catch (error) {
    console.error('[upsertOverheadSettings] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});