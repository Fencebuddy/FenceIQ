import { KeySchemas } from '../canonicalKeyEngine/keySchemas';
import { normColorForKey } from '../canonicalKeyEngine/colorValidator';

function ensureCanonicalKeyString(key, fallback) {
  const k = (typeof key === "string" ? key : "").trim();
  if (k) return k;
  const fb = (typeof fallback === "string" ? fallback : "").trim();
  if (fb) return fb;
  return "INVALID_CANONICAL_KEY";
}

function toCatalogKey(key) {
  if (typeof key !== "string") return null;
  const k = key.trim();
  if (!k) return null;
  if (k.includes("_") && !k.includes(".")) return k;
  return k
    .toLowerCase()
    .replace(/[.\s-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

/**
 * Generate VINYL material line items from post counts
 * EMITS ROLES, NOT UCKSF - Role→UCK mapping applied downstream
 */
export function generateVinylMaterials(job, runs, fenceLines, gates, postCounts, graph) {
  const materials = [];
  const height = job.fenceHeight;
  
  // CRITICAL: For Two Tone Post & Rail, use railsAndPostColor (not "two_tone")
  const effectiveJobColor = job.fenceColor === 'two_tone' && runs.length > 0 && runs[0].railsAndPostColor
    ? runs[0].railsAndPostColor
    : job.fenceColor;
  const color = normColorForKey(effectiveJobColor);
  
  // Get fence system from job (CRITICAL: must match FenceSystemConfig)
  const fenceSystem = job.fenceSystem || 'savannah'; // Default to savannah if not set

  // Detect if any run is Post & Rail
  const isPostAndRail = runs.some(r => r.style === 'RanchRail' || r.style === 'Ranch Style');

  // Run-level materials (fence panels)
  runs.forEach(run => {
    const runLines = fenceLines.filter(l => l.assignedRunId === run.id);
    const runLF = runLines.reduce((sum, l) => sum + (l.manualLengthFt || 0), 0);

    if (runLF <= 0) return;

    const panels = Math.ceil(runLF / 8);
    const heightNum = run.fenceHeight.replace("'", '');
    
    // For Two Tone fences, use railsAndPostColor for panels (not the combined "two_tone" value)
    const effectiveColor = run.fenceColor === 'two_tone' && run.railsAndPostColor
      ? run.railsAndPostColor
      : run.fenceColor || job.fenceColor;
    const panelColor = normColorForKey(effectiveColor);
    
    materials.push({
      canonical_key: ensureCanonicalKeyString(
        toCatalogKey(KeySchemas.vinyl.panelPrivacy({ heightIn: parseInt(heightNum) * 12, style: 'savannah', color: panelColor })),
        `invalid_vinyl_panel_${heightNum}ft`
      ),
      runLabel: run.runLabel,
      lineItemName: `${run.fenceHeight} ${run.style} Vinyl Panels`,
      materialDescription: `${run.fenceHeight} ${run.style} Vinyl Panels`,
      quantityCalculated: panels,
      uom: 'each',
      notes: `${panels} panels for ${runLF.toFixed(1)} LF`,
      source: 'map'
    });
  });
    
    // Overall section - ALL vinyl posts EXCEPT GATE POSTS need galvanized support posts
    // Gate posts use aluminum I-beams instead of galvanized support posts
    const allVinylPosts = postCounts.endPosts + postCounts.cornerPosts + postCounts.linePosts;

    if (allVinylPosts > 0) {
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.reinforcePost()),
          'invalid_vinyl_reinforce_post'
        ),
        runLabel: 'Overall',
        lineItemName: '2.5" Galvanized Support Post',
        materialDescription: '2.5" Galvanized Support Post',
        quantityCalculated: allVinylPosts,
        uom: 'each',
        notes: `${postCounts.endPosts} end + ${postCounts.cornerPosts} corner + ${postCounts.linePosts} line = ${allVinylPosts} support posts (gate posts excluded)`,
        source: 'map'
      });

      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.noDigDonut()),
          'invalid_vinyl_nodig_donut'
        ),
        runLabel: 'Overall',
        lineItemName: 'No-Dig Donuts',
        materialDescription: 'No-Dig Donuts',
        quantityCalculated: allVinylPosts * 2,
        uom: 'each',
        notes: `${allVinylPosts} posts × 2 = ${allVinylPosts * 2} donuts`,
        source: 'map'
      });
    }

    // Vinyl posts by type
    const totalVinylPosts = postCounts.endPosts + postCounts.cornerPosts + postCounts.gatePosts + postCounts.linePosts;
    
    const heightIn = parseInt(height.replace("'", '')) * 12;
    
    if (postCounts.endPosts > 0) {
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.post({ color, size: '5x5' })),
          'invalid_vinyl_post_end'
        ),
        runLabel: 'Overall',
        lineItemName: '5x5 Vinyl End Post',
        materialDescription: '5x5 Vinyl End Post',
        quantityCalculated: postCounts.endPosts,
        uom: 'each',
        notes: `${postCounts.endPosts} end posts`,
        source: 'map'
      });
    }

    if (postCounts.cornerPosts > 0) {
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.post({ color, size: '5x5' })),
          'invalid_vinyl_post_corner'
        ),
        runLabel: 'Overall',
        lineItemName: '5x5 Vinyl Corner Post',
        materialDescription: '5x5 Vinyl Corner Post',
        quantityCalculated: postCounts.cornerPosts,
        uom: 'each',
        notes: `${postCounts.cornerPosts} corner posts`,
        source: 'map'
      });
    }

    if (postCounts.linePosts > 0) {
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.post({ color, size: '5x5' })),
          'invalid_vinyl_post_line'
        ),
        runLabel: 'Overall',
        lineItemName: '5x5 Vinyl Line Post',
        materialDescription: '5x5 Vinyl Line Post',
        quantityCalculated: postCounts.linePosts,
        uom: 'each',
        notes: `${postCounts.linePosts} line posts`,
        source: 'map'
      });
    }

    // Post caps - ALL vinyl posts need caps
    // CRITICAL: Use run color for Post & Rail (not job color)
    if (totalVinylPosts > 0) {
      // Detect if this is Post & Rail by checking run styles
      const isPostAndRail = runs.some(r => r.style === 'RanchRail' || r.style === 'Ranch Style');
      
      // For Post & Rail, use run color (may be black for "Estate Black")
      // For Privacy, use job color
      const capColor = isPostAndRail && runs.length > 0 
        ? normColorForKey(runs[0].fenceColor || job.fenceColor)
        : color;
      
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.capExternal({ color: capColor })),
          'invalid_vinyl_cap'
        ),
        runLabel: 'Overall',
        lineItemName: 'Vinyl Post Caps',
        materialDescription: 'Vinyl Post Caps',
        quantityCalculated: totalVinylPosts,
        uom: 'each',
        notes: `1 per post (${totalVinylPosts} posts)`,
        source: 'map'
      });
    }
    
    // Gate posts and hardware - gates are ALREADY deduplicated by buildVinylTakeoff
    if (gates.length > 0) {
      console.log('[generateVinylMaterials] Gate materials - gates already deduplicated:', {
        gatesCount: gates.length,
        gateDetails: gates.map(g => ({ id: g.id, type: g.gateType, width_ft: g.gateWidth_ft }))
      });

      const totalGatePosts = gates.length * 2;

      // CRITICAL DEBUG: Log gate post calculation
      console.log('[generateVinylMaterials] Gate post calculation:', {
        totalGates: gates.length,
        totalGatePostsCalculated: totalGatePosts,
        postCountsGatePosts: postCounts.gatePosts
      });

      const gateHeightIn = parseInt(height.replace("'", '')) * 12;
      
      materials.push({
        canonical_key: ensureCanonicalKeyString(
          toCatalogKey(KeySchemas.vinyl.post({ color, size: '5x5' })),
          'invalid_vinyl_post_gate'
        ),
        runLabel: 'Gates',
        lineItemName: '5x5 Vinyl Gate Post',
        materialDescription: '5x5 Vinyl Gate Post',
        quantityCalculated: totalGatePosts,
        uom: 'each',
        notes: `${gates.length} gates × 2 = ${totalGatePosts} gate posts`,
        source: 'map'
      });
        
        const singleGates = gates.filter(g => g.gateType === 'Single');
        const doubleGates = gates.filter(g => g.gateType === 'Double');

        console.log('[generateVinylMaterials] Gate breakdown:', {
          totalGates: gates.length,
          singleGates: singleGates.length,
          doubleGates: doubleGates.length,
          singleDetails: singleGates.map(g => ({ id: g.id, width_ft: g.gateWidth_ft })),
          doubleDetails: doubleGates.map(g => ({ id: g.id, width_ft: g.gateWidth_ft }))
        });

        // Gates by width and type
        const gates4ft = singleGates.filter(g => g.gateWidth_ft === 4).length;
        const gates5ft = singleGates.filter(g => g.gateWidth_ft === 5).length;
        const gates6ft = singleGates.filter(g => g.gateWidth_ft === 6).length;
        const gates8ft = doubleGates.filter(g => g.gateWidth_ft === 8).length;
        const gates10ft = doubleGates.filter(g => g.gateWidth_ft === 10).length;
        const gates12ft = doubleGates.filter(g => g.gateWidth_ft === 12).length;

        // Vinyl gates - catalog format: vinyl_gate_single_62_khaki_6ft
        if (gates4ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'single', widthIn: 44.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_4ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 4' Vinyl Gate`,
              materialDescription: `${height} x 4' Vinyl Gate`,
              quantityCalculated: gates4ft,
              uom: 'each',
              notes: `${gates4ft} single gates`,
              source: 'map'
            });
          }
          if (gates5ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'single', widthIn: 62.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_5ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 5' Vinyl Gate`,
              materialDescription: `${height} x 5' Vinyl Gate`,
              quantityCalculated: gates5ft,
              uom: 'each',
              notes: `${gates5ft} single gates`,
              source: 'map'
            });
          }
          if (gates6ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'single', widthIn: 68.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_6ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 6' Vinyl Gate`,
              materialDescription: `${height} x 6' Vinyl Gate`,
              quantityCalculated: gates6ft,
              uom: 'each',
              notes: `${gates6ft} single gates`,
              source: 'map'
            });
          }
          if (gates8ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'double', widthIn: 38.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_8ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 8' Vinyl Gate (Double)`,
              materialDescription: `${height} x 8' Vinyl Gate (Double)`,
              quantityCalculated: gates8ft,
              uom: 'each',
              notes: `${gates8ft} double gates`,
              source: 'map'
            });
          }
          if (gates10ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'double', widthIn: 44.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_10ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 10' Vinyl Gate (Double)`,
              materialDescription: `${height} x 10' Vinyl Gate (Double)`,
              quantityCalculated: gates10ft,
              uom: 'each',
              notes: `${gates10ft} double gates`,
              source: 'map'
            });
          }
          if (gates12ft > 0) {
            materials.push({
              canonical_key: ensureCanonicalKeyString(
                toCatalogKey(KeySchemas.vinyl.gate({ swing: 'double', widthIn: 62.5, heightIn: gateHeightIn, color })),
                'invalid_vinyl_gate_12ft'
              ),
              runLabel: 'Gates',
              lineItemName: `${height} x 12' Vinyl Gate (Double)`,
              materialDescription: `${height} x 12' Vinyl Gate (Double)`,
              quantityCalculated: gates12ft,
              uom: 'each',
              notes: `${gates12ft} double gates`,
              source: 'map'
            });
          }

        // Gate hardware
        const totalHingeSets = singleGates.length + (doubleGates.length * 2);
        materials.push({
          canonical_key: ensureCanonicalKeyString(
            toCatalogKey(KeySchemas.vinyl.hingeSet()),
            'invalid_vinyl_hinge_set'
          ),
          runLabel: 'Gates',
          lineItemName: 'Vinyl Gate Hinges',
          materialDescription: 'Vinyl Gate Hinges',
          quantityCalculated: totalHingeSets,
          uom: 'set',
          notes: `${singleGates.length} single + ${doubleGates.length} double × 2 = ${totalHingeSets} sets`,
          source: 'map'
        });

        // Gate latches
        const totalSingleGateLatches = gates4ft + gates5ft + gates6ft;
        if (totalSingleGateLatches > 0) {
          materials.push({
            canonical_key: ensureCanonicalKeyString(
              toCatalogKey(KeySchemas.vinyl.latchPro({ size: '5in' })),
              'invalid_vinyl_latch_5in'
            ),
            runLabel: 'Gates',
            lineItemName: '5" Locklatch Pro',
            materialDescription: '5" Locklatch Pro',
            quantityCalculated: totalSingleGateLatches,
            uom: 'each',
            notes: `${totalSingleGateLatches} single gates`,
            source: 'map'
          });
        }
        if (doubleGates.length > 0) {
          materials.push({
            canonical_key: ensureCanonicalKeyString(
              toCatalogKey(KeySchemas.vinyl.latchPro({ size: '4in' })),
              'invalid_vinyl_latch_4in'
            ),
            runLabel: 'Gates',
            lineItemName: '4" Locklatch Pro',
            materialDescription: '4" Locklatch Pro',
            quantityCalculated: doubleGates.length,
            uom: 'each',
            notes: `${doubleGates.length} double gates`,
            source: 'map'
          });
        }

        // Cane bolts for double gates
        if (doubleGates.length > 0) {
          materials.push({
            canonical_key: ensureCanonicalKeyString(
              toCatalogKey(KeySchemas.vinyl.caneBolt()),
              'invalid_vinyl_cane_bolt'
            ),
            runLabel: 'Gates',
            lineItemName: 'Cane Bolts',
            materialDescription: 'Cane Bolts',
            quantityCalculated: doubleGates.length * 2,
            uom: 'each',
            notes: `${doubleGates.length} double gates × 2 = ${doubleGates.length * 2} bolts`,
            source: 'map'
          });
        }
        }
    
    return materials;
}