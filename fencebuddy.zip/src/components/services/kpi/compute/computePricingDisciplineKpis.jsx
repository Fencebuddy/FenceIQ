/**
 * PRICING DISCIPLINE KPIs
 * Measures TRUE margin leakage vs. override usage (which is just a mechanism)
 * 
 * CRITICAL: Override != Risk
 * - Override is a mechanism (manual price adjustment)
 * - Risk is selling below floor (margin leakage)
 * - Many overrides are POSITIVE (selling at retail/above model)
 */

/**
 * Categorize a sold job's pricing discipline.
 * Accepts scalar fields directly from truth rows — no nested snapshot object required.
 *
 * @param {number} modelSellPrice  - ProposalPricingSnapshot.model_sell_price (dollars)
 * @param {number} agreedSubtotal  - ProposalPricingSnapshot.agreed_subtotal (dollars) — final sale price
 */
function categorizePricingDiscipline(modelSellPrice, agreedSubtotal) {
  const model = modelSellPrice || 0;
  const final = agreedSubtotal || 0;

  // Missing critical data
  if (!model || model === 0 || !final || final === 0) {
    return 'UNKNOWN_PRICING';
  }

  // Calculate floor (model - max allowed discount = 15%)
  const maxDiscountRate = 0.15;
  const floor = model * (1 - maxDiscountRate);

  // TRUE RISK: Below floor (margin leakage)
  if (final < floor * 0.99) { // 1% rounding tolerance
    return 'BELOW_FLOOR';
  }

  // COACHABLE: Discounted but above floor
  if (final < model * 0.98) { // 2% tolerance
    return 'DISCOUNT_ABOVE_FLOOR';
  }

  // ON MODEL: Within 2% of model price
  if (final >= model * 0.98 && final <= model * 1.02) {
    return 'ON_MODEL';
  }

  // UPLIFT: Above model
  if (final > model * 1.02) {
    return 'UPLIFT';
  }

  return 'ON_MODEL';
}

/**
 * Compute pricing discipline KPIs from sold jobs.
 * Reads scalar fields from truth rows: modelSellPrice, presentedSellPrice, agreedSubtotal, overrideApplied.
 * Does NOT require row.proposalPricingSnapshot object.
 */
export function computePricingDisciplineKpis(signedRows) {
  const total = signedRows.length;

  const empty = {
    total_jobs: 0,
    below_floor_count: 0,
    discount_above_floor_count: 0,
    on_model_count: 0,
    uplift_count: 0,
    unknown_pricing_count: 0,
    below_floor_rate: 0,
    discount_above_floor_rate: 0,
    on_model_rate: 0,
    uplift_rate: 0,
    unknown_pricing_rate: 0,
    override_usage_rate: 0,
    positive_override_count: 0,
    negative_override_count: 0,
    positive_override_rate: 0,
    negative_override_rate: 0,
    status: 'STABLE',
    overrideRatePct: 0,
    modelCoveragePct: 0,
    cards: [
      { label: 'Below Floor', value: 0, format: 'number' },
      { label: 'Discounted Above Floor', value: 0, format: 'number' },
      { label: 'On Model', value: 0, format: 'number' },
      { label: 'Uplift', value: 0, format: 'number' },
      { label: 'Positive Overrides', value: 0, format: 'number' },
      { label: 'Negative Overrides', value: 0, format: 'number' }
    ]
  };

  if (total === 0) return empty;

  let below_floor = 0;
  let discount_above_floor = 0;
  let on_model = 0;
  let uplift = 0;
  let unknown_pricing = 0;
  let override_usage = 0;
  let positive_overrides = 0;
  let negative_overrides = 0;

  signedRows.forEach(row => {
    // Use scalar fields already present on truth rows
    const modelSellPrice = row.modelSellPrice || 0;
    const agreedSubtotal = row.agreedSubtotal || 0;
    const overrideApplied = row.overrideApplied || false;

    const category = categorizePricingDiscipline(modelSellPrice, agreedSubtotal);

    // Track override usage
    if (overrideApplied === true) {
      override_usage++;
      if (category === 'UPLIFT') {
        positive_overrides++;
      } else {
        negative_overrides++;
      }
    }

    switch (category) {
      case 'BELOW_FLOOR':       below_floor++; break;
      case 'DISCOUNT_ABOVE_FLOOR': discount_above_floor++; break;
      case 'ON_MODEL':          on_model++; break;
      case 'UPLIFT':            uplift++; break;
      case 'UNKNOWN_PRICING':   unknown_pricing++; break;
    }
  });

  const below_floor_rate         = below_floor / total;
  const discount_above_floor_rate = discount_above_floor / total;
  const on_model_rate            = on_model / total;
  const uplift_rate              = uplift / total;
  const unknown_pricing_rate     = unknown_pricing / total;
  const override_usage_rate      = override_usage / total;
  const positive_override_rate   = positive_overrides / total;
  const negative_override_rate   = negative_overrides / total;

  // Status based on TRUE margin leakage, not override usage
  let status = 'STABLE';
  if (below_floor > 0)                    status = 'RISK';
  else if (discount_above_floor_rate > 0.20) status = 'WATCH';
  else if (uplift_rate >= 0.50)           status = 'STRONG';

  console.log('[PricingDiscipline] Results:', {
    total, below_floor, discount_above_floor, on_model, uplift, unknown_pricing,
    override_usage, positive_overrides, negative_overrides, status
  });

  return {
    total_jobs: total,
    below_floor_count: below_floor,
    discount_above_floor_count: discount_above_floor,
    on_model_count: on_model,
    uplift_count: uplift,
    unknown_pricing_count: unknown_pricing,
    below_floor_rate,
    discount_above_floor_rate,
    on_model_rate,
    uplift_rate,
    unknown_pricing_rate,
    override_usage_rate,
    positive_override_count: positive_overrides,
    negative_override_count: negative_overrides,
    positive_override_rate,
    negative_override_rate,
    status,
    overrideRatePct: override_usage_rate,
    modelCoveragePct: 1 - unknown_pricing_rate,
    cards: [
      { label: 'Below Floor',           value: below_floor,         format: 'number' },
      { label: 'Discounted Above Floor', value: discount_above_floor, format: 'number' },
      { label: 'On Model',              value: on_model,            format: 'number' },
      { label: 'Uplift',                value: uplift,              format: 'number' },
      { label: 'Positive Overrides',    value: positive_overrides,  format: 'number' },
      { label: 'Negative Overrides',    value: negative_overrides,  format: 'number' }
    ]
  };
}