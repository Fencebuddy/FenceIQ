// Force redeploy v2
/**
 * seedCompanyRoleConfigs
 * 
 * Populates FenceRoleConfig for a company by mapping logical roles
 * (emitted by takeoff builders) to approved UCKs from MaterialCatalog.
 * 
 * Roles are semantic identifiers like 'vinyl_post_end_5ft_white'.
 * UCKs are the canonical keys from MaterialCatalog.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const ROLE_MAPPINGS = {
  // ============= VINYL ROLES (WITH FENCE SYSTEM) =============
  // Roles include fence system (savannah) to match takeoff output
  vinyl_post_end_5ft_savannah_white: 'vinyl_post_end_5ft_savannah_white',
  vinyl_post_end_5ft_savannah_black: 'vinyl_post_end_5ft_savannah_black',
  vinyl_post_line_5ft_savannah_white: 'vinyl_post_line_5ft_savannah_white',
  vinyl_post_line_5ft_savannah_black: 'vinyl_post_line_5ft_savannah_black',
  vinyl_post_end_6ft_savannah_white: 'vinyl_post_end_6ft_savannah_white',
  vinyl_post_end_6ft_savannah_black: 'vinyl_post_end_6ft_savannah_black',
  vinyl_post_line_6ft_savannah_white: 'vinyl_post_line_6ft_savannah_white',
  vinyl_post_line_6ft_savannah_black: 'vinyl_post_line_6ft_savannah_black',

  vinyl_panel_privacy_5ft_savannah_white: 'vinyl_panel_privacy_5ft_savannah_white',
  vinyl_panel_privacy_5ft_savannah_black: 'vinyl_panel_privacy_5ft_savannah_black',
  vinyl_panel_privacy_6ft_savannah_white: 'vinyl_panel_privacy_6ft_savannah_white',
  vinyl_panel_privacy_6ft_savannah_black: 'vinyl_panel_privacy_6ft_savannah_black',

  vinyl_donut_6ft_savannah: 'vinyl_hardware_nodig_donut',
  vinyl_donut_5ft_savannah: 'vinyl_hardware_nodig_donut',

  vinyl_gate_single_4ft_savannah_white: 'vinyl_gate_single_38.5in_4ft',
  vinyl_gate_single_5ft_savannah_white: 'vinyl_gate_single_38.5in_6ft',
  vinyl_gate_single_6ft_savannah_white: 'vinyl_gate_single_38.5in_6ft',
  vinyl_gate_single_4ft_savannah_black: 'vinyl_gate_single_38.5in_4ft',
  vinyl_gate_single_5ft_savannah_black: 'vinyl_gate_single_38.5in_6ft',
  vinyl_gate_single_6ft_savannah_black: 'vinyl_gate_single_38.5in_6ft',

  vinyl_gate_double_8ft_savannah_white: 'vinyl_gate_double_38.5in_4ft',
  vinyl_gate_double_10ft_savannah_white: 'vinyl_gate_double_38.5in_4ft',
  vinyl_gate_double_12ft_savannah_white: 'vinyl_gate_double_38.5in_4ft',
  vinyl_gate_double_8ft_savannah_black: 'vinyl_gate_double_38.5in_4ft',
  vinyl_gate_double_10ft_savannah_black: 'vinyl_gate_double_38.5in_4ft',
  vinyl_gate_double_12ft_savannah_black: 'vinyl_gate_double_38.5in_4ft',

  vinyl_gate_hardware_5ft_savannah_white: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_hardware_5ft_savannah_black: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_hardware_6ft_savannah_white: 'vinyl_cap_new_england_6ft_white',
  vinyl_gate_hardware_6ft_savannah_black: 'vinyl_cap_new_england_6ft_white',

  vinyl_gate_latch_single_5ft_savannah_white: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_latch_single_5ft_savannah_black: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_latch_single_6ft_savannah_white: 'vinyl_cap_new_england_6ft_white',
  vinyl_gate_latch_single_6ft_savannah_black: 'vinyl_cap_new_england_6ft_white',

  vinyl_gate_latch_double_5ft_savannah_white: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_latch_double_5ft_savannah_black: 'vinyl_cap_new_england_5ft_white',
  vinyl_gate_latch_double_6ft_savannah_white: 'vinyl_cap_new_england_6ft_white',
  vinyl_gate_latch_double_6ft_savannah_black: 'vinyl_cap_new_england_6ft_white',

  vinyl_cane_bolt_5ft_savannah_white: 'vinyl_cap_new_england_5ft_white',
  vinyl_cane_bolt_5ft_savannah_black: 'vinyl_cap_new_england_5ft_white',
  vinyl_cane_bolt_6ft_savannah_white: 'vinyl_cap_new_england_6ft_white',
  vinyl_cane_bolt_6ft_savannah_black: 'vinyl_cap_new_england_6ft_white',

  // ============= WOOD ROLES =============
  wood_post_steel_4x4_driven: 'wood_post_treated_4x4_8',
  wood_post_treated_4x6x10_gate: 'wood_post_treated_4x4_8',
  concrete_50lb: 'concrete_50lb_bag',
  wood_rail_treated_2x4x8: 'wood_rail_treated_2x4_8',
  wood_picket_6ft: 'wood_board_pine_1x6_6',
  wood_nail_galv_2in: 'wood_nail_galvanized_2in_lb',
  wood_screw_deck_3in: 'wood_screw_deck_3in_lb',
  wood_gate_hinge_set: 'wood_hinge_gate_pair',
  wood_gate_build_kit: 'wood_gate_kit_adjustable',
  wood_gate_locklatch_4in: 'wood_latch_gate_4in',
  wood_gate_cane_bolt: 'wood_bolt_cane',

  // ============= CHAINLINK ROLES =============
  chainlink_post_terminal_galv_6ft: 'chainlink_post_terminal_8ft_galvanized',
  chainlink_post_line_galv_6ft: 'chainlink_post_line_6ft_galvanized',
  chainlink_post_corner_galv_6ft: 'chainlink_post_line_6ft_galvanized',
  chainlink_post_end_galv_6ft: 'chainlink_post_line_6ft_galvanized',

  chainlink_fabric_6ft_galv_50ft_roll: 'chainlink_fabric_6ft_galvanized',
  chainlink_fabric_6ft_black_vinyl_50ft_roll: 'chainlink_fabric_6ft_black',

  chainlink_rail_top_galv_21ft: 'chainlink_rail_top_6ft_galvanized',
  chainlink_rail_bottom_galv_21ft: 'chainlink_rail_top_6ft_galvanized',

  chainlink_gate_single_4ft_galv: 'gate_single_4',
  chainlink_gate_single_5ft_galv: 'gate_single_6',
  chainlink_gate_single_6ft_galv: 'gate_single_6',

  chainlink_gate_double_8ft_galv: 'gate_double_8',
  chainlink_gate_double_10ft_galv: 'gate_double_8',
  chainlink_gate_double_12ft_galv: 'gate_double_8',

  chainlink_gate_hardware_galv: 'chainlink_hardware_kit',
  chainlink_gate_latch_galv: 'chainlink_hardware_kit',
  chainlink_cane_bolt_galv: 'chainlink_cap_loop_6ft_galvanized',

  // ============= ALUMINUM ROLES =============
  aluminum_post_end_6ft: 'aluminum_post_6_black',
  aluminum_post_line_6ft: 'aluminum_post_6_black',
  aluminum_rail_top_6ft: 'aluminum_rail_top_6_black',
  aluminum_rail_bottom_6ft: 'aluminum_rail_top_6_black',
  
  aluminum_gate_single_4ft: 'gate_single_4',
  aluminum_gate_single_5ft: 'gate_single_6',
  aluminum_gate_single_6ft: 'gate_single_6',
  
  aluminum_gate_double_8ft: 'gate_double_8',
  aluminum_gate_double_10ft: 'gate_double_8',
  aluminum_gate_double_12ft: 'gate_double_8',
  
  aluminum_gate_hardware: 'aluminum_hardware_kit',
  aluminum_gate_latch: 'aluminum_hardware_kit',
  aluminum_cane_bolt: 'aluminum_hardware_kit'
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json(
        { error: 'Admin access required' },
        { status: 403 }
      );
    }

    const { companyId } = await req.json();

    if (!companyId) {
      return Response.json(
        { error: 'companyId required' },
        { status: 400 }
      );
    }

    // Fetch material catalog to map UCKs to catalog IDs
    const catalog = await base44.asServiceRole.entities.MaterialCatalog.list();
    const catalogById = {};
    catalog.forEach(item => {
      catalogById[item.canonical_key] = item.id;
    });

    // Build role config records
    const roleConfigs = [];
    const unmappedRoles = [];

    for (const [role, uckKey] of Object.entries(ROLE_MAPPINGS)) {
      const catalogId = catalogById[uckKey];
      
      if (!catalogId) {
        unmappedRoles.push({ role, uck: uckKey, reason: 'UCK not in MaterialCatalog' });
        continue;
      }

      roleConfigs.push({
        companyId,
        role,
        uck: uckKey,
        materialCatalogId: catalogId,
        enabled: true,
        locked: true,
        source: 'auto-seeded',
        notes: `Auto-seeded role→UCK mapping from ${new Date().toISOString()}`
      });
    }

    // Insert role configs
    let insertedCount = 0;
    if (roleConfigs.length > 0) {
      await base44.asServiceRole.entities.FenceRoleConfig.bulkCreate(roleConfigs);
      insertedCount = roleConfigs.length;
    }

    return Response.json({
      status: 'success',
      companyId,
      inserted: insertedCount,
      unmapped: unmappedRoles,
      message: `Seeded ${insertedCount} role→UCK mappings. ${unmappedRoles.length} roles could not be mapped (missing catalog items).`
    });

  } catch (error) {
    console.error('[seedCompanyRoleConfigs] Error:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});