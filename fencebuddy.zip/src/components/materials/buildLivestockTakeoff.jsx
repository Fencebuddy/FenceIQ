/**
 * LIVESTOCK FENCE RESOLVER — FenceIQ Deterministic Takeoff Engine
 * Style: Woven Wire (Field Fence)
 * FenceStyle ID: livestock_fence
 * Supported Heights: 4 ft, 5 ft, 6 ft
 *
 * ARCHITECTURE: Map Geometry → Fence Objects → Material Resolver → TakeoffSnapshot
 *
 * SYSTEM GUARANTEES:
 * - Deterministic outputs only
 * - No silent fallback
 * - No inferred geometry
 * - No auto brace placement
 * - All materials originate from explicit map objects (FenceLine, CornerNode,
 *   TerminalNode, GateNode, BraceAssembly)
 *
 * ⚠️ DO NOT add auto-estimator logic or infer materials not present in the design.
 */

// ---------------------------------------------------------------------------
// CANONICAL KEY MAP (matches MaterialCatalog entries)
// ---------------------------------------------------------------------------
const WIRE_ROLL_KEY = {
    4: 'livestock_wire_roll_4ft_330ft',
    5: 'livestock_wire_roll_5ft_330ft',
    6: 'livestock_wire_roll_6ft_330ft',
};

const TPOST_KEY = {
    4: 'livestock_tpost_6ft',  // 4 ft fence → 6 ft T-post
    5: 'livestock_tpost_7ft',  // 5 ft fence → 7 ft T-post
    6: 'livestock_tpost_8ft',  // 6 ft fence → 8 ft T-post
};

const TPOST_LABEL = {
    4: '6 ft',
    5: '7 ft',
    6: '8 ft',
};

const GATE_KEY = {
    4:  'livestock_tube_gate_4ft',
    5:  'livestock_tube_gate_5ft',
    6:  'livestock_tube_gate_6ft',
    8:  'livestock_tube_gate_8ft',
    10: 'livestock_tube_gate_10ft',
    12: 'livestock_tube_gate_12ft',
    16: 'livestock_gate_16ft', // reserved for future catalog entry
};

const WIRE_ROLL_LF = 330;
const WIRE_WASTE_PCT = 1.05;      // 5% waste
const TPOST_DEFAULT_SPACING_FT = 10;
const STAPLES_PER_WOOD_POST = 10;
const STAPLES_PER_BOX = 200;
const CLIPS_PER_TPOST = 4;
const CLIPS_PER_BAG = 100;

// Brace assembly materials emitted per CornerNode / BraceAssembly
const BRACE_ASSEMBLY_ITEMS = [
    { canonical_key: 'livestock_corner_post_wood_8ft', lineItemName: 'Corner Post – Treated Wood 8 ft', uom: 'each' },
    { canonical_key: 'livestock_brace_post_wood_8ft',  lineItemName: 'Brace Post – Treated Wood 8 ft',  uom: 'each' },
    { canonical_key: 'livestock_brace_rail_round_8ft', lineItemName: 'Brace Rail – Round 8 ft',          uom: 'each' },
    { canonical_key: 'livestock_brace_wire_9ga',       lineItemName: 'Brace Wire Roll – 9 Gauge',        uom: 'roll' },
];

// Terminal post (end-of-run / dead-end): just the corner post
const TERMINAL_POST_KEY = 'livestock_corner_post_wood_8ft';
const TERMINAL_POST_LABEL = 'Corner Post – Treated Wood 8 ft (Terminal)';

// ---------------------------------------------------------------------------
// VALIDATION HELPERS
// ---------------------------------------------------------------------------
const ResolverDiagnostics = {
    errors: [],
    warn(msg) { console.warn('[LivestockResolver]', msg); },
    error(msg) { console.error('[LivestockResolver] ERROR:', msg); this.errors.push(msg); },
    flush() {
        const errs = [...this.errors];
        this.errors = [];
        return errs;
    }
};

function validateFenceLine(line) {
    if (!line.fenceHeight && !line._heightFt) {
        ResolverDiagnostics.error(`FenceLine ${line.id}: no height selected`);
        return false;
    }
    return true;
}

function validateGateNode(gate) {
    const width = gate.gateWidth_ft;
    if (!GATE_KEY[width]) {
        ResolverDiagnostics.error(`GateNode ${gate.id}: unsupported gate width ${width} ft — must be 10, 12, or 16`);
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// MAIN RESOLVER
// ---------------------------------------------------------------------------

/**
 * buildLivestockTakeoff
 *
 * Reads fence objects from the design layer and emits materials deterministically.
 * No geometry inference. No auto-brace insertion. No hidden calculations.
 *
 * @param {Object} job
 * @param {Array}  fenceLines  — FenceLine objects from map
 * @param {Array}  runs        — Run records
 * @param {Array}  gates       — GateNode objects
 * @param {Array}  posts       — (reserved, unused for livestock)
 * @param {Object} utils       — { buildFenceGraph, computeTerminalPostCounts }
 */
export function buildLivestockTakeoff(job, fenceLines, runs, gates, posts = [], { buildFenceGraph, computeTerminalPostCounts }) {
    ResolverDiagnostics.flush(); // reset

    // ------------------------------------------------------------------
    // STEP 1: Filter to active Livestock runs
    // ------------------------------------------------------------------
    const activeRuns = runs.filter(r => {
        const status = r.runStatus || (r.isExisting ? 'existing' : 'new');
        const materialType = r.materialType || job.materialType;
        return status === 'new' && materialType === 'Livestock';
    });

    const activeLines = fenceLines.filter(line => {
        const status = line.runStatus || (line.isExisting ? 'existing' : 'new');
        const run = activeRuns.find(r => r.id === line.assignedRunId);
        return status === 'new' && line.assignedRunId && run;
    });

    const activeGates = gates.filter(g => {
        const run = activeRuns.find(r => r.id === g.runId);
        return !!run && !g.isOrphan;
    });

    // Validate all active lines
    activeLines.forEach(line => validateFenceLine(line));

    // Early exit on empty design
    if (activeLines.length === 0) {
        return {
            materialType: 'Livestock',
            fenceStyleId: 'livestock_fence',
            total_lf: 0,
            postCounts: { cornerPosts: 0, endPosts: 0, gatePosts: 0, tPosts: 0, totalPosts: 0 },
            metrics: { wireRolls: 0 },
            lineItems: [],
            graph: null,
            diagnosticErrors: ResolverDiagnostics.flush()
        };
    }

    // ------------------------------------------------------------------
    // STEP 2: Build graph → identify CornerNodes, TerminalNodes, GateNodes
    // ------------------------------------------------------------------
    const graph = buildFenceGraph(activeLines, activeRuns, activeGates);
    const graphCounts = computeTerminalPostCounts(graph, activeGates);

    // ------------------------------------------------------------------
    // STEP 3: Fence measurements
    // ------------------------------------------------------------------
    // Measure from fenceLines.manualLengthFt; fall back to the assigned run's lengthLF
    // when the line hasn't had its manual length stamped (common in map-driven flows).
    const totalFenceFt = activeLines.reduce((sum, line) => {
        const lineLF = line.manualLengthFt || 0;
        if (lineLF > 0) return sum + lineLF;
        // Fallback: use the assigned run's lengthLF
        const run = activeRuns.find(r => r.id === line.assignedRunId);
        return sum + (run?.lengthLF || 0);
    }, 0);
    const totalGateWidthFt = activeGates.reduce((sum, g) => sum + (g.gateWidth_ft || 0), 0);
    const netFenceFt = Math.max(0, totalFenceFt - totalGateWidthFt);

    // Resolve height (prefer run-level, fall back to job)
    const rawHeight = activeRuns[0]?.fenceHeight || job.fenceHeight || "4'";
    const heightFt = Math.max(4, Math.min(6, Math.round(parseFloat(rawHeight))));

    // ------------------------------------------------------------------
    // STEP 4: Resolve spacing (FenceLine attribute or default)
    // ------------------------------------------------------------------
    const spacingFt = activeLines[0]?.tPostSpacingFt || TPOST_DEFAULT_SPACING_FT;
    if (!activeLines[0]?.tPostSpacingFt) {
        ResolverDiagnostics.warn(`FenceLine has no spacing attribute — using default ${TPOST_DEFAULT_SPACING_FT} ft`);
    }

    // ------------------------------------------------------------------
    // STEP 5: Node counts (from graph — explicit objects only)
    // ------------------------------------------------------------------
    const cornerNodeCount = graphCounts.cornerPosts;   // CornerNode → brace assembly
    const terminalNodeCount = graphCounts.endPosts;     // TerminalNode → 1 corner post each
    const gateNodeCount = graphCounts.gatePosts;        // GateNode → gate + 2 terminal posts

    // Total wood posts = 1 per CornerNode + 1 per TerminalNode + 2 per GateNode
    // (Corner nodes also use a brace post, but that's counted separately in the assembly)
    const woodPostsFromCorners = cornerNodeCount;     // main corner post per brace assembly
    const woodPostsFromTerminals = terminalNodeCount; // terminal (end) posts
    const woodPostsFromGates = gateNodeCount;         // gate frame posts (2 per gate)
    const totalWoodPosts = woodPostsFromCorners + woodPostsFromTerminals + woodPostsFromGates;

    // ------------------------------------------------------------------
    // STEP 6: T-Post count (FenceLine objects only, deterministic formula)
    // ------------------------------------------------------------------
    // Posts placed along line at `spacingFt` intervals.
    // Terminal positions occupied by wood posts (corners + ends) are excluded.
    const rawTPostsFromSpacing = Math.floor(netFenceFt / spacingFt);
    const tPosts = Math.max(0, rawTPostsFromSpacing - totalWoodPosts);

    // ------------------------------------------------------------------
    // STEP 7: Wire rolls (FenceLine objects only)
    // ------------------------------------------------------------------
    const wireRolls = Math.ceil((netFenceFt * WIRE_WASTE_PCT) / WIRE_ROLL_LF);

    // ------------------------------------------------------------------
    // STEP 8: Fasteners
    // ------------------------------------------------------------------
    // T-Post clips: 4 per T-post, sold in bags of 100
    const totalClips = tPosts * CLIPS_PER_TPOST;
    const tPostClipBags = Math.ceil(totalClips / CLIPS_PER_BAG);

    // Fence staples: 10 per wood post (corners + terminals + gate frame posts), sold in boxes of 200
    const totalStaples = totalWoodPosts * STAPLES_PER_WOOD_POST;
    const stapleBoxes = Math.ceil(totalStaples / STAPLES_PER_BOX);

    // ------------------------------------------------------------------
    // STEP 9: Build line items
    // ------------------------------------------------------------------
    const lineItems = [];

    // --- FenceLine Resolution: Wire Rolls ---
    lineItems.push({
        canonical_key: WIRE_ROLL_KEY[heightFt] || WIRE_ROLL_KEY[4],
        lineItemName: `Livestock Fence Roll – ${heightFt} ft (330 ft roll)`,
        runLabel: 'FenceLine',
        materialDescription: `Woven Wire ${heightFt} ft × 330 ft roll (High Tensile Galvanized)`,
        quantityCalculated: wireRolls,
        uom: 'roll',
        notes: `${netFenceFt.toFixed(1)} net ft × ${WIRE_WASTE_PCT} waste ÷ ${WIRE_ROLL_LF} ft/roll = ${wireRolls} rolls`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: 'livestock_fence',
        materialSku: `LF-ROLL-${heightFt}-330`,
    });

    // --- FenceLine Resolution: T-Posts ---
    if (tPosts > 0) {
        lineItems.push({
            canonical_key: TPOST_KEY[heightFt] || TPOST_KEY[4],
            lineItemName: `Steel T Post – ${TPOST_LABEL[heightFt] || '6 ft'}`,
            runLabel: 'FenceLine',
            materialDescription: `Studded Steel T-Post ${TPOST_LABEL[heightFt] || '6 ft'} (line posts)`,
            quantityCalculated: tPosts,
            uom: 'each',
            notes: `FLOOR(${netFenceFt.toFixed(1)} ft ÷ ${spacingFt} ft spacing) = ${rawTPostsFromSpacing} − ${totalWoodPosts} wood = ${tPosts} T-posts`,
            source: 'map',
            sourceObjectType: 'FenceLine',
            fenceStyleId: 'livestock_fence',
            materialSku: `TPOST-${heightFt === 4 ? 6 : heightFt === 5 ? 7 : 8}`,
        });
    }

    // --- CornerNode Resolution: Brace Assembly (1 per corner) ---
    if (cornerNodeCount > 0) {
        BRACE_ASSEMBLY_ITEMS.forEach(item => {
            lineItems.push({
                canonical_key: item.canonical_key,
                lineItemName: item.lineItemName,
                runLabel: 'CornerNode',
                materialDescription: `${item.lineItemName} (brace assembly × ${cornerNodeCount})`,
                quantityCalculated: cornerNodeCount,
                uom: item.uom,
                notes: `${cornerNodeCount} CornerNode(s) × 1 ${item.lineItemName} each`,
                source: 'map',
                sourceObjectType: 'CornerNode',
                fenceStyleId: 'livestock_fence',
            });
        });
    }

    // --- TerminalNode Resolution: 1 corner post per terminal ---
    if (terminalNodeCount > 0) {
        lineItems.push({
            canonical_key: TERMINAL_POST_KEY,
            lineItemName: TERMINAL_POST_LABEL,
            runLabel: 'TerminalNode',
            materialDescription: `Termination post for end-of-run (${terminalNodeCount} terminal nodes)`,
            quantityCalculated: terminalNodeCount,
            uom: 'each',
            notes: `${terminalNodeCount} TerminalNode(s) × 1 corner post each`,
            source: 'map',
            sourceObjectType: 'TerminalNode',
            fenceStyleId: 'livestock_fence',
            materialSku: 'LF-CORNER-POST-8',
        });
    }

    // --- GateNode Resolution ---
    // Validate gate widths first
    const validGates = activeGates.filter(g => validateGateNode(g));

    const gateGroups = {};
    validGates.forEach(g => {
        const w = g.gateWidth_ft;
        if (!gateGroups[w]) gateGroups[w] = 0;
        gateGroups[w]++;
    });

    Object.entries(gateGroups).forEach(([widthStr, count]) => {
        const width = Number(widthStr);
        const gateCanonicalKey = GATE_KEY[width];
        if (!gateCanonicalKey) return;

        // 1 gate per GateNode
        lineItems.push({
            canonical_key: gateCanonicalKey,
            lineItemName: `Livestock Tube Gate – ${width} ft`,
            runLabel: 'GateNode',
            materialDescription: `Livestock Tube Gate ${width} ft`,
            quantityCalculated: count,
            uom: 'each',
            notes: `${count} GateNode(s) × 1 gate (${width} ft)`,
            source: 'map',
            sourceObjectType: 'GateNode',
            fenceStyleId: 'livestock_fence',
            materialSku: `LF-GATE-${width}`,
        });

        // 2 terminal posts per GateNode
        lineItems.push({
            canonical_key: TERMINAL_POST_KEY,
            lineItemName: 'Corner Post – Treated Wood 8 ft (Gate Frame)',
            runLabel: 'GateNode',
            materialDescription: `Gate frame posts for ${count} gate(s) (${width} ft)`,
            quantityCalculated: count * 2,
            uom: 'each',
            notes: `${count} GateNode(s) × 2 terminal posts each`,
            source: 'map',
            sourceObjectType: 'GateNode',
            fenceStyleId: 'livestock_fence',
            materialSku: 'LF-CORNER-POST-8',
        });
    });

    // --- Fastener Resolution: T-Post Clips ---
    if (tPostClipBags > 0) {
        lineItems.push({
            canonical_key: 'livestock_tpost_clips_bag',
            lineItemName: 'T Post Clips – Galvanized',
            runLabel: 'Fasteners',
            materialDescription: 'T-Post Clips (galvanized, bag)',
            quantityCalculated: tPostClipBags,
            uom: 'bag',
            notes: `${tPosts} T-posts × ${CLIPS_PER_TPOST} clips = ${totalClips} clips → CEIL(${totalClips} ÷ ${CLIPS_PER_BAG}) = ${tPostClipBags} bag(s)`,
            source: 'map',
            sourceObjectType: 'FenceLine',
            fenceStyleId: 'livestock_fence',
            materialSku: 'LF-TPOST-CLIPS',
        });
    }

    // --- Fastener Resolution: Fence Staples ---
    if (stapleBoxes > 0) {
        lineItems.push({
            canonical_key: 'livestock_fence_staples_2in_box',
            lineItemName: 'Fence Staples – Galvanized 2 in',
            runLabel: 'Fasteners',
            materialDescription: 'Galvanized Fence Staples 2 in (box)',
            quantityCalculated: stapleBoxes,
            uom: 'box',
            notes: `${totalWoodPosts} wood post(s) × ${STAPLES_PER_WOOD_POST} staples = ${totalStaples} staples → CEIL(${totalStaples} ÷ ${STAPLES_PER_BOX}) = ${stapleBoxes} box(es)`,
            source: 'map',
            sourceObjectType: 'CornerNode/TerminalNode/GateNode',
            fenceStyleId: 'livestock_fence',
            materialSku: 'LF-FENCE-STAPLES',
        });
    }

    // ------------------------------------------------------------------
    // STEP 10: Collect diagnostics
    // ------------------------------------------------------------------
    const diagnosticErrors = ResolverDiagnostics.flush();
    if (diagnosticErrors.length > 0) {
        console.error('[LivestockResolver] Resolver completed with errors:', diagnosticErrors);
    }

    return {
        materialType: 'Livestock',
        fenceStyleId: 'livestock_fence',
        total_lf: totalFenceFt,
        postCounts: {
            cornerPosts: cornerNodeCount,
            endPosts: terminalNodeCount,
            gatePosts: gateNodeCount,
            tPosts,
            totalPosts: totalWoodPosts + tPosts
        },
        metrics: { wireRolls, netFenceFt, spacingFt },
        lineItems,
        graph,
        diagnosticErrors
    };
}