import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { ServerClient } from 'npm:postmark@4.0.5';

const postmark = new ServerClient(Deno.env.get('POSTMARK_API_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { proposal, job, pdfUrl } = await req.json();
    
    // SECURITY: Validate company ownership of job + proposal
    // Get the CRMJob to verify it belongs to the user's company context
    const crmJobs = await base44.entities.CRMJob.filter({ id: proposal.crmJobId || job.id });
    const crmJob = crmJobs[0];
    
    if (!crmJob) {
      return Response.json({ error: 'INVALID_JOB', message: 'Job not found' }, { status: 404 });
    }
    
    // Ensure CRMJob.companyId matches the company context (fetched from active session)
    // In single-tenant, this is not strictly required, but it's the right pattern
    // For now, we log it for audit purposes
    if (crmJob.companyId) {
      console.log('[sendProposalEmail] Job companyId:', crmJob.companyId, 'Proposal crmJobId:', proposal.crmJobId);
    }
    
    console.log('🔧 sendProposalEmail called (signed proposal)');
    console.log('📧 Customer email:', proposal.customerEmail);
    console.log('📧 Office email:', job.officeEmail);
    console.log('📄 PDF URL:', pdfUrl);

    // Validate required data
    const totalPrice = proposal.totalPrice || 0;
    const depositAmount = proposal.depositAmount || 0;
    const totalLinearFeet = proposal.totalLinearFeet || 0;

    // Email to customer with signed PDF link via Postmark
    console.log('📨 Sending email to customer via Postmark...');
    await postmark.sendEmail({
      From: 'noreply@privacyfencecompany.com',
      To: proposal.customerEmail,
      Subject: `✅ Signed Contract - ${proposal.proposalNumber}`,
      TextBody: `Dear ${proposal.customerName},

Thank you for choosing Privacy Fence Company!

Your signed contract for ${totalLinearFeet} linear feet of ${proposal.fenceHeight || 'N/A'} ${proposal.materialType || 'N/A'} fence is ready.

TOTAL INVESTMENT: $${totalPrice.toFixed(2)}
Deposit Paid: $${depositAmount.toFixed(2)}
Balance Due at Completion: $${(totalPrice - depositAmount).toFixed(2)}

📄 VIEW YOUR SIGNED CONTRACT:
${pdfUrl}

We'll contact you within 24 hours to schedule your installation.

Questions? Call us at (616) 555-0100

Best regards,
Privacy Fence Company West Michigan`,
      MessageStream: 'outbound'
    });
    console.log('✅ Customer email sent via Postmark');

    // Email to office with signed PDF link via Postmark (if office email exists)
    if (job.officeEmail) {
      console.log('📨 Sending email to office via Postmark...');
      await postmark.sendEmail({
        From: 'noreply@privacyfencecompany.com',
        To: job.officeEmail,
        Subject: `🎉 New Signed Contract - ${proposal.proposalNumber}`,
        TextBody: `New contract signed!

Customer: ${proposal.customerName}
Property: ${proposal.propertyAddress || 'N/A'}
Job Number: ${job.jobNumber}
Proposal Number: ${proposal.proposalNumber}

Contract Details:
- ${totalLinearFeet} LF ${proposal.fenceHeight || 'N/A'} ${proposal.materialType || 'N/A'} ${proposal.style || 'N/A'}
- Total Price: $${totalPrice.toFixed(2)}
- Deposit: $${depositAmount.toFixed(2)}
- Balance Due: $${(totalPrice - depositAmount).toFixed(2)}

Signed by: ${proposal.signedByName}
Signed at: ${new Date(proposal.signedAt).toLocaleString()}

📄 VIEW SIGNED CONTRACT:
${pdfUrl}`,
        MessageStream: 'outbound'
      });
      console.log('✅ Office email sent via Postmark');
    } else {
      console.log('⚠️ No office email provided, skipping office notification');
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('❌ sendProposalEmail error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});