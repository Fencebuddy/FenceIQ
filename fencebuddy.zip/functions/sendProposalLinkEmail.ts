import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { ServerClient } from 'npm:postmark@4.0.5';

const postmark = new ServerClient(Deno.env.get('POSTMARK_API_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { proposal, job, pdfUrl } = await req.json();
    
    console.log('🔧 sendProposalLinkEmail called');
    console.log('📧 Customer email:', proposal.customerEmail);
    console.log('📄 PDF URL:', pdfUrl);

    // Email to customer with PDF link via Postmark
    console.log('📨 Sending proposal email via Postmark...');
    await postmark.sendEmail({
      From: 'noreply@privacyfencecompany.com',
      To: proposal.customerEmail,
      Subject: `Your Fence Installation Proposal - ${proposal.proposalNumber}`,
      TextBody: `Dear ${proposal.customerName},

Thank you for considering Privacy Fence Company for your fence installation project!

We're pleased to present your custom proposal for ${proposal.totalLinearFeet} linear feet of ${proposal.fenceHeight} ${proposal.materialType} fence.

TOTAL INVESTMENT: $${proposal.totalPrice.toFixed(2)}
Deposit Required: $${proposal.depositAmount.toFixed(2)} (${(proposal.depositPercent * 100).toFixed(0)}%)
Balance Due at Completion: $${(proposal.totalPrice - proposal.depositAmount).toFixed(2)}

${proposal.tearOutLF > 0 ? `\n🚧 INCLUDES: Tear Out & Haul Away - ${proposal.tearOutLF.toFixed(1)} LF @ $5.00/LF = $${(proposal.tearOutLF * 5.0).toFixed(2)}\n` : ''}

📄 VIEW YOUR PROPOSAL:
${pdfUrl}

This proposal is valid until ${new Date(proposal.validUntil).toLocaleDateString()}.

Please review the attached details. We'll follow up with you shortly to discuss next steps.

Questions? Call us at (616) 555-0100

Best regards,
Privacy Fence Company West Michigan

---
This is an automated message from FenceBuddy. Your proposal number is ${proposal.proposalNumber}.`,
      MessageStream: 'outbound'
    });
    console.log('✅ Email sent via Postmark');

    return Response.json({ success: true });
  } catch (error) {
    console.error('❌ sendProposalLinkEmail error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});