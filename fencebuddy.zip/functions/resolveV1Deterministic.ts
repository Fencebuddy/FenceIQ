import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * V1 DETERMINISTIC RESOLVER CONTRACT
 * 
 * Input: companyId + takeoffLineItems
 * Output: { resolved, unresolved, integrityErrors, pricingStatus }
 * 
 * Rules:
 * - Each takeoff line MUST have: uck, qty, qtyUnit
 * - Lookup CompanySkuMap(companyId, uck, status='mapped')
 * - 0 rows → unresolved
 * - >1 rows → integrityError
 * - Join MaterialCatalog
 * - Unit validation (exact match or defined conversion)
 * - pricingStatus = COMPLETE only if unresolved=0 AND integrityErrors=0
 */
Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { companyId, takeoffLineItems = [] } = await req.json();

        if (!companyId || !Array.isArray(takeoffLineItems)) {
            return Response.json({ 
                error: 'Invalid payload: companyId and takeoffLineItems[] required' 
            }, { status: 400 });
        }

        const resolved = [];
        const unresolved = [];
        const integrityErrors = [];

        // Load all mappings for this company at once
        const allMappings = await base44.asServiceRole.entities.CompanySkuMap.filter({
            companyId,
            status: 'mapped'
        });

        // Load all catalog items at once
        const allCatalog = await base44.asServiceRole.entities.MaterialCatalog.filter({
            active: true
        });

        // Index for O(1) lookups
        const mappingsByUck = {};
        allMappings.forEach(map => {
            if (!mappingsByUck[map.uck]) {
                mappingsByUck[map.uck] = [];
            }
            mappingsByUck[map.uck].push(map);
        });

        const catalogById = {};
        allCatalog.forEach(cat => {
            catalogById[cat.id] = cat;
        });

        // Process each line item
        for (const line of takeoffLineItems) {
            const { uck, qty, qtyUnit, displayName, lineItemName } = line;

            if (!uck) {
                unresolved.push({
                    ...line,
                    reason: 'MISSING_UCK',
                    message: 'No canonical key provided'
                });
                continue;
            }

            // Lookup mapping
            const maps = mappingsByUck[uck] || [];

            if (maps.length === 0) {
                unresolved.push({
                    uck,
                    displayName: displayName || lineItemName,
                    qty,
                    qtyUnit,
                    reason: 'UCK_NOT_MAPPED',
                    message: `No CompanySkuMap entry for UCK: ${uck}`
                });
                continue;
            }

            if (maps.length > 1) {
                integrityErrors.push({
                    uck,
                    displayName: displayName || lineItemName,
                    reason: 'DUPLICATE_MAPPING',
                    message: `Multiple enabled mappings for UCK: ${uck}`,
                    mapIds: maps.map(m => m.id)
                });
                continue;
            }

            const map = maps[0];
            const catalog = catalogById[map.materialCatalogId];

            if (!catalog) {
                unresolved.push({
                    uck,
                    displayName: displayName || lineItemName,
                    qty,
                    qtyUnit,
                    reason: 'MISSING_CATALOG',
                    message: `Catalog item ${map.materialCatalogId} not found`
                });
                continue;
            }

            // Unit validation
            if (qtyUnit !== catalog.unit) {
                // Could add deterministic unit conversion here
                // For now: mark unresolved
                unresolved.push({
                    uck,
                    displayName: displayName || lineItemName,
                    qty,
                    qtyUnit,
                    catalogUnit: catalog.unit,
                    reason: 'UNIT_MISMATCH',
                    message: `Takeoff unit ${qtyUnit} != Catalog unit ${catalog.unit}`
                });
                continue;
            }

            // SUCCESS: Resolved
            resolved.push({
                uck,
                displayName: displayName || lineItemName || catalog.crm_name,
                qty,
                qtyUnit,
                materialCatalogId: catalog.id,
                catalogName: catalog.crm_name,
                unitCost: catalog.cost || 0,
                extCost: (qty || 0) * (catalog.cost || 0),
                catalogRow: {
                    id: catalog.id,
                    crm_name: catalog.crm_name,
                    category: catalog.category,
                    unit: catalog.unit,
                    cost: catalog.cost
                }
            });
        }

        const pricingStatus = unresolved.length === 0 && integrityErrors.length === 0 
            ? 'COMPLETE' 
            : 'INCOMPLETE';

        return Response.json({
            resolved,
            unresolved,
            integrityErrors,
            pricingStatus,
            summary: {
                total: takeoffLineItems.length,
                resolvedCount: resolved.length,
                unresolvedCount: unresolved.length,
                integrityErrorCount: integrityErrors.length
            }
        });
    } catch (error) {
        console.error('[resolveV1Deterministic] Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});