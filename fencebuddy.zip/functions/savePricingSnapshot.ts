import { createGuardedClientFromRequest } from './_shared/base44GuardFactory.js';

/**
 * SAVE PRICING SNAPSHOT WITH ENFORCEMENT
 * Atomic save with discount validation
 * Rejects saves that violate net margin floors
 * 
 * Immutability Note: ProposalPricingSnapshot mutations are routed through the
 * wrapped base44 client which enforces write-once protection.
 */
Deno.serve(async (req) => {
  try {
    const base44 = await createGuardedClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const payload = await req.json();
    const {
      jobId,
      materialCost,
      laborCost,
      deliveryCost,
      selectedTokensPct = [],
      resolvedLineItems = [],
      overheadRate,
      commissionRate,
      taxRate = 0,
      scenarioKey = 'custom',
      retailAnchorOverride = null
    } = payload;
    
    // Step 1: Get company settings for discount policy
    const companySettings = await base44.entities.CompanySettings.list();
    const companyId = companySettings[0]?.id;
    const discountPolicyEnabled = companySettings[0]?.discountPolicy?.stackingMode === 'ADDITIVE';
    
    // Step 2: Compute pricing (with enforcement if policy enabled)
    const pricingResult = await base44.functions.invoke('computeDeterministicPricing', {
      jobId,
      materialCost,
      laborCost,
      deliveryCost,
      selectedTokensPct: discountPolicyEnabled ? selectedTokensPct : [],
      resolvedLineItems,
      overheadRate,
      commissionRate,
      retailAnchorOverride
    });
    
    if (!pricingResult.data.success) {
      // Return structured validation error
      return Response.json({
        success: false,
        error: pricingResult.data.error,
        message: pricingResult.data.message,
        details: {
          ...pricingResult.data.details,
          enforcementMode: discountPolicyEnabled ? 'ENABLED' : 'DISABLED'
        }
      }, { status: 400 });
    }
    
    const snapshot = pricingResult.data.snapshot;
    
    // Step 3: Add tax calculation
    const taxAmountCents = Math.round(snapshot.discountedPriceCents * taxRate);
    const totalPriceCents = snapshot.discountedPriceCents + taxAmountCents;
    
    // Step 4: Get current version number
    const existingSnapshots = await base44.entities.PricingSnapshot.filter({ jobId });
    const version = existingSnapshots.length + 1;
    
    // Step 5: Invalidate previous snapshots if discount tokens changed
    if (discountPolicyEnabled && selectedTokensPct.length > 0) {
      const activeSnapshot = existingSnapshots.find(s => !s.isLocked && s.version === version - 1);
      if (activeSnapshot && 
          JSON.stringify(activeSnapshot.selectedTokensPct) !== JSON.stringify(selectedTokensPct)) {
        // Tokens changed - mark previous snapshot as needs review
        await base44.entities.PricingSnapshot.update(activeSnapshot.id, {
          calcBreakdown: {
            ...activeSnapshot.calcBreakdown,
            needsReview: true,
            reason: 'DISCOUNT_TOKENS_CHANGED'
          }
        });
      }
    }
    
    // Step 6: Create snapshot record with full enforcement metadata
    const snapshotRecord = {
      companyId,
      jobId,
      version,
      scenarioKey,
      pricingModelVersion: snapshot.pricingModelVersion,
      
      // Costs
      materialCost: snapshot.materialCost,
      laborCost: snapshot.laborCost,
      deliveryCost: snapshot.deliveryCost,
      directCost: snapshot.directCost,
      
      // Retail anchor
      retailPrice: snapshot.retailPrice,
      
      // Allocations
      overheadAmount: snapshot.overheadAmount,
      commissionAmount: snapshot.commissionAmount,
      
      // Discounts
      discountPercent: snapshot.effectiveDiscountPct,
      discountAmount: snapshot.discountAmount,
      sellPriceSubtotal: snapshot.sellPriceSubtotal,
      
      // Tax
      taxRate,
      taxAmount: taxAmountCents / 100,
      totalPrice: totalPriceCents / 100,
      
      // Profit
      netProfitAmount: snapshot.netProfitAmount,
      netProfitPercent: snapshot.netPctAfterDiscount,
      
      // Discount policy fields (NEW)
      stackingMode: snapshot.stackingMode,
      tokensAvailablePct: snapshot.tokensAvailablePct,
      selectedTokensPct: snapshot.selectedTokensPct,
      effectiveDiscountPct: snapshot.effectiveDiscountPct,
      maxEffectiveDiscountPct: snapshot.maxEffectiveDiscountPct,
      mixedMaterialPolicy: snapshot.mixedMaterialPolicy,
      materialTypesInJob: snapshot.materialTypesInJob,
      requiredNetAfterDiscountPct: snapshot.requiredNetAfterDiscountPct,
      requiredRetailNetPct: snapshot.requiredRetailNetPct,
      
      // Cents precision fields (NEW)
      costBasisForNetCents: snapshot.costBasisForNetCents,
      retailPriceCents: snapshot.retailPriceCents,
      discountedPriceCents: snapshot.discountedPriceCents,
      netPctRetail: snapshot.netPctRetail,
      netPctAfterDiscount: snapshot.netPctAfterDiscount,
      
      // Reproducibility
      roundingPolicy: snapshot.roundingPolicy,
      pricingInputsHash: snapshot.pricingInputsHash,
      takeoffInputsHash: snapshot.takeoffInputsHash,
      
      // Breakdown with enforcement metadata
      calcBreakdown: {
        computedAt: snapshot.computedAt,
        resolvedMaterialTypes: snapshot.materialTypesInJob,
        enforcementPassed: true,
        enforcementMode: discountPolicyEnabled ? 'ACTIVE' : 'LEGACY',
        policyVersion: companySettings[0]?.discountPolicy?.stackingMode || 'NONE'
      },
      
      isLocked: false
    };
    
    // Step 7: Save snapshot (atomic)
    const saved = await base44.entities.PricingSnapshot.create(snapshotRecord);
    
    // Step 8: Update job with active snapshot reference and invalidate pricing cache
    await base44.entities.CRMJob.update(jobId, {
      currentPricingSnapshotId: saved.id,
      pricing_status: 'SAVED'
    });
    
    // Step 9: Mark for revalidation on next cost change
    if (discountPolicyEnabled && selectedTokensPct.length > 0) {
      await base44.entities.CRMJob.update(jobId, {
        pricingNeedsReview: false // Clear any pending review flags
      });
    }
    
    return Response.json({
      success: true,
      snapshotId: saved.id,
      snapshot: saved,
      enforcement: {
        enabled: discountPolicyEnabled,
        netPctAfterDiscount: snapshot.netPctAfterDiscount,
        requiredFloor: snapshot.requiredNetAfterDiscountPct,
        margin: snapshot.netPctAfterDiscount - snapshot.requiredNetAfterDiscountPct
      }
    });
    
  } catch (error) {
    console.error('[savePricingSnapshot] Error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});