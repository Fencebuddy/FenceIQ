/**
 * FENCEBUDDY V2 ENGINE — PARITY TESTER
 * 
 * CONTRACT 7: SHADOW MODE + PARITY TESTS
 * Compare V1 and V2 outputs before cutover
 */

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, AlertTriangle, Play } from 'lucide-react';
import { runShadowComparison } from './EngineAdapter';

export default function ParityTester({ job, fenceLines, gates, runs, jobPosts, variantConfig }) {
  const [results, setResults] = useState(null);
  const [testing, setTesting] = useState(false);
  
  const runTest = async () => {
    setTesting(true);
    const comparison = await runShadowComparison({
      job,
      fenceLines,
      gates,
      runs,
      jobPosts,
      variantConfig
    });
    setResults(comparison);
    setTesting(false);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🔬 V1/V2 Parity Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-slate-600">
          Run both engines and compare outputs to verify V2 matches V1 before cutover.
        </div>
        
        <Button 
          onClick={runTest} 
          disabled={testing}
          className="w-full"
        >
          {testing ? (
            <>Running Parity Test...</>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Run Parity Test
            </>
          )}
        </Button>
        
        {results && (
          <div className="space-y-3">
            <Alert className="bg-blue-50 border-blue-500">
              <AlertDescription>
                <div className="space-y-2 text-sm">
                  <div className="font-semibold">V2 Results:</div>
                  <div className="font-mono text-xs bg-white p-2 rounded">
                    Geometry Checksum: {results.v2_results?.geometry?.geometry_checksum || 'N/A'}
                  </div>
                  <div className="font-mono text-xs bg-white p-2 rounded">
                    Takeoff Hash: {results.v2_results?.takeoff?.takeoff_hash || 'N/A'}
                  </div>
                  <div className="font-mono text-xs bg-white p-2 rounded">
                    Resolved Items: {results.v2_results?.resolution?.resolved_items?.length || 0}
                  </div>
                  <div className="font-mono text-xs bg-white p-2 rounded">
                    Unresolved Items: {results.v2_results?.resolution?.unresolved_items?.length || 0}
                  </div>
                  <div className="font-mono text-xs bg-white p-2 rounded">
                    Mapping Rate: {results.v2_results?.resolution?.resolution_metrics?.mapping_rate || 0}%
                  </div>
                </div>
              </AlertDescription>
            </Alert>
            
            <div className="text-xs text-slate-500 italic">
              Note: Full V1 comparison requires V1 outputs to be passed in. This shows V2 execution only.
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}