import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { jobId } = await req.json();
    if (!jobId) return Response.json({ error: 'jobId required' }, { status: 400 });

    // Fetch job, runs, gates, catalog
    const jobs = await base44.entities.Job.filter({ id: jobId });
    const job = jobs[0];
    if (!job) return Response.json({ error: 'Job not found' }, { status: 404 });

    const [runs, gates, catalog] = await Promise.all([
      base44.entities.Run.filter({ jobId }),
      base44.entities.Gate.filter({ jobId }),
      base44.entities.MaterialCatalog.filter({ active: true })
    ]);

    // Calculate totals
    const totalLF = runs.reduce((sum, r) => sum + (r.lengthLF || 0), 0);
    const postCount = runs.length * 3; // rough estimate

    console.log('[TestV2] Pipeline test', { jobId, totalLF, postCount, catalog: catalog.length });

    // Build 3 variant takeoffs manually (simulate V2 builder)
    const variants = [
      { materialType: 'chain_link', height: 6, color: 'galv', coating: 'galv' },
      { materialType: 'vinyl', height: 6, color: 'white', coating: null },
      { materialType: 'aluminum', height: 6, color: 'black', coating: null }
    ];

    const results = [];
    
    for (const variant of variants) {
      // Build takeoff items
      const items = [];
      
      if (variant.materialType === 'chain_link') {
        items.push(
          { displayName: 'CL Posts', uck: 'chainlink_post_6_galv', qty: postCount, unit: 'each' },
          { displayName: 'CL Fabric', uck: 'chainlink_fabric_6_galv_50ft', qty: Math.ceil(totalLF / 50), unit: 'roll' },
          { displayName: 'CL Rail', uck: 'chainlink_rail_top_6_galv', qty: Math.ceil(totalLF / 21), unit: 'each' },
          { displayName: 'CL Hardware', uck: 'chainlink_hardware_kit', qty: 1, unit: 'kit' }
        );
      } else if (variant.materialType === 'vinyl') {
        items.push(
          { displayName: 'Vinyl Posts', uck: 'vinyl_post_line_6_white', qty: Math.max(0, postCount - gates.length * 2), unit: 'each' },
          { displayName: 'Vinyl Panels', uck: 'vinyl_panel_privacy_6_white', qty: Math.ceil(totalLF / 6), unit: 'each' },
          { displayName: 'Vinyl Rail', uck: 'vinyl_rail_top_6_white', qty: Math.ceil(totalLF / 21), unit: 'each' },
          { displayName: 'Vinyl Hardware', uck: 'vinyl_hardware_kit', qty: 1, unit: 'kit' }
        );
      } else {
        items.push(
          { displayName: 'Aluminum Posts', uck: 'aluminum_post_6_black', qty: postCount, unit: 'each' },
          { displayName: 'Aluminum Panels', uck: 'aluminum_panel_6_black', qty: Math.ceil(totalLF / 6), unit: 'each' },
          { displayName: 'Aluminum Rail', uck: 'aluminum_rail_top_6_black', qty: Math.ceil(totalLF / 21), unit: 'each' },
          { displayName: 'Aluminum Hardware', uck: 'aluminum_hardware_kit', qty: 1, unit: 'kit' }
        );
      }

      // Add gates
      gates.forEach(gate => {
        items.push({
          displayName: `${gate.gateType} Gate ${gate.gateWidth_ft || gate.gateWidth}ft`,
          uck: `gate_${gate.gateType.toLowerCase()}_${gate.gateWidth_ft || gate.gateWidth}`,
          qty: 1,
          unit: 'each'
        });
      });

      // Add labor
      items.push(
        { displayName: 'Labor', uck: 'labor_lf', qty: totalLF, unit: 'lf' }
      );

      // Resolve against catalog
      const catalogByUck = new Map();
      catalog.forEach(c => {
        if (c.canonical_key) catalogByUck.set(c.canonical_key, c);
      });

      const resolved = [];
      let materialCost = 0;

      for (const item of items) {
        const cat = catalogByUck.get(item.uck);
        if (cat) {
          const extCost = item.qty * (cat.cost || 0);
          resolved.push({
            ...item,
            unit_cost: cat.cost,
            extended_cost: extCost,
            catalog_id: cat.id
          });
          if (item.uck !== 'labor_lf') materialCost += extCost;
        }
      }

      // Compute pricing
      const laborCost = totalLF * 10;
      const deliveryCost = 75;
      const directCost = materialCost + laborCost + deliveryCost;
      const retailPrice = directCost / 0.44;
      const overhead = retailPrice * 0.14;
      const commission = retailPrice * 0.10;
      const netProfit = retailPrice * 0.30;

      results.push({
        variant: variant.materialType,
        resolved_count: resolved.length,
        material_cost: materialCost,
        labor_cost: laborCost,
        delivery_cost: deliveryCost,
        direct_cost: directCost,
        retail_price: Math.round(retailPrice * 100) / 100,
        overhead: Math.round(overhead * 100) / 100,
        commission: Math.round(commission * 100) / 100,
        net_profit: Math.round(netProfit * 100) / 100,
        net_margin_pct: ((netProfit / retailPrice) * 100).toFixed(1)
      });
    }

    return Response.json({
      status: 'SUCCESS',
      jobId,
      totalLF: Math.round(totalLF * 10) / 10,
      postCount,
      variants: results,
      message: 'V2 pipeline test complete'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});