import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Template specs - define exact BOM by UCK (no new prices, no fuzzy matching)
const TEMPLATES = {
  vinyl: [
    // Savannah Vinyl 6ft Privacy
    { materialType: 'vinyl', heights: ['6ft'], colorKeys: ['white', 'coastal_grey', 'cedar_tone'], 
      lines: [
        { uck: 'vinyl_post_terminal_5x5_6ft_savannah_white', qtyRuleType: 'POSTS_TOTAL', sortOrder: 10 },
        { uck: 'vinyl_post_line_5x5_6ft_savannah_white', qtyRuleType: 'POSTS_LINE', sortOrder: 20 },
        { uck: 'vinyl_panel_privacy_6ft_savannah_white', qtyRuleType: 'PANELS_BY_LF', qtyRuleValue: 6, sortOrder: 30 },
        { uck: 'vinyl_hardware_post_cap_5x5_newengland_savannah_white', qtyRuleType: 'POSTS_TOTAL', sortOrder: 40 },
        { uck: 'vinyl_concrete_6ft', qtyRuleType: 'POSTS_TOTAL', sortOrder: 50 }
      ]
    }
  ],
  chain_link: [
    { materialType: 'chain_link', heights: ['4ft', '5ft', '6ft'], coatings: ['galvanized', 'black_vinyl'],
      lines: [
        { uck: 'chainlink_post_terminal_galvanized', qtyRuleType: 'POSTS_TOTAL', sortOrder: 10 },
        { uck: 'chainlink_post_line_galvanized', qtyRuleType: 'POSTS_LINE', sortOrder: 20 },
        { uck: 'chainlink_fabric_6ft_galvanized', qtyRuleType: 'ROLLS_BY_LF', qtyRuleValue: 50, sortOrder: 30 },
        { uck: 'chainlink_cap_dome_galvanized', qtyRuleType: 'POSTS_TOTAL', sortOrder: 40 }
      ]
    }
  ],
  wood: [
    { materialType: 'wood', heights: ['4ft', '5ft', '6ft'],
      lines: [
        { uck: 'wood_post_6ft', qtyRuleType: 'POSTS_TOTAL', sortOrder: 10 },
        { uck: 'wood_rail_2x4x8', qtyRuleType: 'PER_LF', qtyRuleValue: 0.5, sortOrder: 20 },
        { uck: 'wood_picket_6ft_treated', qtyRuleType: 'PER_LF', qtyRuleValue: 3, sortOrder: 30 },
        { uck: 'wood_concrete_6ft', qtyRuleType: 'POSTS_TOTAL', sortOrder: 40 }
      ]
    }
  ],
  aluminum: [
    { materialType: 'aluminum', heights: ['4ft'],
      lines: [
        { uck: 'aluminum_post_line_4ft_black', qtyRuleType: 'POSTS_TOTAL', sortOrder: 10 },
        { uck: 'aluminum_panel_4ft_black', qtyRuleType: 'PANELS_BY_LF', qtyRuleValue: 6, sortOrder: 20 },
        { uck: 'aluminum_post_cap_4ft', qtyRuleType: 'POSTS_TOTAL', sortOrder: 30 }
      ]
    }
  ]
};

function buildSelectionKey(materialType, height, colorKey, coating) {
  if (materialType === 'vinyl') {
    return `vinyl|${height}|${colorKey}`;
  }
  if (materialType === 'chain_link') {
    return `chain_link|${height}|${coating}`;
  }
  if (materialType === 'wood') {
    return `wood|${height}`;
  }
  if (materialType === 'aluminum') {
    return `aluminum|${height}`;
  }
  throw new Error(`Unknown materialType: ${materialType}`);
}

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user || user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const { companyId } = await req.json();
        if (!companyId) {
            return Response.json({ error: 'Missing companyId' }, { status: 400 });
        }

        // Load company settings for vinyl colors
        const companySettings = await base44.asServiceRole.entities.CompanySettings.filter({
            companyId
        });
        if (!companySettings.length) {
            return Response.json({ error: 'Company not found' }, { status: 404 });
        }

        // Load all catalog items once
        const allCatalog = await base44.asServiceRole.entities.MaterialCatalog.filter({ active: true });
        const catalogByUck = {};
        allCatalog.forEach(item => {
            if (item.canonical_key) {
                catalogByUck[item.canonical_key] = item;
            }
        });

        let createdSets = 0;
        let updatedSets = 0;
        let createdLines = 0;
        let updatedLines = 0;
        const missingCatalogKeys = [];
        const unpricedCatalogKeys = [];

        // Enumerate all combinations
        for (const [materialType, specs] of Object.entries(TEMPLATES)) {
            for (const spec of specs) {
                const heights = spec.heights || [];
                const colorKeys = spec.colorKeys || [null];
                const coatings = spec.coatings || [null];

                for (const height of heights) {
                    for (const colorKey of colorKeys) {
                        for (const coating of coatings) {
                            const selectionKey = buildSelectionKey(materialType, height, colorKey, coating);

                            // Check if set exists
                            const existingSets = await base44.asServiceRole.entities.MaterialSelectionSet.filter({
                                companyId,
                                selectionKey
                            });

                            let set;
                            if (existingSets.length > 0) {
                                set = existingSets[0];
                                updatedSets++;
                            } else {
                                // Create set
                                set = await base44.asServiceRole.entities.MaterialSelectionSet.create({
                                    companyId,
                                    materialType,
                                    fenceHeight: height,
                                    colorKey,
                                    colorLabel: colorKey ? colorKey.split('_').map(w => w[0].toUpperCase() + w.slice(1)).join(' ') : null,
                                    coating,
                                    selectionKey,
                                    name: `${materialType}|${height}${colorKey ? `|${colorKey}` : ''}${coating ? `|${coating}` : ''}`,
                                    isActive: true
                                });
                                createdSets++;
                            }

                            // Process lines
                            for (const templateLine of spec.lines) {
                                const catalogItem = catalogByUck[templateLine.uck];
                                if (!catalogItem) {
                                    missingCatalogKeys.push(templateLine.uck);
                                    continue;
                                }

                                // Check cost
                                if (catalogItem.cost <= 0) {
                                    unpricedCatalogKeys.push(templateLine.uck);
                                    continue;
                                }

                                // Check if line exists
                                const existingLines = await base44.asServiceRole.entities.MaterialSelectionLine.filter({
                                    companyId,
                                    selectionSetId: set.id,
                                    materialCatalogId: catalogItem.id
                                });

                                if (existingLines.length > 0) {
                                    updatedLines++;
                                } else {
                                    await base44.asServiceRole.entities.MaterialSelectionLine.create({
                                        companyId,
                                        selectionSetId: set.id,
                                        materialCatalogId: catalogItem.id,
                                        qtyRuleType: templateLine.qtyRuleType,
                                        qtyRuleValue: templateLine.qtyRuleValue || null,
                                        qtyMultiplier: 1,
                                        qtyRounding: 'NONE',
                                        sortOrder: templateLine.sortOrder || 100,
                                        status: 'OK',
                                        allowZeroCost: false
                                    });
                                    createdLines++;
                                }
                            }
                        }
                    }
                }
            }
        }

        return Response.json({
            summary: {
                createdSets,
                updatedSets,
                createdLines,
                updatedLines
            },
            issues: {
                missingCatalogKeys,
                unpricedCatalogKeys
            }
        });

    } catch (error) {
        console.error('Error in seedSelectionSetsFromTemplates:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});