/**
 * Phase 12.3.1: Immutability Enforcement Wrapper
 * 
 * Wraps entity update/delete operations with immutability checks.
 * Starts in WARN mode (log violations, allow operation).
 * Can be toggled to ENFORCE mode (throw on violation, block operation).
 */

const IMMUTABLE_ENTITIES = new Set([
  'ProposalPricingSnapshot',
  'JobCostSnapshot',
  'SaleSnapshot',
  'PricingSnapshot',
  'TakeoffSnapshot'
]);

// Phase 12.3: ENFORCE mode active — snapshots are cryptographically immutable
let ENFORCE_MODE = true; // Hardened after 24h zero-violation observation (2026-03-01)

/**
 * Assert immutability constraint on write operation.
 * In WARN mode: logs violation, allows operation.
 * In ENFORCE mode: throws, blocks operation.
 *
 * Also writes DiagnosticsLog entry on violation attempt (for audit trail).
 */
export async function assertSnapshotImmutability(
  operation: 'create' | 'read' | 'update' | 'delete' | 'patch' | 'set' | 'delete' | 'bulk_update',
  entityName: string,
  options: {
    maintenanceMode?: boolean;
    restoreEnabled?: boolean;
    correlationId?: string;
    entityId?: string;
    payload?: any;
  } = {}
): Promise<void> {
  const { maintenanceMode, restoreEnabled, correlationId, entityId } = options;

  // Allow reads and creates
  if (operation === 'read' || operation === 'create') {
    return;
  }

  // Check if entity is immutable
  if (!IMMUTABLE_ENTITIES.has(entityName)) {
    return; // Not immutable, allow
  }

  // Allow updates/deletes only in restore mode
  if (maintenanceMode && restoreEnabled) {
    console.log(`[ImmutabilityGuard] RESTORE_ALLOWED: ${operation.toUpperCase()} ${entityName}`, {
      correlationId,
      entityId
    });
    return;
  }

  // Violation detected
  const message = `IMMUTABILITY_VIOLATION: ${operation.toUpperCase()} ${entityName} ${entityId || '(batch)'}. Snapshots are write-once. Enable MaintenanceMode + RestoreEnabled for restore operations.`;

  const logData = {
    operation,
    entityName,
    entityId,
    correlationId,
    timestamp: new Date().toISOString()
  };

  if (ENFORCE_MODE) {
    console.error(`[ImmutabilityGuard] ENFORCED:`, message, logData);
    throw new Error(message);
  } else {
    // WARN mode: log but allow (24h observation period)
    console.warn(`[ImmutabilityGuard] WARNING (WARN_MODE):`, message, logData);
  }
}

/**
 * Check if entity is immutable.
 */
export function isImmutableEntity(entityName: string): boolean {
  return IMMUTABLE_ENTITIES.has(entityName);
}

/**
 * Get immutability enforcement status.
 */
export function getEnforcementStatus(): {
  mode: 'WARN' | 'ENFORCE';
  immutableEntities: string[];
} {
  return {
    mode: ENFORCE_MODE ? 'ENFORCE' : 'WARN',
    immutableEntities: Array.from(IMMUTABLE_ENTITIES)
  };
}

/**
 * Toggle enforcement mode (admin-only, for testing).
 * In production, only toggle after confirming 24h of zero violations.
 */
export function setEnforcementMode(enforce: boolean): void {
  const oldMode = ENFORCE_MODE ? 'ENFORCE' : 'WARN';
  ENFORCE_MODE = enforce;
  const newMode = ENFORCE_MODE ? 'ENFORCE' : 'WARN';
  console.log(`[ImmutabilityGuard] Enforcement mode changed: ${oldMode} → ${newMode}`);
}