import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    // Clear existing
    const existing = await base44.asServiceRole.entities.MaterialCatalog.filter({});
    for (const item of existing) {
      await base44.asServiceRole.entities.MaterialCatalog.delete(item.id);
    }

    // V2 Canonical Material Catalog - Real costs
    const catalog = [
      // VINYL 6FT WHITE
      { crm_name: 'Vinyl 6ft White Line Post', canonical_key: 'vinyl_post_line_6_white', category: 'post', material_type: 'vinyl', finish: 'white', size: '6ft', unit: 'each', cost: 45 },
      { crm_name: 'Vinyl 6ft White Corner Post', canonical_key: 'vinyl_post_corner_6_white', category: 'post', material_type: 'vinyl', finish: 'white', size: '6ft', unit: 'each', cost: 52 },
      { crm_name: 'Vinyl 6ft White End Post', canonical_key: 'vinyl_post_end_6_white', category: 'post', material_type: 'vinyl', finish: 'white', size: '6ft', unit: 'each', cost: 48 },
      { crm_name: 'Vinyl 6ft White Privacy Panel', canonical_key: 'vinyl_panel_privacy_6_white', category: 'panel', material_type: 'vinyl', finish: 'white', size: '6ft', unit: 'each', cost: 85, package_qty: 6 },
      { crm_name: 'Vinyl 6ft White Top Rail', canonical_key: 'vinyl_rail_top_6_white', category: 'rail', material_type: 'vinyl', finish: 'white', size: '6ft', unit: 'each', cost: 38, stick_length_ft: 21 },
      { crm_name: 'Vinyl Hardware Kit', canonical_key: 'vinyl_hardware_kit', category: 'hardware', material_type: 'vinyl', finish: 'none', unit: 'kit', cost: 12 },

      // CHAIN LINK 6FT GALV
      { crm_name: 'Chain Link 6ft Galvanized Post', canonical_key: 'chainlink_post_6_galv', category: 'post', material_type: 'chain_link', finish: 'galv', size: '6ft', unit: 'each', cost: 28 },
      { crm_name: 'Chain Link 6ft Galvanized Fabric 50ft', canonical_key: 'chainlink_fabric_6_galv_50ft', category: 'fabric', material_type: 'chain_link', finish: 'galv', size: '6ft', unit: 'roll', cost: 85, package_qty: 50 },
      { crm_name: 'Chain Link 6ft Galvanized Top Rail', canonical_key: 'chainlink_rail_top_6_galv', category: 'rail', material_type: 'chain_link', finish: 'galv', unit: 'each', cost: 32, stick_length_ft: 21 },
      { crm_name: 'Chain Link Hardware Kit', canonical_key: 'chainlink_hardware_kit', category: 'hardware', material_type: 'chain_link', finish: 'none', unit: 'kit', cost: 8 },

      // ALUMINUM 6FT BLACK
      { crm_name: 'Aluminum 6ft Black Post', canonical_key: 'aluminum_post_6_black', category: 'post', material_type: 'aluminum', finish: 'black', size: '6ft', unit: 'each', cost: 65 },
      { crm_name: 'Aluminum 6ft Black Panel', canonical_key: 'aluminum_panel_6_black', category: 'panel', material_type: 'aluminum', finish: 'black', size: '6ft', unit: 'each', cost: 120, package_qty: 6 },
      { crm_name: 'Aluminum 6ft Black Top Rail', canonical_key: 'aluminum_rail_top_6_black', category: 'rail', material_type: 'aluminum', finish: 'black', unit: 'each', cost: 50, stick_length_ft: 21 },
      { crm_name: 'Aluminum Hardware Kit', canonical_key: 'aluminum_hardware_kit', category: 'hardware', material_type: 'aluminum', finish: 'black', unit: 'kit', cost: 15 },

      // WOOD 6FT
      { crm_name: 'Wood 6ft Post', canonical_key: 'wood_post_6', category: 'post', material_type: 'wood', finish: 'none', size: '6ft', unit: 'each', cost: 22 },
      { crm_name: 'Wood 1x6 Privacy Board', canonical_key: 'wood_board_1x6_privacy', category: 'panel', material_type: 'wood', finish: 'none', unit: 'lf', cost: 2.5 },
      { crm_name: 'Wood 2x4 Rail', canonical_key: 'wood_rail_2x4', category: 'rail', material_type: 'wood', finish: 'none', unit: 'lf', cost: 1.8 },
      { crm_name: 'Wood Hardware Kit', canonical_key: 'wood_hardware_kit', category: 'hardware', material_type: 'wood', finish: 'none', unit: 'kit', cost: 10 },

      // GATES
      { crm_name: 'Single Gate 4ft', canonical_key: 'gate_single_4', category: 'gate', material_type: 'general', finish: 'none', unit: 'each', cost: 180 },
      { crm_name: 'Single Gate 6ft', canonical_key: 'gate_single_6', category: 'gate', material_type: 'general', finish: 'none', unit: 'each', cost: 220 },
      { crm_name: 'Double Gate 8ft', canonical_key: 'gate_double_8', category: 'gate', material_type: 'general', finish: 'none', unit: 'each', cost: 420 },

      // LABOR & MISC
      { crm_name: 'Labor - Linear Foot', canonical_key: 'labor_lf', category: 'labor', material_type: 'general', finish: 'none', unit: 'lf', cost: 10 },
      { crm_name: 'Delivery Fee', canonical_key: 'delivery_fee', category: 'fee', material_type: 'general', finish: 'none', unit: 'each', cost: 75 }
    ];

    const created = [];
    // Batch in groups of 5 to avoid rate limit
    for (let i = 0; i < catalog.length; i += 5) {
      const batch = catalog.slice(i, i + 5);
      const results = await Promise.all(
        batch.map(item => base44.asServiceRole.entities.MaterialCatalog.create(item))
      );
      created.push(...results.map(r => r.id));
      await new Promise(resolve => setTimeout(resolve, 500)); // delay between batches
    }

    return Response.json({
      status: 'COMPLETE',
      catalogItems: created.length,
      message: `Seeded ${created.length} material catalog items`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});