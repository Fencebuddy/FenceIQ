import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * COMPLETE MATERIAL CATALOG SEED MIGRATION
 * All fence systems: Chain Link, Vinyl, Wood, Aluminum
 * Applies new rules for vinyl support posts
 */

const COMPLETE_CATALOG = [
  // ========== CHAIN LINK FABRIC (ROLLS) ==========
  { crm_name: "4' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_4ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "4'", unit: "roll", cost: 85.00, package_qty: 50, aliases: ["4' galv fabric", "4ft chain link fabric galvanized", "HOT DIP 2-3/8x11.5x48in KK 50ft/rll"] },
  { crm_name: "5' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_5ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "5'", unit: "roll", cost: 95.00, package_qty: 50, aliases: ["5' galv fabric", "5ft chain link fabric galvanized"] },
  { crm_name: "6' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_6ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "6'", unit: "roll", cost: 105.00, package_qty: 50, aliases: ["6' galv fabric", "6ft chain link fabric galvanized"] },
  
  { crm_name: "4' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_4ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "4'", unit: "roll", cost: 125.00, package_qty: 50, aliases: ["Black Vinyl Coated Chain Link 4'", "4' black fabric", "BLK VNL Ext 2x9(13core)x48in KK 50ft/rll"] },
  { crm_name: "5' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_5ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "5'", unit: "roll", cost: 135.00, package_qty: 50, aliases: ["5' black fabric", "5ft chain link fabric black vinyl coated"] },
  { crm_name: "6' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_6ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "6'", unit: "roll", cost: 145.00, package_qty: 50, aliases: ["6' black fabric", "BLK VNL Ext 2x9(13core)x72in KK 50ft/rll"] },

  { crm_name: "4' Chain Link Fabric (Aluminized) - 50ft Roll", canonical_key: "chainlink_fabric_4ft_aluminized_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "aluminized", size: "4'", unit: "roll", cost: 95.00, package_qty: 50, aliases: ["ALUMINIZED 2x10x48in KK 50ft/rll", "4ft aluminized fabric"] },
  { crm_name: "6' Chain Link Fabric (Aluminized) - 50ft Roll", canonical_key: "chainlink_fabric_6ft_aluminized_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "aluminized", size: "6'", unit: "roll", cost: 115.00, package_qty: 50, aliases: ["ALUMINIZED 2x11x72in KK 50ft/rll", "6ft aluminized fabric"] },

  // ========== CHAIN LINK POSTS - GALV ==========
  { crm_name: "GALV Line Post 1-5/8in - 7ft", canonical_key: "chainlink_post_line_galv_1_625_7ft", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "galv", size: "1-5/8in", unit: "pcs", cost: 11.00, length_ft: 7, aliases: ["GALV 1-5/8\" x 7' x 16ga-SPS", "line post 1-5/8 7' galv"] },
  { crm_name: "GALV Line Post 1-5/8in - 9ft", canonical_key: "chainlink_post_line_galv_1_625_9ft", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "galv", size: "1-5/8in", unit: "pcs", cost: 13.00, length_ft: 9, aliases: ["GALV 1-5/8\" x 9' x 16ga-SPS", "line post 1-5/8 9' galv"] },
  
  // CRITICAL: 8ft terminal post for 4'/5' galv chain link (NOT vinyl support)
  { crm_name: "GALV Terminal Post 2-1/2in - 8ft (4' & 5' Chain Link Terminals)", canonical_key: "chainlink_post_terminal_galv_2_5in_8ft", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 17.00, length_ft: 8, aliases: ["GALV 2-1/2\" x 8' x 16ga-SPS", "terminal post 2-1/2 8ft galv", "end post 2-1/2 8ft", "corner post 2-1/2 8ft", "gate post 2-1/2 8ft", "4ft galv terminal", "5ft galv terminal"] },

  // ========== CHAIN LINK POSTS - BLACK VINYL ==========
  { crm_name: "BLK Line Post 1-5/8in - 7ft", canonical_key: "chainlink_post_line_black_1_625_7ft", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "black_vinyl", size: "1-5/8in", unit: "pcs", cost: 15.00, length_ft: 7, aliases: ["BLK PLY 1-5/8\" x 7' x PP065", "black line post 1-5/8 7ft"] },
  { crm_name: "BLK Line Post 1-5/8in - 9ft", canonical_key: "chainlink_post_line_black_1_625_9ft", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "black_vinyl", size: "1-5/8in", unit: "pcs", cost: 17.00, length_ft: 9, aliases: ["BLK PLY 1-5/8\" x 9' x PP065", "black line post 1-5/8 9ft"] },
  { crm_name: "BLK Terminal Post 2-1/2in - 8ft (4' & 5' Chain Link Terminals)", canonical_key: "chainlink_post_terminal_black_2_5in_8ft", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 23.00, length_ft: 8, aliases: ["BLK PLY 2-1/2\" x 8' x PP065", "black terminal post 2-1/2 8ft"] },

  // ========== CHAIN LINK TOP RAIL (STICK) ==========
  { crm_name: "GALV Top Rail 1-3/8in - 21ft Stick", canonical_key: "chainlink_rail_top_galv_1_375_21ft", category: "rail", sub_category: "top_rail", material_type: "chain_link", finish: "galv", size: "1-3/8in", unit: "stick", cost: 25.00, stick_length_ft: 21, aliases: ["GALV 1-3/8\" x 21' x 16ga-SPS SW x 17pc", "Galv 1-5/8 Top Rail", "Top Rail (1-3/8\" galv pipe)"] },
  { crm_name: "BLK Top Rail 1-3/8in - 21ft Stick", canonical_key: "chainlink_rail_top_black_1_375_21ft", category: "rail", sub_category: "top_rail", material_type: "chain_link", finish: "black_vinyl", size: "1-3/8in", unit: "stick", cost: 35.00, stick_length_ft: 21, aliases: ["BLK Commercial Top Rail", "BLK PLY 1-3/8\" x 21' x PP065 SW x 17pc"] },

  // ========== CHAIN LINK TENSION WIRE ==========
  { crm_name: "GALV Tension Wire (Bottom) - 100ft Roll", canonical_key: "chainlink_tension_wire_galv_100ft", category: "hardware", sub_category: "tension_wire", material_type: "chain_link", finish: "galv", size: "100ft", unit: "100lf", cost: 15.00, package_qty: 100, aliases: ["Tension Wire (bottom wire)", "Galv Tension Wire"] },
  { crm_name: "BLK Tension Wire (Bottom) - 100ft Roll", canonical_key: "chainlink_tension_wire_black_100ft", category: "hardware", sub_category: "tension_wire", material_type: "chain_link", finish: "black_vinyl", size: "100ft", unit: "100lf", cost: 20.00, package_qty: 100, aliases: ["Black Vinyl Tension Wire"] },

  // ========== CHAIN LINK CAPS ==========
  { crm_name: "GALV Dome Cap 2-1/2in (Terminal)", canonical_key: "chainlink_cap_dome_galv_2_5", category: "hardware", sub_category: "dome_cap", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.50, aliases: ["GALV 3\" Dome Cap", "Dome Caps (terminal posts)", "Galv Dome Cap"] },
  { crm_name: "GALV Loop Cap 1-5/8in (Line)", canonical_key: "chainlink_cap_loop_galv_1_625", category: "hardware", sub_category: "loop_cap", material_type: "chain_link", finish: "galv", size: "1-5/8in", unit: "pcs", cost: 1.25, aliases: ["Loop Caps (line posts)", "Galv Loop Cap", "PS Loop Cap 2-1/2 x 5/8"] },
  { crm_name: "BLK Dome Cap 2-1/2in (Terminal)", canonical_key: "chainlink_cap_dome_black_2_5", category: "hardware", sub_category: "dome_cap", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 2.00, aliases: ["BLK PLY Dome Cap 3\"", "Black Vinyl Dome Cap"] },
  { crm_name: "BLK Loop Cap 1-5/8in (Line)", canonical_key: "chainlink_cap_loop_black_1_625", category: "hardware", sub_category: "loop_cap", material_type: "chain_link", finish: "black_vinyl", size: "1-5/8in", unit: "pcs", cost: 1.75, aliases: ["BLK PLY Loop Cap", "BLK PLY AL LOOP CAP 1-5/8x1-3/8", "Black Vinyl Loop Cap"] },

  // ========== CHAIN LINK BANDS/ENDS/BOLTS - GALV ==========
  { crm_name: "GALV Brace Band 2-1/2in", canonical_key: "chainlink_band_brace_galv_2_5", category: "hardware", sub_category: "brace_band", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.80, aliases: ["GALV 3\" Brace Band", "Brace Bands (rail termination)", "Galv Brace Band", "BRACE BAND 2-1/2in"] },
  { crm_name: "GALV Tension Band 2-1/2in", canonical_key: "chainlink_band_tension_galv_2_5", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.20, aliases: ["Tension Bands", "Galv Tension Band 2.5", "TENSION BAND 2-1/2in"] },
  { crm_name: "GALV Tension Band 3in", canonical_key: "chainlink_band_tension_galv_3", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "galv", size: "3in", unit: "pcs", cost: 1.40, aliases: ["GALV 3\" Tension Band", "Galv Tension Band 3.0"] },
  { crm_name: "GALV Rail End Cup 1-3/8in", canonical_key: "chainlink_rail_end_galv_1_375", category: "hardware", sub_category: "rail_cup", material_type: "chain_link", finish: "galv", size: "1-3/8in", unit: "pcs", cost: 1.10, aliases: ["PS Rail End Combo 1 -58", "Rail End Cups", "Galv Rail Cup"] },
  { crm_name: "Carriage Bolt 5/16 x 1-1/4 (Galv)", canonical_key: "chainlink_bolt_carriage_5_16x1_25_galv", category: "hardware", sub_category: "carriage_bolt", material_type: "chain_link", finish: "galv", size: "5/16 x 1-1/4", unit: "pcs", cost: 0.15, package_qty: 50, aliases: ["BOLT/NUT 5/16x1-1/4in", "Carriage Bolts (all hardware)", "Galv Carriage Bolt"] },

  // ========== CHAIN LINK BANDS/ENDS/BOLTS - BLACK ==========
  { crm_name: "BLK Brace Band 2-1/2in", canonical_key: "chainlink_band_brace_black_2_5", category: "hardware", sub_category: "brace_band", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 2.50, aliases: ["BLK PLY BRACE BAND 2-1/2in", "BLK PLY Brace Band 3\"", "Black Vinyl Brace Band"] },
  { crm_name: "BLK Tension Band 2-1/2in", canonical_key: "chainlink_band_tension_black_2_5", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 1.75, aliases: ["BLK PLY TENSION BAND 2-1/2in", "Black Vinyl Tension Band 2.5"] },
  { crm_name: "BLK Tension Band 3in", canonical_key: "chainlink_band_tension_black_3", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "black_vinyl", size: "3in", unit: "pcs", cost: 2.00, aliases: ["BLK PLY Tension Band 3\"", "Black Vinyl Tension Band 3.0"] },
  { crm_name: "BLK Rail End Cup 1-3/8in", canonical_key: "chainlink_rail_end_black_1_375", category: "hardware", sub_category: "rail_cup", material_type: "chain_link", finish: "black_vinyl", size: "1-3/8in", unit: "pcs", cost: 1.50, aliases: ["BLK PLY AL RAIL END 1-3/8in", "Black Vinyl Rail Cup"] },
  { crm_name: "Carriage Bolt 5/16 x 1-1/4 (Black)", canonical_key: "chainlink_bolt_carriage_5_16x1_25_black", category: "hardware", sub_category: "carriage_bolt", material_type: "chain_link", finish: "black_vinyl", size: "5/16 x 1-1/4", unit: "pcs", cost: 0.20, package_qty: 50, aliases: ["black carriage bolt 5/16x1-1/4"] },

  // ========== CHAIN LINK TENSION BARS - GALV ==========
  { crm_name: "GALV Tension Bar 48in (4ft)", canonical_key: "chainlink_tension_bar_48_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "48in", unit: "pcs", cost: 4.50, aliases: ["GALV 96x34 Tension Bar", "TENSION BAR 48\"x5/8\"", "4' Tension Bars", "Galv Tension Bar 4ft"] },
  { crm_name: "GALV Tension Bar 60in (5ft)", canonical_key: "chainlink_tension_bar_60_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "60in", unit: "pcs", cost: 5.50, aliases: ["5' Tension Bars", "Galv Tension Bar 5ft"] },
  { crm_name: "GALV Tension Bar 72in (6ft)", canonical_key: "chainlink_tension_bar_72_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "72in", unit: "pcs", cost: 6.50, aliases: ["TENSION BAR 72\"x3/4\"", "6' Tension Bars", "Galv Tension Bar 6ft"] },

  // ========== CHAIN LINK TENSION BARS - BLACK ==========
  { crm_name: "BLK Tension Bar 48in (4ft)", canonical_key: "chainlink_tension_bar_48_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "48in", unit: "pcs", cost: 6.00, aliases: ["BLK PLY TENSION BAR 48\"x5/8\"", "BLK 96\" x 3/4\" Tension Bar", "Black Vinyl Tension Bar 4ft"] },
  { crm_name: "BLK Tension Bar 60in (5ft)", canonical_key: "chainlink_tension_bar_60_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "60in", unit: "pcs", cost: 7.00, aliases: ["5' black tension bar"] },
  { crm_name: "BLK Tension Bar 72in (6ft)", canonical_key: "chainlink_tension_bar_72_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "72in", unit: "pcs", cost: 8.00, aliases: ["BLK PLY TENSION BAR 72\"x3/4\""] },

  // ========== CHAIN LINK FENCE TIES ==========
  { crm_name: "Chain Link Fence Tie (Galv) 9ga x 6-1/2in", canonical_key: "chainlink_tie_galv_9ga_6_5", category: "hardware", sub_category: "fence_tie", material_type: "chain_link", finish: "galv", size: "9ga x 6-1/2in", unit: "pcs", cost: 0.08, package_qty: 100, aliases: ["Chain Link Fence Ties", "Galv Fence Tie"] },
  { crm_name: "Chain Link Fence Tie (Black) 9ga x 6-1/2in", canonical_key: "chainlink_tie_black_9ga_6_5", category: "hardware", sub_category: "fence_tie", material_type: "chain_link", finish: "black_vinyl", size: "9ga x 6-1/2in", unit: "pcs", cost: 0.12, package_qty: 100, aliases: ["BLK Alum Tie", "BLK VNL ALUM TIE 9gax6-1/2in", "Black Vinyl Fence Tie"] },
  { crm_name: "Chain Link Fence Tie (Aluminum) 9ga x 6-1/2in", canonical_key: "chainlink_tie_aluminum_9ga_6_5", category: "hardware", sub_category: "fence_tie", material_type: "chain_link", finish: "aluminum", size: "9ga x 6-1/2in", unit: "pcs", cost: 0.10, package_qty: 100, aliases: ["ALUM TIE 9gax6-1/2in"] },

  // ========== CHAIN LINK GATE HARDWARE ==========
  { crm_name: "Gate Hinges (pair) - Chain Link", canonical_key: "chainlink_gate_hinge_set_pair", category: "hardware", sub_category: "gate_hinge", material_type: "chain_link", finish: "none", size: "pair", unit: "set", cost: 12.00, aliases: ["Gate Hinges (sets of 2)", "FEMALE HINGE PS 1-3/8in", "MALE HINGE 2-1/2in"] },
  { crm_name: "Gate Drop Rod 3/8 x 30in", canonical_key: "chainlink_gate_drop_rod_3_8x30", category: "hardware", sub_category: "drop_rod", material_type: "chain_link", finish: "none", size: "3/8 x 30in", unit: "pcs", cost: 8.00, aliases: ["RES DROP ROD 3/8x30in", "RES DD drop rod", "BLK RES DROP ROD 3/8x30in"] },
  { crm_name: "Gate Caps - Chain Link", canonical_key: "chainlink_gate_caps", category: "hardware", sub_category: "gate_cap", material_type: "chain_link", finish: "none", size: "standard", unit: "pcs", cost: 1.50, aliases: ["Gate Caps"] },
  { crm_name: "Pool Gate Latch (Chain Link)", canonical_key: "chainlink_gate_latch_pool", category: "hardware", sub_category: "latch", material_type: "chain_link", finish: "none", size: "standard", unit: "pcs", cost: 25.00, aliases: ["Pool gate latch", "Trident 10\" Pool Latch"] },

  // ========== CHAIN LINK GATES - GALV ==========
  { crm_name: "RES SNG GATE 4'Wx4' NO SCR 1-3/8\" .055", canonical_key: "chainlink_gate_single_4x4_galv_res", category: "gate", sub_category: "single_gate", material_type: "chain_link", finish: "galv", size: "4'Wx4'", unit: "each", cost: 85.00, aliases: ["4' Chain Link Gate", "RES SNG 4x4"] },
  { crm_name: "RES SNG GATE 4'Wx6' NO SCR 1-3/8\" .055", canonical_key: "chainlink_gate_single_4x6_galv_res", category: "gate", sub_category: "single_gate", material_type: "chain_link", finish: "galv", size: "4'Wx6'", unit: "each", cost: 95.00, aliases: ["RES SNG 4x6"] },
  { crm_name: "RES DD 10'Wx4' NO SCR 1-3/8\" .055", canonical_key: "chainlink_gate_double_10x4_galv_res", category: "gate", sub_category: "double_gate", material_type: "chain_link", finish: "galv", size: "10'Wx4'", unit: "each", cost: 165.00, aliases: ["RES DD 10x4"] },

  // ========== CHAIN LINK GATES - BLACK ==========
  { crm_name: "BLK RES SNG 4'Wx4' NO SCR 1-3/8\"SP055", canonical_key: "chainlink_gate_single_4x4_black_res", category: "gate", sub_category: "single_gate", material_type: "chain_link", finish: "black_vinyl", size: "4'Wx4'", unit: "each", cost: 125.00, aliases: ["Black Vinyl 4x4 Gate"] },
  { crm_name: "BLK RES SNG 4'Wx6' NO SCR 1-3/8\" SP055 *Fab: BLK EXT 2x9", canonical_key: "chainlink_gate_single_4x6_black_res", category: "gate", sub_category: "single_gate", material_type: "chain_link", finish: "black_vinyl", size: "4'Wx6'", unit: "each", cost: 135.00, aliases: ["Black Vinyl 4x6 Gate"] },
  { crm_name: "BLK RES DD 10'Wx6' NO SCR 1-3/8\" SP055 *Fab: BLK EXT 2x9 KK", canonical_key: "chainlink_gate_double_10x6_black_res", category: "gate", sub_category: "double_gate", material_type: "chain_link", finish: "black_vinyl", size: "10'Wx6'", unit: "each", cost: 265.00, aliases: ["Black Vinyl 10x6 Double Gate"] },

  // ========== VINYL POST SLEEVES - WHITE ==========
  { crm_name: "VINYL LINE POST 5x5x108 WHITE", canonical_key: "vinyl_post_line_5x5_108_white", category: "post", sub_category: "line_post", material_type: "vinyl", finish: "white", size: "5x5x108", unit: "each", cost: 45.00, aliases: ["White Vinyl Line Post", "Lakeshore WHITE 5x5x108in LINE POST (6ft Fence)"] },
  { crm_name: "VINYL END POST 5x5x108 WHITE", canonical_key: "vinyl_post_end_5x5_108_white", category: "post", sub_category: "end_post", material_type: "vinyl", finish: "white", size: "5x5x108", unit: "each", cost: 45.00, aliases: ["White Vinyl End Post", "ANDREW WHITE 5x5x108in END POST (6ft Fence)"] },
  { crm_name: "VINYL CORNER POST 5x5x108 WHITE", canonical_key: "vinyl_post_corner_5x5_108_white", category: "post", sub_category: "corner_post", material_type: "vinyl", finish: "white", size: "5x5x108", unit: "each", cost: 45.00, aliases: ["White Vinyl Corner Post", "Lakeshore WHITE 5x5x108in CORNER POST (6ft Fence)"] },
  { crm_name: "VINYL GATE POST 5x5x108 WHITE", canonical_key: "vinyl_post_gate_5x5_108_white", category: "post", sub_category: "gate_post", material_type: "vinyl", finish: "white", size: "5x5x108", unit: "each", cost: 45.00, aliases: ["White Vinyl Gate Post"] },
  
  { crm_name: "LINE - 5\" X 5\" X 7' POST", canonical_key: "vinyl_post_line_5x5_84_white", category: "post", sub_category: "line_post", material_type: "vinyl", finish: "white", size: "5x5x84", unit: "each", cost: 40.00, aliases: ["5x5x84 vinyl line post", "7ft vinyl line post"] },
  { crm_name: "CORNER - 5\" X 5\" X 7' POST", canonical_key: "vinyl_post_corner_5x5_84_white", category: "post", sub_category: "corner_post", material_type: "vinyl", finish: "white", size: "5x5x84", unit: "each", cost: 40.00, aliases: ["5x5x84 vinyl corner post", "7ft vinyl corner post"] },

  { crm_name: "Colored Vinyl Post 4x7", canonical_key: "vinyl_post_colored_4x4_84", category: "post", sub_category: "line_post", material_type: "vinyl", finish: "colored", size: "4x4x84", unit: "each", cost: 50.00, aliases: ["colored vinyl 4x4x7 post"] },

  // ========== VINYL SUPPORT POSTS (STEEL) - CRITICAL NEW RULE ==========
  { crm_name: "2.5\" Galvanized Post (10ft) - VINYL SUPPORT", canonical_key: "vinyl_support_post_galv_2_5in_10ft", category: "post", sub_category: "support_post", material_type: "steel", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 20.00, length_ft: 10, aliases: ["2.5\" Galvanized Post", "2-1/2 galvanized post 10ft", "vinyl support post", "surface mount support post", "wind support post"] },
  { crm_name: "GALV 2-1/2\" x 7' x 16ga-SPS (Vinyl Support Optional)", canonical_key: "vinyl_support_post_galv_2_5in_7ft", category: "post", sub_category: "support_post", material_type: "steel", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 15.00, length_ft: 7, aliases: ["GALV 2-1/2\" x 7' x 16ga-SPS", "2.5 galv 7ft support"] },

  // ========== VINYL INSERTS / STIFFENERS ==========
  { crm_name: "5\" X 5\" X 7' ALUMINUM GATE POST INSERT", canonical_key: "vinyl_insert_gate_post_alum_5x5_84", category: "hardware", sub_category: "post_insert", material_type: "aluminum", finish: "aluminum", size: "5x5x84", unit: "each", cost: 28.00, aliases: ["5-in Aluminum Metal Post Insert For Vinyl"] },
  { crm_name: "5x5x96 ALUM POST STIFFENER", canonical_key: "vinyl_insert_post_alum_5x5_96", category: "hardware", sub_category: "post_stiffener", material_type: "aluminum", finish: "aluminum", size: "5x5x96", unit: "each", cost: 30.00, aliases: ["alum post stiffener 5x5x96"] },
  { crm_name: "Vinyl Post Donut", canonical_key: "vinyl_post_donut_5x5", category: "hardware", sub_category: "post_donut", material_type: "vinyl", finish: "none", size: "5x5", unit: "each", cost: 5.00, aliases: ["post donut", "no-dig donut"] },

  // ========== VINYL CAPS ==========
  { crm_name: "5x5 POST FLAT CAP - WHITE", canonical_key: "vinyl_cap_5x5_white_flat", category: "hardware", sub_category: "post_cap", material_type: "vinyl", finish: "white", size: "5x5", unit: "pcs", cost: 3.50, aliases: ["lakeshore Flat Cap - White", "5-in W x 5-in L White Vinyl Fence Post Cap", "5x5 FLAT EXTERIOR POST CAP", "NEW ENGLAND 5\" X 5\" POST CAP"] },
  { crm_name: "Colored Vinyl Post Cap", canonical_key: "vinyl_cap_colored_5x5", category: "hardware", sub_category: "post_cap", material_type: "vinyl", finish: "colored", size: "5x5", unit: "pcs", cost: 4.50, aliases: ["Colored Vinyl Post Cap"] },

  // ========== VINYL PANELS ==========
  { crm_name: "6' Stevens Vinyl Privacy Fence", canonical_key: "vinyl_panel_privacy_6ft_white_stevens", category: "panel", sub_category: "privacy_panel", material_type: "vinyl", finish: "white", size: "6'", unit: "each", cost: 95.00, aliases: ["6' Privacy Vinyl Panels"] },
  { crm_name: "6' Lakeshore Vinyl Privacy Fence", canonical_key: "vinyl_panel_privacy_6ft_white_lakeshore", category: "panel", sub_category: "privacy_panel", material_type: "vinyl", finish: "white", size: "6'", unit: "each", cost: 95.00, aliases: ["Lakeshore 6ft vinyl panel"] },
  { crm_name: "Colored 4' Vinyl", canonical_key: "vinyl_panel_4ft_colored", category: "panel", sub_category: "privacy_panel", material_type: "vinyl", finish: "colored", size: "4'", unit: "each", cost: 85.00, aliases: ["4ft colored vinyl panel"] },

  // ========== VINYL RAILS / BRACKETS ==========
  { crm_name: "8-ft H x 0.5-ft W White Vinyl Flat-top Fence Rail", canonical_key: "vinyl_rail_flat_top_8ft_white", category: "rail", sub_category: "fence_rail", material_type: "vinyl", finish: "white", size: "8ft", unit: "stick", cost: 22.00, stick_length_ft: 8, aliases: ["white vinyl rail 8ft"] },
  { crm_name: "White Premium Vinyl Railing Brackets", canonical_key: "vinyl_bracket_railing_white_set", category: "hardware", sub_category: "bracket", material_type: "vinyl", finish: "white", size: "standard", unit: "set", cost: 12.00, aliases: ["vinyl railing brackets"] },
  { crm_name: "White Premium Vinyl Stair Rail Brackets", canonical_key: "vinyl_bracket_stair_rail_white_set", category: "hardware", sub_category: "bracket", material_type: "vinyl", finish: "white", size: "standard", unit: "set", cost: 14.00, aliases: ["vinyl stair rail brackets"] },

  // ========== VINYL GATES + REINFORCEMENT ==========
  { crm_name: "SAVANNAH 4'H X 44.5\"W SINGLE GATE", canonical_key: "vinyl_gate_single_44_5in_4ft_savannah", category: "gate", sub_category: "single_gate", material_type: "vinyl", finish: "white", size: "44.5\"W x 4'H", unit: "each", cost: 245.00, aliases: ["Savannah 44.5 single gate"] },
  { crm_name: "SAVANNAH 4'H X 62.5\"W DOUBLE GATE", canonical_key: "vinyl_gate_double_62_5in_4ft_savannah", category: "gate", sub_category: "double_gate", material_type: "vinyl", finish: "white", size: "62.5\"W x 4'H", unit: "each", cost: 385.00, aliases: ["Savannah 62.5 double gate"] },
  { crm_name: "WHITE 50\"x6' PRE-ASMB GT", canonical_key: "vinyl_gate_single_50in_6ft_preassembled_white", category: "gate", sub_category: "single_gate", material_type: "vinyl", finish: "white", size: "50\"W x 6'H", unit: "each", cost: 285.00, aliases: ["white 50in 6ft gate preassembled"] },
  { crm_name: "Split Rail 4-ft W White Vinyl Fence Gate", canonical_key: "vinyl_gate_split_rail_4ft_white", category: "gate", sub_category: "single_gate", material_type: "vinyl", finish: "white", size: "4'", unit: "each", cost: 195.00, aliases: ["split rail vinyl gate 4ft"] },
  { crm_name: "Emblem 6-ft H x 5-ft W White Vinyl Fence Gate", canonical_key: "vinyl_gate_emblem_5ftx6ft_white", category: "gate", sub_category: "single_gate", material_type: "vinyl", finish: "white", size: "5'W x 6'H", unit: "each", cost: 325.00, aliases: ["emblem vinyl gate 5x6"] },

  { crm_name: "Aluminum Gate Beam (I-Beam Reinforcement)", canonical_key: "vinyl_gate_reinforcement_ibeam", category: "hardware", sub_category: "gate_reinforcement", material_type: "vinyl", finish: "aluminum", size: "standard", unit: "each", cost: 35.00, aliases: ["I-beam", "gate i-beam", "gate reinforcement"] },

  // ========== VINYL GATE HARDWARE ==========
  { crm_name: "5\" Locklatch gate latch", canonical_key: "vinyl_gate_latch_lokklatch_5in", category: "hardware", sub_category: "latch", material_type: "vinyl", finish: "none", size: "5in", unit: "each", cost: 18.00, aliases: ["Locklatch 5 inch"] },
  { crm_name: "4\" Locklatch gate lock (Double gate)", canonical_key: "vinyl_gate_lock_lokklatch_4in_double", category: "hardware", sub_category: "lock", material_type: "vinyl", finish: "none", size: "4in", unit: "each", cost: 22.00, aliases: ["Locklatch 4 inch double"] },
  { crm_name: "Vinyl Gate Hinges (sets of 2)", canonical_key: "vinyl_gate_hinge_set_pair", category: "hardware", sub_category: "gate_hinge", material_type: "vinyl", finish: "none", size: "pair", unit: "set", cost: 18.00, aliases: ["vinyl gate hinges pair"] },
  { crm_name: "Weatherables Cornerstone Heavy Duty Multi-Adjust Hinges", canonical_key: "vinyl_gate_hinge_weatherables_cornerstone_set", category: "hardware", sub_category: "gate_hinge", material_type: "vinyl", finish: "none", size: "heavy_duty", unit: "set", cost: 35.00, aliases: ["weatherables cornerstone hinges"] },
  { crm_name: "True Close Hinges", canonical_key: "vinyl_gate_hinge_trueclose_set", category: "hardware", sub_category: "gate_hinge", material_type: "vinyl", finish: "none", size: "self_closing", unit: "set", cost: 45.00, aliases: ["true close self closing hinges"] },
  { crm_name: "Armor Latch", canonical_key: "vinyl_gate_latch_armor", category: "hardware", sub_category: "latch", material_type: "vinyl", finish: "none", size: "standard", unit: "each", cost: 28.00, aliases: ["armor gate latch"] },
  { crm_name: "Trident 10\" Pool Latch", canonical_key: "vinyl_gate_latch_pool_trident_10in", category: "hardware", sub_category: "latch", material_type: "vinyl", finish: "none", size: "10in", unit: "each", cost: 32.00, aliases: ["trident pool latch 10 inch"] },
  { crm_name: "Key Lockable Stainless Steel Drop Rod", canonical_key: "vinyl_gate_drop_rod_lockable_stainless", category: "hardware", sub_category: "drop_rod", material_type: "vinyl", finish: "none", size: "lockable", unit: "each", cost: 38.00, aliases: ["lockable drop rod stainless"] },
  { crm_name: "Cane Bolts (drop rods)", canonical_key: "vinyl_gate_drop_rod_cane_bolt", category: "hardware", sub_category: "drop_rod", material_type: "vinyl", finish: "none", size: "standard", unit: "each", cost: 15.00, aliases: ["cane bolt drop rod"] },

  // ========== WOOD POSTS ==========
  { crm_name: "Post - Severe Weather - 4-in x 4-in x 8-ft #2 SYP Ground Contact PT", canonical_key: "wood_post_4x4x8_pt", category: "post", sub_category: "wood_post", material_type: "wood", finish: "none", size: "4x4x8", unit: "each", cost: 18.00, aliases: ["PT 4x4x8 post", "pressure treated 4x4x8"] },

  // ========== WOOD RAILS / STRINGERS ==========
  { crm_name: "Stringer - Severe Weather - 2-in x 4-in x 8-ft #2 SYP PT", canonical_key: "wood_rail_2x4x8_pt", category: "rail", sub_category: "stringer", material_type: "wood", finish: "none", size: "2x4x8", unit: "board", cost: 8.50, aliases: ["2x4x8 pressure treated", "Severe Weather - 2-in x 4-in x 8-ft #2 Southern Yellow Pine"] },

  // ========== WOOD PICKETS ==========
  { crm_name: "Picket - Severe Weather - 5/8-in x 5-1/2-in x 6-ft PT", canonical_key: "wood_picket_5_8x5_5x6_pt", category: "misc", sub_category: "picket", material_type: "wood", finish: "none", size: "5/8x5.5x6", unit: "each", cost: 2.50, aliases: ["Pine Pickets", "PT pickets 6ft"] },

  // ========== WOOD FASTENERS ==========
  { crm_name: "Siding nails - coil", canonical_key: "wood_fastener_coil_nails", category: "hardware", sub_category: "fastener", material_type: "wood", finish: "none", size: "coil", unit: "roll", cost: 45.00, aliases: ["coil nails", "siding nails coil"] },

  // ========== WOOD POSTMASTER ==========
  { crm_name: "Lifetime Steel Post 8 ft. x 4 in. Powder Coated Steel Metal Fence Post with Top Plate", canonical_key: "wood_postmaster_8ft_with_top_plate", category: "post", sub_category: "steel_post", material_type: "steel", finish: "none", size: "8ft x 4in", unit: "each", cost: 32.00, aliases: ["PostMaster 8ft", "steel post wood reinforcement"] },

  // ========== WOOD GATES ==========
  { crm_name: "6x4 Wood Privacy Gate", canonical_key: "wood_gate_single_4x6_privacy", category: "gate", sub_category: "single_gate", material_type: "wood", finish: "none", size: "4'W x 6'H", unit: "each", cost: 125.00, aliases: ["wood privacy gate 6ft high"] },
  { crm_name: "Steel gate frame - wood", canonical_key: "wood_gate_frame_steel_kit", category: "hardware", sub_category: "gate_frame", material_type: "steel", finish: "none", size: "standard", unit: "kit", cost: 45.00, aliases: ["steel gate frame kit wood"] },

  // ========== ALUMINUM POSTS ==========
  { crm_name: "2\" X 2\" X 6' LINE ALUMINUM POST", canonical_key: "alum_post_line_2x2x6", category: "post", sub_category: "line_post", material_type: "aluminum", finish: "aluminum", size: "2x2x6", unit: "each", cost: 35.00, aliases: ["aluminum line post 2x2 6ft"] },
  { crm_name: "2\" X 2\" X 6' END ALUMINUM POST", canonical_key: "alum_post_end_2x2x6", category: "post", sub_category: "end_post", material_type: "aluminum", finish: "aluminum", size: "2x2x6", unit: "each", cost: 35.00, aliases: ["aluminum end post 2x2 6ft"] },
  { crm_name: "2\" X 2\" X 6' CORNER ALUMINUM POST", canonical_key: "alum_post_corner_2x2x6", category: "post", sub_category: "corner_post", material_type: "aluminum", finish: "aluminum", size: "2x2x6", unit: "each", cost: 35.00, aliases: ["aluminum corner post 2x2 6ft"] },

  // ========== ALUMINUM HARDWARE ==========
  { crm_name: "AL DOME CAP 1-3/8in", canonical_key: "alum_cap_dome_1_375", category: "hardware", sub_category: "dome_cap", material_type: "aluminum", finish: "aluminum", size: "1-3/8in", unit: "pcs", cost: 2.50, aliases: ["aluminum dome cap 1.375"] },
  { crm_name: "AL DOME CAP 2-1/2in", canonical_key: "alum_cap_dome_2_5", category: "hardware", sub_category: "dome_cap", material_type: "aluminum", finish: "aluminum", size: "2-1/2in", unit: "pcs", cost: 3.50, aliases: ["aluminum dome cap 2.5"] },
  { crm_name: "AL LOOP CAP 1-5/8\"x1-3/8\"", canonical_key: "alum_cap_loop_1_625x1_375", category: "hardware", sub_category: "loop_cap", material_type: "aluminum", finish: "aluminum", size: "1-5/8x1-3/8", unit: "pcs", cost: 2.25, aliases: ["aluminum loop cap"] },
  { crm_name: "AL RAIL END 1-3/8in", canonical_key: "alum_rail_end_1_375", category: "hardware", sub_category: "rail_end", material_type: "aluminum", finish: "aluminum", size: "1-3/8in", unit: "pcs", cost: 2.00, aliases: ["aluminum rail end 1.375"] },

  // ========== CONCRETE ==========
  { crm_name: "QUIKRETE 50-lb Fast Setting Concrete Mix", canonical_key: "concrete_fastset_50lb", category: "concrete", sub_category: "fast_set", material_type: "general", finish: "none", size: "50lb", unit: "bag", cost: 8.50, aliases: ["Quick Crete (50 lb bags)", "quikrete 50lb"] },

  // ========== FEES ==========
  { crm_name: "Material Delivery", canonical_key: "fee_material_delivery", category: "fee", sub_category: "delivery", material_type: "general", finish: "none", size: "standard", unit: "each", cost: 75.00, aliases: ["delivery fee", "material delivery charge"] },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const existingCatalog = await base44.asServiceRole.entities.MaterialCatalog.list('-created_date', 2000);
    
    const results = {
      added: [],
      updated: [],
      relinked: [],
      skipped: [],
      errors: []
    };

    for (const item of COMPLETE_CATALOG) {
      try {
        // Check if item exists by canonical_key OR crm_name
        const existing = existingCatalog.find(cat => 
          cat.canonical_key === item.canonical_key ||
          cat.material_id === item.canonical_key ||
          cat.crm_name === item.crm_name
        );

        if (existing) {
          // Update/relink existing item
          const updates = {};
          
          // Always set canonical_key if missing or wrong
          if (existing.canonical_key !== item.canonical_key && existing.material_id !== item.canonical_key) {
            updates.canonical_key = item.canonical_key;
            updates.material_id = item.canonical_key;
            results.relinked.push({ id: existing.id, name: item.crm_name, old_key: existing.canonical_key || existing.material_id, new_key: item.canonical_key });
          }
          
          // Add missing fields (preserve user costs)
          if (!existing.aliases || existing.aliases.length === 0) updates.aliases = item.aliases;
          if (!existing.sub_category) updates.sub_category = item.sub_category;
          if (!existing.finish) updates.finish = item.finish;
          if (!existing.size) updates.size = item.size;
          if (!existing.package_qty) updates.package_qty = item.package_qty;
          if (!existing.stick_length_ft && item.stick_length_ft) updates.stick_length_ft = item.stick_length_ft;
          if (!existing.length_ft && item.length_ft) updates.length_ft = item.length_ft;
          
          if (Object.keys(updates).length > 0) {
            await base44.asServiceRole.entities.MaterialCatalog.update(existing.id, updates);
            results.updated.push({ id: existing.id, name: item.crm_name, updates });
          } else {
            results.skipped.push({ id: existing.id, name: item.crm_name, reason: 'Already complete' });
          }
        } else {
          // Create new item
          const newItem = await base44.asServiceRole.entities.MaterialCatalog.create({
            ...item,
            material_id: item.canonical_key,
            active: true,
            source: 'seed_migration'
          });
          results.added.push({ id: newItem.id, name: item.crm_name });
        }
      } catch (error) {
        results.errors.push({ name: item.crm_name, error: error.message });
      }
    }

    return Response.json({
      success: true,
      summary: {
        total: COMPLETE_CATALOG.length,
        added: results.added.length,
        updated: results.updated.length,
        relinked: results.relinked.length,
        skipped: results.skipped.length,
        errors: results.errors.length
      },
      results
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});