/**
 * SWITCH CONTEXT
 * 
 * Switches the authenticated user's active context.
 * Validates the requested context against actual memberships.
 * Logs the switch to PlatformAuditLog.
 * 
 * Body: { context_type: "platform" | "company", context_id: string | null }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const { context_type, context_id } = body;

    if (!context_type || !['platform', 'company'].includes(context_type)) {
      return Response.json({ error: 'Invalid context_type. Must be "platform" or "company".' }, { status: 400 });
    }

    if (context_type === 'platform' && context_id !== null && context_id !== undefined) {
      return Response.json({ error: 'Platform context must have null context_id.' }, { status: 400 });
    }

    if (context_type === 'company' && !context_id) {
      return Response.json({ error: 'Company context requires a context_id.' }, { status: 400 });
    }

    // Validate membership for requested context
    if (context_type === 'platform') {
      const memberships = await base44.asServiceRole.entities.PlatformMembership.filter({
        user_id: user.id,
        status: 'active'
      });
      if (memberships.length === 0) {
        return Response.json({ error: 'Forbidden: No platform membership.' }, { status: 403 });
      }

      var resolvedRole = memberships[0].role;
      var resolvedLabel = 'FenceIQ Platform';
      var resolvedCompanyName = null;

    } else {
      // company context
      const memberships = await base44.asServiceRole.entities.CompanyMembership.filter({
        user_id: user.id,
        tenant_company_id: context_id,
        status: 'active'
      });
      if (memberships.length === 0) {
        return Response.json({ error: 'Forbidden: No active membership in this company.' }, { status: 403 });
      }

      const companies = await base44.asServiceRole.entities.TenantCompany.filter({
        id: context_id,
        status: 'active'
      });
      if (companies.length === 0) {
        return Response.json({ error: 'Company not found or inactive.' }, { status: 404 });
      }

      var resolvedRole = memberships[0].role;
      var resolvedLabel = companies[0].company_name;
      var resolvedCompanyName = companies[0].company_name;
    }

    // Load previous context for audit log
    const prevSessions = await base44.asServiceRole.entities.UserSessionContext.filter({
      user_id: user.id
    });
    const prevSession = prevSessions[0] || null;
    const prevContextType = prevSession?.active_context_type;
    const prevContextId = prevSession?.active_context_id;

    // Update session context
    const contextData = {
      user_id: user.id,
      user_email: user.email,
      active_context_type: context_type,
      active_context_id: context_id || null,
      active_role: resolvedRole,
      active_company_name: resolvedCompanyName,
      last_switched_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    };

    let updatedSession;
    if (prevSession) {
      updatedSession = await base44.asServiceRole.entities.UserSessionContext.update(
        prevSession.id, contextData
      );
    } else {
      updatedSession = await base44.asServiceRole.entities.UserSessionContext.create(contextData);
    }

    // Audit log
    await base44.asServiceRole.entities.PlatformAuditLog.create({
      actor_user_id: user.id,
      actor_email: user.email,
      actor_context_type: context_type,
      actor_context_id: context_id || null,
      action: 'CONTEXT_SWITCH',
      target_type: context_type === 'platform' ? 'platform' : 'TenantCompany',
      target_id: context_id || null,
      metadata: {
        from_context_type: prevContextType,
        from_context_id: prevContextId,
        to_context_type: context_type,
        to_context_id: context_id,
        to_role: resolvedRole
      }
    });

    console.log('[switchContext] Context switched:', {
      user: user.email,
      to: context_type,
      context_id,
      role: resolvedRole
    });

    return Response.json({
      status: 'ok',
      activeContext: {
        type: context_type,
        id: context_id || null,
        role: resolvedRole,
        label: resolvedLabel,
        companyName: resolvedCompanyName
      }
    });

  } catch (error) {
    console.error('[switchContext] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});