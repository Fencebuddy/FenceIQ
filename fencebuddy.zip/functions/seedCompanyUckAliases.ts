import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Seed CompanyUckAlias for known takeoff->catalog mismatches
 * Fixes canonical contract violations without changing takeoff generation
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin-only
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { companyId } = await req.json();

    if (!companyId) {
      return Response.json({ error: 'companyId required' }, { status: 400 });
    }

    console.log('[seedCompanyUckAliases] Starting for company:', companyId);

    // Define known aliases
    const aliases = [
      // Wood posts
      {
        fromUck: 'wood_post_4x4_lifetime_steel',
        toUck: 'wood_post_driven_4x4_steel',
        notes: 'Lifetime -> driven mapping'
      },
      {
        fromUck: 'wood_post_6x6_concrete',
        toUck: 'wood_post_set_6x6_concrete',
        notes: 'Set post mapping'
      },
      // Wood rails
      {
        fromUck: 'wood_rail_2x4_8ft_treated',
        toUck: 'wood_rail_2x4x8_treated',
        notes: 'Rail size normalization'
      },
      {
        fromUck: 'wood_rail_2x6_16ft',
        toUck: 'wood_rail_2x6x16_treated',
        notes: 'Rail size + default treated'
      },
      // Wood hardware
      {
        fromUck: 'wood_hardware_nail_2in_galv',
        toUck: 'wood_hardware_nail_galv_2in',
        notes: 'Nail attribute order normalization'
      },
      {
        fromUck: 'wood_hardware_screw_3in_deck',
        toUck: 'wood_hardware_screw_deck_3in',
        notes: 'Deck screw mapping'
      },
      {
        fromUck: 'wood_hardware_bracket_light',
        toUck: 'wood_hardware_bracket_steel_light',
        notes: 'Bracket material explicit'
      },
      // Vinyl posts
      {
        fromUck: 'vinyl_post_galv_2_5',
        toUck: 'vinyl_hardware_galvanized_post_2_5in',
        notes: 'Vinyl post material categorization'
      },
      // Vinyl hardware - donuts
      {
        fromUck: 'vinyl_donut_nodig',
        toUck: 'vinyl_hardware_nodig_donut',
        notes: 'Donut accessory mapping'
      },
      {
        fromUck: 'vinyl_donut_dig',
        toUck: 'vinyl_hardware_dig_donut',
        notes: 'Digging donut mapping'
      },
      // Vinyl fabric/slats
      {
        fromUck: 'vinyl_slats_white_6ft',
        toUck: 'vinyl_fabric_slats_white_6ft',
        notes: 'Slat material categorization'
      },
      // Chain link
      {
        fromUck: 'chainlink_fabric_6ft_galv_50ft_roll',
        toUck: 'chainlink_fabric_galvanized_6ft_50ft_roll',
        notes: 'Fabric finish normalization'
      },
      {
        fromUck: 'chainlink_post_galv_1_5x1_5',
        toUck: 'chainlink_post_galvanized_1_5in_sq',
        notes: 'Post size normalization'
      }
    ];

    const created = [];
    const updated = [];
    const failed = [];

    // Upsert each alias
    for (const alias of aliases) {
      try {
        // Check if exists
        const existing = await base44.entities.CompanyUckAlias.filter({
          companyId,
          fromUck: alias.fromUck
        });

        const aliasRecord = {
          companyId,
          fromUck: alias.fromUck,
          toUck: alias.toUck,
          fromAttributesSignature: alias.fromAttributesSignature || null,
          toAttributesPatch: alias.toAttributesPatch || null,
          enabled: true,
          locked: true, // System-seeded
          source: 'auto-seeded',
          notes: alias.notes,
          createdAt: new Date().toISOString()
        };

        if (existing.length > 0) {
          await base44.entities.CompanyUckAlias.update(existing[0].id, aliasRecord);
          updated.push(alias.fromUck);
        } else {
          await base44.entities.CompanyUckAlias.create(aliasRecord);
          created.push(alias.fromUck);
        }
      } catch (err) {
        console.error('[seedCompanyUckAliases] Error processing alias:', alias.fromUck, err);
        failed.push({ fromUck: alias.fromUck, error: err.message });
      }
    }

    return Response.json({
      success: true,
      companyId,
      totalAliases: aliases.length,
      created: created.length,
      updated: updated.length,
      failed: failed.length,
      createdList: created,
      failedList: failed,
      message: `Seeded ${created.length} aliases, updated ${updated.length}, failed ${failed.length}`
    });
  } catch (error) {
    console.error('[seedCompanyUckAliases] ERROR:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});