import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * CHAIN LINK CATALOG SEED MIGRATION
 * Adds missing items, normalizes units, deduplicates, and adds aliases
 * Preserves existing user-edited costs
 */

// Canonical chain link catalog items
const CHAIN_LINK_CATALOG = [
  // ========== FABRIC (ROLLS) ==========
  { crm_name: "4' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_4ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "4'", unit: "roll", cost: 85.00, package_qty: 50, aliases: ["4' Chain Link Fabric (Galvanized)", "4ft Galv Fabric"] },
  { crm_name: "5' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_5ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "5'", unit: "roll", cost: 95.00, package_qty: 50, aliases: ["5' Chain Link Fabric (Galvanized)", "5ft Galv Fabric"] },
  { crm_name: "6' Chain Link Fabric (Galvanized) - 50ft Roll", canonical_key: "chainlink_fabric_6ft_galv_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "galv", size: "6'", unit: "roll", cost: 105.00, package_qty: 50, aliases: ["6' Chain Link Fabric (Galvanized)", "6ft Galv Fabric"] },
  
  { crm_name: "4' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_4ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "4'", unit: "roll", cost: 125.00, package_qty: 50, aliases: ["4' Chain Link Fabric (Black Vinyl Coated)", "4ft Black Vinyl Fabric"] },
  { crm_name: "5' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_5ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "5'", unit: "roll", cost: 135.00, package_qty: 50, aliases: ["5' Chain Link Fabric (Black Vinyl Coated)", "5ft Black Vinyl Fabric"] },
  { crm_name: "6' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll", canonical_key: "chainlink_fabric_6ft_black_vinyl_50ft_roll", category: "fabric", sub_category: "chain_link_fabric", material_type: "chain_link", finish: "black_vinyl", size: "6'", unit: "roll", cost: 145.00, package_qty: 50, aliases: ["6' Chain Link Fabric (Black Vinyl Coated)", "6ft Black Vinyl Fabric"] },

  // ========== POSTS - GALVANIZED ==========
  { crm_name: "GALV Terminal Post (End) - 2-1/2in", canonical_key: "chainlink_post_terminal_end_galv_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 18.00, aliases: ["Terminal Posts (End)", "Galv End Post"] },
  { crm_name: "GALV Terminal Post (Corner) - 2-1/2in", canonical_key: "chainlink_post_terminal_corner_galv_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 18.00, aliases: ["Terminal Posts (Corner)", "Galv Corner Post"] },
  { crm_name: "GALV Terminal Post (Gate) - 2-1/2in", canonical_key: "chainlink_post_terminal_gate_galv_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 18.00, aliases: ["Terminal Posts (Gate)", "Galv Gate Post"] },
  { crm_name: "GALV Line Post - 1-5/8in", canonical_key: "chainlink_post_line_galv_1_625", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "galv", size: "1-5/8in", unit: "pcs", cost: 12.00, aliases: ["Line Posts (10' spacing)", "Galv Line Post"] },

  // ========== POSTS - BLACK VINYL COATED ==========
  { crm_name: "BLK Terminal Post (End) - 2-1/2in", canonical_key: "chainlink_post_terminal_end_black_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 24.00, aliases: ["Black Vinyl End Post"] },
  { crm_name: "BLK Terminal Post (Corner) - 2-1/2in", canonical_key: "chainlink_post_terminal_corner_black_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 24.00, aliases: ["Black Vinyl Corner Post"] },
  { crm_name: "BLK Terminal Post (Gate) - 2-1/2in", canonical_key: "chainlink_post_terminal_gate_black_2_5", category: "post", sub_category: "terminal_post", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 24.00, aliases: ["Black Vinyl Gate Post"] },
  { crm_name: "BLK Line Post - 1-5/8in", canonical_key: "chainlink_post_line_black_1_625", category: "post", sub_category: "line_post", material_type: "chain_link", finish: "black_vinyl", size: "1-5/8in", unit: "pcs", cost: 16.00, aliases: ["Black Vinyl Line Post"] },

  // ========== TOP RAILS (STICK) ==========
  { crm_name: "GALV Top Rail 1-3/8in x 21ft Stick", canonical_key: "chainlink_rail_top_galv_1_375_21ft", category: "rail", sub_category: "top_rail", material_type: "chain_link", finish: "galv", size: "1-3/8in x 21ft", unit: "stick", cost: 25.00, package_qty: 1, aliases: ["Top Rail (1-3/8\" galv pipe)", "Galv Top Rail"] },
  { crm_name: "BLK Top Rail 1-3/8in x 21ft Stick", canonical_key: "chainlink_rail_top_black_1_375_21ft", category: "rail", sub_category: "top_rail", material_type: "chain_link", finish: "black_vinyl", size: "1-3/8in x 21ft", unit: "stick", cost: 35.00, package_qty: 1, aliases: ["Black Vinyl Top Rail"] },

  // ========== TENSION WIRE (100LF ROLLS) ==========
  { crm_name: "GALV Tension Wire (Bottom) - 100ft Roll", canonical_key: "chainlink_tension_wire_galv_100ft", category: "hardware", sub_category: "tension_wire", material_type: "chain_link", finish: "galv", size: "100ft", unit: "100lf", cost: 15.00, package_qty: 100, aliases: ["Tension Wire (bottom wire)", "Galv Tension Wire"] },
  { crm_name: "BLK Tension Wire (Bottom) - 100ft Roll", canonical_key: "chainlink_tension_wire_black_100ft", category: "hardware", sub_category: "tension_wire", material_type: "chain_link", finish: "black_vinyl", size: "100ft", unit: "100lf", cost: 20.00, package_qty: 100, aliases: ["Black Vinyl Tension Wire"] },

  // ========== CAPS ==========
  { crm_name: "GALV Dome Cap 2-1/2in (Terminal)", canonical_key: "chainlink_cap_dome_galv_2_5", category: "hardware", sub_category: "dome_cap", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.50, aliases: ["Dome Caps (terminal posts)", "Galv Dome Cap"] },
  { crm_name: "GALV Loop Cap 1-5/8in (Line)", canonical_key: "chainlink_cap_loop_galv_1_625", category: "hardware", sub_category: "loop_cap", material_type: "chain_link", finish: "galv", size: "1-5/8in", unit: "pcs", cost: 1.25, aliases: ["Loop Caps (line posts)", "Galv Loop Cap"] },
  { crm_name: "BLK Dome Cap 2-1/2in (Terminal)", canonical_key: "chainlink_cap_dome_black_2_5", category: "hardware", sub_category: "dome_cap", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 2.00, aliases: ["Black Vinyl Dome Cap"] },
  { crm_name: "BLK Loop Cap 1-5/8in (Line)", canonical_key: "chainlink_cap_loop_black_1_625", category: "hardware", sub_category: "loop_cap", material_type: "chain_link", finish: "black_vinyl", size: "1-5/8in", unit: "pcs", cost: 1.75, aliases: ["Black Vinyl Loop Cap"] },

  // ========== BANDS / ENDS / BOLTS - GALVANIZED ==========
  { crm_name: "GALV Brace Band 2-1/2in", canonical_key: "chainlink_band_brace_galv_2_5", category: "hardware", sub_category: "brace_band", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.80, aliases: ["Brace Bands (rail termination)", "Galv Brace Band"] },
  { crm_name: "GALV Tension Band 2-1/2in", canonical_key: "chainlink_band_tension_galv_2_5", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "galv", size: "2-1/2in", unit: "pcs", cost: 1.20, aliases: ["Tension Bands", "Galv Tension Band 2.5"] },
  { crm_name: "GALV Tension Band 3in", canonical_key: "chainlink_band_tension_galv_3", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "galv", size: "3in", unit: "pcs", cost: 1.40, aliases: ["Galv Tension Band 3.0"] },
  { crm_name: "GALV Rail End Cup 1-3/8in", canonical_key: "chainlink_rail_end_galv_1_375", category: "hardware", sub_category: "rail_cup", material_type: "chain_link", finish: "galv", size: "1-3/8in", unit: "pcs", cost: 1.10, aliases: ["Rail End Cups", "Galv Rail Cup"] },
  { crm_name: "GALV Carriage Bolt 5/16 x 1-1/4", canonical_key: "chainlink_bolt_carriage_5_16x1_25_galv", category: "hardware", sub_category: "carriage_bolt", material_type: "chain_link", finish: "galv", size: "5/16 x 1-1/4", unit: "pcs", cost: 0.15, package_qty: 50, aliases: ["Carriage Bolts (all hardware)", "Galv Carriage Bolt"] },

  // ========== BANDS / ENDS / BOLTS - BLACK VINYL COATED ==========
  { crm_name: "BLK Brace Band 2-1/2in", canonical_key: "chainlink_band_brace_black_2_5", category: "hardware", sub_category: "brace_band", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 2.50, aliases: ["Black Vinyl Brace Band"] },
  { crm_name: "BLK Tension Band 2-1/2in", canonical_key: "chainlink_band_tension_black_2_5", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "black_vinyl", size: "2-1/2in", unit: "pcs", cost: 1.75, aliases: ["Black Vinyl Tension Band 2.5"] },
  { crm_name: "BLK Tension Band 3in", canonical_key: "chainlink_band_tension_black_3", category: "hardware", sub_category: "tension_band", material_type: "chain_link", finish: "black_vinyl", size: "3in", unit: "pcs", cost: 2.00, aliases: ["Black Vinyl Tension Band 3.0"] },
  { crm_name: "BLK Rail End Cup 1-3/8in", canonical_key: "chainlink_rail_end_black_1_375", category: "hardware", sub_category: "rail_cup", material_type: "chain_link", finish: "black_vinyl", size: "1-3/8in", unit: "pcs", cost: 1.50, aliases: ["Black Vinyl Rail Cup"] },
  { crm_name: "BLK Carriage Bolt 5/16 x 1-1/4", canonical_key: "chainlink_bolt_carriage_5_16x1_25_black", category: "hardware", sub_category: "carriage_bolt", material_type: "chain_link", finish: "black_vinyl", size: "5/16 x 1-1/4", unit: "pcs", cost: 0.20, package_qty: 50, aliases: ["Black Vinyl Carriage Bolt"] },

  // ========== TENSION BARS - GALVANIZED ==========
  { crm_name: "GALV Tension Bar 48in (4ft)", canonical_key: "chainlink_tension_bar_48_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "48in", unit: "pcs", cost: 4.50, aliases: ["4' Tension Bars", "Galv Tension Bar 4ft"] },
  { crm_name: "GALV Tension Bar 60in (5ft)", canonical_key: "chainlink_tension_bar_60_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "60in", unit: "pcs", cost: 5.50, aliases: ["5' Tension Bars", "Galv Tension Bar 5ft"] },
  { crm_name: "GALV Tension Bar 72in (6ft)", canonical_key: "chainlink_tension_bar_72_galv", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "galv", size: "72in", unit: "pcs", cost: 6.50, aliases: ["6' Tension Bars", "Galv Tension Bar 6ft"] },

  // ========== TENSION BARS - BLACK VINYL COATED ==========
  { crm_name: "BLK Tension Bar 48in (4ft)", canonical_key: "chainlink_tension_bar_48_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "48in", unit: "pcs", cost: 6.00, aliases: ["Black Vinyl Tension Bar 4ft"] },
  { crm_name: "BLK Tension Bar 60in (5ft)", canonical_key: "chainlink_tension_bar_60_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "60in", unit: "pcs", cost: 7.00, aliases: ["Black Vinyl Tension Bar 5ft"] },
  { crm_name: "BLK Tension Bar 72in (6ft)", canonical_key: "chainlink_tension_bar_72_black", category: "hardware", sub_category: "tension_bar", material_type: "chain_link", finish: "black_vinyl", size: "72in", unit: "pcs", cost: 8.00, aliases: ["Black Vinyl Tension Bar 6ft"] },

  // ========== FENCE TIES ==========
  { crm_name: "GALV Chain Link Fence Tie 9ga x 6-1/2in", canonical_key: "chainlink_tie_galv_9ga_6_5", category: "hardware", sub_category: "fence_tie", material_type: "chain_link", finish: "galv", size: "9ga x 6-1/2in", unit: "pcs", cost: 0.08, package_qty: 100, aliases: ["Chain Link Fence Ties", "Galv Fence Tie"] },
  { crm_name: "BLK Chain Link Fence Tie 9ga x 6-1/2in", canonical_key: "chainlink_tie_black_9ga_6_5", category: "hardware", sub_category: "fence_tie", material_type: "chain_link", finish: "black_vinyl", size: "9ga x 6-1/2in", unit: "pcs", cost: 0.12, package_qty: 100, aliases: ["Black Vinyl Fence Tie"] },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Fetch existing catalog
    const existingCatalog = await base44.asServiceRole.entities.MaterialCatalog.list('-created_date', 1000);
    
    const results = {
      added: [],
      updated: [],
      skipped: [],
      errors: []
    };

    for (const item of CHAIN_LINK_CATALOG) {
      try {
        // Check if item exists by canonical_key
        const existing = existingCatalog.find(cat => 
          cat.canonical_key === item.canonical_key ||
          cat.material_id === item.canonical_key
        );

        if (existing) {
          // Update only if missing fields (preserve user costs)
          const updates = {};
          if (!existing.aliases) updates.aliases = item.aliases;
          if (!existing.canonical_key && !existing.material_id) updates.canonical_key = item.canonical_key;
          if (!existing.sub_category) updates.sub_category = item.sub_category;
          if (!existing.finish) updates.finish = item.finish;
          if (!existing.size) updates.size = item.size;
          if (!existing.package_qty) updates.package_qty = item.package_qty;
          
          if (Object.keys(updates).length > 0) {
            await base44.asServiceRole.entities.MaterialCatalog.update(existing.id, updates);
            results.updated.push({ id: existing.id, name: item.crm_name, updates });
          } else {
            results.skipped.push({ id: existing.id, name: item.crm_name, reason: 'Already complete' });
          }
        } else {
          // Create new item
          const newItem = await base44.asServiceRole.entities.MaterialCatalog.create({
            ...item,
            material_id: item.canonical_key,
            active: true,
            source: 'seed_migration'
          });
          results.added.push({ id: newItem.id, name: item.crm_name });
        }
      } catch (error) {
        results.errors.push({ name: item.crm_name, error: error.message });
      }
    }

    return Response.json({
      success: true,
      summary: {
        total: CHAIN_LINK_CATALOG.length,
        added: results.added.length,
        updated: results.updated.length,
        skipped: results.skipped.length,
        errors: results.errors.length
      },
      results
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});