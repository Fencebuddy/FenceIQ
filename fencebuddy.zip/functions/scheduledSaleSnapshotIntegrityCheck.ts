import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get all sold jobs
    const soldJobs = await base44.asServiceRole.entities.CRMJob.filter({ 
      saleStatus: 'sold',
      saleVoidedAt: null // Exclude voided sales
    });
    
    console.log(`[SaleSnapshot Integrity] Found ${soldJobs.length} sold jobs to check`);
    
    const issues = [];
    
    // Check each sold job for SaleSnapshot
    for (const job of soldJobs) {
      const snapshots = await base44.asServiceRole.entities.SaleSnapshot.filter({ 
        crmJobId: job.id 
      });
      
      if (snapshots.length === 0) {
        issues.push({
          jobId: job.id,
          jobNumber: job.jobNumber,
          customerName: job.customerName,
          soldAt: job.saleStatusUpdatedAt,
          issue: 'MISSING_SALE_SNAPSHOT',
          severity: 'CRITICAL'
        });
        
        console.error(`[SaleSnapshot Integrity] CRITICAL: Job ${job.jobNumber} is sold but has no SaleSnapshot`);
      }
    }
    
    // Log results
    if (issues.length === 0) {
      console.log(`[SaleSnapshot Integrity] ✓ All ${soldJobs.length} sold jobs have SaleSnapshots`);
      
      return Response.json({
        success: true,
        timestamp: new Date().toISOString(),
        jobsChecked: soldJobs.length,
        issuesFound: 0,
        status: 'HEALTHY'
      });
    } else {
      console.error(`[SaleSnapshot Integrity] ✗ Found ${issues.length} sold jobs without SaleSnapshots`);
      
      // Create alert record
      await base44.asServiceRole.entities.AlertRecord.create({
        alertType: 'SALE_SNAPSHOT_INTEGRITY',
        severity: 'CRITICAL',
        title: `${issues.length} Sold Jobs Missing SaleSnapshot`,
        description: `Integrity check found ${issues.length} sold jobs without required SaleSnapshot records`,
        detailsJson: { issues },
        status: 'active',
        acknowledgedAt: null
      });
      
      return Response.json({
        success: false,
        timestamp: new Date().toISOString(),
        jobsChecked: soldJobs.length,
        issuesFound: issues.length,
        status: 'UNHEALTHY',
        issues
      }, { status: 200 }); // Return 200 so automation doesn't fail
    }
    
  } catch (error) {
    console.error('[SaleSnapshot Integrity] Check failed:', error);
    return Response.json({ 
      error: error.message,
      timestamp: new Date().toISOString(),
      status: 'ERROR'
    }, { status: 500 });
  }
});