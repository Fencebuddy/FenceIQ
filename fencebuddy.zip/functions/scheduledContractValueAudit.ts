import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * PHASE 5c: Weekly Contract Value Audit
 * 
 * Verifies contract value integrity across CRMJob and SaleSnapshot records.
 * Detects:
 * - Zero or missing contract values (no actual price locked)
 * - Missing SaleSnapshots (jobs marked signed but not locked)
 * - Mismatches between CRMJob.contractValueCents and SaleSnapshot.contractValueCents
 * 
 * Triggered: Weekly (Monday 08:00 UTC or via manual invocation)
 * Output: AlertRecord with CRITICAL severity if mismatches > 5% of signed deals
 */

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);

        // Authorization: admin only
        let isAuthorized = false;
        try {
            const user = await base44.auth.me();
            if (user?.role === 'admin') {
                isAuthorized = true;
            }
        } catch (_) {
            // No user token — allow if service role (platform scheduler)
            isAuthorized = true;
        }

        if (!isAuthorized) {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        // Get all companies with CRM enabled
        const allSettings = await base44.asServiceRole.entities.CompanySettings.filter({ crmEnabled: true });
        const results = [];
        const MISMATCH_THRESHOLD = 0.05; // 5% threshold for alert

        for (const company of allSettings) {
            const companyId = company.companyId || company.id;

            try {
                // Fetch all signed CRMJobs for this company
                const signedJobs = await base44.asServiceRole.entities.CRMJob.filter({
                    companyId,
                    contractStatus: 'signed'
                });

                if (signedJobs.length === 0) {
                    results.push({
                        companyId,
                        companyName: company.companyName,
                        status: 'ok',
                        signedJobsCount: 0,
                        mismatches: []
                    });
                    continue;
                }

                const mismatches = [];

                // Check each signed job for integrity
                for (const job of signedJobs) {
                    const checks = {
                        jobId: job.id,
                        jobNumber: job.jobNumber,
                        issues: []
                    };

                    // Issue 1: Zero or missing contract value
                    if (!job.contractValueCents || job.contractValueCents <= 0) {
                        checks.issues.push('zero_contract_value');
                    }

                    // Issue 2: Missing SaleSnapshot (job signed but lock not recorded)
                    let saleSnapshot = null;
                    try {
                        const snapshots = await base44.asServiceRole.entities.SaleSnapshot.filter({
                            crmJobId: job.id
                        });
                        saleSnapshot = snapshots.length > 0 ? snapshots[0] : null;
                    } catch (_) {
                        // SaleSnapshot fetch failed
                        checks.issues.push('sale_snapshot_fetch_error');
                    }

                    if (!saleSnapshot) {
                        checks.issues.push('missing_sale_snapshot');
                    }

                    // Issue 3: Contract value mismatch (CRMJob vs SaleSnapshot)
                    if (saleSnapshot && job.contractValueCents && saleSnapshot.contractValueCents) {
                        const jobValue = job.contractValueCents;
                        const snapValue = saleSnapshot.contractValueCents;
                        const discrepancy = Math.abs(jobValue - snapValue);

                        if (discrepancy > 0) {
                            checks.issues.push('contract_value_mismatch');
                            checks.mismatchDetails = {
                                crmJobValue: jobValue,
                                saleSnapshotValue: snapValue,
                                discrepancyCents: discrepancy
                            };
                        }
                    }

                    if (checks.issues.length > 0) {
                        mismatches.push(checks);
                    }
                }

                const mismatchRate = mismatches.length / signedJobs.length;
                const shouldAlert = mismatchRate > MISMATCH_THRESHOLD;

                if (shouldAlert) {
                    // Write critical alert
                    await base44.asServiceRole.entities.AlertRecord.create({
                        rule: 'CONTRACT_VALUE_AUDIT',
                        severity: 'CRITICAL',
                        title: 'Contract value audit: High mismatch rate detected',
                        description: `${mismatches.length} of ${signedJobs.length} signed jobs (${(mismatchRate * 100).toFixed(1)}%) have contract value integrity issues`,
                        metric: 'contract_value_mismatch_rate',
                        value: mismatchRate,
                        threshold: MISMATCH_THRESHOLD,
                        tags: { companyId, environment: 'production' },
                        timestamp: new Date().toISOString(),
                        metadata: {
                            mismatchCount: mismatches.length,
                            totalSignedJobs: signedJobs.length,
                            issueTypes: mismatches.flatMap(m => m.issues).reduce((acc, issue) => {
                                acc[issue] = (acc[issue] || 0) + 1;
                                return acc;
                            }, {})
                        }
                    });
                }

                results.push({
                    companyId,
                    companyName: company.companyName,
                    status: shouldAlert ? 'alert' : 'ok',
                    signedJobsCount: signedJobs.length,
                    mismatchCount: mismatches.length,
                    mismatchRate: mismatchRate,
                    alertTriggered: shouldAlert,
                    mismatches: mismatches.slice(0, 5) // First 5 for logging
                });

                console.log('[ContractValueAudit]', {
                    companyId,
                    signedJobsCount: signedJobs.length,
                    mismatchCount: mismatches.length,
                    mismatchRate: (mismatchRate * 100).toFixed(1) + '%',
                    alertTriggered: shouldAlert
                });

            } catch (error) {
                results.push({
                    companyId,
                    companyName: company.companyName,
                    status: 'error',
                    error: error.message
                });

                console.error('[ContractValueAudit] Error for company:', {
                    companyId,
                    error: error.message
                });
            }
        }

        const alertTriggeredCount = results.filter(r => r.alertTriggered).length;
        const errorCount = results.filter(r => r.status === 'error').length;

        return Response.json({
            status: 'success',
            companiesAudited: results.length,
            alertsTriggered: alertTriggeredCount,
            errors: errorCount,
            results
        });

    } catch (error) {
        console.error('[ContractValueAudit] Critical error:', error.message);
        return Response.json({ error: error.message }, { status: 500 });
    }
});