/**
 * Phase 12.3.2: ServiceRole Update Guard
 * 
 * Wrapper for base44.asServiceRole entity update/delete operations.
 * Checks immutability before proceeding.
 * 
 * Usage:
 *   // Instead of: base44.asServiceRole.entities.ProposalPricingSnapshot.update(id, data)
 *   // Use: guardedUpdate(base44.asServiceRole, 'ProposalPricingSnapshot', id, data, { correlationId })
 */

const IMMUTABLE_ENTITIES = new Set([
  'ProposalPricingSnapshot',
  'JobCostSnapshot',
  'SaleSnapshot',
  'PricingSnapshot',
  'TakeoffSnapshot'
]);

export async function guardedUpdate(
  serviceRole: any,
  entityName: string,
  entityId: string,
  data: Record<string, any>,
  options: { correlationId?: string; maintenanceMode?: boolean; restoreEnabled?: boolean } = {}
): Promise<any> {
  const { correlationId, maintenanceMode, restoreEnabled } = options;

  // Check immutability — ENFORCE mode active
  if (IMMUTABLE_ENTITIES.has(entityName)) {
    if (maintenanceMode && restoreEnabled) {
      console.log(`[GuardedUpdate] RESTORE: allowing UPDATE on ${entityName}`, { entityId, correlationId });
    } else {
      // ENFORCE mode: throw error, block operation
      const message = `Immutability violation: cannot UPDATE ${entityName} (id=${entityId}). Snapshots are write-once. Enable MaintenanceMode + RestoreEnabled for restore operations.`;
      console.error(`[GuardedUpdate] ENFORCED:`, message, { entityId, correlationId, timestamp: new Date().toISOString() });
      throw new Error(message);
    }
  }

  // Proceed with update
  return serviceRole.entities[entityName].update(entityId, data);
}

export async function guardedDelete(
  serviceRole: any,
  entityName: string,
  entityId: string,
  options: { correlationId?: string; maintenanceMode?: boolean; restoreEnabled?: boolean } = {}
): Promise<any> {
  const { correlationId, maintenanceMode, restoreEnabled } = options;

  // Check immutability — ENFORCE mode active
  if (IMMUTABLE_ENTITIES.has(entityName)) {
    if (maintenanceMode && restoreEnabled) {
      console.log(`[GuardedDelete] RESTORE: allowing DELETE on ${entityName}`, { entityId, correlationId });
    } else {
      // ENFORCE mode: throw error, block operation
      const message = `Immutability violation: cannot DELETE ${entityName} (id=${entityId}). Snapshots are write-once. Enable MaintenanceMode + RestoreEnabled for restore operations.`;
      console.error(`[GuardedDelete] ENFORCED:`, message, { entityId, correlationId, timestamp: new Date().toISOString() });
      throw new Error(message);
    }
  }

  // Proceed with delete
  return serviceRole.entities[entityName].delete(entityId);
}