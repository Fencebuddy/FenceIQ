/**
 * PDF input validation & sanitization helpers
 * Used by executeSend to ensure deterministic PDF generation
 */

/**
 * Sanitize fence lines to contain only valid numeric points
 */
export function sanitizeFenceLines(fenceLines) {
  if (!Array.isArray(fenceLines)) return [];
  return (fenceLines || [])
    .map(line => {
      if (!line.points || !Array.isArray(line.points)) return null;
      const validPoints = line.points.filter(pt => 
        pt && typeof pt.x === 'number' && isFinite(pt.x) && 
        typeof pt.y === 'number' && isFinite(pt.y)
      );
      return validPoints.length > 1 ? { ...line, points: validPoints } : null;
    })
    .filter(Boolean);
}

/**
 * Validate data URL format (image/png or image/jpeg, min 100 bytes)
 */
export function isValidMapImageDataUrl(s) {
  return typeof s === 'string' && s.startsWith('data:image/') && s.length > 100;
}