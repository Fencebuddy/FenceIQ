import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user || user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const { items } = await req.json();
        if (!Array.isArray(items) || items.length === 0) {
            return Response.json({ error: 'items array required' }, { status: 400 });
        }

        // Transform CSV data to MaterialCatalog schema
        const catalogItems = items.map(item => ({
            canonical_key: item.uck,
            crm_name: item.uck.replace(/_/g, ' ').toUpperCase(),
            material_type: item.material_type,
            category: item.category,
            unit: item.unit,
            cost: Number(item.cost),
            finish: item.finish || 'none',
            active: true,
            source: 'manual'
        }));

        // Create in bulk
        let created = 0;
        let errors = 0;
        const results = [];

        for (const catalogItem of catalogItems) {
            try {
                const result = await base44.asServiceRole.entities.MaterialCatalog.create(catalogItem);
                created++;
                results.push({
                    uck: catalogItem.canonical_key,
                    status: 'CREATED',
                    catalogId: result.id
                });
            } catch (err) {
                errors++;
                results.push({
                    uck: catalogItem.canonical_key,
                    status: 'ERROR',
                    error: err.message
                });
            }
        }

        return Response.json({
            summary: {
                total: items.length,
                created,
                errors
            },
            results: results.slice(0, 50)
        });

    } catch (error) {
        console.error('Error in seedCatalogFromCsv:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});