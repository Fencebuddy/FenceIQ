import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Phase 12.2: CI Proof Endpoint
 * 
 * Returns the latest successful CI run (green build) for investor verification.
 * This proves that tests exist, run, and pass before deployment.
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Allow public read (for investor proof pages)
    // OR admin read
    const isPublic = req.url.includes('?public=true');
    const isAdmin = user?.role === 'admin';
    
    if (!isPublic && !isAdmin) {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Fetch latest successful CI run
    const ciRuns = await base44.asServiceRole.entities.CiRunLog
      .filter({ status: 'success', branch: 'main' }, '-completedAt', 1)
      .catch(() => []);

    const latestRun = ciRuns?.[0];

    if (!latestRun) {
      return Response.json({
        status: 'no_successful_run',
        message: 'No successful CI runs on main branch yet',
        timestamp: new Date().toISOString()
      });
    }

    // Calculate uptime proof
    const runAge = new Date().getTime() - new Date(latestRun.completedAt).getTime();
    const runAgeHours = Math.round(runAge / (60 * 60 * 1000));

    return Response.json({
      status: 'ok',
      ciProof: {
        commitSha: latestRun.commitSha,
        branch: latestRun.branch,
        workflowStatus: latestRun.status,
        testsRun: latestRun.testsRun,
        testsPassed: latestRun.testsPassed,
        testsFailed: latestRun.testsFailed,
        coverage: `${latestRun.coverage}%`,
        completedAt: latestRun.completedAt,
        ageHours: runAgeHours,
        logUrl: latestRun.logUrl
      },
      investorVerification: {
        hasTests: latestRun.testsRun > 0,
        allPassed: latestRun.testsFailed === 0,
        coverageAboveThreshold: latestRun.coverage >= 70,
        recentRun: runAgeHours < 24
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('[CiProof] Fatal error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});