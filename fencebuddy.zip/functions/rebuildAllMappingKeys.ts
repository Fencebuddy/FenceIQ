import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import crypto from 'crypto';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    // Get company settings
    const settings = await base44.entities.CompanySettings.filter({});
    const companyId = settings?.[0]?.companyId || null;

    if (!companyId) {
      return Response.json({ error: 'No company found' }, { status: 400 });
    }

    // Get all company maps
    const allMaps = await base44.entities.CompanySkuMap.filter({ companyId });
    console.log(`[rebuildAllMappingKeys] Found ${allMaps.length} mappings to rebuild`);

    if (allMaps.length === 0) {
      return Response.json({ 
        status: 'COMPLETE',
        count: 0,
        message: 'No mappings to rebuild'
      });
    }

    // Rebuild mappingKey for each
    const updates = [];
    for (const map of allMaps) {
      const uck = map.uck || '';
      const attrs = map.attributes || {};
      
      // Compute mappingKey = hash(uck + normalized_attrs)
      const attrStr = JSON.stringify(normalizeAttributes(attrs));
      const combined = `${uck}|${attrStr}`;
      const mappingKey = crypto
        .createHash('sha256')
        .update(combined)
        .digest('hex')
        .slice(0, 16);

      updates.push(
        base44.asServiceRole.entities.CompanySkuMap.update(map.id, { mappingKey })
      );
    }

    // Execute all updates in parallel (batches of 10 to avoid rate limit)
    const batchSize = 10;
    let completed = 0;
    for (let i = 0; i < updates.length; i += batchSize) {
      const batch = updates.slice(i, i + batchSize);
      await Promise.all(batch);
      completed += batch.length;
      console.log(`[rebuildAllMappingKeys] Completed ${completed}/${updates.length}`);
    }

    return Response.json({
      status: 'COMPLETE',
      count: allMaps.length,
      message: `Rebuilt mappingKey for ${allMaps.length} CompanySkuMap entries`
    });
  } catch (error) {
    console.error('[rebuildAllMappingKeys] ERROR:', error.message);
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});

function normalizeAttributes(attrs) {
  const normalized = {};
  for (const [key, val] of Object.entries(attrs || {})) {
    if (val === undefined || val === null) continue;
    normalized[key] = String(val).toLowerCase().trim();
  }
  return normalized;
}