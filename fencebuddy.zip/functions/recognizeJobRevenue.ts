import { createGuardedClientFromRequest } from "./_shared/base44GuardFactory.js";
import { resolveCompanyContext } from "./_shared/resolveCompanyContext.js";
import { PricingTruthError, requireUniqueOrNull } from "./_shared/truthSetIntegrity.js";
import { monthKeyFromDate } from "./_shared/monthUtils.js";
import { resolveOverheadRate } from "./_shared/pricingRates.js";

/**
 * Payload:
 * - jobId (required)
 * - recognizedRevenueCents (optional) // if omitted, derive from job if available
 * - recognitionSource (required) // e.g. "paymentStage.PAID" or "installStage.CLOSED_OUT"
 *
 * This function must be called by the UI/workflow when the job is considered revenue-recognized.
 * 
 * Immutability Note: All snapshot writes are routed through the wrapped base44 client.
 */
Deno.serve(async (req) => {
  try {
    const base44 = await createGuardedClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const payload = await req.json();
    const { jobId, recognizedRevenueCents: revenueFromPayload, recognitionSource } = payload || {};

    if (!jobId) {
      return Response.json({ success: false, error: "MISSING_JOB_ID", message: "jobId is required" }, { status: 400 });
    }
    if (!recognitionSource || String(recognitionSource).trim().length === 0) {
      return Response.json(
        { success: false, error: "MISSING_RECOGNITION_SOURCE", message: "recognitionSource is required" },
        { status: 400 }
      );
    }

    const ctx = await resolveCompanyContext({ base44, req: base44 });
    if (ctx.error) {
      return Response.json({ success: false, error: ctx.error.code, message: ctx.error.message }, { status: 500 });
    }
    const { companyId, company } = ctx;

    // Load job
    const job = await base44.entities.CRMJob.get(jobId);
    if (!job) {
      return Response.json({ success: false, error: "JOB_NOT_FOUND", message: "CRMJob not found" }, { status: 404 });
    }

    // Idempotency: if already recognized, do nothing
    if (job.recognitionStatus === "RECOGNIZED") {
      return Response.json({ success: true, alreadyRecognized: true, job });
    }

    // Determine revenue (prefer payload, else best-available job field)
    const revenueCents =
      Number.isFinite(Number(revenueFromPayload)) ? Math.round(Number(revenueFromPayload)) :
      Number.isFinite(Number(job.retailPriceCents)) ? Math.round(Number(job.retailPriceCents)) :
      Number.isFinite(Number(job.contractPriceCents)) ? Math.round(Number(job.contractPriceCents)) :
      null;

    if (revenueCents == null || revenueCents <= 0) {
      return Response.json(
        {
          success: false,
          error: "REVENUE_MISSING",
          message: "recognizedRevenueCents missing and no job revenue field found (retailPriceCents/contractPriceCents)."
        },
        { status: 400 }
      );
    }

    // Effective overhead rate from truth ladder (already constitution-safe)
    const overheadResolved = await resolveOverheadRate({
      base44,
      companyId,
      company,
      hardFallback: 0.14
    });
    const overheadRate = Number(overheadResolved.overheadRate);

    if (!Number.isFinite(overheadRate) || overheadRate <= 0 || overheadRate > 0.95) {
      throw new PricingTruthError(
        "INVALID_EFFECTIVE_OVERHEAD_RATE",
        "Effective overhead rate resolved invalid while recognizing revenue.",
        { overheadRate, source: overheadResolved.source }
      );
    }

    const overheadRecoveredCents = Math.round(revenueCents * overheadRate);
    const recognizedAt = new Date().toISOString();
    const monthKey = monthKeyFromDate(recognizedAt);

    // Update job recognition fields
    const updatedJob = await base44.entities.CRMJob.update(jobId, {
      recognitionStatus: "RECOGNIZED",
      recognizedAt,
      recognizedMonthKey: monthKey,
      recognizedRevenueCents: revenueCents,
      recognizedOverheadCents: overheadRecoveredCents,
      recognitionSource: String(recognitionSource)
    });

    // Upsert rollup (STRICT uniqueness)
    const existing = await base44.entities.BreakevenMonthlyRollup.filter({ companyId, monthKey });
    const one = requireUniqueOrNull({
      records: existing,
      code: "BREAKEVEN_ROLLUP_DUPLICATE",
      message: "Multiple BreakevenMonthlyRollup records exist for this company/month (uniqueness violated).",
      details: { companyId, monthKey }
    });

    if (!one) {
      await base44.entities.BreakevenMonthlyRollup.create({
        companyId,
        monthKey,
        recognizedRevenueCents: revenueCents,
        overheadRecoveredCents: overheadRecoveredCents,
        jobsCount: 1,
        lastEventAt: recognizedAt,
        version: "breakevenRollup@1.0.0"
      });
    } else {
      await base44.entities.BreakevenMonthlyRollup.update(one.id, {
        recognizedRevenueCents: Number(one.recognizedRevenueCents || 0) + revenueCents,
        overheadRecoveredCents: Number(one.overheadRecoveredCents || 0) + overheadRecoveredCents,
        jobsCount: Number(one.jobsCount || 0) + 1,
        lastEventAt: recognizedAt
      });
    }

    return Response.json({
      success: true,
      companyId,
      monthKey,
      recognizedRevenueCents: revenueCents,
      overheadRecoveredCents,
      overheadRateUsed: overheadRate,
      overheadRateSource: overheadResolved.source,
      job: updatedJob
    });
  } catch (error) {
    console.error("[recognizeJobRevenue] Error:", error);

    if (error && error.name === "PricingTruthError") {
      return Response.json(
        { success: false, error: error.code, message: error.message, details: error.details },
        { status: 500 }
      );
    }

    return Response.json({ success: false, error: "UNKNOWN_ERROR", message: error.message }, { status: 500 });
  }
});