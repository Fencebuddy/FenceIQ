import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Repair malformed ReportRollupDaily date buckets
 * Converts YYYY-DD-MM (swapped) to YYYY-MM-DD and merges into correct rows
 * NO DELETES — marks repaired rows so they're skipped in future queries
 */
Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        // Admin-only
        if (user?.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }
        
        const payload = await req.json();
        const { companyId } = payload;
        
        if (!companyId) {
            return Response.json({ error: 'Missing companyId' }, { status: 400 });
        }
        
        // Fetch all rollups for this company
        const allRollups = await base44.asServiceRole.entities.ReportRollupDaily.filter({ companyId });
        
        console.log('[Repair] Total rollups found:', allRollups.length);
        
        // Identify malformed rows
        const malformedRows = [];
        const correctRows = [];
        
        for (const rollup of allRollups) {
            if (rollup.isRepaired) {
                console.log('[Repair] Skipping already-repaired row:', rollup.id);
                continue;
            }
            
            const parts = rollup.rollupDate.split('-');
            if (parts.length !== 3) continue;
            
            const [year, monthOrDay, dayOrMonth] = parts;
            const m = parseInt(monthOrDay);
            const d = parseInt(dayOrMonth);
            
            // Detect swapped: month > 12 and day <= 12
            if (m > 12 && d <= 12) {
                malformedRows.push(rollup);
                console.log('[Repair] Found malformed:', rollup.rollupDate, '→', `${year}-${dayOrMonth}-${monthOrDay}`);
            } else {
                correctRows.push(rollup);
            }
        }
        
        console.log('[Repair] Malformed rows:', malformedRows.length);
        console.log('[Repair] Correct rows:', correctRows.length);
        
        // Build map of correct rows for merging
        const correctMap = new Map();
        for (const row of correctRows) {
            const key = `${row.rollupDate}|${row.repUserId || 'null'}|${row.fenceCategory || 'null'}|${row.source || 'null'}`;
            correctMap.set(key, row);
        }
        
        // Process malformed rows: merge into correct rows or create new ones
        let mergedCount = 0;
        let createdCount = 0;
        
        for (const malformed of malformedRows) {
            // Calculate correct bucket
            const [year, monthOrDay, dayOrMonth] = malformed.rollupDate.split('-');
            const correctedBucket = `${year}-${dayOrMonth}-${monthOrDay}`;
            
            const key = `${correctedBucket}|${malformed.repUserId || 'null'}|${malformed.fenceCategory || 'null'}|${malformed.source || 'null'}`;
            
            if (correctMap.has(key)) {
                // Merge into existing correct row
                const correctRow = correctMap.get(key);
                const mergeData = {
                    signedCount: (correctRow.signedCount || 0) + (malformed.signedCount || 0),
                    wonRevenue: (correctRow.wonRevenue || 0) + (malformed.wonRevenue || 0),
                    netProfitAmount: (correctRow.netProfitAmount || 0) + (malformed.netProfitAmount || 0),
                    proposalsSentCount: (correctRow.proposalsSentCount || 0) + (malformed.proposalsSentCount || 0),
                    proposalsSignedCount: (correctRow.proposalsSignedCount || 0) + (malformed.proposalsSignedCount || 0)
                };
                
                // Recompute weighted margin
                if (mergeData.wonRevenue > 0) {
                    mergeData.netMarginPercentWeighted = (mergeData.netProfitAmount / mergeData.wonRevenue) * 100;
                } else {
                    mergeData.netMarginPercentWeighted = 0;
                }
                
                // Recompute avg ticket
                if (mergeData.signedCount > 0) {
                    mergeData.avgTicket = mergeData.wonRevenue / mergeData.signedCount;
                } else {
                    mergeData.avgTicket = 0;
                }
                
                // Update correct row
                await base44.asServiceRole.entities.ReportRollupDaily.update(correctRow.id, mergeData);
                console.log('[Repair] Merged malformed into correct:', malformed.id, '→', correctRow.id);
                mergedCount += 1;
            } else {
                // Create new correct row
                const newData = {
                    companyId: malformed.companyId,
                    rollupDate: correctedBucket,
                    repUserId: malformed.repUserId,
                    fenceCategory: malformed.fenceCategory,
                    source: malformed.source,
                    signedCount: malformed.signedCount || 0,
                    wonRevenue: malformed.wonRevenue || 0,
                    netProfitAmount: malformed.netProfitAmount || 0,
                    netMarginPercentWeighted: malformed.netMarginPercentWeighted || 0,
                    avgTicket: malformed.avgTicket || 0,
                    proposalsSentCount: malformed.proposalsSentCount || 0,
                    proposalsSignedCount: malformed.proposalsSignedCount || 0
                };
                
                await base44.asServiceRole.entities.ReportRollupDaily.create(newData);
                console.log('[Repair] Created new correct row from malformed:', malformed.id);
                createdCount += 1;
            }
            
            // Mark malformed row as repaired (do NOT delete)
            await base44.asServiceRole.entities.ReportRollupDaily.update(malformed.id, {
                isRepaired: true
            });
            console.log('[Repair] Marked malformed as repaired:', malformed.id);
        }
        
        return Response.json({
            success: true,
            message: 'Rollup date bucket repair complete',
            companyId,
            stats: {
                totalRollups: allRollups.length,
                malformedFound: malformedRows.length,
                correctRowsFound: correctRows.length,
                mergedIntoExisting: mergedCount,
                newRowsCreated: createdCount
            }
        });
    } catch (error) {
        console.error('[Repair] Error:', error);
        return Response.json({ 
            error: error.message,
            stack: error.stack 
        }, { status: 500 });
    }
});