import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, ChevronRight } from "lucide-react";
import { ensureRunCompareVariants } from "@/components/fence/compareVariantsService";

const MATERIAL_TYPES = ["Wood", "Chain Link", "Vinyl", "Aluminum"];
const FENCE_HEIGHTS = ["3'", "4'", "5'", "6'", "8'", "10'", "12'"];
const VINYL_COLORS = ["White", "Tan", "Khaki", "Grey", "Coastal Grey", "Cedar Tone", "Black"];
const WOOD_COLORS = ["Pine", "Cedar", "Cedar Tone"];
const CHAIN_LINK_COATINGS = ["Galvanized", "Aluminized", "Black Vinyl Coated"];

export function RunCompareVariantsEditor({ run, onSave, job }) {
  const ensured = ensureRunCompareVariants(run, job);
  
  const [open, setOpen] = useState({ a: true, b: false, c: false });
  const [draft, setDraft] = useState(ensured.compareVariants);
  const [saving, setSaving] = useState(false);

  const update = (key, field, value) => {
    setDraft((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [field]: value
      }
    }));
  };

  const save = async () => {
    setSaving(true);
    try {
      await onSave(draft);
      // CRITICAL: Trigger compare store rebuild after variants are saved
      if (typeof window !== 'undefined' && window.triggerCompareRebuild) {
        window.triggerCompareRebuild();
      }
    } finally {
      setSaving(false);
    }
  };

  const VariantBlock = ({ k, label }) => {
    const variant = draft[k];
    const colors = variant.materialType === "Vinyl" 
      ? VINYL_COLORS 
      : variant.materialType === "Wood" 
      ? WOOD_COLORS 
      : [];

    return (
      <div className="border border-slate-200 rounded-lg overflow-visible">
        <button
          className="w-full px-4 py-3 bg-slate-50 cursor-pointer hover:bg-slate-100 flex items-center justify-between font-medium text-sm text-left"
          onClick={() => setOpen((o) => ({ ...o, [k]: !o[k] }))}
          type="button"
        >
          <span>{label}</span>
          {open[k] ? (
            <ChevronDown className="w-4 h-4" />
          ) : (
            <ChevronRight className="w-4 h-4" />
          )}
        </button>

        {open[k] && (
            <div className="px-4 py-3 space-y-3 bg-white overflow-visible">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700">Material Type</label>
              <Select
                value={variant.materialType}
                onValueChange={(value) => update(k, "materialType", value)}
              >
                <SelectTrigger className="h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="z-[9999]" position="popper">
                  {MATERIAL_TYPES.map((m) => (
                    <SelectItem key={m} value={m}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700">Height</label>
              <Select
                value={variant.fenceHeight}
                onValueChange={(value) => update(k, "fenceHeight", value)}
              >
                <SelectTrigger className="h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="z-[9999]" position="popper">
                  {FENCE_HEIGHTS.map((h) => (
                    <SelectItem key={h} value={h}>
                      {h}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {variant.materialType === "Chain Link" && (
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-700">Coating</label>
                <Select
                  value={variant.chainLinkCoating || "Galvanized"}
                  onValueChange={(value) => update(k, "chainLinkCoating", value)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="z-[9999]" position="popper">
                    {CHAIN_LINK_COATINGS.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {colors.length > 0 && (
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-700">Color</label>
                <Select
                  value={variant.fenceColor || colors[0]}
                  onValueChange={(value) => update(k, "fenceColor", value)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="z-[9999]" position="popper">
                    {colors.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3 relative z-50">
      <VariantBlock k="a" label="Material A" />
      <VariantBlock k="b" label="Material B" />
      <VariantBlock k="c" label="Material C" />

      <Button
        onClick={save}
        disabled={saving}
        size="sm"
        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
      >
        {saving ? "Saving..." : "Save Compare Variants"}
      </Button>
    </div>
  );
}