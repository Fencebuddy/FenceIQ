/**
 * TASK 3: REBUILD MAPPINGS FROM FSC (PREFERRED)
 * Deletes all CompanySkuMap rows and rebuilds ONLY from FenceSystemConfig.
 * 
 * SAFETY:
 * - Dry-run mode by default
 * - Admin-only access
 * - Rebuilds from FSC allowlist (frozen, deterministic)
 * 
 * Usage:
 * POST /api/functions/rebuildFscMappings
 * {
 *   "companyId": "PrivacyFenceCo49319",
 *   "dry_run": false
 * }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Admin-only access
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }
    
    const { companyId, dry_run = true } = await req.json();
    
    if (!companyId) {
      return Response.json({ error: 'companyId required' }, { status: 400 });
    }
    
    console.log(`[RebuildFscMappings] Starting rebuild for companyId=${companyId}, dry_run=${dry_run}`);
    
    // Step 1: Fetch existing CompanySkuMap rows
    const existingMappings = await base44.asServiceRole.entities.CompanySkuMap.filter({ companyId });
    console.log(`[RebuildFscMappings] Found ${existingMappings.length} existing CompanySkuMap rows`);
    
    // Step 2: Fetch MaterialCatalog
    const catalog = await base44.asServiceRole.entities.MaterialCatalog.filter({ active: true });
    console.log(`[RebuildFscMappings] Loaded ${catalog.length} active catalog items`);
    
    const catalogLookup = new Map();
    catalog.forEach(c => catalogLookup.set(c.id, c));
    
    // Step 3: Build FSC canonical UCK allowlist
    // For PrivacyFenceCo49319, we'll define the canonical allowlist here
    // In production, this would be fetched from a configuration entity
    
    const fscAllowlist = [
      // Vinyl Savannah White 6ft
      { uck: 'vinyl_panel_privacy_6ft_savannah_white', materialCatalogId: null, displayName: 'Vinyl Privacy Panel 6ft Savannah White' },
      { uck: 'vinyl_post_line_5x5_6ft_savannah_white', materialCatalogId: null, displayName: 'Vinyl Line Post 5x5 6ft Savannah White' },
      { uck: 'vinyl_post_end_5x5_6ft_savannah_white', materialCatalogId: null, displayName: 'Vinyl End Post 5x5 6ft Savannah White' },
      { uck: 'vinyl_post_gate_5x5_6ft_savannah_white', materialCatalogId: null, displayName: 'Vinyl Gate Post 5x5 6ft Savannah White' },
      { uck: 'vinyl_hardware_post_cap', materialCatalogId: null, displayName: 'Vinyl Post Cap (height-independent)' },
      { uck: 'vinyl_hardware_galvanized_post', materialCatalogId: null, displayName: 'Galvanized Post Insert' },
      { uck: 'vinyl_hardware_nodig_donut', materialCatalogId: null, displayName: 'No-Dig Donuts' },
      { uck: 'vinyl_hardware_gate_hinge_set', materialCatalogId: null, displayName: 'Gate Hinge Set' },
      { uck: 'vinyl_hardware_locklatch_5in', materialCatalogId: null, displayName: 'Locklatch 5in' }
    ];
    
    // Step 4: Find MaterialCatalog IDs for FSC allowlist
    const resolvedAllowlist = [];
    const unresolvedUcks = [];
    
    for (const item of fscAllowlist) {
      // Try to find exact catalog match by canonical_key or crm_name
      const catalogMatch = catalog.find(c => 
        c.canonical_key === item.uck || 
        c.crm_name?.toLowerCase().includes(item.displayName.toLowerCase())
      );
      
      if (catalogMatch) {
        resolvedAllowlist.push({
          uck: item.uck,
          materialCatalogId: catalogMatch.id,
          materialCatalogName: catalogMatch.crm_name,
          displayName: item.displayName,
          status: 'mapped',
          mappingSource: 'FenceSystemConfig'
        });
      } else {
        unresolvedUcks.push(item.uck);
      }
    }
    
    console.log(`[RebuildFscMappings] Resolved ${resolvedAllowlist.length}/${fscAllowlist.length} UCKs from catalog`);
    
    // Step 5: Execute rebuild (delete + recreate)
    let deletedCount = 0;
    let createdCount = 0;
    
    if (!dry_run) {
      // Delete ALL existing CompanySkuMap rows
      console.log(`[RebuildFscMappings] Deleting ${existingMappings.length} existing rows...`);
      for (const row of existingMappings) {
        await base44.asServiceRole.entities.CompanySkuMap.delete(row.id);
        deletedCount++;
      }
      
      // Recreate ONLY from FSC allowlist
      console.log(`[RebuildFscMappings] Creating ${resolvedAllowlist.length} new rows from FSC...`);
      for (const item of resolvedAllowlist) {
        await base44.asServiceRole.entities.CompanySkuMap.create({
          companyId,
          uck: item.uck,
          materialCatalogId: item.materialCatalogId,
          materialCatalogName: item.materialCatalogName,
          materialType: 'vinyl',
          displayName: item.displayName,
          status: 'mapped',
          attributes: {},
          notes: 'Rebuilt from FenceSystemConfig canonical allowlist'
        });
        createdCount++;
      }
    }
    
    return Response.json({
      success: true,
      dry_run,
      companyId,
      summary: {
        existing_rows_deleted: deletedCount,
        new_rows_created: createdCount,
        fsc_allowlist_size: fscAllowlist.length,
        resolved_mappings: resolvedAllowlist.length,
        unresolved_ucks: unresolvedUcks
      },
      preview: resolvedAllowlist,
      unresolved: unresolvedUcks,
      message: dry_run 
        ? 'Dry-run complete. Set dry_run=false to execute rebuild.'
        : `✅ Rebuild complete: ${deletedCount} deleted, ${createdCount} created from FSC.`
    });
    
  } catch (error) {
    console.error('[RebuildFscMappings] Error:', error);
    return Response.json({
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});