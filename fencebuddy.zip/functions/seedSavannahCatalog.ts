import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const SAVANNAH_FAMILY = {
  family: "savannah",
  material: "vinyl",
  style: "privacy",
  default_color: "white",
  supported_heights_ft: [4, 5, 6],
  supported_colors: ["white", "tan", "khaki", "grey"],
  resolver_rules: {
    panel_spacing_ft: 8,
    normalize_spacing: true,
    slope_aware: true,
    fallback_color: "white",
    block_pricing_if_missing: true
  }
};

const PANELS = [
  { canonical_key: "vinyl_panel_privacy_4ft_savannah_white", height_ft: 4, color: "white", unit_cost: 128.60 },
  { canonical_key: "vinyl_panel_privacy_4ft_savannah_tan", height_ft: 4, color: "tan", unit_cost: 128.60 },
  { canonical_key: "vinyl_panel_privacy_4ft_savannah_khaki", height_ft: 4, color: "khaki", unit_cost: 140.29 },
  { canonical_key: "vinyl_panel_privacy_4ft_savannah_grey", height_ft: 4, color: "grey", unit_cost: 153.26 },
  { canonical_key: "vinyl_panel_privacy_5ft_savannah_white", height_ft: 5, color: "white", unit_cost: 142.75 },
  { canonical_key: "vinyl_panel_privacy_5ft_savannah_tan", height_ft: 5, color: "tan", unit_cost: 142.75 },
  { canonical_key: "vinyl_panel_privacy_5ft_savannah_khaki", height_ft: 5, color: "khaki", unit_cost: 155.73 },
  { canonical_key: "vinyl_panel_privacy_5ft_savannah_grey", height_ft: 5, color: "grey", unit_cost: 160.68 },
  { canonical_key: "vinyl_panel_privacy_6ft_savannah_white", height_ft: 6, color: "white", unit_cost: 158.61 },
  { canonical_key: "vinyl_panel_privacy_6ft_savannah_tan", height_ft: 6, color: "tan", unit_cost: 158.61 },
  { canonical_key: "vinyl_panel_privacy_6ft_savannah_khaki", height_ft: 6, color: "khaki", unit_cost: 173.03 },
  { canonical_key: "vinyl_panel_privacy_6ft_savannah_grey", height_ft: 6, color: "grey", unit_cost: 184.78 }
];

const POST_LENGTHS = {
  4: 7,
  5: 8,
  6: 9
};

const POST_COSTS = {
  white: { "7ft": 25.74, "8ft": 42.15, "9ft": 46.10 },
  tan: { "7ft": 25.74, "8ft": 42.15, "9ft": 46.10 },
  khaki: { "7ft": 40.23, "8ft": 45.98, "9ft": 50.72 },
  grey: { "7ft": 43.49, "8ft": 34.98, "9ft": 51.73 }
};

const POST_ROLES = ["line", "end", "corner", "blank", "3-way", "gate"];

const GATES_SINGLE = {
  "38.5": { "4": 474.00, "5": 474.00, "6": 474.00 },
  "44.5": { "4": 478.80, "5": 478.80, "6": 478.80 },
  "62.5": { "4": 477.65, "5": 503.44, "6": 511.93 },
  "68.5": { "4": 486.29, "5": 511.93, "6": 520.44 }
};

const GATES_DOUBLE = {
  "38.5": { "4": 935.41, "5": 1017.60, "6": 1017.60 },
  "44.5": { "4": 1020.00, "5": 1020.00, "6": 1020.00 },
  "62.5": { "4": 969.43, "5": 1020.99, "6": 1038.00 },
  "68.5": { "4": 986.70, "5": 1038.00, "6": 1055.01 }
};

const CAPS = {
  "4": { default: "federation", cost: 7.50 },
  "5": { default: "new_england", cost: 8.09 },
  "6": { default: "new_england", cost: 8.09 }
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { dryRun = true } = await req.json().catch(() => ({ dryRun: true }));
    const mode = dryRun ? 'preview' : 'execute';
    const catalogItems = [];
    const linkMaps = [];

    // 1. PANELS
    for (const panel of PANELS) {
      const catalogItem = {
        crm_name: `Savannah ${panel.height_ft}ft Privacy Panel ${panel.color.charAt(0).toUpperCase() + panel.color.slice(1)}`,
        canonical_key: panel.canonical_key,
        material_type: "vinyl",
        category: "panel",
        sub_category: "privacy_panel",
        finish: panel.color,
        size: `${panel.height_ft}'`,
        unit: "each",
        cost: panel.unit_cost,
        keywords: ["savannah", "privacy", `${panel.height_ft}ft`, panel.color, "panel"],
        active: true
      };

      if (mode === 'execute') {
        const created = await base44.entities.MaterialCatalog.create(catalogItem);
        catalogItems.push(created.id);
        linkMaps.push({ canonical_key: panel.canonical_key, catalog_item_id: created.id });
      } else {
        catalogItems.push(catalogItem);
      }
    }

    // 2. POSTS (all role variants)
    for (const height of SAVANNAH_FAMILY.supported_heights_ft) {
      const postLength = POST_LENGTHS[height];
      
      for (const color of SAVANNAH_FAMILY.supported_colors) {
        for (const role of POST_ROLES) {
          const canonicalKey = `vinyl_post_${role}_${height}ft_savannah_${color}`;
          const postKey = `${postLength}ft`;
          const cost = POST_COSTS[color][postKey];

          const catalogItem = {
            crm_name: `Savannah ${height}ft Post ${role.charAt(0).toUpperCase() + role.slice(1)} ${color.charAt(0).toUpperCase() + color.slice(1)}`,
            canonical_key: canonicalKey,
            material_type: "vinyl",
            category: "post",
            sub_category: `${role}_post`,
            finish: color,
            size: `${postLength}'`,
            unit: "each",
            cost: cost,
            length_ft: postLength,
            keywords: ["savannah", "post", `${height}ft`, color, role],
            active: true
          };

          if (mode === 'execute') {
            const created = await base44.entities.MaterialCatalog.create(catalogItem);
            catalogItems.push(created.id);
            linkMaps.push({ canonical_key: canonicalKey, catalog_item_id: created.id });
          } else {
            catalogItems.push(catalogItem);
          }
        }
      }
    }

    // 3. GATES (single)
    for (const widthStr of Object.keys(GATES_SINGLE)) {
      const widthInches = parseFloat(widthStr);
      const costs = GATES_SINGLE[widthStr];

      for (const heightStr of Object.keys(costs)) {
        const height = parseInt(heightStr);
        const cost = costs[heightStr];
        const canonicalKey = `vinyl_gate_single_${widthStr}in_${height}ft`;

        const catalogItem = {
          crm_name: `Savannah Single Gate ${widthStr}" x ${height}ft`,
          canonical_key: canonicalKey,
          material_type: "vinyl",
          category: "gate",
          sub_category: "single_gate",
          size: `${widthStr}" x ${height}'`,
          unit: "each",
          cost: cost,
          keywords: ["savannah", "gate", "single", `${widthStr}in`, `${height}ft`],
          active: true
        };

        if (mode === 'execute') {
          const created = await base44.entities.MaterialCatalog.create(catalogItem);
          catalogItems.push(created.id);
          linkMaps.push({ canonical_key: canonicalKey, catalog_item_id: created.id });
        } else {
          catalogItems.push(catalogItem);
        }
      }
    }

    // 4. GATES (double)
    for (const widthStr of Object.keys(GATES_DOUBLE)) {
      const widthInches = parseFloat(widthStr);
      const costs = GATES_DOUBLE[widthStr];

      for (const heightStr of Object.keys(costs)) {
        const height = parseInt(heightStr);
        const cost = costs[heightStr];
        const canonicalKey = `vinyl_gate_double_${widthStr}in_${height}ft`;

        const catalogItem = {
          crm_name: `Savannah Double Gate ${widthStr}" x ${height}ft`,
          canonical_key: canonicalKey,
          material_type: "vinyl",
          category: "gate",
          sub_category: "double_gate",
          size: `${widthStr}" x ${height}'`,
          unit: "each",
          cost: cost,
          keywords: ["savannah", "gate", "double", `${widthStr}in`, `${height}ft`],
          active: true
        };

        if (mode === 'execute') {
          const created = await base44.entities.MaterialCatalog.create(catalogItem);
          catalogItems.push(created.id);
          linkMaps.push({ canonical_key: canonicalKey, catalog_item_id: created.id });
        } else {
          catalogItems.push(catalogItem);
        }
      }
    }

    // 5. CAPS
    for (const heightStr of Object.keys(CAPS)) {
      const height = parseInt(heightStr);
      const capData = CAPS[heightStr];

      for (const color of SAVANNAH_FAMILY.supported_colors) {
        const canonicalKey = `vinyl_cap_${capData.default}_${height}ft_${color}`;

        const catalogItem = {
          crm_name: `Savannah ${capData.default.replace(/_/g, ' ').toUpperCase()} Cap ${height}ft ${color.charAt(0).toUpperCase() + color.slice(1)}`,
          canonical_key: canonicalKey,
          material_type: "vinyl",
          category: "hardware",
          sub_category: "post_cap",
          finish: color,
          size: `${height}'`,
          unit: "each",
          cost: capData.cost,
          keywords: ["savannah", "cap", `${height}ft`, color],
          active: true
        };

        if (mode === 'execute') {
          const created = await base44.entities.MaterialCatalog.create(catalogItem);
          catalogItems.push(created.id);
          linkMaps.push({ canonical_key: canonicalKey, catalog_item_id: created.id });
        } else {
          catalogItems.push(catalogItem);
        }
      }
    }

    // Execute link maps if in execute mode
    if (mode === 'execute') {
      for (const link of linkMaps) {
        await base44.entities.CatalogLinkMap.create({
          canonical_key: link.canonical_key,
          catalog_item_id: link.catalog_item_id,
          priority: 1,
          active: true
        });
      }

      return Response.json({
        success: true,
        message: `Seeded ${catalogItems.length} catalog items with ${linkMaps.length} links`,
        mode: 'execute'
      });
    } else {
      return Response.json({
        success: true,
        preview: true,
        itemsToCreate: catalogItems.length,
        linksToCreate: linkMaps.length,
        breakdown: {
          panels: PANELS.length,
          posts: SAVANNAH_FAMILY.supported_heights_ft.length * SAVANNAH_FAMILY.supported_colors.length * POST_ROLES.length,
          singleGates: Object.keys(GATES_SINGLE).reduce((sum, w) => sum + Object.keys(GATES_SINGLE[w]).length, 0),
          doubleGates: Object.keys(GATES_DOUBLE).reduce((sum, w) => sum + Object.keys(GATES_DOUBLE[w]).length, 0),
          caps: SAVANNAH_FAMILY.supported_heights_ft.length * SAVANNAH_FAMILY.supported_colors.length
        }
      });
    }
  } catch (error) {
    console.error('[seedSavannahCatalog] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});