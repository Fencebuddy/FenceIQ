import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { upsertCrmJob } from './crm/upsertCrmJob.js';

Deno.serve(async (req) => {
    try {
        // 1. Validate secret header
        const secret = req.headers.get('x-fenceiq-secret');
        const expectedSecret = Deno.env.get('ZAPIER_WEBHOOK_SECRET');
        
        if (!secret || secret !== expectedSecret) {
            return Response.json({ 
                error: 'Unauthorized - Invalid or missing x-fenceiq-secret header' 
            }, { status: 401 });
        }

        // 2. Parse JSON payload
        const payload = await req.json();

        // 3. Validate required fields (customer, address, and contact info)
        const required = ['customerName', 'customerEmail', 'customerPhone', 'addressLine1', 'city', 'state', 'zip'];
        const missing = required.filter(field => !payload[field]);
        
        if (missing.length > 0) {
            return Response.json({ 
                error: 'Missing required fields', 
                missing 
            }, { status: 400 });
        }

        // 5. Create Base44 client with service role (webhook context)
        const base44 = createClientFromRequest(req);

        // 6. Get company context
        const ctxRes = await base44.asServiceRole.functions.invoke('getCompanyContext', {});
        if (!ctxRes?.data?.success || !ctxRes?.data?.companyId) {
            return Response.json({ error: 'Company context unavailable' }, { status: 400 });
        }
        const companyId = ctxRes.data.companyId;

        // 7. Dedupe key: use email or phone (if provided) or customerName + address
        const dedupeKey = payload.customerEmail || payload.customerPhone || 
                         `${payload.customerName}-${payload.addressLine1}`.toLowerCase().replace(/\s+/g, '');

        // 8. Check for existing CRMContact (idempotent)
        let existingContacts = [];
        if (payload.customerEmail) {
            existingContacts = await base44.asServiceRole.entities.CRMContact.filter({
                companyId,
                email: payload.customerEmail
            });
        }
        if (existingContacts.length === 0 && payload.customerPhone) {
            existingContacts = await base44.asServiceRole.entities.CRMContact.filter({
                companyId,
                phoneMobile: payload.customerPhone
            });
        }

        let crmJob;

        if (existingContacts.length > 0) {
            // Contact exists - find existing job linked to this contact
            const existingContact = existingContacts[0];
            const existingJobs = await base44.asServiceRole.entities.CRMJob.filter({
                companyId,
                primaryContactId: existingContact.id
            });
            
            if (existingJobs.length > 0) {
                // Update existing job (non-destructive)
                crmJob = existingJobs[0];
                const updates = {
                    customerName: payload.customerName,
                    stage: 'new'
                };
                crmJob = await base44.asServiceRole.entities.CRMJob.update(crmJob.id, updates);
            } else {
                // Contact exists but no job - create new job and link to existing contact
                const jobNumRes = await base44.asServiceRole.functions.invoke('allocateJobNumber', { companyId });
                const jobNumber = jobNumRes?.data?.success 
                    ? jobNumRes.data.jobNumber 
                    : `Z-${Date.now()}`;

                const crmPatch = {
                    jobNumber,
                    customerName: payload.customerName,
                    externalCRM: 'zapier',
                    externalAppointmentId: dedupeKey,
                    createdFrom: 'appointment_sync',
                    stage: 'new',
                    saleStatus: 'unsold',
                    contractStatus: 'unsigned',
                    lossType: 'na',
                    paymentStatus: 'na',
                    installStatus: 'na',
                    source: 'inbound',
                    contractValueCents: 0,
                    priceSource: 'unknown',
                    customerEmail: payload.customerEmail,
                    customerPhone: payload.customerPhone,
                    accountId: existingContact.accountId,
                    primaryContactId: existingContact.id
                };

                const upsertRes = await upsertCrmJob({
                    base44: base44.asServiceRole,
                    tenantId: companyId,
                    patch: crmPatch,
                    mode: 'appointment_sync'
                });

                if (!upsertRes?.success) {
                    throw new Error(`CRMJob upsert failed: ${upsertRes?.error?.message || 'unknown'}`);
                }

                crmJob = upsertRes.crmJob;

                // Create activity event
                await base44.asServiceRole.entities.CRMActivityEvent.create({
                    companyId,
                    jobId: crmJob.id,
                    type: 'job_created',
                    occurredAt: new Date().toISOString(),
                    metadata: {
                        source: 'zapier',
                        materialType: payload.materialType,
                        fenceHeight: payload.fenceHeight,
                        style: payload.style
                    }
                });
            }
        } else {
            // Allocate job number
            const jobNumRes = await base44.asServiceRole.functions.invoke('allocateJobNumber', { companyId });
            const jobNumber = jobNumRes?.data?.success 
                ? jobNumRes.data.jobNumber 
                : `Z-${Date.now()}`;

            // Create CRMJob
            const crmPatch = {
                jobNumber,
                customerName: payload.customerName,
                externalCRM: 'zapier',
                externalAppointmentId: dedupeKey,
                createdFrom: 'appointment_sync',
                stage: 'new',
                saleStatus: 'unsold',
                contractStatus: 'unsigned',
                lossType: 'na',
                paymentStatus: 'na',
                installStatus: 'na',
                source: 'inbound',
                contractValueCents: 0,
                priceSource: 'unknown',
                customerEmail: payload.customerEmail,
                customerPhone: payload.customerPhone
            };

            const upsertRes = await upsertCrmJob({
                base44: base44.asServiceRole,
                tenantId: companyId,
                patch: crmPatch,
                mode: 'appointment_sync'
            });

            if (!upsertRes?.success) {
                throw new Error(`CRMJob upsert failed: ${upsertRes?.error?.message || 'unknown'}`);
            }

            crmJob = upsertRes.crmJob;

            // Create CRMAccount
            const account = await base44.asServiceRole.entities.CRMAccount.create({
                companyId,
                displayName: payload.customerName,
                accountType: 'residential'
            });

            // Create CRMContact
            let contact;
            if (payload.customerEmail || payload.customerPhone) {
                const [firstName, ...lastNameParts] = payload.customerName.split(' ');
                contact = await base44.asServiceRole.entities.CRMContact.create({
                    companyId,
                    accountId: account.id,
                    firstName: firstName || 'Unknown',
                    lastName: lastNameParts.join(' ') || '',
                    email: payload.customerEmail,
                    phoneMobile: payload.customerPhone,
                    isPrimary: true
                });
            }

            // Create CRMAddress
            const address = await base44.asServiceRole.entities.CRMAddress.create({
                companyId,
                accountId: account.id,
                addressType: 'service',
                addressLine1: payload.addressLine1,
                city: payload.city,
                state: payload.state,
                zip: payload.zip,
                isPrimary: true
            });

            // Link account, contact, and address to CRMJob
            await base44.asServiceRole.entities.CRMJob.update(crmJob.id, {
                accountId: account.id,
                primaryContactId: contact?.id,
                jobsiteAddressId: address.id
            });

            // Create activity event
            await base44.asServiceRole.entities.CRMActivityEvent.create({
                companyId,
                jobId: crmJob.id,
                type: 'job_created',
                occurredAt: new Date().toISOString(),
                metadata: {
                    source: 'zapier',
                    materialType: payload.materialType,
                    fenceHeight: payload.fenceHeight,
                    style: payload.style
                }
            });
        }

        return Response.json({ 
            success: true, 
            crmJobId: crmJob.id,
            jobNumber: crmJob.jobNumber,
            message: existingContacts.length > 0 ? 'Job updated (duplicate prevented)' : 'Job created successfully'
        });

    } catch (error) {
        console.error('Zapier webhook error:', error);
        return Response.json({ 
            error: error.message,
            details: error.stack 
        }, { status: 500 });
    }
});