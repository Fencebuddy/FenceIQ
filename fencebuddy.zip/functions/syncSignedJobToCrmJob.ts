/**
 * SYNC SIGNED JOB TO CRM JOB
 * Phase 5: Real-time sync automation
 * 
 * Triggered by entity automation when Job is created/updated.
 * - Checks if Job is signed
 * - Creates or updates corresponding CRMJob
 * - Idempotent
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function isJobSigned(job) {
  const hasProposalAccepted = job.proposalAccepted === true;
  const hasSignedField = job.signedAt || job.customerSignatureName;
  const hasSignatureRecord = job.signatureRecordId;
  
  return hasProposalAccepted || hasSignedField || hasSignatureRecord;
}

function buildCrmJobUpdate(job, companyId) {
  return {
    companyId,
    jobNumber: job.jobNumber || `JOB-${job.id.slice(0, 8)}`,
    status: 'won',
    stage: 'signed',
    saleStatus: 'sold',
    contractStatus: 'signed',
    externalJobId: job.id,
    createdFrom: 'manual',
    customerName: job.customerName,
    signatureRecordId: job.signatureRecordId || null,
    wonAt: job.signedAt ? new Date(job.signedAt).toISOString() : new Date().toISOString()
  };
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const { event, data } = await req.json();

    if (!event || !data) {
      return Response.json({ error: 'event and data required' }, { status: 400 });
    }

    const job = data;
    console.log(`[SyncSignedJob] Processing Job ${job.jobNumber} (${job.id})`);

    // Check if job is signed
    if (!isJobSigned(job)) {
      console.log(`[SyncSignedJob] Job ${job.jobNumber} is not signed, skipping`);
      return Response.json({
        jobId: job.id,
        status: 'skipped',
        reason: 'Job not signed'
      });
    }

    // Check if already linked to a CRMJob
    const existingCrmJob = await base44.asServiceRole.entities.CRMJob.filter({
      externalJobId: job.id
    });

    if (existingCrmJob.length > 0) {
      // Update existing CRMJob
      const crmJob = existingCrmJob[0];
      console.log(`[SyncSignedJob] Updating existing CRMJob ${crmJob.id}`);
      
      const updateData = buildCrmJobUpdate(job, job.companyId);
      await base44.asServiceRole.entities.CRMJob.update(crmJob.id, updateData);

      return Response.json({
        jobId: job.id,
        crmJobId: crmJob.id,
        status: 'updated',
        timestamp: new Date().toISOString()
      });
    } else {
      // Create new CRMJob
      console.log(`[SyncSignedJob] Creating new CRMJob for Job ${job.jobNumber}`);
      
      const crmJobData = buildCrmJobUpdate(job, job.companyId);
      const newCrmJob = await base44.asServiceRole.entities.CRMJob.create(crmJobData);

      return Response.json({
        jobId: job.id,
        crmJobId: newCrmJob.id,
        status: 'created',
        timestamp: new Date().toISOString()
      });
    }

  } catch (error) {
    console.error('[SyncSignedJob] ERROR:', error);
    return Response.json(
      { error: error.message, timestamp: new Date().toISOString() },
      { status: 500 }
    );
  }
});