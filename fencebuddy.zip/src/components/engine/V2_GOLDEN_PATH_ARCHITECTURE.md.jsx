# V2 Golden Path Architecture

**DETERMINISTIC TRACED PIPELINE FOR FENCEBUDDY**

## Overview

The V2 pipeline ensures that every job follows a single, traceable path from map changes through pricing:

```
[MAP SAVE] → [TAKEOFF SNAPSHOT] → [SEED MAPPINGS] → [RESOLVE] → [PRICE] → [SNAPSHOT]
     ↓             ↓                    ↓                ↓          ↓         ↓
  MAP_SAVE_WRITE  SNAPSHOT_CREATE   MAPPING_SEED_PASS  RESOLVER   PRICING   SNAPSHOT_WRITE
  (Job.mapData)   (inputHash)       (CompanySkuMap)    (UCK→Cat)  (Cost)    (JobCost)
                  (dedup)           (UnmappedItem)     (no fallback) (no legacy) (locked)
                  (1 source)
```

**KEY GUARANTEES:**
- ✅ Deterministic: Same input hash = reuse snapshot
- ✅ No localStorage: All sources are entities
- ✅ No legacy: V1 resolver disabled
- ✅ Traced: Every step logged to FlowTrace
- ✅ No fallbacks: Pipeline fails loudly, not silently

---

## ENTITIES (New/Modified)

### FlowTrace
Tracks every step of the deterministic pipeline.

**Fields:**
- `traceId` (UUID) - Unique trace per user action
- `jobId` (FK Job)
- `variantKey` (CURRENT, A, B, C)
- `stepName` (MAP_SAVE_WRITE, TAKEOFF_SNAPSHOT_CREATE, MAPPING_SEED_PASS, RESOLVER_RUN, PRICING_RUN, JOBCOST_SNAPSHOT_WRITE)
- `functionName`
- `timestamp` (ISO)
- `inputHashes` (object) - Hash of all inputs
- `sourcesUsed` (array) - Explicit sources read
- `fallbacksUsed` (array) - Should be EMPTY
- `errorOccurred` (bool)
- `errorMessage` (string)
- `entityReads` (array) - Queries executed
- `entityWrites` (array) - Creates/updates
- `durationMs` (number)

### UnmappedItem
Visibility into which takeoff UCKs need mapping configuration.

**Fields:**
- `companyId` (FK CompanySettings)
- `jobId` (FK Job)
- `takeoffSnapshotId` (FK TakeoffSnapshot)
- `uck` (string) - Universal Canonical Key
- `mappingKey` (string) - hash(uck + normalizedAttributes)
- `attributesNormalized` (object) - Sorted, consistent casing
- `displayName` (string)
- `quantity`, `unit`
- `autoMapCandidates` (array) - Auto-map suggestions
- `status` (new | user_reviewing | auto_mapped | user_mapped | ignored)
- `createdAt`, `resolvedAt`

---

## FUNCTIONS (New)

### getOrCreateTakeoffSnapshotV2
**File:** `components/services/goldenPath/getOrCreateTakeoffSnapshotV2.js`

Load Job + Runs → compute inputHash → reuse if exists → else build new → trace every step

**Guarantees:**
- No localStorage reads
- No legacy resolver
- Every read traced
- Deterministic deduplication

### seedMappingsForSnapshot
**File:** `functions/seedMappingsForSnapshot.js`

Load TakeoffSnapshot → check CompanySkuMap → create UnmappedItem for missing → auto-map if possible

**Metrics:** mappedCount, unmappedCount, autoMappedCount

### normalizeAttributes
**File:** `components/materials/normalizeAttributes.js`

Normalize attributes (sort keys, lowercase, consistent units) for deterministic mapping keys

---

## QUERY INVALIDATION STRATEGY

### After Map Save
```javascript
queryClient.invalidateQueries({ queryKey: ['job', jobId] });
queryClient.invalidateQueries({ queryKey: ['takeoffSnapshot', jobId] });
```

### After Mapping Save
```javascript
queryClient.invalidateQueries({ queryKey: ['companySkuMap', companyId] });
queryClient.invalidateQueries({ queryKey: ['unmappedItems', companyId] });
```

---

## FLOW TRACE EXAMPLE

Good trace (no fallbacks):
```
✅ MAP_SAVE_WRITE (45ms) | fallbacks=0
✅ TAKEOFF_SNAPSHOT_CREATE (320ms) | fallbacks=0
✅ MAPPING_SEED_PASS (180ms) | fallbacks=0
✅ RESOLVER_RUN (95ms) | fallbacks=0
✅ PRICING_RUN (280ms) | fallbacks=0
✅ JOBCOST_SNAPSHOT_WRITE (60ms) | fallbacks=0
```

Bad trace (would fail):
```
❌ TAKEOFF_SNAPSHOT_CREATE (320ms) | fallbacks=1
  ⚠️ FALLBACK: Used localStorage (stale data)
```

---

## CHECKLIST (Non-Negotiable)

- [ ] JobCost calls getOrCreateTakeoffSnapshotV2 (not buildTakeoff directly)
- [ ] seedMappingsForSnapshot runs before pricing
- [ ] Resolver only queries CompanySkuMap (no V1 fallbacks)
- [ ] FlowTrace created for every step (0 fallbacks expected)
- [ ] FenceSystemConfig locked=true on user confirm
- [ ] React Query invalidation on save
- [ ] Test: Map Save → Price → Verify trace has 0 fallbacks
- [ ] Test: Missing mapping → UnmappedItem created, pricing blocked

---

## REMOVED LEGACY CALLS

| File | Function |
|------|----------|
| pages/JobCost.js | buildTakeoff() direct call |
| components/materials/universalResolver.js | localStorage fallback |
| components/pricing/pricingService.js | V1ResolverEngine |