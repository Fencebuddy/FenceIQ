/**
 * TRUTH SET SERVICE
 * Deterministic canonical data for KPI computation
 * Enforces data integrity rules and inclusion criteria
 *
 * NOTE: All functions accept pre-fetched `allJobs` to avoid redundant fetches.
 * The orchestrator (kpiAnalyticsService) fetches CRMJobs once and passes them in.
 */

import { base44 } from '@/api/base44Client';

/**
 * Load all snapshot data needed for a set of CRM jobs.
 * Returns { proposalMap, saleSnapshotMap, costMap }
 */
export async function loadSnapshotMaps(allJobs) {
    const proposalIdSet = new Set();
    const externalJobIds = [];
    const crmJobIdSet = new Set();

    for (const job of allJobs) {
        crmJobIdSet.add(job.id);
        if (job.currentProposalSnapshotId) {
            proposalIdSet.add(job.currentProposalSnapshotId);
        } else if (job.externalJobId) {
            externalJobIds.push(job.externalJobId);
        }
    }

    // Fetch all snapshots in 3 bulk parallel requests (no N+1)
    const [allProposals, allSaleSnapshots, allJobCostSnapshots] = await Promise.all([
        base44.entities.ProposalPricingSnapshot.list('-created_date', 2000).catch(() => []),
        base44.entities.SaleSnapshot.list('-created_date', 2000).catch(() => []),
        externalJobIds.length > 0
            ? base44.entities.JobCostSnapshot.list('-created_date', 2000).catch(() => [])
            : Promise.resolve([])
    ]);

    // Build proposal map (by id and by job_id)
    const proposalMap = new Map();
    allProposals.forEach(pps => {
        if (proposalIdSet.has(pps.id)) {
            proposalMap.set(pps.id, pps);
        }
        if (pps.job_id && externalJobIds.includes(pps.job_id)) {
            proposalMap.set(pps.job_id, pps);
        }
    });

    // Build sale snapshot map — keep latest per crmJobId
    const saleSnapshotMap = new Map();
    allSaleSnapshots.forEach(ss => {
        if (!crmJobIdSet.has(ss.crmJobId)) return;
        const existing = saleSnapshotMap.get(ss.crmJobId);
        if (!existing || new Date(ss.soldAt) > new Date(existing.soldAt)) {
            saleSnapshotMap.set(ss.crmJobId, ss);
        }
    });

    // Build cost map for externalJobId fallback
    const costMap = new Map();
    allJobCostSnapshots.forEach(jcs => {
        if (jcs.jobId && externalJobIds.includes(jcs.jobId) && !costMap.has(jcs.jobId)) {
            costMap.set(jcs.jobId, jcs);
        }
    });

    console.log('[TruthSet] Snapshot maps loaded:', {
        proposals: proposalMap.size,
        saleSnapshots: saleSnapshotMap.size,
        costSnapshots: costMap.size,
    });

    return { proposalMap, saleSnapshotMap, costMap };
}

/**
 * Get signed deals truth set with full integrity checks
 */
export function buildSignedDealsTruthSet({ allJobs, proposalMap, saleSnapshotMap, costMap, dateStart, dateEnd, repId, territoryId, leadSource, productSystem, financingOnly }) {
    const start = new Date(dateStart);
    const end = new Date(dateEnd);
    end.setDate(end.getDate() + 1);

    const truthRows = [];

    for (const job of allJobs) {
        // Use same logic as isSoldForReporting
        if (job.saleVoidedAt) continue;
        if (job.saleStatus === 'unsold') continue;
        const isSold = job.installStatus === 'installed' ||
            job.paymentStatus === 'payment_received' ||
            job.contractStatus === 'signed' ||
            job.saleStatus === 'sold';
        if (!isSold) continue;

        const dateAnchor = job.wonAt || job.saleStatusUpdatedAt || job.created_date;
        const dateEstimated = !job.wonAt;
        const jobDate = new Date(dateAnchor);
        if (jobDate < start || jobDate > end) continue;

        if (repId && job.assignedRepUserId !== repId) continue;
        if (territoryId && job.territoryId !== territoryId) continue;
        if (leadSource && job.source !== leadSource) continue;
        if (productSystem && job.fenceCategory !== productSystem) continue;
        if (financingOnly && !job.financingEnabled) continue;

        let proposalSnapshot = null;
        if (job.currentProposalSnapshotId) proposalSnapshot = proposalMap.get(job.currentProposalSnapshotId);
        if (!proposalSnapshot && job.externalJobId) proposalSnapshot = proposalMap.get(job.externalJobId);

        let integrityStatus = 'OK';
        let missingFields = [];
        if (!proposalSnapshot) {
            integrityStatus = 'MISSING_PROPOSAL';
            missingFields.push('proposal_snapshot');
        }

        let agreedSubtotal = 0, directCost = 0, netProfit = 0, netMarginPct = 0;
        let overheadPercent = 0.14, commissionPercent = 0.10;
        let modelSellPrice = null, presentedSellPrice = null, overrideApplied = false;
        let revenueSource = 'unknown';

        const saleSnapshot = saleSnapshotMap.get(job.id);

        if (saleSnapshot && saleSnapshot.contractValueCents > 0) {
            agreedSubtotal = saleSnapshot.contractValueCents / 100;
            revenueSource = 'sale_snapshot';
            if (saleSnapshot.direct_cost_cents > 0) {
                directCost = saleSnapshot.direct_cost_cents / 100;
                netProfit = saleSnapshot.net_profit_cents / 100;
                netMarginPct = agreedSubtotal > 0 ? (netProfit / agreedSubtotal) * 100 : 0;
            } else {
                integrityStatus = 'MISSING_COST';
                missingFields.push('direct_cost');
            }
            if (proposalSnapshot) {
                overheadPercent = proposalSnapshot.overhead_percent || 0.14;
                commissionPercent = proposalSnapshot.commission_percent || 0.10;
                modelSellPrice = proposalSnapshot.model_sell_price;
                presentedSellPrice = proposalSnapshot.presented_sell_price;
                overrideApplied = proposalSnapshot.override_applied || false;
            }
        } else if (proposalSnapshot) {
            revenueSource = 'proposal_snapshot';
            agreedSubtotal = proposalSnapshot.agreed_subtotal || 0;
            overheadPercent = proposalSnapshot.overhead_percent || 0.14;
            commissionPercent = proposalSnapshot.commission_percent || 0.10;
            modelSellPrice = proposalSnapshot.model_sell_price;
            presentedSellPrice = proposalSnapshot.presented_sell_price;
            overrideApplied = proposalSnapshot.override_applied || false;

            if (proposalSnapshot.direct_cost && proposalSnapshot.direct_cost > 0) {
                directCost = proposalSnapshot.direct_cost;
            } else if (job.externalJobId) {
                const costSnapshot = costMap.get(job.externalJobId);
                if (costSnapshot && costSnapshot.direct_cost > 0) {
                    directCost = costSnapshot.direct_cost;
                } else {
                    integrityStatus = 'MISSING_COST';
                    missingFields.push('direct_cost');
                }
            } else {
                integrityStatus = 'MISSING_COST';
                missingFields.push('direct_cost');
            }

            if (integrityStatus !== 'MISSING_COST' && directCost > 0) {
                const overhead = agreedSubtotal * overheadPercent;
                const commission = agreedSubtotal * commissionPercent;
                netProfit = agreedSubtotal - directCost - overhead - commission;
                netMarginPct = agreedSubtotal > 0 ? (netProfit / agreedSubtotal) * 100 : 0;
            }
        }

        if (proposalSnapshot && (!proposalSnapshot.model_sell_price || proposalSnapshot.model_sell_price <= 0)) {
            if (integrityStatus === 'OK') integrityStatus = 'MODEL_UNAVAILABLE';
            missingFields.push('model_sell_price');
        }

        truthRows.push({
            crmJobId: job.id, jobNumber: job.jobNumber, customerName: job.customerName,
            repUserId: job.assignedRepUserId, territoryId: job.territoryId,
            leadSource: job.source, productSystem: job.fenceCategory,
            wonAt: job.wonAt || job.created_date, dateEstimated,
            agreedSubtotal, directCost, netProfit, netMarginPct,
            overheadPercent, commissionPercent, modelSellPrice, presentedSellPrice, overrideApplied,
            integrityStatus, missingFields, proposalSnapshotId: job.currentProposalSnapshotId,
            hasFinancing: job.financingEnabled || false,
            revenueSource, hasSaleSnapshot: !!saleSnapshot
        });
    }

    console.log('[Truth Set] Signed deals:', {
        total: truthRows.length,
        ok: truthRows.filter(r => r.integrityStatus === 'OK').length,
        missingProposal: truthRows.filter(r => r.integrityStatus === 'MISSING_PROPOSAL').length,
        missingCost: truthRows.filter(r => r.integrityStatus === 'MISSING_COST').length,
    });

    return truthRows;
}

/**
 * Build appointments truth set from pre-fetched jobs
 */
export function buildAppointmentsTruthSet({ allJobs, dateStart, dateEnd, repId }) {
    const start = new Date(dateStart);
    const end = new Date(dateEnd);
    end.setDate(end.getDate() + 1);
    const rows = [];

    for (const job of allJobs) {
        const dateAnchor = job.appointmentDateTime || job.created_date;
        const jobDate = new Date(dateAnchor);
        if (jobDate < start || jobDate > end) continue;
        if (repId && job.assignedRepUserId !== repId) continue;

        let status, ranProxy = false;
        if (job.appointmentStatus === 'cancelled') {
            status = 'CANCELED';
        } else if (job.appointmentStatus === 'completed') {
            status = 'RAN';
        } else if (job.saleStatus === 'sold' || job.contractStatus === 'signed') {
            status = 'RAN'; ranProxy = true;
        } else if (job.appointmentStatus === 'scheduled' || job.appointmentStatus === 'rescheduled') {
            status = 'SET';
        } else {
            continue;
        }

        rows.push({
            crmJobId: job.id, jobNumber: job.jobNumber, repUserId: job.assignedRepUserId,
            status, ranProxy, scheduledAt: job.appointmentDateTime || job.created_date,
            ranAt: job.appointmentStatus === 'completed' ? job.updated_date : null
        });
    }
    return rows;
}

/**
 * Build production truth set from pre-fetched jobs
 */
export function buildProductionTruthSet({ allJobs, dateStart, dateEnd, crewId, installStage }) {
    const start = new Date(dateStart);
    const end = new Date(dateEnd);
    end.setDate(end.getDate() + 1);
    const rows = [];
    const now = new Date();

    for (const job of allJobs) {
        if (job.saleVoidedAt) continue;
        if (job.saleStatus === 'unsold') continue;
        const isSoldProd = job.installStatus === 'installed' ||
            job.paymentStatus === 'payment_received' ||
            job.contractStatus === 'signed' ||
            job.saleStatus === 'sold';
        if (!isSoldProd) continue;
        const jobDate = new Date(job.wonAt || job.created_date);
        if (jobDate < start || jobDate > end) continue;
        if (crewId && job.crewId !== crewId) continue;
        if (installStage && job.installStage !== installStage) continue;

        const daysInStage = job.installStageUpdatedAt
            ? Math.floor((now - new Date(job.installStageUpdatedAt)) / (1000 * 60 * 60 * 24))
            : 0;

        rows.push({
            crmJobId: job.id, jobNumber: job.jobNumber,
            installStage: job.installStage || 'SOLD_NOT_SCHEDULED',
            daysInStage, crewId: job.crewId,
            scheduledAt: job.installScheduledAt, completedAt: job.installCompletedAt
        });
    }
    return rows;
}

// Legacy async wrappers for backward compatibility (used by other callers)
export async function getSignedDealsTruthSet(params) {
    const allJobs = await base44.entities.CRMJob.filter({ companyId: params.companyId }, '-created_date', 2000);
    const maps = await loadSnapshotMaps(allJobs);
    return buildSignedDealsTruthSet({ allJobs, ...maps, ...params });
}

export async function getAppointmentsTruthSet(params) {
    const allJobs = await base44.entities.CRMJob.filter({ companyId: params.companyId }, '-created_date', 2000);
    return buildAppointmentsTruthSet({ allJobs, ...params });
}

export async function getPricingDisciplineTruthSet(params) {
    const signedDeals = await getSignedDealsTruthSet(params);
    const eligible = signedDeals.filter(d => d.modelSellPrice > 0 && d.presentedSellPrice > 0);
    return eligible.map(deal => {
        const deviation = Math.abs((deal.presentedSellPrice - deal.modelSellPrice) / deal.modelSellPrice);
        return { ...deal, deviation: deviation * 100, isOverride: deviation > 0.02 };
    });
}

export async function getProductionTruthSet(params) {
    const allJobs = await base44.entities.CRMJob.filter({ companyId: params.companyId }, '-created_date', 2000);
    return buildProductionTruthSet({ allJobs, ...params });
}