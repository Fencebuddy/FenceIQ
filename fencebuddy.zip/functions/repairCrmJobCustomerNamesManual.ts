/**
 * repairCrmJobCustomerNamesManual — Canonical Root-Level Repair + Debug
 * Purpose:
 * 1) Eliminate 404 routing ambiguity by being root-level.
 * 2) Provide debugScan + dryRun repair for missing CRMJob.customerName.
 *
 * Payload:
 * { __echo?: true, debugScan?: true, dryRun?: boolean, limit?: number }
 */

import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

function safeText(v) {
  const s = (v ?? "").toString().trim();
  return s.length ? s : null;
}

function computeCustomerNameFromJobLike(obj) {
  // Deterministic fallback chain
  const direct = safeText(obj?.customerName);
  if (direct) return direct;

  const first = safeText(obj?.firstName);
  const last = safeText(obj?.lastName);
  const full = safeText([first, last].filter(Boolean).join(" "));
  if (full) return full;

  const email = safeText(obj?.email);
  if (email) return email;

  const phone = safeText(obj?.phone);
  if (phone) return phone;

  return null;
}

async function resolveCompanyContext({ base44, req }) {
  // Tenant Resolution Ladder (future-proof)
  // Tier 1: header selector (future multi-tenant)
  const headerCompanyKey = req.headers.get("x-company-id");
  if (headerCompanyKey) {
    const matches = await base44.entities.CompanySettings.filter({ companyId: headerCompanyKey });
    if (Array.isArray(matches) && matches.length === 1) {
      return {
        mode: "header",
        tenantId: matches[0].id,
        companyKey: matches[0].companyId ?? null,
        company: matches[0]
      };
    }
    if (Array.isArray(matches) && matches.length > 1) {
      throw new Error("MULTI_TENANT_AMBIGUOUS_HEADER: multiple CompanySettings match x-company-id");
    }
    throw new Error("COMPANY_NOT_FOUND_FOR_HEADER: x-company-id provided but no CompanySettings match");
  }

  // Tier 2: primary company
  const primary = await base44.entities.CompanySettings.filter({ isPrimary: true });
  if (Array.isArray(primary) && primary.length === 1) {
    return {
      mode: "primary",
      tenantId: primary[0].id,
      companyKey: primary[0].companyId ?? null,
      company: primary[0]
    };
  }
  if (Array.isArray(primary) && primary.length > 1) {
    throw new Error("MULTI_PRIMARY_COMPANY_SETTINGS: more than one CompanySettings has isPrimary=true");
  }

  // Tier 3: single-record invariant
  const all = await base44.entities.CompanySettings.list();
  if (!Array.isArray(all) || all.length === 0) {
    throw new Error("COMPANY_SETTINGS_MISSING: no CompanySettings records exist");
  }
  if (all.length === 1) {
    return {
      mode: "single_record",
      tenantId: all[0].id,
      companyKey: all[0].companyId ?? null,
      company: all[0]
    };
  }

  // Tier 4: ambiguous multi-tenant
  throw new Error("MULTI_TENANT_CONTEXT_REQUIRED: multiple CompanySettings exist; set isPrimary or pass x-company-id");
}

async function companyScopeQuery({ entity, tenantId, companyKey }) {
  // Dual-scope read: tenantId first, then companyKey (fault-tolerant), merge+dedupe by id, tenantId wins
  let byTenant = [];
  let byKey = [];
  let tenantErr = null;
  let keyErr = null;

  if (tenantId) {
    try {
      byTenant = await entity.filter({ companyId: tenantId });
    } catch (e) {
      tenantErr = e;
    }
  }

  if (companyKey && companyKey !== tenantId) {
    try {
      byKey = await entity.filter({ companyId: companyKey });
    } catch (e) {
      keyErr = e;
    }
  }

  if (tenantErr && (companyKey && companyKey !== tenantId) && keyErr) {
    throw new Error(
      `companyScopeQuery failed for both scopes. tenantId=${String(tenantId)} companyKey=${String(companyKey)} ` +
      `tenantErr=${tenantErr?.message || tenantErr} keyErr=${keyErr?.message || keyErr}`
    );
  }

  const merged = new Map();
  for (const r of byKey) merged.set(r.id, r);
  for (const r of byTenant) merged.set(r.id, r);

  return Array.from(merged.values());
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ success: false, error: "Unauthorized" }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const __echo = payload?.__echo === true;
    const debugScan = payload?.debugScan === true;
    const dryRun = payload?.dryRun !== false; // default true
    const limit = Number.isFinite(Number(payload?.limit)) ? Math.max(1, Math.min(1000, Number(payload.limit))) : 200;

    if (__echo) {
      return Response.json({
        success: true,
        echo: {
          route: "repairCrmJobCustomerNamesManual",
          receivedPayload: payload,
          parsed: { __echo, debugScan, dryRun, limit }
        }
      });
    }

    const ctx = await resolveCompanyContext({ base44, req });
    const { tenantId, companyKey, mode } = ctx;

    // Pull jobs from both scopes (deduped)
    const jobsAll = await companyScopeQuery({
      entity: base44.entities.CRMJob,
      tenantId,
      companyKey
    });

    // limit to most recent-ish (if createdAt exists)
    const jobs = jobsAll
      .slice()
      .sort((a, b) => new Date(b.createdAt || b.created_date || 0) - new Date(a.createdAt || a.created_date || 0))
      .slice(0, limit);

    if (debugScan) {
      const distinct = (arr) => Array.from(new Set(arr.filter(Boolean)));
      const samples = jobs.slice(0, 25).map((j) => ({
        id: j.id,
        jobNumber: j.jobNumber ?? null,
        customerName: j.customerName ?? null,
        createdFrom: j.createdFrom ?? null,
        source: j.source ?? null,
        externalCRM: j.externalCRM ?? null,
        externalJobId: j.externalJobId ?? null,
        primaryContactId: j.primaryContactId ?? null,
        accountId: j.accountId ?? null,
        companyId: j.companyId ?? null
      }));

      const missingCustomerNameCount = jobs.filter((j) => !safeText(j.customerName)).length;

      return Response.json({
        success: true,
        context: { tenantId, companyKey, mode },
        debug: {
          sampleCount: jobs.length,
          missingCustomerNameCount,
          distinct_externalCRM: distinct(jobs.map((j) => j.externalCRM)),
          distinct_createdFrom: distinct(jobs.map((j) => j.createdFrom)),
          distinct_source: distinct(jobs.map((j) => j.source)),
          companyId_values: distinct(jobs.map((j) => j.companyId)),
          externalJobId_present: { true: jobs.filter((j) => !!j.externalJobId).length, false: jobs.filter((j) => !j.externalJobId).length },
          primaryContactId_present: { true: jobs.filter((j) => !!j.primaryContactId).length, false: jobs.filter((j) => !j.primaryContactId).length },
          accountId_present: { true: jobs.filter((j) => !!j.accountId).length, false: jobs.filter((j) => !j.accountId).length },
          samples
        }
      });
    }

    // Repair mode (manual jobs with missing customerName)
    const needsRepair = jobs.filter((j) => !safeText(j.customerName));
    let updated = 0;
    let stillMissing = 0;
    const idsToUpdate = [];

    for (const j of needsRepair) {
      let candidate = null;

      // 1) try derive from linked Contact/Account if present
      if (!candidate && j.primaryContactId) {
        try {
          const c = await base44.entities.CRMContact.read(j.primaryContactId);
          candidate = computeCustomerNameFromJobLike(c);
        } catch {}
      }
      if (!candidate && j.accountId) {
        try {
          const a = await base44.entities.CRMAccount.read(j.accountId);
          candidate = computeCustomerNameFromJobLike(a) || safeText(a?.name);
        } catch {}
      }

      // 2) try linked Job record if externalJobId exists (legacy)
      if (!candidate && j.externalJobId) {
        try {
          const job = await base44.entities.Job.read(j.externalJobId);
          candidate = computeCustomerNameFromJobLike(job);
        } catch {}
      }

      // 3) last-resort: use fallback value (never a placeholder)
      if (!candidate) {
        candidate = "Unknown Customer";
      }

      if (candidate) {
        idsToUpdate.push({ id: j.id, customerName: candidate });
        if (!dryRun) {
          // service role avoids UI permission edge cases
          await base44.asServiceRole.entities.CRMJob.update(j.id, { customerName: candidate });
        }
        updated += dryRun ? 0 : 1;
      } else {
        stillMissing += 1;
      }
    }

    return Response.json({
      success: true,
      context: { tenantId, companyKey, mode },
      summary: {
        scanned: jobs.length,
        needsRepair: needsRepair.length,
        updated,
        stillMissing,
        dryRun
      },
      idsToUpdate: dryRun ? idsToUpdate : []
    });
  } catch (e) {
    return Response.json({ success: false, error: e?.message || String(e) }, { status: 500 });
  }
});