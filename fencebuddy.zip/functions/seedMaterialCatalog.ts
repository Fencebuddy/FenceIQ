/**
 * Seed Material Catalog
 * Populates MaterialCatalog and CatalogLinkMap with FenceBuddy pricing
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { 
  VINYL_MATERIALS, 
  CHAIN_LINK_MATERIALS, 
  WOOD_MATERIALS, 
  ALUMINUM_MATERIALS 
} from '../components/catalog/fenceBuddyMaterialData.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }
    
    const { mode = 'preview' } = await req.json();
    
    // Combine all materials
    const allMaterials = [
      ...VINYL_MATERIALS,
      ...CHAIN_LINK_MATERIALS,
      ...WOOD_MATERIALS,
      ...ALUMINUM_MATERIALS
    ];
    
    console.log(`[seedMaterialCatalog] Processing ${allMaterials.length} materials in ${mode} mode`);
    
    if (mode === 'preview') {
      // Preview mode - return what would be created
      return Response.json({
        mode: 'preview',
        total_materials: allMaterials.length,
        breakdown: {
          vinyl: VINYL_MATERIALS.length,
          chain_link: CHAIN_LINK_MATERIALS.length,
          wood: WOOD_MATERIALS.length,
          aluminum: ALUMINUM_MATERIALS.length
        },
        sample_materials: allMaterials.slice(0, 10),
        message: 'Preview successful - call with mode=execute to create records'
      });
    }
    
    // Execute mode - create records
    const createdCatalog = [];
    const createdLinks = [];
    const errors = [];
    
    // Check if records already exist
    const existingCatalog = await base44.asServiceRole.entities.MaterialCatalog.list();
    const existingLinks = await base44.asServiceRole.entities.CatalogLinkMap.list();
    
    console.log(`[seedMaterialCatalog] Existing: ${existingCatalog.length} catalog, ${existingLinks.length} links`);
    
    for (const material of allMaterials) {
      try {
        // Check if catalog item exists by canonical_key
        const existingItem = existingCatalog.find(c => 
          c.fencebuddy_mapping === material.canonical_key
        );
        
        let catalogItem;
        if (existingItem) {
          // Update existing
          catalogItem = await base44.asServiceRole.entities.MaterialCatalog.update(existingItem.id, {
            crm_name: material.crm_name,
            cost: material.cost,
            unit: material.unit,
            category: material.category,
            material_type: material.material_type,
            size: material.size || null,
            finish: material.finish || null,
            fencebuddy_mapping: material.canonical_key,
            active: true,
            last_updated: new Date().toISOString()
          });
          console.log(`[seedMaterialCatalog] Updated: ${material.crm_name}`);
        } else {
          // Create new
          catalogItem = await base44.asServiceRole.entities.MaterialCatalog.create({
            crm_name: material.crm_name,
            cost: material.cost,
            unit: material.unit,
            category: material.category,
            material_type: material.material_type,
            size: material.size || null,
            finish: material.finish || null,
            fencebuddy_mapping: material.canonical_key,
            active: true,
            source: 'manual',
            last_updated: new Date().toISOString()
          });
          console.log(`[seedMaterialCatalog] Created: ${material.crm_name}`);
        }
        
        createdCatalog.push(catalogItem);
        
        // Create/update CatalogLinkMap
        const existingLink = existingLinks.find(l => 
          l.canonical_key === material.canonical_key
        );
        
        if (existingLink) {
          // Update existing link
          await base44.asServiceRole.entities.CatalogLinkMap.update(existingLink.id, {
            catalog_item_id: catalogItem.id,
            priority: 1,
            active: true
          });
          createdLinks.push(existingLink);
          console.log(`[seedMaterialCatalog] Updated link: ${material.canonical_key}`);
        } else {
          // Create new link
          const link = await base44.asServiceRole.entities.CatalogLinkMap.create({
            canonical_key: material.canonical_key,
            catalog_item_id: catalogItem.id,
            priority: 1,
            active: true,
            notes: `Auto-linked during seed - ${material.crm_name}`
          });
          createdLinks.push(link);
          console.log(`[seedMaterialCatalog] Created link: ${material.canonical_key}`);
        }
        
      } catch (err) {
        console.error(`[seedMaterialCatalog] Error processing ${material.crm_name}:`, err.message);
        errors.push({
          material: material.crm_name,
          error: err.message
        });
      }
    }
    
    return Response.json({
      success: true,
      mode: 'execute',
      catalog_created: createdCatalog.length,
      links_created: createdLinks.length,
      errors: errors.length,
      error_details: errors,
      message: `Successfully seeded ${createdCatalog.length} catalog items and ${createdLinks.length} links`
    });
    
  } catch (error) {
    console.error('[seedMaterialCatalog] Error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});