import { useMemo } from 'react';

function fmt$(cents) {
  if (!cents) return '$0';
  return '$' + (cents / 100).toLocaleString('en-US', { maximumFractionDigits: 0 });
}
function fmtPct(v) {
  if (v === null || v === undefined) return '—';
  return (v * 100).toFixed(1) + '%';
}
function marginColor(m) {
  if (m === null) return 'text-slate-400';
  if (m < 0) return 'text-red-600 font-bold';
  if (m < 0.25) return 'text-amber-600 font-semibold';
  return 'text-green-600';
}

export default function ProfitGroupTable({ jobs, groupKey, labelFn, emptyLabel = 'Unknown', onDrill }) {
  const rows = useMemo(() => {
    const groups = {};
    for (const job of jobs) {
      if (job.recognitionStatus !== 'RECOGNIZED' || !job.contractValueCents) continue;
      const key = job[groupKey] || '__none__';
      if (!groups[key]) groups[key] = { key, label: labelFn ? labelFn(key, job) : (key === '__none__' ? emptyLabel : key), jobs: [] };
      groups[key].jobs.push(job);
    }

    return Object.values(groups).map(g => {
      const totalContract = g.jobs.reduce((s, j) => s + (j.contractValueCents || 0), 0);
      const totalCost = g.jobs.reduce((s, j) => s + (j.directCostCents || 0), 0);
      const netProfit = totalContract - totalCost;
      const margin = totalContract > 0 ? netProfit / totalContract : null;
      const avgContract = g.jobs.length > 0 ? totalContract / g.jobs.length : 0;
      const reworks = g.jobs.filter(j => j.reworkFlag).length;
      return { ...g, totalContract, totalCost, netProfit, margin, avgContract, reworks };
    }).sort((a, b) => (a.margin ?? 999) - (b.margin ?? 999));
  }, [jobs, groupKey, labelFn, emptyLabel]);

  if (rows.length === 0) {
    return <div className="py-12 text-center text-slate-400">No recognized jobs with cost data in range.</div>;
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs uppercase text-slate-500 bg-slate-50 border-b border-slate-200">
              <th className="text-left px-4 py-3">Group</th>
              <th className="text-right px-4 py-3">Jobs</th>
              <th className="text-right px-4 py-3">Revenue</th>
              <th className="text-right px-4 py-3">Cost</th>
              <th className="text-right px-4 py-3">Net Profit</th>
              <th className="text-right px-4 py-3">Margin</th>
              <th className="text-right px-4 py-3">Avg Job</th>
              <th className="text-right px-4 py-3">Reworks</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(r => (
              <tr
                key={r.key}
                className="hover:bg-blue-50 cursor-pointer transition-colors"
                onClick={() => onDrill && onDrill(r)}
              >
                <td className="px-4 py-3 font-medium text-slate-800">{r.label}</td>
                <td className="px-4 py-3 text-right text-slate-600">{r.jobs.length}</td>
                <td className="px-4 py-3 text-right text-slate-700">{fmt$(r.totalContract)}</td>
                <td className="px-4 py-3 text-right text-slate-500">{fmt$(r.totalCost)}</td>
                <td className={`px-4 py-3 text-right ${r.netProfit >= 0 ? 'text-green-600' : 'text-red-500'}`}>{fmt$(r.netProfit)}</td>
                <td className={`px-4 py-3 text-right ${marginColor(r.margin)}`}>{fmtPct(r.margin)}</td>
                <td className="px-4 py-3 text-right text-slate-500">{fmt$(r.avgContract)}</td>
                <td className={`px-4 py-3 text-right ${r.reworks > 0 ? 'text-orange-500 font-semibold' : 'text-slate-400'}`}>{r.reworks}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}