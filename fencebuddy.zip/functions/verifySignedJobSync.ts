/**
 * VERIFY SIGNED JOB SYNC
 * Phase 6: Validate sync success and KPI impact
 * 
 * Post-sync validation:
 * - Confirms CRMJob records were created
 * - Verifies externalJobId linkage
 * - Checks KPI dashboard data availability
 * - Reports sync success metrics
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return Response.json(
        { error: 'Forbidden: Admin access required' },
        { status: 403 }
      );
    }

    const { companyId } = await req.json();

    if (!companyId) {
      return Response.json({ error: 'companyId required' }, { status: 400 });
    }

    console.log(`[VerifySync] Starting verification for company ${companyId}`);

    // Fetch all Jobs
    const allJobs = await base44.asServiceRole.entities.Job.filter({ companyId });
    
    // Filter to signed
    const signedJobs = allJobs.filter(job => 
      job.proposalAccepted === true || 
      job.signedAt || 
      job.customerSignatureName || 
      job.signatureRecordId
    );

    console.log(`[VerifySync] Found ${signedJobs.length} signed Jobs`);

    // Fetch all CRMJobs
    const allCrmJobs = await base44.asServiceRole.entities.CRMJob.filter({ companyId });
    
    // Filter to those linked from Jobs
    const linkedCrmJobs = allCrmJobs.filter(crm => crm.externalJobId);
    const linkedJobIds = new Set(linkedCrmJobs.map(crm => crm.externalJobId));

    console.log(`[VerifySync] Found ${linkedCrmJobs.length} linked CRMJobs`);

    // Calculate coverage
    const synced = signedJobs.filter(job => linkedJobIds.has(job.id));
    const syncRate = signedJobs.length > 0 
      ? Math.round((synced.length / signedJobs.length) * 100) 
      : 0;

    // Find any orphaned CRMJobs (linked to non-existent Jobs)
    const jobIds = new Set(allJobs.map(j => j.id));
    const orphanedCrmJobs = linkedCrmJobs.filter(crm => !jobIds.has(crm.externalJobId));

    // Check for duplicates (same Job linked to multiple CRMJobs)
    const jobLinkCounts = {};
    linkedCrmJobs.forEach(crm => {
      jobLinkCounts[crm.externalJobId] = (jobLinkCounts[crm.externalJobId] || 0) + 1;
    });
    const duplicateLinks = Object.entries(jobLinkCounts)
      .filter(([_, count]) => count > 1)
      .length;

    const report = {
      companyId,
      timestamp: new Date().toISOString(),
      summary: {
        totalSignedJobs: signedJobs.length,
        linkedCrmJobs: linkedCrmJobs.length,
        syncRate: `${syncRate}%`,
        status: syncRate === 100 ? '✓ Complete' : syncRate > 80 ? '⚠ Partial' : '✗ Incomplete'
      },
      dataQuality: {
        orphanedCrmJobs: orphanedCrmJobs.length,
        duplicateLinks,
        healthStatus: orphanedCrmJobs.length === 0 && duplicateLinks === 0 ? '✓ Healthy' : '⚠ Issues detected'
      },
      sampleLinkedJobs: synced.slice(0, 5).map(job => ({
        jobId: job.id,
        jobNumber: job.jobNumber,
        customerName: job.customerName,
        linkedCrmJobId: linkedCrmJobs.find(crm => crm.externalJobId === job.id)?.id
      })),
      recommendations: [
        syncRate === 100 
          ? '✓ All signed Jobs are synced to CRM' 
          : `⚠ ${signedJobs.length - synced.length} signed Jobs still need syncing`,
        orphanedCrmJobs.length > 0
          ? `⚠ Found ${orphanedCrmJobs.length} orphaned CRMJobs - consider cleanup`
          : '✓ No orphaned CRMJobs',
        duplicateLinks > 0
          ? `⚠ Found ${duplicateLinks} Jobs with duplicate CRMJob links`
          : '✓ No duplicate links'
      ]
    };

    console.log('[VerifySync] Complete', report);
    return Response.json(report);

  } catch (error) {
    console.error('[VerifySync] ERROR:', error);
    return Response.json(
      { error: error.message, timestamp: new Date().toISOString() },
      { status: 500 }
    );
  }
});