import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Check for 429 errors in last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    
    // Get all error logs
    const errorLogs = await base44.asServiceRole.entities.DiagnosticsLog.filter({
      logType: 'API_ERROR',
      created_date: { $gte: oneDayAgo }
    });
    
    const rateLimitErrors = errorLogs.filter(log => 
      log.detailsJson?.statusCode === 429 ||
      log.detailsJson?.error?.includes('429') ||
      log.detailsJson?.error?.includes('rate limit')
    );
    
    // Get total request count (approximate from all API logs)
    const totalRequests = await base44.asServiceRole.entities.DiagnosticsLog.filter({
      created_date: { $gte: oneDayAgo }
    });
    
    const rateLimitCount = rateLimitErrors.length;
    const totalCount = totalRequests.length || 1; // Avoid division by zero
    const errorRate = (rateLimitCount / totalCount) * 100;
    
    console.log(`[Rate Limit Monitor] ${rateLimitCount} rate limit errors out of ${totalCount} requests (${errorRate.toFixed(3)}%)`);
    
    const threshold = 0.1; // 0.1%
    
    if (errorRate < threshold) {
      return Response.json({
        success: true,
        timestamp: new Date().toISOString(),
        rateLimitErrors: rateLimitCount,
        totalRequests: totalCount,
        errorRate: errorRate.toFixed(3) + '%',
        status: 'HEALTHY'
      });
    }
    
    // Create alert if above threshold
    await base44.asServiceRole.entities.AlertRecord.create({
      alertType: 'RATE_LIMIT_THRESHOLD_EXCEEDED',
      severity: 'HIGH',
      title: `Rate Limit Errors Exceed ${threshold}%`,
      description: `${rateLimitCount} rate limit errors (${errorRate.toFixed(3)}%) in last 24 hours`,
      detailsJson: {
        rateLimitErrors: rateLimitCount,
        totalRequests: totalCount,
        errorRate: errorRate.toFixed(3) + '%',
        threshold: threshold + '%',
        recentErrors: rateLimitErrors.slice(0, 10).map(e => ({
          timestamp: e.created_date,
          details: e.detailsJson
        }))
      },
      status: 'active'
    });
    
    return Response.json({
      success: false,
      timestamp: new Date().toISOString(),
      rateLimitErrors: rateLimitCount,
      totalRequests: totalCount,
      errorRate: errorRate.toFixed(3) + '%',
      status: 'UNHEALTHY'
    }, { status: 200 });
    
  } catch (error) {
    console.error('[Rate Limit Monitor] Failed:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});