import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Count Savannah items in catalog
    const savannahItems = await base44.entities.MaterialCatalog.filter({
      material_type: "vinyl"
    });
    
    const savannahCount = savannahItems.filter(item => 
      item.canonical_key?.includes('savannah') || 
      item.crm_name?.includes('Savannah')
    ).length;

    // Count CatalogLinkMap entries for Savannah
    const allLinks = await base44.entities.CatalogLinkMap.list('-created_date', 500);
    const savannahLinks = allLinks.filter(link => 
      link.canonical_key?.includes('savannah')
    ).length;

    // Breakdown by type
    const panels = savannahItems.filter(i => 
      i.canonical_key?.includes('panel') && 
      i.canonical_key?.includes('savannah')
    ).length;
    
    const posts = savannahItems.filter(i => 
      i.canonical_key?.includes('post') && 
      i.canonical_key?.includes('savannah')
    ).length;
    
    const gates = savannahItems.filter(i => 
      i.canonical_key?.includes('gate') && 
      i.canonical_key?.includes('savannah')
    ).length;
    
    const caps = savannahItems.filter(i => 
      i.canonical_key?.includes('cap') && 
      i.canonical_key?.includes('savannah')
    ).length;

    return Response.json({
      status: 'complete',
      summary: {
        catalogItemsSeeded: savannahCount,
        linksCreated: savannahLinks,
        isComplete: savannahCount > 0 && savannahLinks > 0
      },
      breakdown: {
        panels,
        posts,
        gates,
        caps
      },
      nextStep: savannahCount > 0 && savannahLinks > 0 
        ? 'All done! Savannah catalog is seeded and linked.' 
        : 'Run seedSavannahCatalog?mode=execute then linkUnresolvedItems?mode=execute'
    });
  } catch (error) {
    console.error('[verifySavannahSeeding] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});