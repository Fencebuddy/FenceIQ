import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, AlertCircle, Sparkles } from "lucide-react";
import { generateMathSubRuns } from '@/components/materials/mathSubRunEngine';
import { base44 } from '@/api/base44Client';
import { RunCompareVariantsEditor } from './RunCompareVariantsEditor';
import { useQueryClient } from '@tanstack/react-query';

const SLOPE_MODES = ['AutoDetect', 'QuickSelect', 'MeasuredDrop'];
const SLOPE_RANGES = ['Level', 'Slight', 'Moderate', 'Heavy', 'Extreme'];
const SLOPE_RANGE_DEFAULTS = {
  'Level': 0,
  'Slight': 0.75,
  'Moderate': 1.5,
  'Heavy': 3,
  'Extreme': 5
};
const END_TYPES = ['Post', 'Gate', 'House/Structure', 'Corner', 'Existing Fence', 'Other'];
const RUN_LABELS = [
  'LEFT FRONT',
  'LEFT SIDE', 
  'LEFT BOTTOM',
  'LEFT TOP',
  'RIGHT FRONT',
  'RIGHT SIDE',
  'RIGHT BOTTOM',
  'RIGHT TOP',
  'FRONT SIDE',
  'BACK LINE',
  'BACK LEFT',
  'BACK RIGHT',
  'ADD ON #1',
  'ADD ON #2',
  'ADD ON #3',
  'ADD ON #4'
];
const MATERIAL_TYPES = ['Vinyl', 'Wood', 'Chain Link', 'Aluminum', 'Livestock'];
const FENCE_HEIGHTS = ["3'", "4'", "5'", "6'", "8'", "10'", "12'"];
// Material-specific styles
const WOOD_STYLES = ['Privacy', 'Picket', 'Semi-Private', 'Shadowbox', 'Board-on-Board', 'Board and Cap', 'Horizontal'];
const LIVESTOCK_STYLES = ['Woven Wire'];
const VINYL_STYLES = ['Privacy', 'Semi-Privacy', 'Picket', 'RanchRail', 'Horizontal'];
const CHAINLINK_STYLES = ['Standard'];
const ALUMINUM_STYLES = ['Ornamental Flat Top', 'Ornamental Picket Top', 'Ornamental Flat Top W/ Puppy Picket'];

// Material-specific colors
const WOOD_COLORS = ['Pine', 'Cedar', 'Cedar Tone'];
const ALUMINUM_COLORS = ['Black', 'Bronze'];
const VINYL_COLORS = ['White', 'Tan', 'Khaki', 'Grey', 'Coastal Grey', 'Cedar Tone', 'Black', 'Two Tone'];
const SINGLE_COLORS = ['White', 'Tan', 'Khaki', 'Grey', 'Coastal Grey', 'Cedar Tone', 'Black'];
const RANCH_STYLE_TYPES = ['2 Rail', '3 Rail', 'Crossbuck'];
const CHAIN_LINK_COATINGS = ['Galvanized', 'Aluminized', 'Black Vinyl Coated'];
const CHAIN_LINK_PRIVACY = ['None', 'Vinyl Slats', 'Privacy Screen'];
const VINYL_SLAT_COLORS = ['White', 'Grey', 'Green', 'Blue', 'Black', 'Tan', 'Khaki', 'Hedge Slat'];

export default function RunForm({ run, jobId, job, assigningLine, onSave, onLineLengthUpdate, onClose, isLoading }) {
  const queryClient = useQueryClient();
  const [showDxfOverrideWarning, setShowDxfOverrideWarning] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [aiSuggesting, setAiSuggesting] = useState(false);

  // Initialize form data with DXF elevation data if available
  const initializeFormData = () => {
    // Prefill lengthLF from drawn line if assigning - round to nearest 0.5 ft
    const rawLength = assigningLine?.drawnLengthFt || run?.lengthLF || '';
    const prefillLength = rawLength ? Math.round(rawLength * 2) / 2 : '';
    
    const baseData = {
      jobId,
      runLabel: '',
      lengthLF: prefillLength,
      materialType: job?.materialType || 'Vinyl',
      fenceHeight: job?.fenceHeight || "6'",
      style: job?.style || 'Privacy',
      ranchStyleType: job?.ranchStyleType || '',
      chainLinkCoating: job?.chainLinkCoating || '',
      chainLinkPrivacyType: job?.chainLinkPrivacyType || 'None',
      vinylSlatColor: job?.vinylSlatColor || '',
      fenceColor: job?.fenceColor || '',
      railsAndPostColor: job?.railsAndPostColor || '',
      picketColor: job?.picketColor || '',
      useCedarPickets: job?.useCedarPickets || false,
      horizontalRunFt: run?.horizontalRunFt || run?.lengthLF || '',
      dropFt: run?.dropFt || 0,
      slopeGrade: run?.slopeGrade || 0,
      slopeRangeLabel: run?.slopeRangeLabel || 'Level',
      slopeModeSelection: run?.slopeModeSelection || 'QuickSelect',
      slopeMode: run?.slopeMode || 'None',
      slopeSource: run?.slopeSource || 'NONE',
      slopeDetectedFrom: run?.slopeDetectedFrom || '',
      startElevation: run?.startElevation || '',
      endElevation: run?.endElevation || '',
      startType: 'Post',
      endType: 'Post',
      cornerPostCount: 0,
      endPostCount: 0,
      hasTearout: run?.hasTearout || false,
      runNotes: '',
      ...run
    };
    
    // DXF ELEVATION TRANSFER: If run has dxfElevation, populate slope fields
    if (run?.dxfElevation && !run?.id) {
      baseData.startElevation = run.dxfElevation.startElevation;
      baseData.endElevation = run.dxfElevation.endElevation;
      baseData.dropFt = Math.abs(run.dxfElevation.endElevation - run.dxfElevation.startElevation);
      baseData.horizontalRunFt = run.lengthLF || run.dxfElevation.horizontalRunFt || '';
      baseData.slopeGrade = baseData.horizontalRunFt > 0 ? baseData.dropFt / baseData.horizontalRunFt : 0;
      baseData.slopeSource = 'DXF_AUTO_DETECT';
      baseData.slopeDetectedFrom = 'DXF Import';
      baseData.slopeModeSelection = 'AutoDetect';
      
      // Force vinyl rack if slope exists
      if (baseData.materialType === 'Vinyl' && baseData.dropFt > 0.05) {
        baseData.slopeMode = 'Rack';
      }
    }
    
    return baseData;
  };

  const [formData, setFormData] = useState(initializeFormData());

  const [customLabel, setCustomLabel] = useState('');
  
  // Show DXF override warning if slope source is DXF
  React.useEffect(() => {
    if (formData.slopeSource === 'DXF_AUTO_DETECT' && formData.slopeDetectedFrom) {
      setShowDxfOverrideWarning(true);
    }
  }, [formData.slopeSource, formData.slopeDetectedFrom]);

  // Get material-specific options
  const getStylesForMaterial = (material) => {
    switch (material) {
      case 'Wood': return WOOD_STYLES;
      case 'Vinyl': return VINYL_STYLES;
      case 'Chain Link': return CHAINLINK_STYLES;
      case 'Aluminum': return ALUMINUM_STYLES;
      case 'Livestock': return LIVESTOCK_STYLES;
      default: return [];
    }
  };
  
  const getColorsForMaterial = (material) => {
    switch (material) {
      case 'Wood': return WOOD_COLORS;
      case 'Aluminum': return ALUMINUM_COLORS;
      case 'Vinyl': return VINYL_COLORS;
      case 'Chain Link': return []; // Chain Link uses coating, not color
      default: return [];
    }
  };
  
  const availableStyles = getStylesForMaterial(formData.materialType);
  const availableColors = getColorsForMaterial(formData.materialType);
  const showColorField = formData.materialType !== 'Chain Link' && formData.materialType !== 'Livestock';

  // Auto-detect slope from available data
  const autoDetectSlope = () => {
    // Priority 1: Start/End elevation
    if (formData.startElevation && formData.endElevation) {
      const drop = Math.abs(formData.endElevation - formData.startElevation);
      const horizontal = formData.horizontalRunFt || formData.lengthLF || 0;
      return {
        dropFt: drop,
        horizontalRunFt: horizontal,
        slopeGrade: horizontal > 0 ? drop / horizontal : 0
      };
    }
    
    // Priority 2: Grade points (future implementation)
    // Priority 3: DXF Z values (future implementation)
    
    return null;
  };

  // Classify slope into range based on drop
  const classifySlopeRange = (dropFt) => {
    const dropInches = dropFt * 12;
    if (dropInches <= 6) return 'Level';
    if (dropInches <= 12) return 'Slight';
    if (dropInches <= 24) return 'Moderate';
    if (dropInches <= 48) return 'Heavy';
    return 'Extreme';
  };

  // Get detected slope info
  const detectedSlope = autoDetectSlope();
  const hasElevationData = !!(formData.startElevation && formData.endElevation);

  const handleChange = (field, value) => {
    const updates = { [field]: value };
    
    // Real-time update for line length when assigning
    if (field === 'lengthLF' && assigningLine && onLineLengthUpdate) {
      onLineLengthUpdate(value);
    }
    
    // When material changes, validate and clear invalid dependent fields
    if (field === 'materialType') {
      const validStyles = getStylesForMaterial(value);
      const validColors = getColorsForMaterial(value);
      
      // Clear style if invalid for new material
      if (formData.style && !validStyles.includes(formData.style)) {
        updates.style = '';
      }
      
      // Clear color if invalid for new material
      if (formData.fenceColor && !validColors.includes(formData.fenceColor)) {
        updates.fenceColor = '';
        updates.railsAndPostColor = '';
        updates.picketColor = '';
      }
      
      // Clear material-specific fields
      if (value !== 'Chain Link') {
        updates.chainLinkCoating = '';
        updates.chainLinkPrivacyType = 'None';
        updates.vinylSlatColor = '';
      }
      
      // Vinyl Privacy ALWAYS uses Rack mode on slopes
      if (value === 'Vinyl' && formData.dropFt > 0) {
        updates.slopeMode = 'Rack';
      }
    }
    
    // Handle slope mode changes
    if (field === 'slopeModeSelection') {
      if (value === 'AutoDetect' && detectedSlope) {
        updates.slopeSource = 'DXF_AUTO_DETECT';
        updates.dropFt = detectedSlope.dropFt;
        updates.horizontalRunFt = detectedSlope.horizontalRunFt;
        updates.slopeGrade = detectedSlope.slopeGrade;
        updates.slopeRangeLabel = classifySlopeRange(detectedSlope.dropFt);
        updates.slopeMode = (formData.materialType === 'Vinyl' && detectedSlope.dropFt > 0) ? 'Rack' : 'None';
      } else if (value === 'QuickSelect') {
        updates.slopeSource = 'USER_QUICK_SELECT';
        const defaultDrop = SLOPE_RANGE_DEFAULTS[formData.slopeRangeLabel] || 0;
        const horizontal = formData.horizontalRunFt || formData.lengthLF || 0;
        updates.dropFt = defaultDrop;
        updates.slopeGrade = horizontal > 0 ? defaultDrop / horizontal : 0;
        updates.slopeMode = (formData.materialType === 'Vinyl' && defaultDrop > 0) ? 'Rack' : 'None';
      } else if (value === 'MeasuredDrop') {
        updates.slopeSource = 'USER_MEASURED_DROP';
      }
    }
    
    // Handle slope range selection in Quick Select mode
    if (field === 'slopeRangeLabel' && formData.slopeModeSelection === 'QuickSelect') {
      const defaultDrop = SLOPE_RANGE_DEFAULTS[value] || 0;
      const horizontal = formData.horizontalRunFt || formData.lengthLF || 0;
      updates.dropFt = defaultDrop;
      updates.slopeGrade = horizontal > 0 ? defaultDrop / horizontal : 0;
      updates.slopeMode = (formData.materialType === 'Vinyl' && defaultDrop > 0) ? 'Rack' : 'None';
    }
    
    // Handle measured drop entry
    if (field === 'dropFt') {
      const horizontal = formData.horizontalRunFt || formData.lengthLF || 0;
      updates.slopeGrade = horizontal > 0 ? value / horizontal : 0;
      updates.slopeRangeLabel = classifySlopeRange(value);
      updates.slopeMode = (formData.materialType === 'Vinyl' && value > 0) ? 'Rack' : 'None';
    }
    
    // Recalculate slope when horizontal run or length changes
    if (field === 'horizontalRunFt' || field === 'lengthLF') {
      const horizontal = field === 'horizontalRunFt' ? value : (formData.horizontalRunFt || value);
      if (horizontal > 0 && formData.dropFt > 0) {
        updates.slopeGrade = formData.dropFt / horizontal;
      }
      if (field === 'lengthLF' && !formData.horizontalRunFt) {
        updates.horizontalRunFt = value;
      }
    }
    
    // Recalculate when elevations change
    if ((field === 'startElevation' || field === 'endElevation') && formData.slopeModeSelection === 'AutoDetect') {
      const newDetected = autoDetectSlope();
      if (newDetected) {
        updates.dropFt = newDetected.dropFt;
        updates.horizontalRunFt = newDetected.horizontalRunFt;
        updates.slopeGrade = newDetected.slopeGrade;
        updates.slopeRangeLabel = classifySlopeRange(newDetected.dropFt);
        updates.slopeMode = (formData.materialType === 'Vinyl' && newDetected.dropFt > 0) ? 'Rack' : 'None';
      }
    }
    
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleAISuggest = async () => {
    setAiSuggesting(true);
    setValidationError('');
    
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this fence job and suggest optimal run details:

Job Context:
- Customer: ${job.customerName}
- Address: ${job.addressLine1}, ${job.city}, ${job.state}
- Current Job Material: ${job.materialType || 'Not specified'}
- Current Job Height: ${job.fenceHeight || 'Not specified'}
- Current Job Style: ${job.style || 'Not specified'}
- Current Job Color: ${job.fenceColor || 'Not specified'}
- Run Location: ${formData.runLabel || 'Not specified'}
- Run Length: ${formData.lengthLF || 'Not specified'} ft
${job.jobNotes ? `- Job Notes: ${job.jobNotes}` : ''}

Task: Suggest the most appropriate values for this run. Consider:
1. Should this run match the job defaults or be different? Why?
2. What material type is best for this location?
3. What height makes sense?
4. What style fits this location best?
5. What color recommendation?

Return JSON only with this structure:
{
  "materialType": "Vinyl|Wood|Chain Link|Aluminum",
  "fenceHeight": "3'|4'|5'|6'|8'|10'|12'",
  "style": "appropriate style based on material",
  "fenceColor": "appropriate color based on material",
  "reasoning": "brief explanation of your recommendations"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            materialType: { type: "string" },
            fenceHeight: { type: "string" },
            style: { type: "string" },
            fenceColor: { type: "string" },
            reasoning: { type: "string" }
          },
          required: ["materialType", "fenceHeight", "style", "reasoning"]
        }
      });

      // Apply AI suggestions to form
      const suggestions = response;
      const updates = {
        materialType: suggestions.materialType,
        fenceHeight: suggestions.fenceHeight,
        style: suggestions.style
      };
      
      if (suggestions.fenceColor) {
        updates.fenceColor = suggestions.fenceColor;
      }
      
      setFormData(prev => ({ ...prev, ...updates }));
      
      // Show reasoning as info
      if (suggestions.reasoning) {
        setValidationError('');
        alert(`AI Suggestion Applied:\n\n${suggestions.reasoning}`);
      }
    } catch (error) {
      console.error('AI suggestion failed:', error);
      setValidationError('AI suggestion failed. Please set values manually.');
    } finally {
      setAiSuggesting(false);
    }
  };

  // Helper: normalize color names for canonical keys (replace spaces with underscores, lowercase)
  const normalizeColorForUck = (color) => {
    if (!color) return color;
    // Normalize spaces and convert to lowercase
    let normalized = color.replace(/\s+/g, '_').toLowerCase();
    // Handle special case: "mixed" is not a valid canonical color, replace with "white" as default
    if (normalized === 'mixed') {
      normalized = 'white';
    }
    return normalized;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setValidationError('');
    
    console.log('RUN FORM SUBMIT CLICKED', formData);
    
    // Validation
    if (!formData.runLabel) {
      setValidationError('Please select a run label.');
      return;
    }
    
    // Length is optional - will use drawn length if not specified
    if (formData.lengthLF && parseFloat(formData.lengthLF) <= 0) {
      setValidationError('Length must be greater than 0 if specified.');
      return;
    }
    
    if (!formData.style) {
      setValidationError('Please select a valid style for the chosen material.');
      return;
    }
    
    if (showColorField && formData.materialType !== 'Livestock' && !formData.fenceColor) {
      setValidationError('Please select a valid color for the chosen material.');
      return;
    }
    
    const finalLabel = formData.runLabel === 'Custom' ? customLabel : formData.runLabel;
    
    // NORMALIZATION: Derive dropFt from elevations if not set
    let normalizedData = { 
      ...formData,
      // Normalize color fields to be UCK-compatible (spaces → underscores, lowercase)
      fenceColor: normalizeColorForUck(formData.fenceColor),
      railsAndPostColor: normalizeColorForUck(formData.railsAndPostColor),
      picketColor: normalizeColorForUck(formData.picketColor),
      vinylSlatColor: normalizeColorForUck(formData.vinylSlatColor)
    };
    
    // Clean up numeric fields - convert empty strings to proper values
    normalizedData.dropFt = normalizedData.dropFt === '' ? 0 : parseFloat(normalizedData.dropFt) || 0;
    normalizedData.slopeGrade = normalizedData.slopeGrade === '' ? 0 : parseFloat(normalizedData.slopeGrade) || 0;
    normalizedData.startElevation = normalizedData.startElevation === '' ? null : normalizedData.startElevation;
    normalizedData.endElevation = normalizedData.endElevation === '' ? null : normalizedData.endElevation;
    normalizedData.horizontalRunFt = normalizedData.horizontalRunFt === '' ? null : normalizedData.horizontalRunFt;
    
    if ((normalizedData.startElevation !== null && normalizedData.endElevation !== null) &&
        normalizedData.dropFt === 0) {
      normalizedData.dropFt = Math.abs(normalizedData.endElevation - normalizedData.startElevation);
      normalizedData.horizontalRunFt = normalizedData.horizontalRunFt || normalizedData.lengthLF;
      normalizedData.slopeGrade = normalizedData.horizontalRunFt > 0 
        ? normalizedData.dropFt / normalizedData.horizontalRunFt 
        : 0;
      
      // Set source if from DXF elevations
      if (normalizedData.slopeDetectedFrom && normalizedData.slopeDetectedFrom.includes('DXF')) {
        normalizedData.slopeSource = 'DXF_AUTO_DETECT';
      }
    }
    
    // Generate math sub-runs if DXF slope data exists OR elevations exist
    let mathSubRuns = normalizedData.mathSubRuns || [];
    if ((normalizedData.slopeSource === 'DXF_AUTO_DETECT' && normalizedData.gradePoints && normalizedData.gradePoints.length >= 2) ||
        (normalizedData.startElevation !== null && normalizedData.endElevation !== null)) {
      try {
        mathSubRuns = generateMathSubRuns(normalizedData);
      } catch (error) {
        console.error('Math sub-runs generation failed:', error);
        // Continue without math sub-runs
      }
    }
    
    // VINYL RACK MODE: Force for any slope source using central helper
    if (normalizedData.materialType === 'Vinyl') {
      // Check slope from ALL sources
      const hasMeaningfulSlope = 
        (normalizedData.dropFt != null && normalizedData.dropFt > 0.05) ||
        (normalizedData.startElevation != null && normalizedData.endElevation != null && 
         Math.abs(normalizedData.endElevation - normalizedData.startElevation) > 0.05) ||
        (mathSubRuns.length > 0 && mathSubRuns.some(sr => sr.slopeRangeLabel !== 'Level')) ||
        (normalizedData.gradePoints && normalizedData.gradePoints.length >= 2 &&
         normalizedData.gradePoints.some((gp, i) => i > 0 && 
           Math.abs(gp.elevationFt - normalizedData.gradePoints[i-1].elevationFt) > 0.05));
      
      if (hasMeaningfulSlope) {
        normalizedData.slopeMode = 'Rack'; // FORCED
      } else {
        normalizedData.slopeMode = 'None'; // Flat
      }
    }
    
    const saveData = {
      ...normalizedData,
      runLabel: finalLabel,
      lengthLF: parseFloat(normalizedData.lengthLF),
      hasTearout: normalizedData.hasTearout || false,
      mathSubRuns
    };
    
    console.log('RUN FORM CALLING onSave WITH:', saveData);
    onSave(saveData);
  };

  return (
    <Dialog open onOpenChange={onClose} modal={true}>
      <DialogContent className="max-w-md max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-4">
          <DialogTitle>
            {run?.id ? 'Edit Run' : assigningLine ? 'Assign Line to Run' : 'Add New Run'}
          </DialogTitle>
          {assigningLine && (
            <p className="text-xs text-slate-500 mt-1">
              Assigning new {assigningLine.drawnLengthFt?.toFixed(1)} ft line
            </p>
          )}
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 pb-6 space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="runLabel">Run Label *</Label>
            <Select value={formData.runLabel} onValueChange={(v) => handleChange('runLabel', v)}>
              <SelectTrigger>
                <SelectValue placeholder="Select location..." />
              </SelectTrigger>
              <SelectContent>
                {RUN_LABELS.map(l => (
                  <SelectItem key={l} value={l}>{l}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {formData.runLabel === 'Custom' && (
              <Input
                placeholder="Enter custom label..."
                value={customLabel}
                onChange={(e) => setCustomLabel(e.target.value)}
                className="mt-2"
              />
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="lengthLF">Length (Linear Feet)</Label>
            <Input
              id="lengthLF"
              type="number"
              step="0.5"
              min="0"
              value={formData.lengthLF}
              onChange={(e) => handleChange('lengthLF', e.target.value)}
              placeholder="Auto-filled from map"
              className="text-lg font-semibold"
            />
          </div>

          <div className="border-t pt-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-sm text-slate-700">Fence Specifications</h4>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleAISuggest}
                disabled={aiSuggesting}
                className="gap-2 text-xs"
              >
                <Sparkles className="w-3 h-3" />
                {aiSuggesting ? 'Suggesting...' : 'AI Suggest'}
              </Button>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="materialType">Material</Label>
                <Select value={formData.materialType} onValueChange={(v) => handleChange('materialType', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {MATERIAL_TYPES.map(m => (
                      <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fenceHeight">Height</Label>
                <Select value={formData.fenceHeight} onValueChange={(v) => handleChange('fenceHeight', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FENCE_HEIGHTS.map(h => (
                      <SelectItem key={h} value={h}>{h}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="style">Style *</Label>
                <Select value={formData.style} onValueChange={(v) => handleChange('style', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder={availableStyles.length > 0 ? "Select style..." : "Select material first"} />
                  </SelectTrigger>
                  <SelectContent>
                    {availableStyles.map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.style === 'Ranch Style' && (
              <div className="space-y-2">
                <Label htmlFor="ranchStyleType">Ranch Style Type</Label>
                <Select value={formData.ranchStyleType} onValueChange={(v) => handleChange('ranchStyleType', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select ranch type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {RANCH_STYLE_TYPES.map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {formData.materialType === 'Chain Link' ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="chainLinkCoating">Chain Link Coating</Label>
                  <Select value={formData.chainLinkCoating} onValueChange={(v) => handleChange('chainLinkCoating', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select coating..." />
                    </SelectTrigger>
                    <SelectContent>
                      {CHAIN_LINK_COATINGS.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="chainLinkPrivacyType">Privacy Option</Label>
                  <Select value={formData.chainLinkPrivacyType} onValueChange={(v) => handleChange('chainLinkPrivacyType', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CHAIN_LINK_PRIVACY.map(p => (
                        <SelectItem key={p} value={p}>{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {formData.chainLinkPrivacyType === 'Vinyl Slats' && (
                  <div className="space-y-2">
                    <Label htmlFor="vinylSlatColor">Vinyl Slat Color</Label>
                    <Select value={formData.vinylSlatColor} onValueChange={(v) => handleChange('vinylSlatColor', v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select color..." />
                      </SelectTrigger>
                      <SelectContent>
                        {VINYL_SLAT_COLORS.map(c => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </>
            ) : showColorField ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="fenceColor">Fence Color *</Label>
                  <Select value={formData.fenceColor} onValueChange={(v) => handleChange('fenceColor', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder={availableColors.length > 0 ? "Select color..." : "Select material first"} />
                    </SelectTrigger>
                    <SelectContent>
                      {availableColors.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {formData.fenceColor === 'Two Tone' && (
                   <>
                     <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-2">
                         <Label htmlFor="railsAndPostColor">Rails/Posts Color</Label>
                         <Select value={formData.railsAndPostColor} onValueChange={(v) => handleChange('railsAndPostColor', v)}>
                           <SelectTrigger>
                             <SelectValue placeholder="Select..." />
                           </SelectTrigger>
                           <SelectContent>
                             {SINGLE_COLORS.map(c => (
                               <SelectItem key={c} value={c}>{c}</SelectItem>
                             ))}
                           </SelectContent>
                         </Select>
                       </div>
                       <div className="space-y-2">
                         <Label htmlFor="picketColor">Picket Color</Label>
                         <Select value={formData.picketColor} onValueChange={(v) => handleChange('picketColor', v)}>
                           <SelectTrigger>
                             <SelectValue placeholder="Select..." />
                           </SelectTrigger>
                           <SelectContent>
                             {SINGLE_COLORS.map(c => (
                               <SelectItem key={c} value={c}>{c}</SelectItem>
                             ))}
                           </SelectContent>
                         </Select>
                       </div>
                     </div>
                     {formData.railsAndPostColor && formData.picketColor && (
                       <div className="text-xs bg-indigo-50 p-2 rounded border border-indigo-200 text-indigo-800">
                         <strong>Two-Tone Preview:</strong> {formData.railsAndPostColor} (rails/posts) + {formData.picketColor} (pickets)
                       </div>
                     )}
                   </>
                 )}
              </>
            ) : null}
          </div>

          <div className="border-t pt-4 space-y-4">
            <h4 className="font-medium text-sm text-slate-700">Slope Configuration</h4>
            
            {showDxfOverrideWarning && (
              <Alert className="bg-amber-50 border-amber-300">
                <AlertCircle className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-sm text-amber-900">
                  <strong>Slope set from DXF import for accuracy.</strong> Manual slope values were replaced by detected elevation data.
                </AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="slopeModeSelection">Slope Input Method</Label>
              {formData.slopeSource === 'DXF_AUTO_DETECT' ? (
                <div className="space-y-2">
                  <div className="px-3 py-2 bg-blue-50 border border-blue-200 rounded-md text-sm">
                    <div className="flex items-center gap-2 text-blue-900 font-semibold">
                      <span>📍 Slope Source: DXF Import (Auto-Detected)</span>
                    </div>
                    <div className="text-blue-700 text-xs mt-1">
                      Elevation data from imported DXF file. Cannot be manually overridden.
                    </div>
                  </div>
                  <Select value="AutoDetect" disabled>
                    <SelectTrigger className="bg-slate-50">
                      <SelectValue>Auto-Detect (DXF)</SelectValue>
                    </SelectTrigger>
                  </Select>
                </div>
              ) : (
                <Select value={formData.slopeModeSelection} onValueChange={(v) => handleChange('slopeModeSelection', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AutoDetect">Auto-Detect {hasElevationData ? '(Recommended)' : ''}</SelectItem>
                    <SelectItem value="QuickSelect">Quick Select (Range)</SelectItem>
                    <SelectItem value="MeasuredDrop">Measured Drop (Manual)</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>

            {formData.slopeModeSelection === 'AutoDetect' && (
              <div className="space-y-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                {hasElevationData ? (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label htmlFor="startElevation" className="text-xs">Start Elevation (ft)</Label>
                        <Input
                          id="startElevation"
                          type="number"
                          step="0.1"
                          value={formData.startElevation}
                          onChange={(e) => handleChange('startElevation', parseFloat(e.target.value) || 0)}
                          className="h-8 text-sm"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="endElevation" className="text-xs">End Elevation (ft)</Label>
                        <Input
                          id="endElevation"
                          type="number"
                          step="0.1"
                          value={formData.endElevation}
                          onChange={(e) => handleChange('endElevation', parseFloat(e.target.value) || 0)}
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                    {detectedSlope && (
                      <div className="text-xs bg-white p-2 rounded border border-blue-300">
                        <div className="font-semibold text-blue-900">Detected Drop: {(detectedSlope.dropFt * 12).toFixed(1)}" ({formData.slopeRangeLabel})</div>
                        <div className="text-blue-700">Grade: {(detectedSlope.slopeGrade * 100).toFixed(2)}%</div>
                        {formData.slopeDetectedFrom && (
                          <div className="text-blue-600 mt-1">Source: {formData.slopeDetectedFrom}</div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-sm text-amber-700">
                    <p className="font-medium">No elevation data found</p>
                    <p className="text-xs mt-1">Enter start and end elevations to enable auto-detect</p>
                  </div>
                )}
              </div>
            )}

            {formData.slopeModeSelection === 'QuickSelect' && (
              <div className="space-y-2">
                <Label htmlFor="slopeRangeLabel">Slope Range</Label>
                <Select value={formData.slopeRangeLabel} onValueChange={(v) => handleChange('slopeRangeLabel', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SLOPE_RANGES.map(r => (
                      <SelectItem key={r} value={r}>
                        {r} ({r === 'Level' ? '0-6"' : r === 'Slight' ? '6-12"' : r === 'Moderate' ? '12-24"' : r === 'Heavy' ? '24-48"' : '48+"'})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">Using default drop: {(formData.dropFt * 12).toFixed(1)}" ({formData.dropFt.toFixed(2)} ft)</p>
              </div>
            )}

            {formData.slopeModeSelection === 'MeasuredDrop' && (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="dropFt">Measured Drop (feet)</Label>
                  <Input
                    id="dropFt"
                    type="number"
                    step="0.1"
                    min="0"
                    value={formData.dropFt}
                    onChange={(e) => handleChange('dropFt', parseFloat(e.target.value) || 0)}
                    placeholder="Enter total drop in feet"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="horizontalRunFt">Horizontal Run (feet)</Label>
                  <Input
                    id="horizontalRunFt"
                    type="number"
                    step="0.5"
                    min="0"
                    value={formData.horizontalRunFt}
                    onChange={(e) => handleChange('horizontalRunFt', parseFloat(e.target.value) || 0)}
                    placeholder="Horizontal distance (default: length)"
                  />
                </div>
                {formData.dropFt > 0 && (
                  <div className="text-xs bg-slate-50 p-2 rounded border">
                    <div className="font-semibold">Classified: {formData.slopeRangeLabel}</div>
                    <div className="text-slate-600">Drop: {(formData.dropFt * 12).toFixed(1)}" | Grade: {(formData.slopeGrade * 100).toFixed(2)}%</div>
                  </div>
                )}
              </div>
            )}

            {formData.dropFt > 0 && formData.materialType === 'Vinyl' && (
              <div className="text-xs bg-emerald-50 p-2 rounded border border-emerald-200 text-emerald-800">
                <strong>Vinyl on Slope:</strong> Rack mode enforced (FenceBuddy standard - follows grade)
              </div>
            )}

            {formData.materialType === 'Vinyl' && formData.dropFt === 0 && (
              <div className="text-xs bg-slate-50 p-2 rounded border border-slate-200 text-slate-600">
                <strong>Vinyl Flat:</strong> No rack mode needed
              </div>
            )}

            {formData.slopeSource === 'DXF_AUTO_DETECT' && formData.gradePoints && formData.gradePoints.length > 2 && (
              <div className="text-xs bg-blue-50 p-2 rounded border border-blue-200 text-blue-700">
                <strong>Note:</strong> Slope varies along this run (auto-adjusted for calculations)
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startType">Starts At</Label>
              <Select value={formData.startType} onValueChange={(v) => handleChange('startType', v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {END_TYPES.map(t => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="endType">Ends At</Label>
              <Select value={formData.endType} onValueChange={(v) => handleChange('endType', v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {END_TYPES.map(t => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border-t pt-4 space-y-4">
            <h4 className="font-medium text-sm text-slate-700">Material Options (Job-Level)</h4>

            {formData.materialType === 'Wood' && (
              <div className="flex items-center gap-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <Checkbox
                  id="useCedarPickets"
                  checked={formData.useCedarPickets || false}
                  disabled
                />
                <div className="flex-1">
                  <Label htmlFor="useCedarPickets" className="font-medium text-sm cursor-default text-slate-600">
                    Use Cedar Pickets & Boards
                  </Label>
                  <p className="text-xs text-slate-500 mt-1">Configured at job level (edit from Job page)</p>
                </div>
              </div>
            )}
          </div>

          <div className="border-t pt-4 space-y-4">
            <h4 className="font-medium text-sm text-slate-700">Labor Options</h4>

            <div className="flex items-center gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <Checkbox
                id="hasTearout"
                checked={formData.hasTearout}
                onCheckedChange={(checked) => handleChange('hasTearout', checked)}
              />
              <div className="flex-1">
                <Label htmlFor="hasTearout" className="font-medium text-sm cursor-pointer">
                  Include Tear-Out Labor
                </Label>
                <p className="text-xs text-amber-700 mt-1">Adds $5/LF labor cost for existing fence removal</p>
              </div>
              {formData.hasTearout && formData.lengthLF && (
                <div className="text-sm font-semibold text-amber-900">
                  +${(formData.lengthLF * 5).toFixed(2)}
                </div>
              )}
            </div>
          </div>

          <div className="border-t pt-4 space-y-4">
            <h4 className="font-medium text-sm text-slate-700">Post Details</h4>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cornerPostCount">Corner Posts (0-10)</Label>
                <Select value={String(formData.cornerPostCount)} onValueChange={(v) => handleChange('cornerPostCount', parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[...Array(11)].map((_, i) => (
                      <SelectItem key={i} value={String(i)}>{i}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="endPostCount">End Posts (0-10)</Label>
                <Select value={String(formData.endPostCount)} onValueChange={(v) => handleChange('endPostCount', parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[...Array(11)].map((_, i) => (
                      <SelectItem key={i} value={String(i)}>{i}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="runNotes">Notes</Label>
            <Textarea
              id="runNotes"
              value={formData.runNotes}
              onChange={(e) => handleChange('runNotes', e.target.value)}
              rows={2}
              placeholder="Any special notes..."
            />
          </div>

          {run?.id && (
            <div className="border-t pt-4 space-y-4">
              <h4 className="font-medium text-sm text-slate-700">Compare Materials (A / B / C)</h4>
              <RunCompareVariantsEditor
                run={run}
                onSave={async (compareVariants) => {
                  try {
                    await base44.entities.Run.update(run.id, { compareVariants });
                    queryClient.invalidateQueries({ queryKey: ['runs', jobId] });
                    queryClient.invalidateQueries({ queryKey: ['job', jobId] });
                  } catch (e) {
                    console.error('Failed to save compare variants:', e);
                  }
                }}
              />
            </div>
          )}

          <div className="sticky bottom-0 bg-white pt-4 border-t mt-6">
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={isLoading} className="bg-emerald-600 hover:bg-emerald-700">
                <Save className="w-4 h-4 mr-2" />
                {isLoading ? 'Saving...' : 'Save Run'}
              </Button>
            </DialogFooter>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}