import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const FINAL_DISPOSITIONS = new Set(['sold', 'canceled', 'demo_no_sale', 'unqualified', 'no_demo']);

const REASON_ENUMS = {
  canceled: ['customer_canceled', 'office_canceled', 'duplicate', 'project_canceled', 'moved', 'other'],
  demo_no_sale: ['price', 'shopping', 'went_with_competitor', 'needs_to_think', 'financing', 'no_decision', 'scope_change', 'other'],
  unqualified: ['outside_service_area', 'unsupported_project_type', 'rental_or_permission_issue', 'bad_contact_info', 'duplicate', 'other'],
  no_demo: ['no_show', 'could_not_contact', 'customer_unresponsive', 'access_issue', 'weather', 'other'],
  rescheduled: ['customer_request', 'rep_request', 'weather', 'scheduling_conflict', 'other'],
};

Deno.serve(async (req) => {
  if (req.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405 });

  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { jobId, disposition, reason, notes, soldPackage, rescheduledAppointmentStart, rescheduledAppointmentEnd } = await req.json();

  if (!jobId || !disposition) return Response.json({ error: 'jobId and disposition required' }, { status: 400 });

  // Load job
  const jobs = await base44.asServiceRole.entities.CRMJob.filter({ id: jobId });
  if (!jobs.length) return Response.json({ error: 'Job not found' }, { status: 404 });
  const job = jobs[0];

  // Must be BP-sourced
  const bpOpportunityId = job.builderPrimeOpportunityId || job.externalOpportunityId;
  const bpClientId = job.builderPrimeClientId || job.externalCustomerId;
  if (job.externalSource !== 'builder_prime' && job.externalCRM !== 'builderprime') {
    return Response.json({ error: 'Job is not Builder Prime sourced' }, { status: 400 });
  }

  // Validate disposition value
  const validDispositions = ['sold', 'canceled', 'demo_no_sale', 'unqualified', 'no_demo', 'rescheduled'];
  if (!validDispositions.includes(disposition)) {
    return Response.json({ error: `Invalid disposition: ${disposition}` }, { status: 400 });
  }

  // Disposition-specific validation
  if (disposition === 'sold') {
    if (!soldPackage) return Response.json({ error: 'soldPackage required for sold disposition' }, { status: 400 });
    const { contractValueCents, contractDocumentUrl, contractDocumentStorageKey } = soldPackage;
    if (!contractValueCents || contractValueCents <= 0) return Response.json({ error: 'contractValueCents required and > 0 for sold' }, { status: 400 });
    if (!contractDocumentUrl && !contractDocumentStorageKey) return Response.json({ error: 'contractDocumentUrl or contractDocumentStorageKey required for sold' }, { status: 400 });
    if (soldPackage.signatureCaptured === true && !soldPackage.contractSignedAt) {
      return Response.json({ error: 'contractSignedAt required when signatureCaptured is true' }, { status: 400 });
    }
  } else if (disposition === 'rescheduled') {
    if (!rescheduledAppointmentStart) return Response.json({ error: 'rescheduledAppointmentStart required for rescheduled' }, { status: 400 });
  } else {
    // canceled, demo_no_sale, unqualified, no_demo — require reason
    if (!reason) return Response.json({ error: `reason required for disposition: ${disposition}` }, { status: 400 });
  }

  const now = new Date().toISOString();
  const newRevision = (job.dispositionRevision || 0) + 1;
  const isFinal = FINAL_DISPOSITIONS.has(disposition);

  // Build job patch
  const jobPatch = {
    leadDisposition: disposition,
    leadDispositionAt: now,
    leadDispositionReason: reason || null,
    leadDispositionNotes: notes || null,
    isFinalDisposition: isFinal,
    dispositionRevision: newRevision,
    externalSource: job.externalSource || 'builder_prime',
    builderPrimeOpportunityId: bpOpportunityId || null,
    builderPrimeClientId: bpClientId || null,
    bpOutcomeReportingStatus: 'pending',
  };

  if (disposition === 'rescheduled') {
    jobPatch.rescheduledAppointmentStart = rescheduledAppointmentStart;
    jobPatch.rescheduledAppointmentEnd = rescheduledAppointmentEnd || null;
  }

  if (disposition === 'sold' && soldPackage) {
    jobPatch.contractValueCents = soldPackage.contractValueCents || 0;
    jobPatch.depositCollectedCents = soldPackage.depositCollectedCents || 0;
    jobPatch.totalCollectedCents = soldPackage.depositCollectedCents || 0;
    jobPatch.balanceRemainingCents = (soldPackage.contractValueCents || 0) - (soldPackage.depositCollectedCents || 0);
    jobPatch.contractNumber = soldPackage.contractNumber || null;
    jobPatch.contractSignedAt = soldPackage.contractSignedAt || null;
    jobPatch.signatureCaptured = soldPackage.signatureCaptured || false;
    jobPatch.signatureProvider = soldPackage.signatureProvider || null;
    jobPatch.contractDocumentUrl = soldPackage.contractDocumentUrl || null;
    jobPatch.contractDocumentStorageKey = soldPackage.contractDocumentStorageKey || null;
    jobPatch.signedContractDocumentUrl = soldPackage.signedContractDocumentUrl || null;
    jobPatch.signedContractStorageKey = soldPackage.signedContractStorageKey || null;
    jobPatch.saleStatus = 'sold';
  }

  // 1. Save job internally first
  await base44.asServiceRole.entities.CRMJob.update(jobId, jobPatch);

  // 2. Create LeadDispositionEvent (audit record)
  const eventData = {
    companyId: job.companyId,
    jobId,
    externalSource: 'builder_prime',
    builderPrimeOpportunityId: bpOpportunityId || null,
    builderPrimeClientId: bpClientId || null,
    disposition,
    reason: reason || null,
    notes: notes || null,
    isFinalDisposition: isFinal,
    rescheduledAppointmentStart: rescheduledAppointmentStart || null,
    rescheduledAppointmentEnd: rescheduledAppointmentEnd || null,
    recordedByUserId: user.id,
    recordedAt: now,
    dispositionRevision: newRevision,
    syncStatus: 'pending',
    syncAttemptCount: 0,
    ...(disposition === 'sold' && soldPackage ? {
      contractValueCents: soldPackage.contractValueCents || 0,
      depositCollectedCents: soldPackage.depositCollectedCents || 0,
      totalCollectedCents: soldPackage.depositCollectedCents || 0,
      balanceRemainingCents: (soldPackage.contractValueCents || 0) - (soldPackage.depositCollectedCents || 0),
      contractNumber: soldPackage.contractNumber || null,
      contractSignedAt: soldPackage.contractSignedAt || null,
      signatureCaptured: soldPackage.signatureCaptured || false,
      signatureProvider: soldPackage.signatureProvider || null,
      contractDocumentUrl: soldPackage.contractDocumentUrl || null,
      signedContractDocumentUrl: soldPackage.signedContractDocumentUrl || null,
    } : {}),
  };
  const dispositionEvent = await base44.asServiceRole.entities.LeadDispositionEvent.create(eventData);

  // 3. If sold + deposit, write a PaymentLedgerEvent
  if (disposition === 'sold' && soldPackage?.depositCollectedCents > 0) {
    await base44.asServiceRole.entities.PaymentLedgerEvent.create({
      companyId: job.companyId,
      jobId,
      externalSource: 'builder_prime',
      builderPrimeOpportunityId: bpOpportunityId || null,
      builderPrimeClientId: bpClientId || null,
      paymentEventType: 'deposit',
      paymentDate: now,
      amountCents: soldPackage.depositCollectedCents,
      paymentMethod: soldPackage.depositPaymentMethod || 'other',
      processor: 'manual',
      runningContractValueCents: soldPackage.contractValueCents || 0,
      runningCollectedCents: soldPackage.depositCollectedCents,
      balanceRemainingCents: (soldPackage.contractValueCents || 0) - soldPackage.depositCollectedCents,
      createdByUserId: user.id,
      createdAt: now,
    });
  }

  // 4. Build normalized closeout payload
  const idempotencyKey = `bp_closeout::${bpOpportunityId}::rev::${newRevision}`;

  // Check for duplicate outbound event
  const existingOutbound = await base44.asServiceRole.entities.OutboundIntegrationEvent.filter({ idempotencyKey });
  if (existingOutbound.length === 0) {
    const closeoutPayload = {
      eventType: 'bp_closeout_report',
      externalSource: 'builder_prime',
      companyId: job.companyId,
      jobId,
      builderPrimeOpportunityId: bpOpportunityId || null,
      builderPrimeClientId: bpClientId || null,
      customerName: job.customerName || null,
      disposition,
      reason: reason || null,
      notes: notes || null,
      dispositionAt: now,
      isFinalDisposition: isFinal,
      salesRep: job.salesRepName || null,
      leadSetter: job.leadSetterName || null,
      rescheduledAppointmentStart: rescheduledAppointmentStart || null,
      rescheduledAppointmentEnd: rescheduledAppointmentEnd || null,
      contract: disposition === 'sold' && soldPackage ? {
        contractNumber: soldPackage.contractNumber || null,
        signedAt: soldPackage.contractSignedAt || null,
        contractValueCents: soldPackage.contractValueCents || 0,
        documentUrl: soldPackage.contractDocumentUrl || null,
        signedDocumentUrl: soldPackage.signedContractDocumentUrl || null,
        signatureCaptured: soldPackage.signatureCaptured || false,
        signatureProvider: soldPackage.signatureProvider || null,
      } : null,
      payments: disposition === 'sold' && soldPackage ? {
        depositCollectedCents: soldPackage.depositCollectedCents || 0,
        totalCollectedCents: soldPackage.depositCollectedCents || 0,
        balanceRemainingCents: (soldPackage.contractValueCents || 0) - (soldPackage.depositCollectedCents || 0),
        paymentStatus: null,
        ledger: soldPackage.depositCollectedCents > 0 ? [{
          paymentEventType: 'deposit',
          paymentDate: now,
          amountCents: soldPackage.depositCollectedCents,
          paymentMethod: soldPackage.depositPaymentMethod || 'other',
          processor: 'manual',
          referenceNumber: null,
          notes: null,
        }] : [],
      } : null,
      dispositionRevision: newRevision,
      reportedFrom: 'fenceiq',
    };

    await base44.asServiceRole.entities.OutboundIntegrationEvent.create({
      companyId: job.companyId,
      destination: 'builder_prime_closeout',
      eventType: 'bp_closeout_report',
      sourceEntity: 'LeadDispositionEvent',
      sourceEntityId: dispositionEvent.id,
      jobId,
      builderPrimeOpportunityId: bpOpportunityId || null,
      builderPrimeClientId: bpClientId || null,
      payloadJson: JSON.stringify(closeoutPayload),
      status: 'pending',
      attemptCount: 0,
      nextAttemptAt: now,
      idempotencyKey,
      dispositionRevision: newRevision,
      triggeredByUserId: user.id,
      createdAt: now,
    });
  }

  return Response.json({
    status: 'ok',
    jobId,
    disposition,
    dispositionRevision: newRevision,
    isFinalDisposition: isFinal,
    dispositionEventId: dispositionEvent.id,
    idempotencyKey,
  });
});