import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import { computeCustomerNameFromObject } from "../_shared/computeCustomerName.js";
import { resolveCompanyContext } from "../_shared/resolveCompanyContext.js";

/**
 * _repair/repairCrmJobCustomerNamesManual
 * Payload:
 *  - __echo?: true
 *  - dryRun?: boolean (default true)
 *  - limit?: number (default 200)
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ success: false, error: "Unauthorized" }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const { __echo = false, dryRun = true, limit = 200 } = payload;

    // Echo branch to verify deployment + payload routing
    if (__echo) {
      return Response.json({
        success: true,
        echo: {
          route: "_repair/repairCrmJobCustomerNamesManual",
          receivedPayloadKeys: Object.keys(payload || {}),
          dryRun,
          limit
        }
      });
    }

    // Resolve tenant context
    const ctx = await resolveCompanyContext({ base44, req });
    if (ctx?.error) {
      return Response.json({ success: false, error: ctx.error.message, code: ctx.error.code }, { status: 400 });
    }
    const { companyId: tenantId } = ctx;

    // Pull CRMJobs scoped by tenantId
    // NOTE: We only scope by tenantId here because you've canonicalized companyId to tenantId in your system.
    const jobs = await base44.entities.CRMJob.filter({ companyId: tenantId });

    const max = Math.max(1, Math.min(Number(limit) || 200, 1000));
    const slice = Array.isArray(jobs) ? jobs.slice(0, max) : [];

    const needsRepair = [];
    for (const j of slice) {
      const raw = (j?.customerName ?? "").toString().trim();
      if (!raw || raw === "Unknown Customer") needsRepair.push(j);
    }

    const idsToUpdate = [];
    let updated = 0;
    let stillMissing = 0;

    for (const j of needsRepair) {
      const computed = computeCustomerNameFromObject(j);
      const finalName = (computed ?? "").toString().trim() || "Unknown Customer";

      idsToUpdate.push({ id: j.id, jobNumber: j.jobNumber || null, customerName: finalName });

      if (dryRun) continue;

      // Update only if different
      if ((j.customerName ?? "").toString().trim() !== finalName) {
        await base44.asServiceRole.entities.CRMJob.update(j.id, { customerName: finalName });
        updated++;
      }
      if (!finalName) stillMissing++;
    }

    return Response.json({
      success: true,
      context: { tenantId, mode: ctx?.mode || "unknown" },
      summary: {
        scanned: slice.length,
        needsRepair: needsRepair.length,
        updated,
        stillMissing,
        dryRun: !!dryRun
      },
      idsToUpdate: dryRun ? idsToUpdate : undefined
    });
  } catch (e) {
    console.error("[_repair/repairCrmJobCustomerNamesManual] error", e);
    return Response.json({ success: false, error: e?.message || String(e) }, { status: 500 });
  }
});