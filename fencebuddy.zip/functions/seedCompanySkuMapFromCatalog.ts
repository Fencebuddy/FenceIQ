import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Seed CompanySkuMap from MaterialCatalog
 * Creates deterministic mappings from approved catalog items to canonical keys
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin-only
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    let companyId;
    try {
      const body = await req.json();
      companyId = body.companyId;
    } catch (parseErr) {
      console.error('[seedCompanySkuMapFromCatalog] JSON parse error:', parseErr.message);
      return Response.json({ error: 'Invalid JSON body', details: parseErr.message }, { status: 400 });
    }

    if (!companyId) {
      return Response.json({ error: 'companyId required in request body' }, { status: 400 });
    }

    console.log('[seedCompanySkuMapFromCatalog] Starting for company:', companyId);

    // 1. Fetch active MaterialCatalog items
    const catalog = await base44.entities.MaterialCatalog.filter({
      active: true
    });

    console.log('[seedCompanySkuMapFromCatalog] Loaded catalog:', catalog.length, 'items');

    // 2. For each item, create CompanySkuMap entry
    const mappingsToCreate = [];
    const mappingsCreated = [];
    const mappingsFailed = [];

    for (const item of catalog) {
      try {
        // Check if item is active for this company
        if (item.active_company_ids?.length > 0) {
          if (!item.active_company_ids.includes(companyId)) {
            continue; // Skip items not active for this company
          }
        }

        const uck = item.canonical_key || item.material_id;
        if (!uck) {
          console.warn('[seedCompanySkuMapFromCatalog] Item missing canonical_key:', item.id);
          continue;
        }

        // Build mapping entry
        const mapping = {
          companyId,
          uck,
          uckVersion: 1,
          materialCatalogId: item.id,
          materialCatalogName: item.crm_name,
          materialType: item.material_type,
          fenceSystem: 'universal', // Generic mapping
          attributes: {
            category: item.category,
            sub_category: item.sub_category,
            material_type: item.material_type,
            finish: item.finish,
            size: item.size,
            unit: item.unit
          },
          displayName: item.crm_name,
          status: 'mapped',
          notes: `Auto-seeded from catalog on ${new Date().toISOString()}`,
          lastSeenAt: new Date().toISOString()
        };

        mappingsToCreate.push(mapping);
      } catch (err) {
        console.error('[seedCompanySkuMapFromCatalog] Item processing error:', item.id, err.message);
        mappingsFailed.push({ itemId: item.id, error: err.message });
      }
    }

    console.log('[seedCompanySkuMapFromCatalog] Will create:', mappingsToCreate.length, 'mappings');

    // 3. Bulk upsert mappings
    for (const mapping of mappingsToCreate) {
      try {
        // Check if mapping already exists
        const existing = await base44.entities.CompanySkuMap.filter({
          companyId: mapping.companyId,
          uck: mapping.uck
        });

        if (existing.length > 0) {
          // Update existing
          await base44.entities.CompanySkuMap.update(existing[0].id, mapping);
          mappingsCreated.push({ uck: mapping.uck, action: 'updated' });
        } else {
          // Create new
          await base44.entities.CompanySkuMap.create(mapping);
          mappingsCreated.push({ uck: mapping.uck, action: 'created' });
        }
      } catch (err) {
        console.error('[seedCompanySkuMapFromCatalog] Mapping error:', mapping.uck, err.message);
        mappingsFailed.push({ uck: mapping.uck, error: err.message });
      }
    }

    // 4. Fetch updated count
    const finalCount = await base44.entities.CompanySkuMap.filter({
      companyId
    });

    return Response.json({
      success: true,
      companyId,
      catalogItemsProcessed: catalog.length,
      mappingsCreated: mappingsCreated.length,
      mappingsFailed: mappingsFailed.length,
      totalMappings: finalCount.length,
      created: mappingsCreated,
      failed: mappingsFailed
    });
  } catch (error) {
    console.error('[seedCompanySkuMapFromCatalog] ERROR:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});