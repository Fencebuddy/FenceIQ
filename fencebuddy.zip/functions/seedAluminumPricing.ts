import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Seeds aluminum fence catalog items with canonical keys and pricing
 * Creates both catalog items and catalog link mappings
 */

const ALUMINUM_CATALOG_DATA = [
  // Posts - 4ft height
  {
    crm_name: "4' Aluminum End Posts",
    category: "post",
    sub_category: "end_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 22.50,
    fencebuddy_mapping: "aluminum_post_end_4ft",
    keywords: ["aluminum", "post", "end", "4ft", "4'"]
  },
  {
    crm_name: "4' Aluminum Corner Posts",
    category: "post",
    sub_category: "corner_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 22.50,
    fencebuddy_mapping: "aluminum_post_corner_4ft",
    keywords: ["aluminum", "post", "corner", "4ft", "4'"]
  },
  {
    crm_name: "4' Aluminum Gate Posts",
    category: "post",
    sub_category: "gate_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 22.50,
    fencebuddy_mapping: "aluminum_post_gate_4ft",
    keywords: ["aluminum", "post", "gate", "4ft", "4'"]
  },
  {
    crm_name: "4' Aluminum Line Posts",
    category: "post",
    sub_category: "line_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 22.50,
    fencebuddy_mapping: "aluminum_post_line_4ft",
    keywords: ["aluminum", "post", "line", "4ft", "4'"]
  },
  
  // Posts - 5ft height
  {
    crm_name: "5' Aluminum End Posts",
    category: "post",
    sub_category: "end_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 26.00,
    fencebuddy_mapping: "aluminum_post_end_5ft",
    keywords: ["aluminum", "post", "end", "5ft", "5'"]
  },
  {
    crm_name: "5' Aluminum Corner Posts",
    category: "post",
    sub_category: "corner_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 26.00,
    fencebuddy_mapping: "aluminum_post_corner_5ft",
    keywords: ["aluminum", "post", "corner", "5ft", "5'"]
  },
  {
    crm_name: "5' Aluminum Gate Posts",
    category: "post",
    sub_category: "gate_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 26.00,
    fencebuddy_mapping: "aluminum_post_gate_5ft",
    keywords: ["aluminum", "post", "gate", "5ft", "5'"]
  },
  {
    crm_name: "5' Aluminum Line Posts",
    category: "post",
    sub_category: "line_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 26.00,
    fencebuddy_mapping: "aluminum_post_line_5ft",
    keywords: ["aluminum", "post", "line", "5ft", "5'"]
  },
  
  // Posts - 6ft height
  {
    crm_name: "6' Aluminum End Posts",
    category: "post",
    sub_category: "end_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 29.50,
    fencebuddy_mapping: "aluminum_post_end_6ft",
    keywords: ["aluminum", "post", "end", "6ft", "6'"]
  },
  {
    crm_name: "6' Aluminum Corner Posts",
    category: "post",
    sub_category: "corner_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 29.50,
    fencebuddy_mapping: "aluminum_post_corner_6ft",
    keywords: ["aluminum", "post", "corner", "6ft", "6'"]
  },
  {
    crm_name: "6' Aluminum Gate Posts",
    category: "post",
    sub_category: "gate_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 29.50,
    fencebuddy_mapping: "aluminum_post_gate_6ft",
    keywords: ["aluminum", "post", "gate", "6ft", "6'"]
  },
  {
    crm_name: "6' Aluminum Line Posts",
    category: "post",
    sub_category: "line_post",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 29.50,
    fencebuddy_mapping: "aluminum_post_line_6ft",
    keywords: ["aluminum", "post", "line", "6ft", "6'"]
  },
  
  // Panels - 4ft height
  {
    crm_name: "4' Aluminum Fence Panels",
    category: "panel",
    sub_category: "fence_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 85.00,
    fencebuddy_mapping: "aluminum_panel_fence_4ft",
    keywords: ["aluminum", "panel", "fence", "4ft", "4'"]
  },
  
  // Panels - 5ft height
  {
    crm_name: "5' Aluminum Fence Panels",
    category: "panel",
    sub_category: "fence_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 95.00,
    fencebuddy_mapping: "aluminum_panel_fence_5ft",
    keywords: ["aluminum", "panel", "fence", "5ft", "5'"]
  },
  
  // Panels - 6ft height
  {
    crm_name: "6' Aluminum Fence Panels",
    category: "panel",
    sub_category: "fence_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 105.00,
    fencebuddy_mapping: "aluminum_panel_fence_6ft",
    keywords: ["aluminum", "panel", "fence", "6ft", "6'"]
  },
  
  // Hardware
  {
    crm_name: "Aluminum Post Caps",
    category: "hardware",
    sub_category: "post_cap",
    material_type: "aluminum",
    finish: "aluminum",
    size: "universal",
    unit: "each",
    cost: 4.50,
    fencebuddy_mapping: "aluminum_hardware_post_cap",
    keywords: ["aluminum", "post", "cap", "hardware"]
  },
  {
    crm_name: "Aluminum Gate Hinges (Set)",
    category: "hardware",
    sub_category: "hinge",
    material_type: "aluminum",
    finish: "aluminum",
    size: "set",
    unit: "set",
    cost: 12.00,
    fencebuddy_mapping: "aluminum_hardware_gate_hinge_set",
    keywords: ["aluminum", "gate", "hinge", "hardware"]
  },
  {
    crm_name: "Aluminum Locklatch 5\"",
    category: "hardware",
    sub_category: "latch",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5in",
    unit: "each",
    cost: 18.00,
    fencebuddy_mapping: "aluminum_hardware_locklatch_5in",
    keywords: ["aluminum", "locklatch", "latch", "5in", "hardware"]
  },
  {
    crm_name: "Aluminum Locklatch 4\"",
    category: "hardware",
    sub_category: "latch",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4in",
    unit: "each",
    cost: 16.00,
    fencebuddy_mapping: "aluminum_hardware_locklatch_4in",
    keywords: ["aluminum", "locklatch", "latch", "4in", "hardware"]
  },
  {
    crm_name: "Aluminum Cane Bolt",
    category: "hardware",
    sub_category: "latch",
    material_type: "aluminum",
    finish: "aluminum",
    size: "standard",
    unit: "each",
    cost: 8.50,
    fencebuddy_mapping: "aluminum_hardware_cane_bolt",
    keywords: ["aluminum", "cane", "bolt", "hardware"]
  },
  
  // Gate Panels - 4ft height
  {
    crm_name: "4' Aluminum Gate Panels",
    category: "gate",
    sub_category: "gate_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "4ft",
    unit: "each",
    cost: 95.00,
    fencebuddy_mapping: "aluminum_gate_panel_4ft",
    keywords: ["aluminum", "gate", "panel", "4ft", "4'"]
  },
  
  // Gate Panels - 5ft height
  {
    crm_name: "5' Aluminum Gate Panels",
    category: "gate",
    sub_category: "gate_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "5ft",
    unit: "each",
    cost: 105.00,
    fencebuddy_mapping: "aluminum_gate_panel_5ft",
    keywords: ["aluminum", "gate", "panel", "5ft", "5'"]
  },
  
  // Gate Panels - 6ft height
  {
    crm_name: "6' Aluminum Gate Panels",
    category: "gate",
    sub_category: "gate_panel",
    material_type: "aluminum",
    finish: "aluminum",
    size: "6ft",
    unit: "each",
    cost: 115.00,
    fencebuddy_mapping: "aluminum_gate_panel_6ft",
    keywords: ["aluminum", "gate", "panel", "6ft", "6'"]
  },
  
  // Concrete
  {
    crm_name: "Fast-Set Concrete (50 lb)",
    category: "concrete",
    sub_category: "mix",
    material_type: "aluminum",
    finish: "none",
    size: "50lb",
    unit: "bag",
    cost: 5.50,
    fencebuddy_mapping: "aluminum_concrete_fastset_50lb",
    keywords: ["concrete", "fast-set", "50lb", "bag"]
  }
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { mode } = await req.json();

    if (mode === 'preview') {
      return Response.json({
        mode: 'preview',
        total_materials: ALUMINUM_CATALOG_DATA.length,
        breakdown: {
          posts: ALUMINUM_CATALOG_DATA.filter(i => i.category === 'post').length,
          panels: ALUMINUM_CATALOG_DATA.filter(i => i.category === 'panel').length,
          gates: ALUMINUM_CATALOG_DATA.filter(i => i.category === 'gate').length,
          hardware: ALUMINUM_CATALOG_DATA.filter(i => i.category === 'hardware').length,
          concrete: ALUMINUM_CATALOG_DATA.filter(i => i.category === 'concrete').length
        },
        message: `Ready to seed ${ALUMINUM_CATALOG_DATA.length} aluminum catalog items with canonical keys`
      });
    }

    if (mode === 'execute') {
      let catalog_created = 0;
      let catalog_updated = 0;
      let links_created = 0;

      for (const item of ALUMINUM_CATALOG_DATA) {
        // Check if catalog item exists by fencebuddy_mapping
        const existing = await base44.asServiceRole.entities.MaterialCatalog.filter({
          fencebuddy_mapping: item.fencebuddy_mapping
        });

        let catalogItemId;
        if (existing.length > 0) {
          // Update existing
          await base44.asServiceRole.entities.MaterialCatalog.update(existing[0].id, item);
          catalogItemId = existing[0].id;
          catalog_updated++;
        } else {
          // Create new
          const created = await base44.asServiceRole.entities.MaterialCatalog.create({
            ...item,
            source: 'manual',
            active: true,
            last_updated: new Date().toISOString()
          });
          catalogItemId = created.id;
          catalog_created++;
        }

        // Create catalog link map if it doesn't exist
        const existingLink = await base44.asServiceRole.entities.CatalogLinkMap.filter({
          canonical_key: item.fencebuddy_mapping,
          catalog_item_id: catalogItemId
        });

        if (existingLink.length === 0) {
          await base44.asServiceRole.entities.CatalogLinkMap.create({
            canonical_key: item.fencebuddy_mapping,
            catalog_item_id: catalogItemId,
            priority: 1,
            active: true,
            notes: 'Auto-generated by aluminum seed'
          });
          links_created++;
        }
      }

      return Response.json({
        mode: 'execute',
        success: true,
        catalog_created,
        catalog_updated,
        links_created,
        message: `Seeded aluminum catalog successfully`
      });
    }

    return Response.json({ error: 'Invalid mode' }, { status: 400 });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});