import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Check for navigation errors logged in last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    
    const navErrors = await base44.asServiceRole.entities.DiagnosticsLog.filter({
      logType: 'NAVIGATION_ERROR',
      created_date: { $gte: oneDayAgo }
    });
    
    const missingJobIdErrors = navErrors.filter(log => 
      log.detailsJson?.error?.includes('Missing Job ID') ||
      log.detailsJson?.message?.includes('Missing Job ID')
    );
    
    console.log(`[Navigation Audit] Found ${missingJobIdErrors.length} "Missing Job ID" errors in last 24h`);
    
    if (missingJobIdErrors.length === 0) {
      return Response.json({
        success: true,
        timestamp: new Date().toISOString(),
        missingJobIdErrors: 0,
        status: 'HEALTHY'
      });
    }
    
    // Create alert if any found
    await base44.asServiceRole.entities.AlertRecord.create({
      alertType: 'NAVIGATION_ERROR_DETECTED',
      severity: 'HIGH',
      title: `${missingJobIdErrors.length} Navigation Errors (Missing Job ID)`,
      description: `Found ${missingJobIdErrors.length} "Missing Job ID" navigation errors in last 24 hours`,
      detailsJson: {
        errorCount: missingJobIdErrors.length,
        errors: missingJobIdErrors.slice(0, 10).map(e => ({
          timestamp: e.created_date,
          page: e.detailsJson?.page,
          details: e.detailsJson
        }))
      },
      status: 'active'
    });
    
    return Response.json({
      success: false,
      timestamp: new Date().toISOString(),
      missingJobIdErrors: missingJobIdErrors.length,
      status: 'UNHEALTHY',
      errors: missingJobIdErrors
    }, { status: 200 });
    
  } catch (error) {
    console.error('[Navigation Audit] Failed:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});