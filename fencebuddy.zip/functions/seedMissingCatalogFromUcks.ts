/**
 * Seeds MaterialCatalog with items derived from unmapped CompanySkuMap UCKs
 * Parses human-readable UCK names and creates catalog entries
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function parseUckName(uckName) {
  // Try to extract info from human-readable names like "Savannah 6' Khaki 9' Line Post"
  const parts = uckName.toLowerCase().split(/\s+/);
  
  let category = 'misc';
  let material_type = 'general';
  let finish = 'none';
  let size = '';
  let sub_category = '';
  
  // Detect material type
  if (uckName.includes('Savannah') || uckName.includes('savannah')) {
    material_type = 'vinyl';
  } else if (uckName.includes('Wood') || uckName.includes('wood')) {
    material_type = 'wood';
  } else if (uckName.includes('Chain') || uckName.includes('chain')) {
    material_type = 'chain_link';
  } else if (uckName.includes('Aluminum') || uckName.includes('aluminum')) {
    material_type = 'aluminum';
  }
  
  // Detect category and subcategory
  if (uckName.includes('Post') || uckName.includes('post')) {
    category = 'post';
    if (uckName.includes('Line')) sub_category = 'line_post';
    else if (uckName.includes('End')) sub_category = 'end_post';
    else if (uckName.includes('Corner')) sub_category = 'corner_post';
    else if (uckName.includes('Terminal')) sub_category = 'terminal_post';
  } else if (uckName.includes('Rail') || uckName.includes('rail')) {
    category = 'rail';
    if (uckName.includes('Top')) sub_category = 'top_rail';
    else if (uckName.includes('Bottom')) sub_category = 'bottom_rail';
  } else if (uckName.includes('Panel') || uckName.includes('panel')) {
    category = 'panel';
    if (uckName.includes('Privacy')) sub_category = 'privacy_panel';
  } else if (uckName.includes('Picket') || uckName.includes('picket')) {
    category = 'panel';
    sub_category = 'picket_board';
  } else if (uckName.includes('Fabric') || uckName.includes('fabric')) {
    category = 'fabric';
  } else if (uckName.includes('Gate') || uckName.includes('gate')) {
    category = 'gate';
    if (uckName.includes('Double')) sub_category = 'double_gate';
    else sub_category = 'single_gate';
  } else if (uckName.includes('Cap') || uckName.includes('cap')) {
    category = 'hardware';
    sub_category = 'cap';
  } else if (uckName.includes('Hardware') || uckName.includes('hardware')) {
    category = 'hardware';
  } else if (uckName.includes('Concrete') || uckName.includes('concrete')) {
    category = 'concrete';
  }
  
  // Detect finish/color
  if (uckName.includes('Galv') || uckName.includes('galv')) finish = 'galv';
  else if (uckName.includes('White') || uckName.includes('white')) finish = 'white';
  else if (uckName.includes('Black') || uckName.includes('black')) finish = 'black_vinyl';
  else if (uckName.includes('Khaki') || uckName.includes('khaki')) finish = 'khaki';
  else if (uckName.includes('Tan') || uckName.includes('tan')) finish = 'tan';
  else if (uckName.includes('Grey') || uckName.includes('grey') || uckName.includes('Gray')) finish = 'grey';
  else if (uckName.includes('Cedar') || uckName.includes('cedar')) finish = 'cedar';
  
  // Extract size (4', 5', 6', 8', 9', etc)
  const sizeMatch = uckName.match(/(\d+)['"]?/);
  if (sizeMatch) {
    size = sizeMatch[1] + "'";
  }
  
  // Build canonical key
  let canonical_key = `${material_type}_${category}`;
  if (sub_category) canonical_key += `_${sub_category}`;
  if (size && size !== "'") canonical_key += `_${size.replace("'", "ft")}`;
  if (finish && finish !== 'none') canonical_key += `_${finish}`;
  
  canonical_key = canonical_key.toLowerCase().replace(/[^a-z0-9_]/g, '').replace(/_+/g, '_');
  
  return {
    canonical_key,
    category,
    sub_category: sub_category || category,
    material_type,
    finish,
    size,
    unit: category === 'fabric' ? 'lf' : 'each'
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { companyId } = await req.json();
    if (!companyId) {
      return Response.json({ error: 'companyId required' }, { status: 400 });
    }

    // Get all unmapped CompanySkuMap entries
    const mappings = await base44.asServiceRole.entities.CompanySkuMap.filter({ companyId });
    const unmapped = mappings.filter(m => !m.materialCatalogId);

    console.log(`[SEED] Found ${unmapped.length} unmapped entries`);

    // Get existing catalog
    const catalog = await base44.asServiceRole.entities.MaterialCatalog.filter({ active: true });
    const canonicalKeySet = new Set(catalog.map(c => c.canonical_key));

    const created = [];
    const skipped = [];

    // Group by UCK to avoid duplicates
    const uckToUpsert = new Map();
    for (const map of unmapped) {
      if (!uckToUpsert.has(map.uck)) {
        uckToUpsert.set(map.uck, []);
      }
      uckToUpsert.get(map.uck).push(map);
    }

    console.log(`[SEED] Processing ${uckToUpsert.size} unique UCK values`);

    // Create catalog items in batches
    const BATCH_SIZE = 20;
    const uckArray = Array.from(uckToUpsert.keys());

    for (let i = 0; i < uckArray.length; i += BATCH_SIZE) {
      const batch = uckArray.slice(i, i + BATCH_SIZE);
      
      const catalogItems = batch.map(uck => {
        const parsed = parseUckName(uck);
        
        // Skip if canonical key already exists
        if (canonicalKeySet.has(parsed.canonical_key)) {
          skipped.push({ uck, reason: 'canonical_key_exists', canonical_key: parsed.canonical_key });
          return null;
        }
        
        return {
          crm_name: uck,
          canonical_key: parsed.canonical_key,
          category: parsed.category,
          sub_category: parsed.sub_category,
          material_type: parsed.material_type,
          finish: parsed.finish,
          size: parsed.size,
          unit: parsed.unit,
          cost: 0, // Placeholder - must be updated manually
          source: 'seed_migration',
          active: true
        };
      }).filter(Boolean);

      if (catalogItems.length === 0) {
        console.log(`[BATCH ${Math.floor(i / BATCH_SIZE) + 1}] No new items to create`);
        continue;
      }

      const results = await base44.asServiceRole.entities.MaterialCatalog.bulkCreate(catalogItems);
      console.log(`[BATCH ${Math.floor(i / BATCH_SIZE) + 1}] Created ${results.length} items`);
      created.push(...results);

      // Add to set to track
      results.forEach(r => canonicalKeySet.add(r.canonical_key));

      // Delay between batches
      if (i + BATCH_SIZE < uckArray.length) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    console.log(`[SEED] Created ${created.length} catalog items`);
    console.log(`[SEED] Skipped ${skipped.length} (already exist)`);

    return Response.json({
      status: 'success',
      companyId,
      totalUnmapped: unmapped.length,
      uniqueUcks: uckToUpsert.size,
      created: created.length,
      skipped: skipped.length,
      createdItems: created.map(c => ({ id: c.id, canonical_key: c.canonical_key, crm_name: c.crm_name })),
      skippedExamples: skipped.slice(0, 5)
    });

  } catch (error) {
    console.error('[seedMissingCatalogFromUcks] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});