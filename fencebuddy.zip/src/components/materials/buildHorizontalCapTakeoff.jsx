/**
 * HORIZONTAL WOOD PRIVACY WITH CAP BOARD — FenceIQ Deterministic Resolver
 * fenceStyleId: wood_horizontal_cap
 * Display Name: Horizontal Wood Privacy with Cap Board
 * Supported Heights: 4 ft, 5 ft, 6 ft
 *
 * ARCHITECTURE: Map Geometry → Fence Objects → Material Resolver → TakeoffSnapshot.materialLines
 *
 * SYSTEM GUARANTEES:
 * - Deterministic outputs only
 * - No auto-estimation or geometry inference
 * - All materials derived strictly from: FenceLine, CornerNode, TerminalNode, GateNode
 * - Same galvanized steel post SKUs as all other wood fence styles
 */

// ---------------------------------------------------------------------------
// STYLE CONSTANTS
// ---------------------------------------------------------------------------
const FENCE_STYLE_ID = 'wood_horizontal_cap';
const POST_SPACING_FT = 5;           // Nominal post spacing for horizontal fences
const DECK_BOARD_LENGTH_FT = 10;     // 5/4 × 6 × 10 deck boards
const RAIL_LENGTH_FT = 8;            // 2×4×8 backing rails
const CAP_BOARD_LENGTH_FT = 8;       // 2×6×8 cap boards
const CAP_BOARD_UNIT_COST = 12.99;   // Fixed cost per cap board
const NAILER_LENGTH_FT = 10;         // 2×4×10 nailer
const NAILER_UNIT_COST = 12.99;      // Fixed cost per nailer

// Board geometry (5/4 × 6 actual face = 5.5 in, gap = 0.25 in)
const USABLE_BOARD_FACE_IN = 5.5;
const BOARD_GAP_IN = 0.25;
const ROW_PITCH_IN = USABLE_BOARD_FACE_IN + BOARD_GAP_IN; // 5.75 in

// Supported heights
const SUPPORTED_HEIGHTS = [4, 5, 6];

// Rails per height
const RAILS_PER_HEIGHT = { 4: 2, 5: 3, 6: 3 };

// Existing wood steel post canonical keys (same as all other wood styles)
const POST_KEYS = {
    line:   'wood_post_4x4_steel',
    corner: 'wood_post_4x4_steel',
    end:    'wood_post_4x4_steel',
    gate:   'wood_post_4x6_gate',
};

// Supported gate widths → leaf config
const GATE_CONFIG = {
    4:  { type: 'single', leafCount: 1, leafWidthFt: 4 },
    5:  { type: 'single', leafCount: 1, leafWidthFt: 5 },
    8:  { type: 'double', leafCount: 2, leafWidthFt: 4 },
    10: { type: 'double', leafCount: 2, leafWidthFt: 5 },
};
const SUPPORTED_GATE_WIDTHS = [4, 5, 8, 10];

// Material SKUs
const SKUS = {
    deckBoard:     'DECKBOARD-5_4X6X10',
    seamCover:     'SEAM-COVER-DECKBOARD',
    rail:          'wood_rail_2x4x8',
    frameBoard:    'wood_rail_2x4x8',       // 2×4×8 treated — same SKU as rails
    capBoard:      'CAP-2X6X8-TREATED',
    nailer:        'NAILER-2X4X10-TREATED',
    screwDeck:     'wood_screw_3in_deck',
    gatePost:      'wood_post_4x6_gate',
    hingeSet:      'wood_hinge_set',
    latchStandard: 'wood_gate_latch',
    latchLock:     'wood_gate_latch_lock',
    latchDouble:   'wood_gate_latch_double',
    caneBolt:      'wood_bolt_cane',
    handle:        'wood_gate_handle',
};

// ---------------------------------------------------------------------------
// DIAGNOSTICS
// ---------------------------------------------------------------------------
const ResolverDiagnostics = {
    _errors: [],
    error(msg) { console.error('[HorizontalCapResolver] ERROR:', msg); this._errors.push(msg); },
    warn(msg)  { console.warn('[HorizontalCapResolver]', msg); },
    flush()    { const e = [...this._errors]; this._errors = []; return e; },
};

// ---------------------------------------------------------------------------
// HELPER: compute board rows for a given height
// ---------------------------------------------------------------------------
function computeBoardRows(heightFt) {
    const heightIn = heightFt * 12;
    return Math.ceil((heightIn - BOARD_GAP_IN) / ROW_PITCH_IN);
}

// ---------------------------------------------------------------------------
// MAIN RESOLVER
// ---------------------------------------------------------------------------

/**
 * buildHorizontalCapTakeoff
 *
 * Resolves Horizontal Wood Privacy with Cap Board materials deterministically
 * from map geometry objects. Never infers or auto-estimates structural elements.
 *
 * @param {Object} job
 * @param {Array}  fenceLines  — FenceLine objects from design layer
 * @param {Array}  runs        — Run records
 * @param {Array}  gates       — GateNode objects
 * @param {Array}  posts       — posts from postLayoutEngine (used for total count)
 * @param {Object} graphUtils  — { buildFenceGraph, computeTerminalPostCounts }
 */
export function buildHorizontalCapTakeoff(job, fenceLines, runs, gates, posts = [], { buildFenceGraph, computeTerminalPostCounts }) {
    ResolverDiagnostics.flush();

    // ------------------------------------------------------------------
    // STEP 1: Filter to active Wood runs
    // ------------------------------------------------------------------
    const activeRuns = runs.filter(r => {
        const status = r.runStatus || (r.isExisting ? 'existing' : 'new');
        const materialType = r.materialType || job.materialType;
        return status === 'new' && materialType === 'Wood';
    });

    const activeLines = fenceLines.filter(line => {
        const status = line.runStatus || (line.isExisting ? 'existing' : 'new');
        const run = activeRuns.find(r => r.id === line.assignedRunId);
        return status === 'new' && line.assignedRunId && run;
    });

    const activeGates = gates.filter(g => {
        const run = activeRuns.find(r => r.id === g.runId);
        return !!run && !g.isOrphan;
    });

    // ------------------------------------------------------------------
    // STEP 2: Height validation
    // ------------------------------------------------------------------
    const rawHeight = activeRuns[0]?.fenceHeight || job.fenceHeight;
    if (!rawHeight) {
        ResolverDiagnostics.error('heightFt missing — cannot resolve horizontal cap takeoff');
    }
    const heightFt = Math.round(parseFloat(rawHeight) || 0);
    if (!SUPPORTED_HEIGHTS.includes(heightFt)) {
        ResolverDiagnostics.error(`Unsupported height: ${heightFt} ft — must be 4, 5, or 6`);
    }

    // Early exit
    if (activeLines.length === 0) {
        return _emptyResult(ResolverDiagnostics.flush());
    }

    // ------------------------------------------------------------------
    // STEP 3: Fence geometry measurements
    // ------------------------------------------------------------------
    const totalFenceFt = activeLines.reduce((sum, l) => sum + (l.manualLengthFt || 0), 0);
    if (totalFenceFt <= 0) {
        ResolverDiagnostics.error(`line_length_ft <= 0 — no measurable fence length found`);
    }
    const totalGateWidthFt = activeGates.reduce((sum, g) => sum + (g.gateWidth_ft || 0), 0);
    const effectiveFenceFt = Math.max(0, totalFenceFt - totalGateWidthFt);

    // ------------------------------------------------------------------
    // STEP 4: Segment + post counts (5 ft spacing, deterministic)
    // ------------------------------------------------------------------
    const segmentCount = Math.ceil(effectiveFenceFt / POST_SPACING_FT);
    // bayCount == segmentCount for backing rail calculation
    const bayCount = segmentCount;

    // Graph for node classification (CornerNode, TerminalNode, GateNode)
    const graph = buildFenceGraph(activeLines, activeRuns, activeGates);
    const graphCounts = computeTerminalPostCounts(graph, activeGates);

    // Posts from map + fallback formula for horizontal style
    const endPosts   = graphCounts.endPosts;
    const cornerPosts = graphCounts.cornerPosts;
    const gatePosts  = graphCounts.gatePosts;

    // Line posts: segments - 1 (interior posts along the span)
    // Terminal posts (ends + corners) already cap the fence; avoid double-count
    const terminalPostCount = endPosts + cornerPosts; // provided by nodes
    const formulaLinePosts  = Math.max(0, segmentCount - 1 - terminalPostCount);
    // If map posts are available, prefer them; otherwise use formula
    const mapLinePosts = posts.filter(p => p.kind === 'line').length;
    const linePosts = mapLinePosts > 0 ? mapLinePosts : formulaLinePosts;

    const totalPosts = endPosts + cornerPosts + gatePosts + linePosts;

    // ------------------------------------------------------------------
    // STEP 5: Board rows (height-driven, deterministic)
    // ------------------------------------------------------------------
    const boardRows = computeBoardRows(heightFt);
    // Expected: 4ft→9, 5ft→11, 6ft→13

    // ------------------------------------------------------------------
    // STEP 6: Deck boards — FenceLine → horizontal pickets
    // ------------------------------------------------------------------
    const totalDeckBoardLF = boardRows * effectiveFenceFt;
    const rawDeckBoards    = Math.ceil(totalDeckBoardLF / DECK_BOARD_LENGTH_FT);
    const deckBoardCount   = Math.ceil(rawDeckBoards * 1.10); // 10% waste

    // ------------------------------------------------------------------
    // STEP 7: Seam cover boards — 1 vertical board every 2 posts
    // ------------------------------------------------------------------
    const rawSeamCovers    = Math.ceil(segmentCount / 2);
    const seamCoverCount   = Math.ceil(rawSeamCovers * 1.05); // 5% waste

    // ------------------------------------------------------------------
    // STEP 8: Backing rails
    // ------------------------------------------------------------------
    const railRows             = RAILS_PER_HEIGHT[heightFt] || 3;
    const totalRailLF          = railRows * effectiveFenceFt;
    const rawRails             = Math.ceil(totalRailLF / RAIL_LENGTH_FT);
    const railCount            = Math.ceil(rawRails * 1.05); // 5% waste

    // ------------------------------------------------------------------
    // STEP 8b: Nailers — 2×4×10 @ $12.99, one per every 2 posts
    // ------------------------------------------------------------------
    const nailerCount = Math.ceil(totalPosts / 2);

    // ------------------------------------------------------------------
    // STEP 9: Cap board
    // ------------------------------------------------------------------
    const capBoardLF    = effectiveFenceFt;
    const rawCapBoards  = Math.ceil(capBoardLF / CAP_BOARD_LENGTH_FT);
    const capBoardCount = Math.ceil(rawCapBoards * 1.05); // 5% waste

    // ------------------------------------------------------------------
    // STEP 10: Fasteners
    // ------------------------------------------------------------------
    // Board-to-rail: board_rows × rail_rows × bay_count × 2 screws per crossing
    const boardRailCrossings = boardRows * railRows * bayCount;
    const boardFasteners     = boardRailCrossings * 2;

    // Rail-to-post: bay_count × rail_rows × 2 ends × 2 screws
    const railPostConnections = bayCount * railRows * 2;
    const railPostFasteners   = railPostConnections * 2;

    // Seam cover boards: seam_cover_count × board_rows × 2 screws
    const seamCoverFasteners = rawSeamCovers * boardRows * 2;

    // Cap board: (segment_count + 1) × 2 screws
    const capFasteners = (segmentCount + 1) * 2;

    const totalScrews = boardFasteners + railPostFasteners + seamCoverFasteners + capFasteners;

    // ------------------------------------------------------------------
    // STEP 11: Gate resolver — deterministic per GateNode
    // ------------------------------------------------------------------
    const gateItems = [];

    activeGates.forEach(gate => {
        const gWidth = gate.gateWidth_ft || 0;
        const gateId = gate.id || 'unknown';

        // Validation: hard fail on unsupported gate width
        if (!SUPPORTED_GATE_WIDTHS.includes(gWidth)) {
            ResolverDiagnostics.error(`GateNode ${gateId}: unsupported gate width ${gWidth} ft — must be 4, 5, 8, or 10`);
            return;
        }

        const cfg        = GATE_CONFIG[gWidth];
        const leafCount  = cfg.leafCount;
        const leafWidth  = cfg.leafWidthFt;
        const isDouble   = cfg.type === 'double';
        const sourceInfo = { source: 'map', sourceObjectType: 'GateNode', sourceObjectId: gateId, fenceStyleId: FENCE_STYLE_ID };

        // --- Gate posts (2 per gate, same steel post SKU) ---
        gateItems.push({
            canonical_key: SKUS.gatePost,
            lineItemName: `Wood Post Gate 4×6 Treated (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: `Steel gate posts for ${gWidth} ft gate`,
            quantityCalculated: 2,
            uom: 'each',
            notes: `${gWidth} ft gate → 2 steel gate posts`,
            materialSku: SKUS.gatePost,
            ...sourceInfo,
        });

        // --- Gate frame boards: 5 per leaf (2 vertical + 2 horizontal + 1 diagonal brace) ---
        const rawFrameBoards   = leafCount * 5;
        const frameBoards      = Math.ceil(rawFrameBoards * 1.05);
        gateItems.push({
            canonical_key: SKUS.frameBoard,
            lineItemName: `Gate Frame Board 2×4×8 Treated (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: `Gate frame boards incl. 45° diagonal brace (${leafCount} leaf × 5 boards)`,
            quantityCalculated: frameBoards,
            uom: 'each',
            notes: `${leafCount} leaf × 5 boards = ${rawFrameBoards} × 1.05 waste = ${frameBoards} boards`,
            materialSku: SKUS.frameBoard,
            metadata: { frameBoardsPerLeaf: 5, includesDiagonalBrace: true },
            ...sourceInfo,
        });

        // --- Horizontal face boards (deck boards) ---
        const gateBoardLF    = boardRows * leafWidth * leafCount;
        const rawGateBoards  = Math.ceil(gateBoardLF / DECK_BOARD_LENGTH_FT);
        const gateBoardCount = Math.ceil(rawGateBoards * 1.10);
        gateItems.push({
            canonical_key: SKUS.deckBoard,
            lineItemName: `Deck Board 5/4×6×10 (${gWidth} ft gate face)`,
            runLabel: 'Gates',
            materialDescription: `Horizontal deck boards for ${gWidth} ft gate`,
            quantityCalculated: gateBoardCount,
            uom: 'each',
            notes: `${boardRows} rows × ${leafWidth} ft leaf × ${leafCount} leaf ÷ 10 ft × 1.10 waste = ${gateBoardCount} boards`,
            materialSku: SKUS.deckBoard,
            ...sourceInfo,
        });

        // --- Vertical seam cover boards: CEIL(leafWidthFt / 5) per leaf ---
        const rawSeamsPerLeaf = Math.ceil(leafWidth / 5);
        const rawGateSeams    = rawSeamsPerLeaf * leafCount;
        const gateSeamCount   = Math.ceil(rawGateSeams * 1.05);
        gateItems.push({
            canonical_key: SKUS.seamCover,
            lineItemName: `Seam Cover Board 5/4×6×10 (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: `Vertical seam cover boards for ${gWidth} ft gate`,
            quantityCalculated: gateSeamCount,
            uom: 'each',
            notes: `CEIL(${leafWidth} ft ÷ 5) = ${rawSeamsPerLeaf}/leaf × ${leafCount} leaf × 1.05 = ${gateSeamCount}`,
            materialSku: SKUS.seamCover,
            ...sourceInfo,
        });

        // --- Cap board: CEIL(leafWidthFt / 8) per leaf ---
        const rawCapPerLeaf  = Math.ceil(leafWidth / CAP_BOARD_LENGTH_FT);
        const gateCapCount   = rawCapPerLeaf * leafCount;
        gateItems.push({
            canonical_key: SKUS.capBoard,
            lineItemName: `Cap Board 2×6×8 (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: `Cap board for ${gWidth} ft gate`,
            quantityCalculated: gateCapCount,
            uom: 'each',
            unitCost: CAP_BOARD_UNIT_COST,
            extendedCost: gateCapCount * CAP_BOARD_UNIT_COST,
            notes: `CEIL(${leafWidth} ft ÷ ${CAP_BOARD_LENGTH_FT} ft) = ${rawCapPerLeaf}/leaf × ${leafCount} leaf = ${gateCapCount} boards @ $${CAP_BOARD_UNIT_COST}`,
            materialSku: SKUS.capBoard,
            metadata: { capIncluded: true },
            ...sourceInfo,
        });

        // --- Hinges: 1 set per leaf ---
        gateItems.push({
            canonical_key: SKUS.hingeSet,
            lineItemName: `Gate Hinge Set (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: `Heavy-duty gate hinge set`,
            quantityCalculated: leafCount,
            uom: 'set',
            notes: `${leafCount} leaf × 1 hinge set`,
            materialSku: SKUS.hingeSet,
            ...sourceInfo,
        });

        // --- Latch: deterministic by gate width ---
        const latchSku  = gWidth === 4 ? SKUS.latchLock : isDouble ? SKUS.latchDouble : SKUS.latchStandard;
        const latchName = gWidth === 4 ? 'LockLatch (4 ft single gate)'
                        : isDouble     ? 'Double Gate Latch System'
                        :                'Wood Gate Latch (5 ft single gate)';
        gateItems.push({
            canonical_key: latchSku,
            lineItemName: latchName,
            runLabel: 'Gates',
            materialDescription: latchName,
            quantityCalculated: 1,
            uom: 'each',
            notes: `${gWidth} ft gate → 1 ${latchName}`,
            materialSku: latchSku,
            ...sourceInfo,
        });

        // --- Cane bolts: double gates only ---
        if (isDouble) {
            gateItems.push({
                canonical_key: SKUS.caneBolt,
                lineItemName: `Cane Bolt (${gWidth} ft double gate)`,
                runLabel: 'Gates',
                materialDescription: 'Cane bolt for double gate',
                quantityCalculated: 2,
                uom: 'each',
                notes: `Double gate → 2 cane bolts`,
                materialSku: SKUS.caneBolt,
                ...sourceInfo,
            });
        }

        // --- Handle: 1 per leaf ---
        gateItems.push({
            canonical_key: SKUS.handle,
            lineItemName: `Gate Handle (${gWidth} ft gate)`,
            runLabel: 'Gates',
            materialDescription: 'Gate handle',
            quantityCalculated: leafCount,
            uom: 'each',
            notes: `${leafCount} leaf × 1 handle`,
            materialSku: SKUS.handle,
            ...sourceInfo,
        });

        // --- Gate fasteners ---
        const faceFasteners  = boardRows * leafCount * 4;
        const seamFasteners  = rawGateSeams * boardRows * 2;
        const capFastenersG  = leafCount * 4;
        const frameFasteners = leafCount * 6 * 2;
        const gateScrews     = faceFasteners + seamFasteners + capFastenersG + frameFasteners;
        gateItems.push({
            canonical_key: SKUS.screwDeck,
            lineItemName: `Deck Screw 3 in (${gWidth} ft gate fasteners)`,
            runLabel: 'Gates',
            materialDescription: 'Gate assembly fasteners (face + seam + cap + frame)',
            quantityCalculated: gateScrews,
            uom: 'pcs',
            notes: `Face: ${faceFasteners} | Seam: ${seamFasteners} | Cap: ${capFastenersG} | Frame: ${frameFasteners} = ${gateScrews}`,
            materialSku: SKUS.screwDeck,
            ...sourceInfo,
        });

        // Attach leaf metadata to last item (for snapshot auditability)
        gateItems[gateItems.length - 1].metadata = {
            gateWidthFt: gWidth,
            leafCount,
            leafWidthFt: leafWidth,
            boardRows,
            seamCoverCount: rawGateSeams,
            frameBoardsPerLeaf: 5,
            includesDiagonalBrace: true,
            capIncluded: true,
        };
    });

    // ------------------------------------------------------------------
    // STEP 12: Build line items
    // ------------------------------------------------------------------
    const lineItems = [];

    // --- Posts: line + terminal (same steel post SKU as all wood styles) ---
    if (endPosts + linePosts > 0) {
        lineItems.push({
            canonical_key: POST_KEYS.end,
            lineItemName: 'Wood Post 4×4 Driven Steel',
            runLabel: 'Overall',
            materialDescription: 'Galvanized steel driven post (end + line)',
            quantityCalculated: endPosts + linePosts,
            uom: 'each',
            notes: `${endPosts} TerminalNode + ${linePosts} line = ${endPosts + linePosts} posts (5 ft spacing)`,
            source: 'map',
            sourceObjectType: 'TerminalNode/FenceLine',
            fenceStyleId: FENCE_STYLE_ID,
            materialSku: POST_KEYS.end,
        });
    }
    if (cornerPosts > 0) {
        lineItems.push({
            canonical_key: POST_KEYS.corner,
            lineItemName: 'Wood Post 4×4 Driven Steel (Corner)',
            runLabel: 'Overall',
            materialDescription: 'Galvanized steel driven post (corner)',
            quantityCalculated: cornerPosts,
            uom: 'each',
            notes: `${cornerPosts} CornerNode(s)`,
            source: 'map',
            sourceObjectType: 'CornerNode',
            fenceStyleId: FENCE_STYLE_ID,
            materialSku: POST_KEYS.corner,
        });
    }
    if (gatePosts > 0) {
        lineItems.push({
            canonical_key: POST_KEYS.gate,
            lineItemName: 'Wood Post Gate 4×6 Treated',
            runLabel: 'Overall',
            materialDescription: 'Treated gate post (4×6)',
            quantityCalculated: gatePosts,
            uom: 'each',
            notes: `${activeGates.length} gate(s) × 2 posts = ${gatePosts}`,
            source: 'map',
            sourceObjectType: 'GateNode',
            fenceStyleId: FENCE_STYLE_ID,
            materialSku: POST_KEYS.gate,
        });
    }

    // --- Deck boards (horizontal pickets) - cedar or treated ---
    lineItems.push({
        canonical_key: job.useCedarPickets ? 'cedar_5_4x6x10' : SKUS.deckBoard,
        lineItemName: job.useCedarPickets ? 'Deck Board 5/4×6×10 Cedar (Horizontal Pickets)' : 'Deck Board 5/4×6×10 Treated (Horizontal Pickets)',
        runLabel: 'FenceLine',
        materialDescription: job.useCedarPickets ? '5/4 × 6 × 10 cedar deck board (horizontal pickets)' : '5/4 × 6 × 10 treated deck board (horizontal pickets)',
        quantityCalculated: deckBoardCount,
        uom: 'each',
        notes: `${boardRows} rows × ${effectiveFenceFt.toFixed(1)} ft ÷ 10 ft × 1.10 waste = ${deckBoardCount} boards`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: job.useCedarPickets ? 'cedar_5_4x6x10' : SKUS.deckBoard,
    });

    // --- Seam cover boards (vertical, every 2 posts) ---
    lineItems.push({
        canonical_key: SKUS.seamCover,
        lineItemName: 'Deck Board 5/4×6×10 Treated (Seam Cover)',
        runLabel: 'FenceLine',
        materialDescription: 'Vertical seam cover board at post joints (every 2 posts)',
        quantityCalculated: seamCoverCount,
        uom: 'each',
        notes: `CEIL(${segmentCount} segments ÷ 2) = ${rawSeamCovers} covers × 1.05 waste = ${seamCoverCount}`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: SKUS.seamCover,
    });

    // --- Backing rails - cedar or treated ---
    lineItems.push({
        canonical_key: job.useCedarPickets ? 'cedar_2x4x8' : SKUS.rail,
        lineItemName: job.useCedarPickets ? 'Wood Rail 2×4×8 Cedar (Backing Rail)' : 'Wood Rail 2×4×8 Treated (Backing Rail)',
        runLabel: 'FenceLine',
        materialDescription: job.useCedarPickets ? `Cedar backing rails – ${railRows} rows per bay` : `Horizontal backing rails – ${railRows} rows per bay`,
        quantityCalculated: railCount,
        uom: 'each',
        notes: `${railRows} rows × ${effectiveFenceFt.toFixed(1)} ft ÷ ${RAIL_LENGTH_FT} ft × 1.05 waste = ${railCount} boards`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: job.useCedarPickets ? 'cedar_2x4x8' : SKUS.rail,
    });

    // --- Nailer boards (2×4×10, 1 per every 2 posts) ---
    lineItems.push({
        canonical_key: SKUS.nailer,
        lineItemName: 'Nailer 2×4×10 Treated',
        runLabel: 'FenceLine',
        materialDescription: '2 × 4 × 10 treated nailer board (1 per every 2 posts)',
        quantityCalculated: nailerCount,
        uom: 'each',
        unitCost: NAILER_UNIT_COST,
        extendedCost: nailerCount * NAILER_UNIT_COST,
        notes: `CEIL(${totalPosts} posts ÷ 2) = ${nailerCount} nailers @ $${NAILER_UNIT_COST}`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: SKUS.nailer,
    });

    // --- Cap board - cedar or treated ---
    lineItems.push({
        canonical_key: job.useCedarPickets ? 'cedar_cap_2x6x10' : SKUS.capBoard,
        lineItemName: job.useCedarPickets ? 'Cap Board 2×6×10 Cedar' : 'Cap Board 2×6×8 Treated',
        runLabel: 'FenceLine',
        materialDescription: job.useCedarPickets ? '2 × 6 × 10 cedar cap board (top of fence)' : '2 × 6 × 8 treated cap board (top of fence)',
        quantityCalculated: capBoardCount,
        uom: 'each',
        unitCost: CAP_BOARD_UNIT_COST,
        extendedCost: capBoardCount * CAP_BOARD_UNIT_COST,
        notes: `CEIL(${effectiveFenceFt.toFixed(1)} ft ÷ ${CAP_BOARD_LENGTH_FT} ft) × 1.05 waste = ${capBoardCount} boards @ $${CAP_BOARD_UNIT_COST}`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: job.useCedarPickets ? 'cedar_cap_2x6x10' : SKUS.capBoard,
    });

    // --- Fasteners (all deck screws) ---
    lineItems.push({
        canonical_key: SKUS.screwDeck,
        lineItemName: 'Deck Screw 3 in (all fasteners)',
        runLabel: 'Fasteners',
        materialDescription: '3 in deck screw (board-to-rail + rail-to-post + seam covers + cap)',
        quantityCalculated: totalScrews,
        uom: 'pcs',
        notes: `Board-to-rail: ${boardFasteners} | Rail-to-post: ${railPostFasteners} | Seam covers: ${seamCoverFasteners} | Cap: ${capFasteners} = ${totalScrews} total`,
        source: 'map',
        sourceObjectType: 'FenceLine',
        fenceStyleId: FENCE_STYLE_ID,
        materialSku: SKUS.screwDeck,
    });

    // --- Gate items (all resolved per-GateNode above) ---
    lineItems.push(...gateItems);

    // ------------------------------------------------------------------
    // STEP 13: Return result with full metadata
    // ------------------------------------------------------------------
    const diagnosticErrors = ResolverDiagnostics.flush();
    if (diagnosticErrors.length > 0) {
        console.error('[HorizontalCapResolver] Completed with errors:', diagnosticErrors);
    }

    return {
        materialType: 'Wood',
        fenceStyleId: FENCE_STYLE_ID,
        total_lf: totalFenceFt,
        postCounts: { endPosts, cornerPosts, gatePosts, linePosts, totalPosts },
        metrics: {
            heightFt,
            boardRows,
            segmentCount,
            seamCoverCount: rawSeamCovers,
            railRows,
            deckBoardCount,
            railCount,
            capBoardCount,
            nailerCount,
            wasteApplied: true,
        },
        lineItems,
        graph,
        diagnosticErrors,
    };
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------
function _emptyResult(errors) {
    return {
        materialType: 'Wood',
        fenceStyleId: FENCE_STYLE_ID,
        total_lf: 0,
        postCounts: { endPosts: 0, cornerPosts: 0, gatePosts: 0, linePosts: 0, totalPosts: 0 },
        metrics: { heightFt: 0, boardRows: 0, segmentCount: 0, seamCoverCount: 0, wasteApplied: false },
        lineItems: [],
        graph: null,
        diagnosticErrors: errors,
    };
}