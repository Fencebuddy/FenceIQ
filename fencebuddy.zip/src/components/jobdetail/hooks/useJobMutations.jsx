import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { generateMathSubRuns } from '@/components/materials/mathSubRunEngine';
import { toast } from 'react-hot-toast';

/**
 * useJobMutations — all run/gate/material CRUD mutations extracted from JobDetail.
 */
export function useJobMutations({
  jobId,
  job,
  runs,
  fenceLines,
  trees,
  rotation,
  assigningLine,
  setFenceLines,
  setMapSaveStatus,
  setShowRunForm,
  setEditingRun,
  setAssigningLine,
  setMaterialChangeDialog,
  setDeleteRun,
  setShowGateForm,
  setEditingGate,
  setDeleteGate,
  setShowMaterialForm,
  setEditingMaterial,
  setDeleteMaterial,
  queryClient,
}) {
  // ─── Run save ───────────────────────────────────────────────────────────
  const saveRunMutation = useMutation({
    mutationFn: async (runData) => {
      const isNewRun = !runData.id;
      if (!isNewRun && runs && runs.length > 1) {
        const originalRun = runs?.find(r => r.id === runData.id);
        const materialTypeChanged = originalRun?.materialType !== runData.materialType;
        const styleChanged = originalRun?.style !== runData.style;
        const heightChanged = originalRun?.fenceHeight !== runData.fenceHeight;
        const colorChanged = originalRun?.fenceColor !== runData.fenceColor;
        const privacyTypeChanged = originalRun?.chainLinkPrivacyType !== runData.chainLinkPrivacyType;
        const slatColorChanged = originalRun?.vinylSlatColor !== runData.vinylSlatColor;
        const hasSpecChange = materialTypeChanged || styleChanged || heightChanged || colorChanged || privacyTypeChanged || slatColorChanged;
        if (hasSpecChange) {
          setMaterialChangeDialog({
            runData, originalRun,
            isMaterialTypeChange: materialTypeChanged,
            isStyleChange: styleChanged,
            isHeightChange: heightChanged,
            isColorChange: colorChanged,
            isPrivacyTypeChange: privacyTypeChanged,
            isSlatColorChange: slatColorChanged,
          });
          throw new Error('PENDING_CONFIRMATION');
        }
      }

      let normalizedRun = { ...runData };
      if ((normalizedRun.startElevation != null && normalizedRun.endElevation != null) &&
          (normalizedRun.dropFt == null || normalizedRun.dropFt === 0)) {
        normalizedRun.dropFt = Math.abs(normalizedRun.endElevation - normalizedRun.startElevation);
        normalizedRun.horizontalRunFt = normalizedRun.horizontalRunFt || normalizedRun.lengthLF;
        normalizedRun.slopeGrade = normalizedRun.horizontalRunFt > 0 ? normalizedRun.dropFt / normalizedRun.horizontalRunFt : 0;
        if (normalizedRun.slopeDetectedFrom && normalizedRun.slopeDetectedFrom.includes('DXF')) {
          normalizedRun.slopeSource = 'DXF_AUTO_DETECT';
        }
      }
      if ((normalizedRun.gradePoints && normalizedRun.gradePoints.length >= 2) ||
          (normalizedRun.startElevation != null && normalizedRun.endElevation != null)) {
        normalizedRun.mathSubRuns = generateMathSubRuns(normalizedRun);
      }
      if (normalizedRun.materialType === 'Vinyl') {
        const hasSlope =
          (normalizedRun.dropFt != null && normalizedRun.dropFt > 0.05) ||
          (normalizedRun.startElevation != null && normalizedRun.endElevation != null &&
           Math.abs(normalizedRun.endElevation - normalizedRun.startElevation) > 0.05) ||
          (normalizedRun.mathSubRuns && normalizedRun.mathSubRuns.some(sr => sr.slopeRangeLabel !== 'Level')) ||
          (normalizedRun.gradePoints && normalizedRun.gradePoints.length >= 2);
        if (hasSlope) normalizedRun.slopeMode = 'Rack';
      }

      let savedRun;
      if (normalizedRun.id) {
        await base44.entities.Run.update(normalizedRun.id, normalizedRun);
        savedRun = { ...normalizedRun };
      } else {
        savedRun = await base44.entities.Run.create(normalizedRun);
      }

      const allRuns = await base44.entities.Run.filter({ jobId });
      const newTotal = allRuns.reduce((sum, r) => sum + (r.lengthLF || 0), 0);
      const materials = [...new Set(allRuns.map(r => r.materialType).filter(Boolean))];
      const jobUpdates = { totalLF: newTotal };
      if (materials.length > 1) jobUpdates.materialType = 'Mixed';
      else if (materials.length === 1) jobUpdates.materialType = materials[0];
      const materialColors = allRuns.map(r => {
        if (r.materialType === 'Chain Link') {
          const coating = r.chainLinkCoating || 'Galvanized';
          return coating === 'Black Vinyl Coated' ? 'Black' : coating;
        } else if (r.materialType === 'Wood') return 'Pine';
        else return r.fenceColor;
      }).filter(Boolean);
      const uniqueColors = [...new Set(materialColors)];
      if (uniqueColors.length > 1) jobUpdates.fenceColor = 'Mixed';
      else if (uniqueColors.length === 1) jobUpdates.fenceColor = uniqueColors[0];

      // If assigning a line, include mapData in the same Job update (avoid double write)
      return { savedRun, jobUpdates, allRuns };
    },
    onSuccess: async ({ savedRun, jobUpdates }, variables) => {
      if (assigningLine) {
        const runId = savedRun?.id || variables.id;
        if (runId) {
          const newLines = [...fenceLines];
          if (newLines[assigningLine.lineIndex]) {
            newLines[assigningLine.lineIndex] = {
              ...newLines[assigningLine.lineIndex],
              assignedRunId: runId,
              manualLengthFt: variables.lengthLF,
            };
            setFenceLines(newLines);
            const canvasItems = {
              gates: window.gates || [], doubleGates: window.doubleGates || [],
              houses: window.houses || [], pools: window.pools || [],
              garages: window.garages || [], dogs: window.dogs || [],
              driveways: window.driveways || [], decks: window.decks || [],
              bushes: window.bushes || [], porches: window.porches || [],
              grasses: window.grasses || [], endPosts: window.endPosts || [],
              beds: window.beds || [],
            };
            // Single Job.update combining totals + mapData
            await base44.entities.Job.update(jobId, {
              ...jobUpdates,
              mapData: { fenceLines: newLines, trees, rotation, ...canvasItems },
            });
            setMapSaveStatus('saved');
            toast.success('Run created and assigned');
          }
        }
      } else {
        // No line assignment — just persist job totals
        await base44.entities.Job.update(jobId, jobUpdates);
      }
      queryClient.invalidateQueries(['runs', jobId]);
      queryClient.invalidateQueries(['job', jobId]);
      setShowRunForm(false);
      setEditingRun(null);
      setAssigningLine(null);
    },
    onError: (error) => {
      if (error.message !== 'PENDING_CONFIRMATION') {
        alert(`Failed to save run: ${error.message || 'Unknown error'}`);
      }
    },
  });

  // ─── Delete run ──────────────────────────────────────────────────────────
  const deleteRunMutation = useMutation({
    mutationFn: async (runId) => {
      const gatesOnRun = await base44.entities.Gate.filter({ runId });
      for (const gate of gatesOnRun) await base44.entities.Gate.delete(gate.id);
      await base44.entities.Run.delete(runId);
      const allRuns = await base44.entities.Run.filter({ jobId });
      const newTotal = allRuns.reduce((sum, r) => sum + (r.lengthLF || 0), 0);
      const materials = [...new Set(allRuns.map(r => r.materialType).filter(Boolean))];
      const updates = { totalLF: newTotal };
      if (materials.length > 1) updates.materialType = 'Mixed';
      else if (materials.length === 1) updates.materialType = materials[0];
      const materialColors = allRuns.map(r => {
        if (r.materialType === 'Chain Link') {
          const coating = r.chainLinkCoating || 'Galvanized';
          return coating === 'Black Vinyl Coated' ? 'Black' : coating;
        } else if (r.materialType === 'Wood') return 'Pine';
        else return r.fenceColor;
      }).filter(Boolean);
      const uniqueColors = [...new Set(materialColors)];
      if (uniqueColors.length > 1) updates.fenceColor = 'Mixed';
      else if (uniqueColors.length === 1) updates.fenceColor = uniqueColors[0];
      await base44.entities.Job.update(jobId, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['runs', jobId]);
      queryClient.invalidateQueries(['gates', jobId]);
      queryClient.invalidateQueries(['job', jobId]);
      setDeleteRun(null);
    },
  });

  // ─── Save gate ───────────────────────────────────────────────────────────
  const saveGateMutation = useMutation({
    mutationFn: async (gateData) => {
      const activeVersion = job?.activeGateVersion || 'v1';
      const gateDataWithVersion = { ...gateData, version: gateData.version || activeVersion, isOrphan: false };
      if (gateData.id) await base44.entities.Gate.update(gateData.id, gateDataWithVersion);
      else await base44.entities.Gate.create(gateDataWithVersion);
    },
    onSuccess: async () => {
      queryClient.invalidateQueries(['gates', jobId]);
      queryClient.invalidateQueries(['materials', jobId]);
      setShowGateForm(false);
      setEditingGate(null);
      toast.success('Gate saved');
    },
  });

  // ─── Delete gate ─────────────────────────────────────────────────────────
  const deleteGateMutation = useMutation({
    mutationFn: (gateId) => base44.entities.Gate.delete(gateId),
    onSuccess: async () => {
      queryClient.invalidateQueries(['gates', jobId]);
      queryClient.invalidateQueries(['materials', jobId]);
      setDeleteGate(null);
    },
  });

  // ─── Save material ───────────────────────────────────────────────────────
  const saveMaterialMutation = useMutation({
    mutationFn: async (materialData) => {
      if (materialData.id) {
        const updates = { ...materialData };
        if (materialData.quantity !== undefined) {
          updates.manualOverrideQty = materialData.quantity;
          delete updates.quantity;
        }
        await base44.entities.MaterialLine.update(materialData.id, updates);
      } else {
        const newMat = { ...materialData, calculatedQty: materialData.quantity || 0, manualOverrideQty: null, source: 'manual' };
        delete newMat.quantity;
        await base44.entities.MaterialLine.create(newMat);
      }
    },
    onSuccess: async () => {
      queryClient.invalidateQueries(['materials', jobId]);
      setShowMaterialForm(false);
      setEditingMaterial(null);
    },
  });

  // ─── Delete material ─────────────────────────────────────────────────────
  const deleteMaterialMutation = useMutation({
    mutationFn: (materialId) => base44.entities.MaterialLine.delete(materialId),
    onSuccess: async () => {
      queryClient.invalidateQueries(['materials', jobId]);
      setDeleteMaterial(null);
    },
  });

  // ─── Update status ───────────────────────────────────────────────────────
  const updateStatusMutation = useMutation({
    mutationFn: (status) => base44.entities.Job.update(jobId, { status }),
    onSuccess: () => queryClient.invalidateQueries(['job', jobId]),
  });

  // ─── Update job ──────────────────────────────────────────────────────────
  const updateJobMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Job.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(['job', jobId]),
  });

  return {
    saveRunMutation,
    deleteRunMutation,
    saveGateMutation,
    deleteGateMutation,
    saveMaterialMutation,
    deleteMaterialMutation,
    updateStatusMutation,
    updateJobMutation,
  };
}