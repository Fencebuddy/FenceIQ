import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { AlertCircle, ChevronRight, Loader2, CheckCircle2 } from "lucide-react";
import { createPageUrl } from "@/utils";

function fmtUSD(x) {
  if (x == null) return "—";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(x);
}

export default function BreakevenIntelligencePanel() {
  const queryClient = useQueryClient();
  const [initializing, setInitializing] = useState(false);

  const { data, isLoading, error } = useQuery({
    queryKey: ["breakeven-intelligence"],
    queryFn: async () => {
      const res = await base44.functions.invoke("getBreakevenIntelligence", {});
      return res.data;
    },
    refetchInterval: 60_000,
    staleTime: 30_000
  });

  const [initError, setInitError] = useState(null);
  const [initSuccess, setInitSuccess] = useState(false);

  const handleInitialize = async () => {
    setInitializing(true);
    setInitError(null);
    setInitSuccess(false);
    try {
      const res = await base44.functions.invoke("initializeOverheadSettings", {});
      if (res.data?.success) {
        setInitSuccess(true);
        // Refetch breakeven data
        await queryClient.invalidateQueries({ queryKey: ["breakeven-intelligence"] });
      } else {
        setInitError(res.data?.message || "Initialization failed");
      }
    } catch (err) {
      setInitError(err?.message || "Failed to initialize overhead settings");
      console.error('Failed to initialize:', err);
    } finally {
      setInitializing(false);
    }
  };

  const payload = data?.success ? data : null;
  const setupRequired = payload?.setupRequired ?? false;

  const status = payload?.status;
  const monthlyOverhead = payload?.overhead?.monthlyOverheadUSD ?? null;
  const overheadRecovered = payload?.recovery?.overheadRecoveredUSD ?? null;
  const gap = monthlyOverhead != null && overheadRecovered != null ? (monthlyOverhead - overheadRecovered) : null;
  const coveragePct = payload?.recovery?.coveragePct ?? 0;
  const pct = Math.round(coveragePct * 100);

  const requiredMonthlyRevenue = payload?.breakeven?.requiredMonthlyRevenueUSD ?? null;
  const effectiveOverheadRate = payload?.breakeven?.effectiveOverheadRate ?? null;
  const confidence = payload?.confidence ?? null;
  const confidenceNotes = payload?.confidenceNotes ?? [];

  const banner =
    setupRequired ? "Set up overhead to activate breakeven tracking" :
    status === "DANGEROUS" ? "Your overhead coverage is dangerous. Either increase revenue or reduce fixed expenses." :
    status === "NEAR" ? "Close — keep pushing revenue to cover overhead this month." :
    status === "COVERED" ? "Overhead covered for this month. Everything above this is true profit leverage." :
    "Complete overhead setup to unlock breakeven intelligence.";

  return (
    <Card>
      <CardHeader>
        <CardTitle>Breakeven Intelligence</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading && <div>Loading breakeven intelligence…</div>}

        {!isLoading && error && !data?.success && (
          <Alert>
            <AlertDescription>
              {error?.message || "Unable to load breakeven intelligence."}
            </AlertDescription>
          </Alert>
        )}

        {/* Setup Required State */}
        {setupRequired && payload && (
          <div className="space-y-4">
            <Alert className="bg-amber-900/20 border-amber-600">
              <AlertCircle className="w-4 h-4 text-amber-500" />
              <AlertDescription className="text-amber-100 ml-2">
                Overhead settings not configured. Set your monthly fixed costs to enable breakeven tracking.
              </AlertDescription>
            </Alert>
            
            {initSuccess && (
              <Alert className="bg-green-900/20 border-green-600">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <AlertDescription className="text-green-100 ml-2">
                  Overhead settings initialized! Refresh to see breakeven data.
                </AlertDescription>
              </Alert>
            )}

            {initError && (
              <Alert className="bg-red-900/20 border-red-600">
                <AlertCircle className="w-4 h-4 text-red-500" />
                <AlertDescription className="text-red-100 ml-2">
                  {initError}
                </AlertDescription>
              </Alert>
            )}

            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-sm text-slate-700 mb-4">
                Quick start: Initialize with $10,000/month overhead (adjustable later), or manually configure your actual expenses.
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={handleInitialize}
                  disabled={initializing}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {initializing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Initializing...
                    </>
                  ) : (
                    <>Initialize ($10k/month default)</>
                  )}
                </Button>
                <Button 
                  onClick={() => window.location.href = createPageUrl('OverheadIntelligence')}
                  variant="outline"
                  className="flex-1"
                >
                  Configure Manually
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Live Data State */}
        {payload && !setupRequired && (
          <>
            <Alert>
              <AlertDescription>{banner}</AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <div className="text-sm opacity-70">Monthly Overhead</div>
                <div className="text-xl font-semibold">{fmtUSD(monthlyOverhead)}</div>
              </div>
              <div>
                <div className="text-sm opacity-70">Overhead Recovered MTD</div>
                <div className="text-xl font-semibold">{fmtUSD(overheadRecovered)}</div>
              </div>
              <div>
                <div className="text-sm opacity-70">Gap / Surplus MTD</div>
                <div className={`text-xl font-semibold ${gap != null && gap <= 0 ? "text-green-600" : "text-red-600"}`}>
                  {gap == null ? "—" : fmtUSD(gap)}
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span>Coverage Progress</span>
                <span>{pct}%</span>
              </div>
              <Progress value={pct} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <div className="text-sm opacity-70">Breakeven Revenue Needed (Monthly)</div>
                <div className="text-xl font-semibold">{fmtUSD(requiredMonthlyRevenue)}</div>
              </div>
              <div>
                <div className="text-sm opacity-70">Effective Overhead Rate</div>
                <div className="text-xl font-semibold">
                  {effectiveOverheadRate == null ? "—" : `${(effectiveOverheadRate * 100).toFixed(2)}%`}
                </div>
              </div>
            </div>

            <div className="text-xs opacity-60 space-y-1">
              <div>
                Source: {payload.dataSource === 'ROLLUP_TABLE' ? 'Rollup table' : payload.dataSource === 'LIVE_CRMJOB_SCAN' ? 'Live CRM jobs' : 'Partial fallback'}
              </div>
              <div>
                Confidence: {confidence} {confidenceNotes.length > 0 && `— ${confidenceNotes[0]}`}
              </div>
              <div>Updated: {payload.updatedAt}</div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}