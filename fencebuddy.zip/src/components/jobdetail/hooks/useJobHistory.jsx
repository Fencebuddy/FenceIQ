import { useState } from 'react';

/**
 * useJobHistory — undo/redo history stack for the fence map.
 * Extracted as-is from pages/JobDetail.
 */
export function useJobHistory({ fenceLines, trees, annotations, surfaceMountedPosts, setFenceLines, setTrees, setAnnotations, setSelectedItem, setSurfaceMountedPosts }) {
  const [history, setHistory] = useState([]);
  const [redoHistory, setRedoHistory] = useState([]);

  const getCanvasSnapshot = () => ({
    gates: window.gates || [],
    doubleGates: window.doubleGates || [],
    houses: window.houses || [],
    pools: window.pools || [],
    garages: window.garages || [],
    dogs: window.dogs || [],
    driveways: window.driveways || [],
    decks: window.decks || [],
    bushes: window.bushes || [],
    porches: window.porches || [],
    grasses: window.grasses || [],
    endPosts: window.endPosts || [],
    beds: window.beds || [],
  });

  const saveToHistory = () => {
    const canvas = getCanvasSnapshot();
    const snapshot = {
      fenceLines: JSON.parse(JSON.stringify(fenceLines)),
      trees: JSON.parse(JSON.stringify(trees)),
      ...Object.fromEntries(Object.entries(canvas).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))])),
      annotations: JSON.parse(JSON.stringify(annotations || [])),
      surfaceMountedPosts: JSON.parse(JSON.stringify(surfaceMountedPosts || [])),
    };
    setHistory(prev => [...prev, snapshot]);
    setRedoHistory([]);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    const canvas = getCanvasSnapshot();
    const currentSnapshot = {
      fenceLines: JSON.parse(JSON.stringify(fenceLines)),
      trees: JSON.parse(JSON.stringify(trees)),
      ...Object.fromEntries(Object.entries(canvas).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))])),
      annotations: JSON.parse(JSON.stringify(annotations || [])),
      surfaceMountedPosts: JSON.parse(JSON.stringify(surfaceMountedPosts || [])),
    };
    setRedoHistory(prev => [...prev, currentSnapshot]);
    setFenceLines(previous.fenceLines || []);
    setTrees(previous.trees || []);
    setAnnotations(previous.annotations || []);
    if (setSurfaceMountedPosts) setSurfaceMountedPosts(previous.surfaceMountedPosts || []);
    if (window.setCanvasItems) {
      window.setCanvasItems({
        gates: previous.gates || [],
        doubleGates: previous.doubleGates || [],
        houses: previous.houses || [],
        pools: previous.pools || [],
        garages: previous.garages || [],
        dogs: previous.dogs || [],
        driveways: previous.driveways || [],
        decks: previous.decks || [],
        bushes: previous.bushes || [],
        porches: previous.porches || [],
        grasses: previous.grasses || [],
        endPosts: previous.endPosts || [],
        beds: previous.beds || [],
      });
    }
    setHistory(prev => prev.slice(0, -1));
    setSelectedItem(null);
  };

  const handleRedo = () => {
    if (redoHistory.length === 0) return;
    const next = redoHistory[redoHistory.length - 1];
    const canvas = getCanvasSnapshot();
    const currentSnapshot = {
      fenceLines: JSON.parse(JSON.stringify(fenceLines)),
      trees: JSON.parse(JSON.stringify(trees)),
      ...Object.fromEntries(Object.entries(canvas).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))])),
      annotations: JSON.parse(JSON.stringify(annotations || [])),
      surfaceMountedPosts: JSON.parse(JSON.stringify(surfaceMountedPosts || [])),
    };
    setHistory(prev => [...prev, currentSnapshot]);
    setFenceLines(next.fenceLines || []);
    setTrees(next.trees || []);
    setAnnotations(next.annotations || []);
    if (setSurfaceMountedPosts) setSurfaceMountedPosts(next.surfaceMountedPosts || []);
    if (window.setCanvasItems) {
      window.setCanvasItems({
        gates: next.gates || [],
        doubleGates: next.doubleGates || [],
        houses: next.houses || [],
        pools: next.pools || [],
        garages: next.garages || [],
        dogs: next.dogs || [],
        driveways: next.driveways || [],
        decks: next.decks || [],
        bushes: next.bushes || [],
        porches: next.porches || [],
        grasses: next.grasses || [],
        endPosts: next.endPosts || [],
        beds: next.beds || [],
      });
    }
    setRedoHistory(prev => prev.slice(0, -1));
    setSelectedItem(null);
  };

  return { history, redoHistory, saveToHistory, handleUndo, handleRedo };
}