import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user || user.role !== 'admin') {
    return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
  }

  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  // Fetch all scheduled touchpoints across all companies
  const scheduled = await base44.asServiceRole.entities.StewardshipTouchpoint.filter({ status: 'scheduled' });

  // Filter to those due today or past due
  const due = scheduled.filter(tp => tp.scheduledAt && new Date(tp.scheduledAt) <= todayEnd);

  const updated = [];
  for (const tp of due) {
    const result = await base44.asServiceRole.entities.StewardshipTouchpoint.update(tp.id, { status: 'ready' });
    updated.push(result);
  }

  return Response.json({
    success: true,
    processed: updated.length,
    message: `${updated.length} touchpoint(s) marked as ready`,
    readyIds: updated.map(t => t.id)
  });
});