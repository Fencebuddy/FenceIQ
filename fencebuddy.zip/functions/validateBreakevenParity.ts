import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

function monthKeyFromDate(isoDate) {
  const d = new Date(isoDate);
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    // Parse request body
    const body = await req.json();
    const { companyId, monthKey } = body;

    if (!companyId || !monthKey) {
      return Response.json({
        error: "INVALID_INPUT",
        message: "companyId and monthKey required"
      }, { status: 400 });
    }

    console.log(`[validateBreakevenParity] Validating ${companyId}/${monthKey}`);

    // Resolve crmCompanyId from CompanySettings using the MongoDB companyId
    let crmCompanyId = null;
    try {
      const companySettings = await base44.entities.CompanySettings.get(companyId);
      if (!companySettings) {
        return Response.json({
          success: false,
          error: "COMPANY_NOT_FOUND",
          message: `No CompanySettings found for companyId: ${companyId}`
        }, { status: 400 });
      }
      if (!companySettings.companyId) {
        return Response.json({
          success: false,
          error: "CRM_COMPANY_ID_MISSING",
          message: `CompanySettings found but companyId (CRM key) is blank for: ${companyId}`
        }, { status: 400 });
      }
      crmCompanyId = companySettings.companyId;
      console.log(`[validateBreakevenParity] Resolved crmCompanyId: ${crmCompanyId}`);
    } catch (e) {
      return Response.json({
        success: false,
        error: "COMPANY_RESOLVE_FAILED",
        message: e.message
      }, { status: 500 });
    }

    // Compute live results
    let liveJobsCount = 0;
    let liveRevenueCents = 0;
    let liveOverheadRecoveredCents = 0;

    try {
      // Parse monthKey to get date range
      const [yearStr, monthStr] = monthKey.split("-");
      const year = parseInt(yearStr);
      const month = parseInt(monthStr);
      const monthStart = new Date(Date.UTC(year, month - 1, 1));
      const monthEnd = new Date(Date.UTC(year, month, 1));

      // Fetch won jobs scoped to this company only (mirrors getBreakevenIntelligence)
      const allWonJobs = await base44.entities.CRMJob.filter({ status: "won", companyId: crmCompanyId });
      
      if (allWonJobs && allWonJobs.length > 0) {
        const mtdJobs = allWonJobs.filter(job => {
          if (!job.wonAt) return false;
          const wonDate = new Date(job.wonAt);
          return wonDate >= monthStart && wonDate < monthEnd;
        });

        liveJobsCount = mtdJobs.length;
        liveRevenueCents = mtdJobs.reduce((acc, job) => {
          const revenue = Number(job.contractValueCents || job.recognizedRevenueCents || 0);
          return acc + revenue;
        }, 0);

        const overheadRate = 0.14;
        liveOverheadRecoveredCents = Math.floor(liveRevenueCents * overheadRate);
      }

      console.log(`[validateBreakevenParity] Live: jobs=${liveJobsCount}, revenue=${liveRevenueCents}, recovered=${liveOverheadRecoveredCents}`);
    } catch (e) {
      console.error(`[validateBreakevenParity] Live scan failed: ${e.message}`);
      return Response.json({
        success: false,
        error: "LIVE_SCAN_FAILED",
        message: e.message
      }, { status: 500 });
    }

    // Read rollup
    let rollupJobsCount = 0;
    let rollupRevenueCents = 0;
    let rollupOverheadRecoveredCents = 0;

    try {
      const rollups = await base44.entities.BreakevenMonthlyRollup.filter({
        companyId,
        monthKey
      });

      if (rollups && rollups.length > 0) {
        const rollup = rollups[0];
        rollupJobsCount = Number(rollup.jobsCount || 0);
        rollupRevenueCents = Number(rollup.recognizedRevenueCents || 0);
        rollupOverheadRecoveredCents = Number(rollup.overheadRecoveredCents || 0);
      }

      console.log(`[validateBreakevenParity] Rollup: jobs=${rollupJobsCount}, revenue=${rollupRevenueCents}, recovered=${rollupOverheadRecoveredCents}`);
    } catch (e) {
      console.warn(`[validateBreakevenParity] Rollup read failed: ${e.message}`);
    }

    // Compute derived metrics
    const liveBreakevenTarget = liveRevenueCents / 0.36;
    const rollupBreakevenTarget = rollupRevenueCents / 0.36;

    // Fetch monthly overhead dynamically from OverheadSettings
    let liveMonthlyOverheadCents = 0;
    try {
      const ohArr = await base44.entities.OverheadSettings.filter({ companyId });
      if (ohArr && ohArr.length > 0) {
        liveMonthlyOverheadCents = Number(ohArr[0].monthlyOverheadCents || 0);
      }
      console.log(`[validateBreakevenParity] monthlyOverheadCents from OverheadSettings: ${liveMonthlyOverheadCents}`);
    } catch (e) {
      console.warn(`[validateBreakevenParity] OverheadSettings fetch failed: ${e.message}`);
    }
    const liveCoveragePercent = liveMonthlyOverheadCents > 0 ? Math.min(1, liveOverheadRecoveredCents / liveMonthlyOverheadCents) : 0;
    const rollupCoveragePercent = liveMonthlyOverheadCents > 0 ? Math.min(1, rollupOverheadRecoveredCents / liveMonthlyOverheadCents) : 0;

    // Build differences array
    const differences = [];
    if (liveJobsCount !== rollupJobsCount) {
      differences.push({
        field: "jobsCount",
        live: liveJobsCount,
        rollup: rollupJobsCount
      });
    }
    if (liveRevenueCents !== rollupRevenueCents) {
      differences.push({
        field: "recognizedRevenueCents",
        live: liveRevenueCents,
        rollup: rollupRevenueCents
      });
    }
    if (liveOverheadRecoveredCents !== rollupOverheadRecoveredCents) {
      differences.push({
        field: "overheadRecoveredCents",
        live: liveOverheadRecoveredCents,
        rollup: rollupOverheadRecoveredCents
      });
    }

    const parity = differences.length === 0 ? "MATCHED" : "MISMATCH";

    console.log(`[validateBreakevenParity] Result: ${parity}, differences=${differences.length}`);

    return Response.json({
      success: true,
      companyId,
      monthKey,
      parity,
      live: {
        jobsCount: liveJobsCount,
        recognizedRevenueCents: liveRevenueCents,
        overheadRecoveredCents: liveOverheadRecoveredCents,
        breakeven: liveBreakevenTarget,
        coveragePercent: Math.round(liveCoveragePercent * 10000) / 10000
      },
      rollup: {
        jobsCount: rollupJobsCount,
        recognizedRevenueCents: rollupRevenueCents,
        overheadRecoveredCents: rollupOverheadRecoveredCents,
        breakeven: rollupBreakevenTarget,
        coveragePercent: Math.round(rollupCoveragePercent * 10000) / 10000
      },
      differences,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error("[validateBreakevenParity] Unexpected error:", error);
    return Response.json({
      success: false,
      error: "INTERNAL_ERROR",
      message: error.message
    }, { status: 500 });
  }
});