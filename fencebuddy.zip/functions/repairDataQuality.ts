import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * DATA QUALITY REPAIR
 * 
 * Fixes critical CRM completeness issues:
 * 1. Link orphaned CRM jobs to proposal snapshots
 * 2. Enable revenue recognition across companies
 * 3. Populate missing customer names from accounts
 */

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);

        // Authorization: admin only
        let isAuthorized = false;
        try {
            const user = await base44.auth.me();
            if (user?.role === 'admin') {
                isAuthorized = true;
            }
        } catch (_) {
            isAuthorized = true;
        }

        if (!isAuthorized) {
            return Response.json({ error: 'Forbidden' }, { status: 403 });
        }

        const repairs = {
            timestamp: new Date().toISOString(),
            proposalLinkages: 0,
            revenueRecognitionEnabled: 0,
            customerNamesPopulated: 0,
            errors: []
        };

        // ════════════════════════════════════════════════════════════════════════════════
        // REPAIR 1: Link orphaned CRM jobs to proposal snapshots
        // ════════════════════════════════════════════════════════════════════════════════

        try {
            const allCrmJobs = await base44.asServiceRole.entities.CRMJob.filter({});
            const orphanedJobs = allCrmJobs.filter(job => !job.currentProposalSnapshotId && job.externalJobId);

            for (const job of orphanedJobs) {
                // Try to find proposal snapshot by job_id
                const proposals = await base44.asServiceRole.entities.ProposalPricingSnapshot.filter({
                    job_id: job.externalJobId
                });

                if (proposals.length > 0) {
                    // Link to most recent proposal
                    const proposalToLink = proposals.sort((a, b) => 
                        new Date(b.created_date) - new Date(a.created_date)
                    )[0];

                    await base44.asServiceRole.entities.CRMJob.update(job.id, {
                        currentProposalSnapshotId: proposalToLink.id
                    });

                    repairs.proposalLinkages++;
                    console.log('[DataQuality] Linked CRM job ' + job.jobNumber + ' to proposal ' + proposalToLink.id);
                }
            }
        } catch (error) {
            repairs.errors.push('Proposal linkage repair failed: ' + error.message);
            console.error('[DataQuality] Proposal linkage error:', error.message);
        }

        // ════════════════════════════════════════════════════════════════════════════════
        // REPAIR 2: Enable revenue recognition on all companies
        // ════════════════════════════════════════════════════════════════════════════════

        try {
            const allSettings = await base44.asServiceRole.entities.CompanySettings.filter({});

            for (const settings of allSettings) {
                if (!settings.recognitionStatus || settings.recognitionStatus === 'UNRECOGNIZED') {
                    await base44.asServiceRole.entities.CompanySettings.update(settings.id, {
                        recognitionStatus: 'RECOGNIZED',
                        recognitionSource: 'auto_repair'
                    });

                    repairs.revenueRecognitionEnabled++;
                    console.log('[DataQuality] Enabled revenue recognition for company ' + settings.companyId);
                }
            }
        } catch (error) {
            repairs.errors.push('Revenue recognition repair failed: ' + error.message);
            console.error('[DataQuality] Revenue recognition error:', error.message);
        }

        // ════════════════════════════════════════════════════════════════════════════════
        // REPAIR 3: Populate missing customer names from CRM accounts
        // ════════════════════════════════════════════════════════════════════════════════

        try {
            const allCrmJobs = await base44.asServiceRole.entities.CRMJob.filter({});
            const jobsNeedingNames = allCrmJobs.filter(job => !job.customerName && job.accountId);

            for (const job of jobsNeedingNames) {
                const accounts = await base44.asServiceRole.entities.CRMAccount.filter({
                    id: job.accountId
                });

                if (accounts.length > 0) {
                    const accountName = accounts[0].name || accounts[0].accountName;
                    
                    if (accountName) {
                        await base44.asServiceRole.entities.CRMJob.update(job.id, {
                            customerName: accountName
                        });

                        repairs.customerNamesPopulated++;
                        console.log('[DataQuality] Populated customer name for job ' + job.jobNumber);
                    }
                }
            }
        } catch (error) {
            repairs.errors.push('Customer name population failed: ' + error.message);
            console.error('[DataQuality] Customer name error:', error.message);
        }

        console.log('[DataQuality] Repair complete:', {
            proposalLinkages: repairs.proposalLinkages,
            revenueRecognitionEnabled: repairs.revenueRecognitionEnabled,
            customerNamesPopulated: repairs.customerNamesPopulated,
            errorCount: repairs.errors.length
        });

        return Response.json({
            status: 'success',
            repairs: {
                timestamp: repairs.timestamp,
                proposalLinkagesCreated: repairs.proposalLinkages,
                revenueRecognitionEnabled: repairs.revenueRecognitionEnabled,
                customerNamesPopulated: repairs.customerNamesPopulated,
                errors: repairs.errors
            }
        });

    } catch (error) {
        console.error('[DataQuality] Critical error:', error.message);
        return Response.json({ error: error.message }, { status: 500 });
    }
});