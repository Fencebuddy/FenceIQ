import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { upsertCrmJob } from './crm/upsertCrmJob.js';

/**
 * Sync Legacy Jobs to CRM
 * Creates CRMJob records for existing legacy jobs with sold/installed status
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // FIXED: Get company context (scoped)
    const ctxRes = await base44.asServiceRole.functions.invoke('getCompanyContext', {});
    if (!ctxRes?.data?.success || !ctxRes?.data?.companyId) {
      return Response.json({ error: 'Company context unavailable' }, { status: 400 });
    }
    const companyId = ctxRes.data.companyId;

    // FIXED: Get all legacy jobs SCOPED BY COMPANY
    const allJobs = await base44.asServiceRole.entities.Job.filter({ companyId });
    const soldStatuses = ['Proposal Signed', 'Sold', 'Installed', 'Closed'];
    const soldJobs = allJobs.filter(j => soldStatuses.includes(j.status));

    console.log(`Found ${soldJobs.length} sold legacy jobs for companyId ${companyId}`);

    // FIXED: Get existing CRM jobs SCOPED BY COMPANY
    const existingCRMJobs = await base44.asServiceRole.entities.CRMJob.filter({ companyId });
    const existingExternalIds = new Set(existingCRMJobs.map(c => c.externalJobId).filter(Boolean));

    const results = {
      created: 0,
      skipped: 0,
      errors: []
    };

    for (const job of soldJobs) {
      try {
        // Skip if already exists
        if (existingExternalIds.has(job.id)) {
          results.skipped++;
          continue;
        }

        // Create CRM job from legacy job via upsertCrmJob invariant
        // Pass name fields for deterministic resolution by invariant
        const crmJobPatch = {
          externalJobId: job.id,
          jobNumber: job.jobNumber,
          customerName: job.customerName,
          customerPhone: job.customerPhone,
          customerEmail: job.customerEmail || '',
          addressLine1: job.addressLine1,
          city: job.city,
          state: job.state,
          zip: job.zip,
          addressFull: job.address_full || `${job.addressLine1}, ${job.city}, ${job.state} ${job.zip}`,
          fenceCategory: job.materialType || 'Vinyl',
          stage: job.status === 'Installed' ? 'installed' : 'sold',
          saleStatus: 'sold',
          installStatus: job.status === 'Installed' ? 'installed' : null,
          paymentStatus: null,
          contractStatus: job.proposalAccepted ? 'signed' : null,
          appointmentStatus: 'completed',
          assignedRepUserId: job.created_by_id,
          assignedRepName: job.repName || user.full_name,
          source: 'legacy_sync',
          wonAt: job.signedAt || job.updated_date,
          saleStatusUpdatedAt: job.signedAt || job.updated_date,
          currentProposalSnapshotId: null,
          notes: job.jobNotes || '',
          // Pass component fields for upsertCrmJob name resolution
          firstName: job.firstName,
          lastName: job.lastName,
          email: job.customerEmail
        };

        const upsertRes = await upsertCrmJob({
          base44: base44.asServiceRole,
          tenantId: companyId,
          patch: crmJobPatch,
          mode: 'legacy_sync'
        });

        if (!upsertRes?.success) {
          throw new Error(`CRMJob upsert failed: ${upsertRes?.error?.message || 'unknown'}`);
        }

        results.created++;
        console.log(`✓ Created CRM job: ${job.jobNumber}`);
      } catch (err) {
        results.errors.push({ jobNumber: job.jobNumber, error: err.message });
        console.error(`✗ Failed to sync job ${job.jobNumber}:`, err.message);
      }
    }

    return Response.json({
      success: true,
      message: `Synced ${results.created} jobs to CRM`,
      results
    });
  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});