import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

function fmt$(cents) {
  if (!cents) return '$0';
  return '$' + (cents / 100).toLocaleString('en-US', { maximumFractionDigits: 0 });
}
function fmtPct(v) {
  if (v === null || v === undefined) return '—';
  return (v * 100).toFixed(1) + '%';
}

export default function DrillJobsDrawer({ group, onClose }) {
  if (!group) return null;
  const jobs = group.jobs || [];

  return (
    <Sheet open={!!group} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="mb-4">
          <SheetTitle>{group.label} — {jobs.length} Jobs</SheetTitle>
        </SheetHeader>
        <div className="space-y-2">
          {jobs.map(j => {
            const margin = j.contractValueCents > 0 ? (j.contractValueCents - (j.directCostCents || 0)) / j.contractValueCents : null;
            return (
              <div key={j.id} className="border border-slate-200 rounded-lg p-3 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium text-slate-800">{j.customerName || j.jobNumber}</span>
                  <span className={margin !== null && margin < 0.25 ? 'text-amber-600 font-semibold' : 'text-green-600'}>{fmtPct(margin)}</span>
                </div>
                <div className="flex gap-4 mt-1 text-xs text-slate-500">
                  <span>{j.jobNumber}</span>
                  <span>{j.fenceCategory || '—'}</span>
                  <span>{fmt$(j.contractValueCents)}</span>
                  {j.reworkFlag && <span className="text-orange-500 font-semibold">Rework</span>}
                  {(j.changeOrdersCount || 0) > 0 && <span className="text-amber-500">{j.changeOrdersCount} CO</span>}
                </div>
              </div>
            );
          })}
        </div>
      </SheetContent>
    </Sheet>
  );
}