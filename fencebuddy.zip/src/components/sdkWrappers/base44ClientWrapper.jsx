/**
 * PHASE 12.3.4: Canonical Base44 Client Wrapper
 *
 * Single chokepoint for all entity mutations.
 * Intercepts update/delete/patch/upsert/remove on immutable snapshot entities.
 * Enforces immutability constraint at the SDK layer (not advisory).
 *
 * Import this instead of raw "base44" in backend functions + services.
 * Example: import { base44 } from '@/components/sdkWrappers/base44ClientWrapper';
 */

import { base44 as base44Raw } from '@/api/base44Client';
import { assertSnapshotImmutability, isImmutableEntity } from '@/functions/phase12_3_1_immutabilityEnforcementWrapper';

/**
 * Wrap an entity instance to intercept mutations on immutable entities.
 */
function wrapEntity(entityName: string, rawEntity: any): any {
  if (!rawEntity) return rawEntity;

  const wrapped = { ...rawEntity };

  // Mutation methods to intercept
  const mutationMethods = ['update', 'patch', 'set', 'delete', 'remove', 'upsert'];

  for (const method of mutationMethods) {
    if (typeof rawEntity[method] === 'function') {
      const rawMethod = rawEntity[method].bind(rawEntity);

      // Wrap the mutation method
      wrapped[method] = async (...args: any[]) => {
        // Check immutability (will throw if enforced + not in restore mode)
        if (isImmutableEntity(entityName)) {
          const entityId = args[0]; // Most mutations have id as first arg
          const payload = args[1] || args[0]; // update(id, patch), delete(id)

          assertSnapshotImmutability('update', entityName, {
            // Note: could enhance to read MaintenanceMode here if needed
          });
        }

        // Call original method
        return rawMethod(...args);
      };
    }
  }

  // Wrap bulk/batch mutations if they exist
  if (typeof rawEntity.bulkUpdate === 'function') {
    const rawBulk = rawEntity.bulkUpdate.bind(rawEntity);
    wrapped.bulkUpdate = async (updates: Array<any>, ...rest: any[]) => {
      // Check each update
      if (isImmutableEntity(entityName)) {
        for (const update of updates) {
          assertSnapshotImmutability('update', entityName, {});
        }
      }
      return rawBulk(updates, ...rest);
    };
  }

  return wrapped;
}

/**
 * Wrap the entities accessor to intercept entity() calls.
 */
const entitiesProxy = new Proxy(base44Raw.entities, {
  get(target: any, entityName: string | symbol) {
    const rawEntity = target[entityName as string];
    if (!rawEntity) return rawEntity;

    // Return wrapped entity for immutable ones
    if (isImmutableEntity(entityName as string)) {
      return wrapEntity(entityName as string, rawEntity);
    }
    return rawEntity;
  },
});

/**
 * Wrap asServiceRole to ensure service-role writes also go through immutability checks.
 */
function createWrappedServiceRole(): any {
  const rawServiceRole = base44Raw.asServiceRole;

  return {
    ...rawServiceRole,
    entities: new Proxy(rawServiceRole.entities, {
      get(target: any, entityName: string | symbol) {
        const rawEntity = target[entityName as string];
        if (!rawEntity) return rawEntity;

        // Wrap immutable entities at service role level too
        if (isImmutableEntity(entityName as string)) {
          return wrapEntity(entityName as string, rawEntity);
        }
        return rawEntity;
      },
    }),
  };
}

/**
 * Canonical wrapped base44 client.
 * Use this instead of raw "base44" in all backend functions and services.
 */
const base44 = {
  ...base44Raw,
  entities: entitiesProxy,
  asServiceRole: createWrappedServiceRole(),
  auth: base44Raw.auth,
  functions: base44Raw.functions,
  analytics: base44Raw.analytics,
  integrations: base44Raw.integrations,
  users: base44Raw.users,
  agents: base44Raw.agents,
};

export { base44 };
export default base44;