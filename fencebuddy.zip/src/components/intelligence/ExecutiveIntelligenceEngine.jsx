/**
 * EXECUTIVE INTELLIGENCE ENGINE
 * Computes the executive state object consumed by OwnerDashboard.
 * Sources: ownerDashboardService (truth rows) + dashboardGoalEngine
 */

import {
    getSignedDealsTruthSet,
    computeWonKpis,
    getProposalCloseSet,
    computeCloseRate
} from '../services/ownerDashboardService';
import { computePricingDisciplineKpis } from '../services/kpi/compute/computePricingDisciplineKpis';
import { base44 } from '@/api/base44Client';

/**
 * Build date range - handle both string ranges and explicit dates
 */
function buildDateRange(range, dateStart, dateEnd) {
     // If explicit dates provided, use them
     if (dateStart && dateEnd) {
         return { dateStart, dateEnd };
     }

     // Fall back to range string logic
     const now = new Date();
     let start;

     if (range === 'MTD') {
         start = new Date(now.getFullYear(), now.getMonth(), 1);
     } else if (range === 'L7') {
         start = new Date(now);
         start.setDate(now.getDate() - 7);
     } else {
         // L30 default
         start = new Date(now);
         start.setDate(now.getDate() - 30);
     }

     return { dateStart: start.toISOString(), dateEnd: now.toISOString() };
}

/**
 * Load company goals from CompanySettings
 */
async function loadGoals(companyId) {
    // CompanySettings has goalNetMarginPercent, goalAvgTicket, goalCloseRatePercent
    // DashboardGoalSettings has the actual dailyRevenueGoal
    const [settingsArr, goalSettingsArr] = await Promise.all([
        base44.entities.CompanySettings.filter({ companyId }),
        base44.entities.DashboardGoalSettings.filter({ companyId })
    ]);
    const s = settingsArr[0] || {};
    const g = goalSettingsArr[0] || {};
    return {
        goalRevenue: g.dailyRevenueGoal || s.goalRevenue || 0,
        goalNetMarginPercent: s.goalNetMarginPercent ?? s.targetNetMarginPct ?? 25,
        goalNetProfitPercent: s.targetNetMarginPct || s.goalNetMarginPercent || 25
    };
}

/**
 * Determine company state label from KPIs vs goals
 */
function resolveCompanyState({ netMarginPct, jobsSold, goalNetMarginPercent }) {
    if (jobsSold === 0) return 'INSUFFICIENT_DATA';
    if (netMarginPct >= goalNetMarginPercent + 10) return 'DOMINANT';
    if (netMarginPct >= goalNetMarginPercent + 5) return 'STRONG';
    if (netMarginPct >= goalNetMarginPercent - 5) return 'STABLE';
    if (netMarginPct >= goalNetMarginPercent - 15) return 'CAUTION';
    return 'AT_RISK';
}

/**
 * Determine trajectory from margin
 */
function resolveTrajectory(netMarginPct, goalNetMarginPercent) {
    if (netMarginPct >= goalNetMarginPercent + 5) return 'ASCENDING';
    if (netMarginPct >= goalNetMarginPercent - 5) return 'LEVEL';
    return 'DECLINING';
}

/**
 * Build flight brief bullets
 */
function buildFlightBrief({ jobsSold, wonRevenue, netMarginPct, closeRatePercent, pricingDiscipline }) {
    const bullets = [];

    if (jobsSold === 0) {
        bullets.push('No sold jobs in this period — connect CRM data to activate intelligence.');
        return bullets;
    }

    bullets.push(`${jobsSold} jobs closed totaling $${wonRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })} in revenue.`);

    if (netMarginPct > 0) {
        bullets.push(`Net margin running at ${netMarginPct.toFixed(1)}%.`);
    } else {
        bullets.push('Net margin data incomplete — verify direct cost on proposals.');
    }

    if (closeRatePercent > 0) {
        bullets.push(`Close rate: ${closeRatePercent.toFixed(0)}% of demos run.`);
    }

    if (pricingDiscipline?.below_floor_count > 0) {
        bullets.push(`⚠️ ${pricingDiscipline.below_floor_count} job(s) sold below pricing floor — margin leakage detected.`);
    } else if (pricingDiscipline?.total_jobs > 0) {
        bullets.push('No jobs sold below floor — pricing discipline holding.');
    }

    return bullets;
}

/**
 * Build intel section
 */
function buildIntel({ netMarginPct, goalNetMarginPercent, pricingDiscipline, jobsSold, closeRatePercent }) {
    if (jobsSold === 0) return null;

    const marginGap = netMarginPct - goalNetMarginPercent;
    const riskLevel = pricingDiscipline?.below_floor_count > 0 ? 'HIGH' :
        netMarginPct < goalNetMarginPercent - 10 ? 'HIGH' :
        netMarginPct < goalNetMarginPercent ? 'MED' : 'LOW';

    const why_summary = marginGap >= 5
        ? `Margin is ${marginGap.toFixed(1)}pts above goal — strong execution.`
        : marginGap >= 0
        ? `Margin is on target at ${netMarginPct.toFixed(1)}%.`
        : `Margin is ${Math.abs(marginGap).toFixed(1)}pts below goal — investigate job costs.`;

    const risk_reason = pricingDiscipline?.below_floor_count > 0
        ? `${pricingDiscipline.below_floor_count} job(s) below pricing floor.`
        : riskLevel === 'HIGH'
        ? 'Net margin significantly below goal.'
        : riskLevel === 'MED'
        ? 'Net margin slightly below goal — monitor trend.'
        : 'No active risk detected.';

    let next_best_action = null;
    if (pricingDiscipline?.below_floor_count > 0) {
        next_best_action = {
            title: 'Review below-floor jobs',
            why: 'Margin leakage detected — identify and coach reps involved.'
        };
    } else if (netMarginPct < goalNetMarginPercent) {
        next_best_action = {
            title: 'Audit direct costs',
            why: 'Margin below goal — verify direct_cost populated on all proposals.'
        };
    }

    return { why_summary, risk_level: riskLevel, risk_reason, next_best_action };
}

/**
 * Build alerts array
 */
function buildAlerts({ pricingDiscipline, netMarginPct, goalNetMarginPercent }) {
    const alerts = [];

    if (pricingDiscipline?.below_floor_count > 0) {
        alerts.push({
            id: 'below_floor',
            title: 'Margin Leakage Detected',
            severity: 'RISK',
            message: `${pricingDiscipline.below_floor_count} job(s) sold below pricing floor this period.`,
            recommended_action: 'Review below-floor jobs with assigned reps immediately.'
        });
    }

    if (netMarginPct > 0 && netMarginPct < goalNetMarginPercent - 10) {
        alerts.push({
            id: 'low_margin',
            title: 'Net Margin Well Below Goal',
            severity: 'RISK',
            message: `Current net margin ${netMarginPct.toFixed(1)}% is significantly below ${goalNetMarginPercent}% goal.`,
            recommended_action: 'Investigate job costs and pricing on recent closed deals.'
        });
    }

    return alerts;
}

/**
 * Main entry point: compute and return executive state
 */
export async function getExecutiveState({ companyId, range = 'MTD', dateStart, dateEnd }) {
     const dates = buildDateRange(range, dateStart, dateEnd);

     try {
         // Load goals and truth rows in parallel (eliminates sequential fetch)
         const [goals, truthRows, proposalRows] = await Promise.all([
             loadGoals(companyId).catch(err => {
                 console.error('[ExecutiveIntelligenceEngine] loadGoals failed:', err);
                 throw err;
             }),
             getSignedDealsTruthSet({ companyId, dateStart: dates.dateStart, dateEnd: dates.dateEnd }).catch(err => {
                 console.error('[ExecutiveIntelligenceEngine] getSignedDealsTruthSet failed:', err);
                 throw err;
             }),
             getProposalCloseSet({ companyId, dateStart: dates.dateStart, dateEnd: dates.dateEnd }).catch(err => {
                 console.error('[ExecutiveIntelligenceEngine] getProposalCloseSet failed:', err);
                 throw err;
             })
         ]);

         // Compute KPIs
         const wonKpis = computeWonKpis(truthRows);
         const closeKpis = computeCloseRate(proposalRows);
         const pricingDiscipline = computePricingDisciplineKpis(truthRows);

         const {
             signedCount: jobsSold,
             wonRevenue,
             avgTicket,
             netMarginPercentWeighted: netMarginPct,
             estimatedCount,
             estimatedRevenueSubtotal,
             estimateReasonCounts,
             knownCostCount,
             defaultOverheadRateCount,
             defaultCommissionRateCount
         } = wonKpis;

         const { closeRatePercent } = closeKpis;

         const netProfit = wonRevenue > 0 ? wonRevenue * (netMarginPct / 100) : 0;

         // Projection (simple: pace current period to end of month)
         const now = new Date();
         const dayOfMonth = now.getDate();
         const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
         const paceFactor = range === 'MTD' && dayOfMonth > 0 ? daysInMonth / dayOfMonth : 1;
         const projectedRevenue = wonRevenue * paceFactor;
         const projectedNetProfit = netProfit * paceFactor;

         const companyState = resolveCompanyState({
             netMarginPct,
             jobsSold,
             goalNetMarginPercent: goals.goalNetMarginPercent
         });

         const trajectory = resolveTrajectory(netMarginPct, goals.goalNetMarginPercent);

         const confidence_label = jobsSold === 0 ? 'Low' : jobsSold < 3 ? 'Medium' : 'High';
         const forecast_confidence = jobsSold === 0 ? 0 : Math.min(100, 40 + jobsSold * 5);

         const glide_path_status = projectedRevenue >= (goals.goalRevenue || 0)
             ? 'CLIMBING'
             : projectedRevenue >= (goals.goalRevenue || 0) * 0.9
             ? 'ON_TRACK'
             : 'LAGGING';

         const flight_brief = buildFlightBrief({ jobsSold, wonRevenue, netMarginPct, closeRatePercent, pricingDiscipline });
         const intel = buildIntel({ netMarginPct, goalNetMarginPercent: goals.goalNetMarginPercent, pricingDiscipline, jobsSold, closeRatePercent });
         const alerts = buildAlerts({ pricingDiscipline, netMarginPct, goalNetMarginPercent: goals.goalNetMarginPercent });

         return {
             company_state: companyState,
             trajectory,
             confidence_label,
             forecast_confidence,
             glide_path_status,

             // Financial
             net_profit: netProfit,
             net_margin: netMarginPct / 100,
             projected_net_profit: projectedNetProfit,
             projected_revenue: projectedRevenue,
             profit_per_day: dayOfMonth > 0 ? netProfit / dayOfMonth : 0,

             // Goals
             goal_net_profit: goals.goalRevenue ? goals.goalRevenue * (goals.goalNetMarginPercent / 100) : null,
             goal_revenue: goals.goalRevenue || null,

             // Revenue engine
             jobs_sold: jobsSold,
             close_rate: closeRatePercent / 100,

             // Pricing
             pricingDiscipline,

             // Narrative
             flight_brief,
             intel,
             alerts,

             // Estimation transparency (PHASE 10.3A)
             estimatedCount: estimatedCount || 0,
             estimatedRevenueSubtotal: estimatedRevenueSubtotal || 0,
             estimateReasonCounts: estimateReasonCounts || {},
             knownCostCount: knownCostCount || 0,
             // Rate source disclosure (PHASE 10.3B)
             defaultOverheadRateCount: defaultOverheadRateCount || 0,
             defaultCommissionRateCount: defaultCommissionRateCount || 0,

             // Meta
                 range,
                 dateStart: dates.dateStart,
                 dateEnd: dates.dateEnd
         };
     } catch (error) {
         console.error('[ExecutiveIntelligenceEngine] Fatal error loading state:', error);
         throw new Error(`Unable to load intelligence: ${error.message}`);
     }
 }