import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

/**
 * Phase 11.2 — Data Confidence Panel
 * Display-only summary of estimation/default rate usage.
 * Sourced from ExecutiveIntelligenceEngine computations.
 */
export default function DataConfidencePanel({ executiveState }) {
  if (!executiveState) return null;

  const {
    jobs_sold = 0,
    knownCostCount = 0,
    estimatedCount = 0,
    estimatedRevenueSubtotal = 0,
    defaultOverheadRateCount = 0,
    defaultCommissionRateCount = 0
  } = executiveState;

  // Calculate confidence score
  const totalIncluded = knownCostCount || jobs_sold;
  const percentEstimated = totalIncluded > 0 ? (estimatedCount / (estimatedCount + totalIncluded)) * 100 : 0;
  const percentDefaultRates =
    totalIncluded > 0 ? ((defaultOverheadRateCount + defaultCommissionRateCount) / (totalIncluded * 2)) * 100 : 0;

  const confidenceScore = Math.max(0, 100 - (percentEstimated * 0.5 + percentDefaultRates * 0.3));
  const confidenceLabel =
    confidenceScore >= 85 ? 'HIGH' : confidenceScore >= 70 ? 'MEDIUM' : 'LOW';
  const confidenceColor =
    confidenceLabel === 'HIGH'
      ? 'bg-[#52AE22] text-white'
      : confidenceLabel === 'MEDIUM'
      ? 'bg-amber-500 text-white'
      : 'bg-red-500 text-white';

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm uppercase tracking-wider text-white font-semibold flex items-center gap-2">
            <Info className="w-4 h-4" />
            DATA CONFIDENCE
          </CardTitle>
          <Badge className={`${confidenceColor} text-xs font-bold`}>
            {confidenceLabel} ({confidenceScore.toFixed(0)}%)
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div>
            <div className="text-xs text-white/70 mb-1">Jobs Analyzed</div>
            <div className="text-lg font-bold text-white">{jobs_sold}</div>
          </div>
          <div>
            <div className="text-xs text-white/70 mb-1">With Cost Data</div>
            <div className="text-lg font-bold text-white">{knownCostCount || 0}</div>
          </div>
          <div>
            <div className="text-xs text-white/70 mb-1">Estimated</div>
            <div className="text-lg font-bold text-amber-400 flex items-center gap-1">
              {estimatedCount}
              {estimatedCount > 0 && (
                <Popover>
                  <PopoverTrigger asChild>
                    <button className="hover:opacity-70">
                      <AlertTriangle className="w-3 h-3" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 text-xs bg-slate-900 border-slate-700 text-white">
                    These jobs lack direct cost data and are <strong>excluded from all profit calculations</strong>.
                    {estimatedRevenueSubtotal > 0 && (
                      <div className="mt-2">
                        Estimated revenue: ${estimatedRevenueSubtotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </div>
                    )}
                  </PopoverContent>
                </Popover>
              )}
            </div>
          </div>
        </div>

        {/* Default Rates Usage */}
        {(defaultOverheadRateCount > 0 || defaultCommissionRateCount > 0) && (
          <div className="bg-slate-700/50 border border-slate-600/50 rounded-lg p-3">
            <div className="text-xs text-white/80 mb-2 font-semibold">Default Rates Used</div>
            <div className="text-xs text-white/70 space-y-1">
              {defaultOverheadRateCount > 0 && (
                <div>
                  • Overhead: <span className="text-slate-300">{defaultOverheadRateCount} job{defaultOverheadRateCount !== 1 ? 's' : ''}</span>
                </div>
              )}
              {defaultCommissionRateCount > 0 && (
                <div>
                  • Commission: <span className="text-slate-300">{defaultCommissionRateCount} job{defaultCommissionRateCount !== 1 ? 's' : ''}</span>
                </div>
              )}
              <div className="text-xs text-white/50 mt-2 italic">
                These jobs use company default rates instead of snapshot-specific rates.
              </div>
            </div>
          </div>
        )}

        {/* Confidence Breakdown */}
        <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-700">
          <div className="text-xs text-white/80 mb-2 font-semibold">What This Means</div>
          <div className="text-xs text-white/70 space-y-1">
            {confidenceScore >= 85 && (
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-3 h-3 text-[#52AE22] mt-0.5 flex-shrink-0" />
                <span>High-quality data. KPIs are reliable for decision-making.</span>
              </div>
            )}
            {confidenceScore >= 70 && confidenceScore < 85 && (
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-3 h-3 text-amber-400 mt-0.5 flex-shrink-0" />
                <span>Some jobs missing cost data or using defaults. KPIs are directionally accurate.</span>
              </div>
            )}
            {confidenceScore < 70 && (
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                <span>Significant estimation. Complete cost data before relying on trends.</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}