import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import jsPDF from 'jspdf';
import { generateCrewLoadSheetSafe } from '@/components/office/executeSendHelper';
import { generateSupplierPDF, generateSupplierCSV } from '@/components/office/SupplierExportGenerator';
import { normalizeMapState, validateTakeoffEligibility } from '@/components/materials/normalizeMapState';
import { normalizeRunsForSlope, applyNormalizationFixes } from '@/components/office/sendNormalization';
import { validateJob } from '@/components/validation/jobValidator';

export function useSendToOffice({
  job,
  jobId,
  fenceLines,
  trees,
  rotation,
  runs,
  gates,
  materials,
  calculatedMaterials,
  takeoff,
  validation,
  queryClient,
  setValidation,
  setShowBlockedModal,
  setMapSaveStatus,
}) {
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [sendError, setSendError] = useState(null);

  const sendToOffice = async () => {
    setSendError(null);

    // Duplicate send guard
    if (job.sentAt) {
      const minutesSinceSend = (new Date() - new Date(job.sentAt)) / 1000 / 60;
      if (minutesSinceSend < 2) {
        alert(`Already sent ${Math.floor(minutesSinceSend)} minute(s) ago.`);
        return;
      }
    }

    // Normalize map state
    const normalizationResult = normalizeMapState(
      { fenceLines, trees, annotations: [] },
      runs,
      gates
    );

    if (normalizationResult.errors.length > 0) {
      setSendError(`Data integrity errors: ${normalizationResult.errors.map(e => e.type).join(', ')}`);
      return;
    }

    // Atomic save with stable line IDs
    try {
      const linesWithAssignments = fenceLines.map(line => ({
        ...line,
        lineId: line.lineId || crypto.randomUUID(),
        assignedRunId: line.assignedRunId || null
      }));

      await base44.entities.Job.update(jobId, {
        mapData: {
          fenceLines: linesWithAssignments,
          trees,
          rotation,
          gates: window.gates || [],
          doubleGates: window.doubleGates || [],
          houses: window.houses || [],
          pools: window.pools || [],
          garages: window.garages || [],
          dogs: window.dogs || [],
          driveways: window.driveways || [],
          decks: window.decks || [],
          bushes: window.bushes || [],
          porches: window.porches || [],
          grasses: window.grasses || [],
          endPosts: window.endPosts || [],
          beds: window.beds || []
        }
      });
    } catch {
      setSendError('Could not save job. Please try again.');
      return;
    }

    // Pre-send slope normalization
    try {
      const currentRuns = await base44.entities.Run.filter({ jobId });
      const slopeNorm = normalizeRunsForSlope(currentRuns);
      if (slopeNorm.hasChanges) {
        await applyNormalizationFixes(base44, jobId, slopeNorm.normalizedRuns, slopeNorm.changes);
        await queryClient.invalidateQueries(['runs', jobId]);
      }
      if (slopeNorm.hasBlockers) {
        setValidation({ validationStatus: 'BLOCKED', issues: slopeNorm.issues, canSend: false });
        setShowBlockedModal(true);
        return;
      }
    } catch {
      setSendError('Slope normalization failed. Please review runs manually.');
      return;
    }

    const takeoffSource = fenceLines?.length > 0 ? 'MAP_DRIVEN' : 'MANUAL_ENTRY';
    await base44.entities.Job.update(jobId, { takeoffSource });

    await executeSend({ validationResult: { validationStatus: 'PASS', issues: [], canSend: true }, takeoffSource });
  };

  const executeSend = async ({ validationResult, takeoffSource }) => {
    setIsSending(true);
    let mapImageData = null;

    const freshMaterials = await base44.entities.MaterialLine.filter({ jobId });

    const calculatedItems = (calculatedMaterials || [])
      .filter(m => m.runLabel !== '__AUDIT__')
      .map(m => ({
        lineItemName: m.materialDescription || m.lineItemName,
        totalQty: m.quantityCalculated || m.quantity || 0,
        quantity: m.quantityCalculated || m.quantity || 0,
        unit: m.uom || m.unit,
        calculationDetails: m.notes || m.calculationDetails || '',
        source: m.source || 'calculated'
      }));

    const manualItems = freshMaterials
      .filter(m => m.source === 'manual')
      .map(m => ({
        lineItemName: m.lineItemName,
        totalQty: m.manualOverrideQty || m.calculatedQty || 0,
        quantity: m.manualOverrideQty || m.calculatedQty || 0,
        unit: m.unit,
        calculationDetails: m.calculationDetails || '',
        source: 'manual'
      }));

    const allMaterialsForExport = [...calculatedItems, ...manualItems];

    const crewLoadPdf = await generateCrewLoadSheetSafe(job, runs, gates, allMaterialsForExport, fenceLines, mapImageData);
    const crewLoadBlob = crewLoadPdf.output('blob');
    const crewLoadFile = new File([crewLoadBlob], `${job.jobNumber}_CrewLoadSheet.pdf`, { type: 'application/pdf' });
    const { file_url: crewLoadUrl } = await base44.integrations.Core.UploadFile({ file: crewLoadFile });

    const supplierPdf = generateSupplierPDF(job, allMaterialsForExport, runs, gates, fenceLines);
    const supplierBlob = supplierPdf.output('blob');
    const supplierFile = new File([supplierBlob], `${job.jobNumber}_SupplierExport.pdf`, { type: 'application/pdf' });
    const { file_url: supplierUrl } = await base44.integrations.Core.UploadFile({ file: supplierFile });

    const supplierCsv = generateSupplierCSV(allMaterialsForExport);
    const csvBlob = new Blob([supplierCsv], { type: 'text/csv' });
    const csvFile = new File([csvBlob], `${job.jobNumber}_SupplierExport.csv`, { type: 'text/csv' });
    const { file_url: csvUrl } = await base44.integrations.Core.UploadFile({ file: csvFile });

    let user;
    try {
      user = await base44.auth.me();
    } catch {
      setIsSending(false);
      return;
    }

    // Build organized materials for PDF
    const pdfCalculatedItems = (calculatedMaterials || []).filter(item => {
      const runLabel = item.runLabel || '';
      if (runLabel === '__AUDIT__') return false;
      const itemName = item.materialDescription || item.lineItemName || '';
      if (itemName.includes('Fence') && (item.uom === 'LF' || item.unit === 'LF')) return false;
      return item.source !== 'manual';
    });

    const pdfManualItems = (materials || []).filter(m => m.source === 'manual');

    const aggregated = pdfCalculatedItems.reduce((acc, item) => {
      const itemName = item.materialDescription || item.lineItemName || '';
      const qty = item.quantityCalculated || item.quantity || 0;
      const isCornerPost = itemName.toLowerCase().includes('corner');
      const isEndPost = itemName.toLowerCase().includes('end') && !itemName.toLowerCase().includes('corner');
      const isLinePost = itemName.toLowerCase().includes('line post');
      let key = itemName;
      if (isCornerPost) key = itemName + '__CORNER__';
      else if (isEndPost) key = itemName + '__END__';
      else if (isLinePost) key = itemName + '__LINE__';
      const existing = acc.find(m => m.key === key);
      if (existing) { existing.totalQty += qty; }
      else { acc.push({ key, lineItemName: itemName, totalQty: qty, unit: item.uom || item.unit || 'pcs', calculationDetails: item.notes || item.calculationDetails || '' }); }
      return acc;
    }, []);

    const organizedMaterials = [...aggregated];
    if (pdfManualItems.length > 0) {
      organizedMaterials.push({ lineItemName: '__SECTION__Additional Materials', totalQty: 0, unit: '', calculationDetails: '' });
      pdfManualItems.forEach(m => {
        organizedMaterials.push({ lineItemName: m.lineItemName, totalQty: m.manualOverrideQty || m.calculatedQty || m.quantity || 0, unit: m.unit, calculationDetails: m.calculationDetails || '' });
      });
    }

    const { generateSendToOfficePdf } = await import('@/components/office/SendToOfficePdfGenerator');
    const pdf = new jsPDF();
    await generateSendToOfficePdf(pdf, job, runs, gates, allMaterialsForExport, fenceLines, mapImageData, validation, takeoffSource, organizedMaterials, takeoff, user);

    const pdfBlob = pdf.output('blob');
    const pdfFile = new File([pdfBlob], `${job.jobNumber}_Materials.pdf`, { type: 'application/pdf' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file: pdfFile });

    const newVersion = (job.versionNumber || 0) + 1;

    const emailBody = `Materials list for ${job.jobNumber} - ${job.customerName}

    Version ${newVersion} | ${takeoffSource === 'MAP_DRIVEN' ? 'Map-Driven' : 'Manual Entry'} Takeoff

    Download Materials PDF: ${file_url}
    Download Crew Load Sheet: ${crewLoadUrl}
    Download Supplier Export (PDF): ${supplierUrl}
    Download Supplier Export (CSV): ${csvUrl}

    Job Details:
    - Total Linear Feet: ${job.totalLF}
    - Material: ${job.materialType}
    - Height: ${job.fenceHeight}
    - Style: ${job.style}

    PLEASE FORWARD TO: materials@pfcwestmi.com`;

    await base44.integrations.Core.SendEmail({
      to: job.officeEmail || user.email,
      subject: `Materials List – ${job.jobNumber} – ${job.customerName} (v${newVersion})`,
      body: emailBody
    });

    const now = new Date().toISOString();
    await base44.entities.Job.update(jobId, {
      status: 'Sent to Office',
      sentAt: now,
      sentBy: user.email,
      takeoffSource: takeoffSource || job.takeoffSource,
      validationSnapshot: validationResult,
      lastDeliveryStatus: 'SUCCESS',
      isLocked: true,
      lockedAt: now,
      versionNumber: newVersion,
      crewLoadSheetUrl: crewLoadUrl,
      supplierExportUrl: supplierUrl
    });

    queryClient.invalidateQueries(['job', jobId]);
    setIsSending(false);
    setSendSuccess(true);
    setTimeout(() => setSendSuccess(false), 3000);
  };

  const handleConfirmSend = async () => {
    const takeoffSource = fenceLines?.length > 0 ? 'MAP_DRIVEN' : 'MANUAL_ENTRY';
    await executeSend({ validationResult: validation, takeoffSource });
  };

  return { sendToOffice, handleConfirmSend, isSending, sendSuccess, sendError, setSendError };
}