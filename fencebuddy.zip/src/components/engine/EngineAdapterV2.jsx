/**
 * FENCEBUDDY V2 ENGINE ADAPTER
 * Single entry point for all engine operations.
 * GENESIS resolver only — no legacy fallbacks.
 */

import { ENGINE_VERSIONS } from './versions';
import { generateGeometryChecksum, generateTakeoffHash } from './checksums';
import { logDiagnostic } from './diagnosticsService';
import { validatePricingGates } from './contracts/validatePricingGates';
import { validateGridContract, GRID_CONTRACT } from './contracts/validateGridContract';
import { base44 } from '@/api/base44Client';

import { buildTakeoff as buildTakeoffV1 } from '../materials/canonicalTakeoffEngine';
import { computePricing as computePricingV1 } from '../pricing/computePricing';
import { resolveLineItemsWithMappings as resolveV1 } from '../materials/universalResolver';
import { computePricingV1Locked } from './pricing/PricingEngineV1Locked';
import { canonicalizeLineItems } from '../services/v2clean/uckCanonicalizer';

/**
 * Get complete variant state
 */
export async function getVariantState({ jobId, variantKey = 'CURRENT', job, fenceLines, gates, runs }) {
  const mapScaleConfig = await getOrCreateMapScaleConfig(job);
  
  const gridValidation = validateGridContract(mapScaleConfig);
  if (!gridValidation.valid) {
    return {
      status: 'BLOCKED',
      blockedReasons: gridValidation.violations,
      geometry_result: null,
      takeoff: null,
      pricing_status: 'BLOCKED'
    };
  }
  
  const geometryResult = await computeGeometry({ jobId, variantKey, fenceLines, gates, mapScaleConfig });
  
  let takeoffResult = null;
  if (geometryResult.status === 'VALID') {
    takeoffResult = await buildTakeoff({ jobId, variantKey, geometryResult, runs, job });
  }
  
  let pricingStatus = 'NEEDS_RECALC';
  if (job?.active_pricing_snapshot_id) {
    pricingStatus = 'SAVED';
  } else if (takeoffResult?.status === 'COMPLETE') {
    pricingStatus = 'READY';
  }
  
  return {
    status: 'OK',
    variantKey,
    geometry_result: geometryResult,
    geometry_checksum: geometryResult.geometry_checksum,
    takeoff: takeoffResult,
    takeoff_hash: takeoffResult?.takeoff_hash,
    pricing_status: pricingStatus,
    snapshot_ids: {
      takeoff: job?.active_takeoff_snapshot_id,
      pricing: job?.active_pricing_snapshot_id
    },
    blockedReasons: [],
    versions: {
      geometry: ENGINE_VERSIONS.GEOMETRY_VERSION,
      takeoff: ENGINE_VERSIONS.TAKEOFF_VERSION,
      pricing: ENGINE_VERSIONS.PRICING_VERSION
    }
  };
}

/**
 * Compute geometry with checksums
 */
export async function computeGeometry({ jobId, variantKey, fenceLines, gates, mapScaleConfig }) {
  const processedLines = (fenceLines || []).map(line => ({
    ...line,
    effective_length_ft: (line.manualLengthFt && line.manualLengthFt > 0)
      ? line.manualLengthFt
      : line.length || 0
  }));
  
  const total_lf = processedLines
    .filter(line => line.assignedRunId && !line.isExisting)
    .reduce((sum, line) => sum + line.effective_length_ft, 0);
  
  const geometry_checksum = generateGeometryChecksum({
    fenceLines: processedLines,
    gates: gates || [],
    mapScaleConfig
  });
  
  return {
    status: 'VALID',
    fence_lines: processedLines,
    gates: gates || [],
    total_lf,
    geometry_checksum,
    geometry_version: ENGINE_VERSIONS.GEOMETRY_VERSION,
    map_scale_version: mapScaleConfig.config_version
  };
}

/**
 * Build takeoff from geometry
 */
export async function buildTakeoff({ jobId, variantKey, geometryResult, runs, job, jobPosts = [] }) {
  const fenceLines = geometryResult.fence_lines || [];
  const gates = geometryResult.gates || [];
  
  const takeoff = buildTakeoffV1(job, fenceLines, runs, gates, jobPosts);
  
  const variantConfig = {
    materialType: job.materialType,
    heightFt: parseFloat(job.fenceHeight) || 6,
    color: job.fenceColor,
    coating: job.chainLinkCoating
  };
  
  const takeoff_hash = generateTakeoffHash({
    lineItems: takeoff.lineItems || [],
    variantConfig
  });
  
  return {
    status: 'COMPLETE',
    line_items: takeoff.lineItems || [],
    takeoff_hash,
    takeoff_version: ENGINE_VERSIONS.TAKEOFF_VERSION,
    total_lf: geometryResult.total_lf,
    post_counts: takeoff.postCounts
  };
}

/**
 * Resolve takeoff to catalog — GENESIS only
 */
export async function resolveTakeoff({ jobId, variantKey, takeoffResult, companyId, catalog, job, companySkuMap, companySettings = null, companyUckAliases = null }) {
  const lineItems = takeoffResult.line_items || [];
  
  const canonicalizedItems = canonicalizeLineItems(
    lineItems,
    companyId,
    companyUckAliases || [],
    companySettings || {}
  );
  
  const normalized = canonicalizedItems.map(item => ({
    ...item,
    uck: item.canonical_key || item.uck || item.canonicalUck,
    qty: item.quantityCalculated || 0
  }));
  
  const result = await resolveV1({
    companyId,
    lineItems: normalized,
    catalog,
    companySkuMap
  });

  const debugEnrichedItems = result.lineItems.map((item, idx) => {
    const displayName = item.displayName || item.lineItemName || item.uck || 'Unknown';
    const mappingKey = item.mappingKey || 'N/A';
    const origItem = canonicalizedItems[idx] || item;
    
    return {
      ...item,
      originalUck: origItem.originalUck,
      canonicalUck: origItem.canonicalUck || item.uck,
      aliasApplied: origItem.aliasApplied || null,
      canonicalizationReason: origItem.canonicalizationReason,
      debug_payload: {
        uck: item.uck,
        originalUck: origItem.originalUck,
        canonicalUck: origItem.canonicalUck || item.uck,
        displayName,
        attributesNormalized: item.attributesNormalized || item.attributes || {},
        mappingKey,
        companyId,
        aliasApplied: origItem.aliasApplied || null,
        resolution_result: item.resolved ? 'MAPPED' : 'UNRESOLVED',
        match_type: item.matchType || (item.resolved ? 'unknown_match' : 'no_match'),
        reason: item.reason || (item.resolved ? 'Resolved' : 'No CompanySkuMap entry'),
        catalog_id: item.catalog_id || null,
        mapping_id: item.mapping_id || null
      }
    };
  });

  return {
    status: result.summary.pricing_status || (result.summary.unresolved_count === 0 ? 'COMPLETE' : 'INCOMPLETE'),
    pricingStatus: result.summary.pricing_status || (result.summary.unresolved_count === 0 ? 'COMPLETE' : 'INCOMPLETE'),
    resolved_items: debugEnrichedItems.filter(i => i.resolved),
    unresolved_items: debugEnrichedItems.filter(i => !i.resolved),
    resolution_metrics: {
      total: result.summary.resolved_count + result.summary.unresolved_count,
      resolved: result.summary.resolved_count,
      unresolved: result.summary.unresolved_count,
      mapping_rate: result.lineItems.length > 0
        ? Math.round((result.summary.resolved_count / result.lineItems.length) * 1000) / 10
        : 0
    },
    resolver_version: 'GENESIS',
    resolver_authority: 'CompanySkuMap-only'
  };
}

/**
 * Compute pricing
 */
export async function computePricing({
  jobId,
  variantKey,
  resolvedItems = [],
  unresolvedItems = [],
  takeoff_hash,
  total_lf,
  material_type,
  labor_per_lf = 10,
  tear_out_cost = 0,
  delivery_cost = 75,
  discount_percentage = 0,
  retail_anchor_override = null,
}) {
  const gatesCheck = validatePricingGates({
    geometry_checksum: 'legacy',
    takeoff_hash,
    takeoffStatus: 'COMPLETE',
    unresolved_items: unresolvedItems,
    unitAuthority: 'OK',
    retail_anchor: retail_anchor_override || 'computed'
  });

  if (!gatesCheck.canPrice) {
    return {
      pricingStatus: 'BLOCKED',
      blockedReasons: gatesCheck.blockedReasons || [{ code: 'PRICING_GATES_BLOCKED', message: 'Pricing blocked.' }],
    };
  }

  const material_cost = resolvedItems.reduce((sum, item) => {
    if (Number.isFinite(Number(item?.extendedCost))) return sum + Number(item.extendedCost);
    const qty = Number(item?.quantity || item?.qty || 0);
    const unitCost = Number(item?.unit_cost ?? item?.cost ?? 0);
    return sum + qty * unitCost;
  }, 0);

  const pricing = computePricingV1({
    material_cost,
    total_lf,
    labor_per_lf,
    delivery_cost,
    overhead_rate: 0.14,
    commission_rate: 0.10,
    max_discount: 0.15,
    material_type,
    discount_percentage,
    tear_out_cost,
    retail_anchor_override
  });

  return {
    pricingStatus: 'COMPLETE',
    pricing_breakdown: pricing,
    retail_anchor: pricing.retail_price,
    retail_anchor_source: retail_anchor_override ? 'restored' : 'computed'
  };
}

/**
 * Get or create MapScaleConfig
 */
async function getOrCreateMapScaleConfig(job) {
  if (job?.mapScaleConfigId) {
    const configs = await base44.entities.MapScaleConfig.filter({ id: job.mapScaleConfigId });
    if (configs.length > 0) return configs[0];
  }
  
  const config = await base44.entities.MapScaleConfig.create({
    config_version: 'grid_v1',
    pixels_per_foot: GRID_CONTRACT.PIXELS_PER_FOOT,
    world_width_px: GRID_CONTRACT.CANVAS_WIDTH_PX,
    world_height_px: GRID_CONTRACT.CANVAS_HEIGHT_PX,
    grid_square_px: GRID_CONTRACT.GRID_SQUARE_PX,
    grid_square_ft: GRID_CONTRACT.GRID_SQUARE_FT,
    snap_threshold_px: GRID_CONTRACT.SNAP_THRESHOLD_PX,
    post_overlap_tolerance_ft: GRID_CONTRACT.POST_OVERLAP_TOLERANCE_FT,
    notes: 'V1 legacy config (auto-created)'
  });
  
  await base44.entities.Job.update(job.id, { mapScaleConfigId: config.id });
  return config;
}

export default {
  getVariantState,
  computeGeometry,
  buildTakeoff,
  resolveTakeoff,
  computePricing
};