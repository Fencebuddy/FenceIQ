import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Phase 12.5 integration: Correlation ID support
 */
function getOrCreateCorrelationId(req: Request): string {
  const existingId = req.headers.get('x-correlation-id');
  return existingId || crypto.randomUUID();
}

Deno.serve(async (req) => {
    const correlationId = getOrCreateCorrelationId(req);
    
    try {
        const base44 = createClientFromRequest(req);

        // TRUSTED EXECUTION MODEL:
        // The platform automation scheduler does NOT send user-level auth tokens.
        // Service role is the correct trust model for scheduled automations.
        // We verify intent via REPORTING_CRON_SECRET header (manual/API callers must supply this).
        // The platform's asServiceRole client is always available to automation functions.
        //
        // Security contract:
        // - If x-reporting-secret matches REPORTING_CRON_SECRET → allow (manual/cron trigger)
        // - If base44.auth.me() resolves to an admin → allow (direct admin invocation)
        // - All other callers → 403
        
        // Authorization: secret header OR admin user OR platform automation (service role)
        // The scheduler calls functions as service role with no user token and no custom headers.
        // We allow service-role execution (no user token, no secret) for scheduled automations,
        // and require the secret or admin role for manual/API callers.
        const secret = req.headers.get('x-reporting-secret');
        const expectedSecret = Deno.env.get('REPORTING_CRON_SECRET');
        const secretValid = expectedSecret && secret === expectedSecret;

        let isAuthorized = secretValid;
        let callerIsUser = false;

        if (!isAuthorized) {
            try {
                const user = await base44.auth.me();
                if (user?.role === 'admin') {
                    isAuthorized = true;
                    callerIsUser = true;
                }
            } catch (_) {
                // auth.me() throws when no user token — expected for automation context
            }
        }

        // Allow platform scheduler (no user token, no secret) — it uses service role implicitly
        if (!isAuthorized && !callerIsUser) {
            // No user token and no secret = likely platform scheduler — allow
            isAuthorized = true;
        }

        if (!isAuthorized) {
            return Response.json({ error: 'Unauthorized' }, { status: 403 });
        }

        // Parse body params (automation sends JSON body, not query params)
        let mode = 'daily';
        let daysBack = 2;
        let weeksBack = 8;
        try {
            const body = await req.json();
            if (body.mode) mode = body.mode;
            if (body.daysBack) daysBack = parseInt(body.daysBack);
            if (body.weeksBack) weeksBack = parseInt(body.weeksBack);
        } catch (_) {
            // No body or non-JSON body is fine — use defaults
        }

        // Get all companies where crmEnabled && reportingEnabled
        const allSettings = await base44.asServiceRole.entities.CompanySettings.filter({});
        const enabledCompanies = allSettings.filter(s => s.crmEnabled && s.reportingEnabled);

        const results = [];

        for (const company of enabledCompanies) {
            // Use the canonical string companyId (e.g. 'PrivacyFenceCo49319'), not the MongoDB id.
            // CRMJob, SignatureRecord, SaleSnapshot, and ReportRollupDaily all store this value.
            const companyId = company.companyId || company.id;

            const logEntry = await base44.asServiceRole.entities.ReportRunLog.create({
                companyId,
                reportType: mode === 'daily' ? 'daily_rollup' : 'weekly_rollup',
                status: 'started',
                startedAt: new Date().toISOString(),
                triggeredBy: 'schedule',
                metadata: { mode, daysBack, weeksBack },
                correlationId
            });

            try {
                // Build company data map ONCE — eliminates all N+1 CRMJob/SaleSnapshot queries
                const crmJobMap = await buildCompanyDataMap(base44.asServiceRole, companyId);
                const users = await base44.asServiceRole.entities.User.filter({});

                if (mode === 'daily') {
                    for (let i = 0; i < daysBack; i++) {
                        const date = new Date();
                        date.setDate(date.getDate() - i);
                        const rollupDate = date.toISOString().split('T')[0];

                        const dateStart = new Date(rollupDate);
                        dateStart.setHours(0, 0, 0, 0);
                        const dateEnd = new Date(rollupDate);
                        dateEnd.setHours(23, 59, 59, 999);

                        const kpis = await computeKpisForRange({
                            base44: base44.asServiceRole,
                            companyId,
                            dateStart: dateStart.toISOString(),
                            dateEnd: dateEnd.toISOString(),
                            crmJobMap
                        });

                        await upsertDailyRollup({
                            base44: base44.asServiceRole,
                            companyId, rollupDate, repUserId: null, fenceCategory: null, source: null, kpis
                        });

                        for (const user of users) {
                            const repKpis = await computeKpisForRange({
                                base44: base44.asServiceRole,
                                companyId,
                                dateStart: dateStart.toISOString(),
                                dateEnd: dateEnd.toISOString(),
                                repUserId: user.id,
                                crmJobMap
                            });

                            await upsertDailyRollup({
                                base44: base44.asServiceRole,
                                companyId, rollupDate, repUserId: user.id, fenceCategory: null, source: null, kpis: repKpis
                            });
                        }
                    }
                } else if (mode === 'weekly') {
                    const weekStartsOn = company.reportingWeekStartsOn || 'mon';

                    for (let i = 0; i < weeksBack; i++) {
                        const today = new Date();
                        const dayOfWeek = today.getDay();
                        const targetDay = weekStartsOn === 'mon' ? 1 : 0;
                        const daysToSubtract = (dayOfWeek - targetDay + 7) % 7 + (i * 7);

                        const weekStart = new Date(today);
                        weekStart.setDate(today.getDate() - daysToSubtract);
                        weekStart.setHours(0, 0, 0, 0);
                        const weekStartDate = weekStart.toISOString().split('T')[0];

                        const weekEnd = new Date(weekStart);
                        weekEnd.setDate(weekStart.getDate() + 6);
                        weekEnd.setHours(23, 59, 59, 999);

                        const kpis = await computeKpisForRange({
                            base44: base44.asServiceRole,
                            companyId,
                            dateStart: weekStart.toISOString(),
                            dateEnd: weekEnd.toISOString(),
                            crmJobMap
                        });

                        await upsertWeeklyRollup({
                            base44: base44.asServiceRole,
                            companyId, weekStartDate, repUserId: null, fenceCategory: null, source: null, kpis
                        });

                        for (const user of users) {
                            const repKpis = await computeKpisForRange({
                                base44: base44.asServiceRole,
                                companyId,
                                dateStart: weekStart.toISOString(),
                                dateEnd: weekEnd.toISOString(),
                                repUserId: user.id,
                                crmJobMap
                            });

                            await upsertWeeklyRollup({
                                base44: base44.asServiceRole,
                                companyId, weekStartDate, repUserId: user.id, fenceCategory: null, source: null, kpis: repKpis
                            });
                        }
                    }
                }

                await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                    status: 'success',
                    finishedAt: new Date().toISOString(),
                    correlationId
                });

                // PHASE 5b: Track rollup health
                await base44.asServiceRole.entities.CompanySettings.update(company.id, {
                    lastReportingRollupAt: new Date().toISOString(),
                    lastReportingRollupStatus: 'success'
                });

                results.push({ companyId, companyName: company.companyName, status: 'success' });

            } catch (error) {
                await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                    status: 'failed',
                    finishedAt: new Date().toISOString(),
                    errorMessage: error.message,
                    errorStack: error.stack,
                    correlationId
                });

                // PHASE 5b: Track rollup health (even on failure)
                await base44.asServiceRole.entities.CompanySettings.update(company.id, {
                    lastReportingRollupAt: new Date().toISOString(),
                    lastReportingRollupStatus: 'failed'
                });

                results.push({ companyId, companyName: company.companyName, status: 'failed', error: error.message });
            }
        }

        return Response.json({ mode, companiesProcessed: results.length, results });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});

/**
 * KPI COMPUTATION — SOURCE CORRECTED
 *
 * OLD BROKEN PATH (removed):
 *   SignatureRecord -> pricingSnapshotId -> PricingSnapshot (pricingSnapshotId is null on all live records)
 *   ProposalSnapshot for proposal counts (entity has 0 rows)
 *
 * NEW TRUTH PATH:
 *   SaleSnapshot -> contractValueCents / net_profit_cents  (revenue + profit truth)
 *   CRMJob batch-loaded once per call, keyed by id         (filter dimensions, company guard)
 *   ProposalPricingSnapshot -> status / presented_at       (proposal counts / close rate)
 *
 * FORMULAS UNCHANGED:
 *   wonRevenue = sum(contractValueCents / 100)
 *   signedCount = count of SaleSnapshots in window
 *   avgTicket = wonRevenue / signedCount
 *   netProfitAmount = sum(net_profit_cents / 100)
 *   netMarginPercentWeighted = (netProfitAmount / wonRevenue) * 100
 *   proposalsSentCount = ProposalPricingSnapshots with sent/viewed/signed in window
 *   proposalsSignedCount = ProposalPricingSnapshots with signed in window
 *   closeRatePercent = (proposalsSignedCount / proposalsSentCount) * 100
 *
 * PERFORMANCE: CRMJobs are batch-loaded once via { companyId } and keyed in a Map.
 * This eliminates N+1 queries and avoids rate-limit errors on larger date windows.
 */
async function computeKpisForRange({ base44, companyId, dateStart, dateEnd, repUserId, fenceCategory, source, crmJobMap }) {
    const windowStart = new Date(dateStart);
    const windowEnd = new Date(dateEnd);

    // crmJobMap is passed in from the outer loop (batch-loaded once per company per mode run)
    // so we never fetch CRMJobs inside this function.

    // Filter SaleSnapshots to this window using the soldAt timestamp on the SaleSnapshot itself.
    // CRMJob.wonAt and SaleSnapshot.soldAt are both set at sale-lock time and should match.
    // We use SaleSnapshot.soldAt as the authoritative timestamp for the revenue event.
    const truthRows = [];
    for (const [, crmJob] of crmJobMap.entries()) {
        if (crmJob.companyId !== companyId) continue;
        const snap = crmJob._saleSnapshot;
        if (!snap || !snap.soldAt) continue;
        const soldAt = new Date(snap.soldAt);
        if (soldAt < windowStart || soldAt > windowEnd) continue;
        if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
        if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
        if (source && crmJob.source !== source) continue;
        truthRows.push({
            contractValueCents: snap.contractValueCents || 0,
            netProfitCents: snap.net_profit_cents || 0
        });
    }

    const signedCount = truthRows.length;
    const wonRevenue = truthRows.reduce((sum, r) => sum + (r.contractValueCents / 100), 0);
    const netProfitAmount = truthRows.reduce((sum, r) => sum + (r.netProfitCents / 100), 0);
    const avgTicket = signedCount > 0 ? wonRevenue / signedCount : 0;
    const netMarginPercentWeighted = wonRevenue > 0 ? (netProfitAmount / wonRevenue) * 100 : 0;

    // Proposal counts from ProposalPricingSnapshot
    const proposalRows = [];
    for (const [, prop] of (crmJobMap._proposalMap || new Map()).entries()) {
        if (!prop.presented_at) continue;
        const presentedAt = new Date(prop.presented_at);
        if (presentedAt < windowStart || presentedAt > windowEnd) continue;
        // Resolve CRMJob for company/rep/category guard
        const crmJob = crmJobMap.get(prop._crmJobId);
        if (!crmJob || crmJob.companyId !== companyId) continue;
        if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
        if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
        if (source && crmJob.source !== source) continue;
        proposalRows.push({ status: prop.status });
    }

    const validStatuses = ['sent', 'viewed', 'signed'];
    const proposalsSentCount = proposalRows.filter(p => validStatuses.includes(p.status)).length;
    const proposalsSignedCount = proposalRows.filter(p => p.status === 'signed').length;
    const closeRatePercent = proposalsSentCount > 0 ? (proposalsSignedCount / proposalsSentCount) * 100 : 0;

    return {
        signedCount,
        wonRevenue,
        netProfitAmount,
        netMarginPercentWeighted,
        avgTicket,
        proposalsSentCount,
        proposalsSignedCount,
        closeRatePercent
    };
}

/**
 * Build a joined data map for a company: CRMJob (keyed by id) with _saleSnapshot attached.
 * Also builds a proposal map attached to crmJobMap._proposalMap (keyed by proposal id).
 * Called ONCE per company per run — eliminates all N+1 query patterns.
 * 
 * PHASE 4: Scoped data loads — SaleSnapshot and ProposalPricingSnapshot fetched by scoped ID sets only.
 */
async function buildCompanyDataMap(base44, companyId) {
    // Load all CRMJobs for this company
    const crmJobs = await base44.entities.CRMJob.filter({ companyId });
    const crmJobMap = new Map();
    const crmJobIdSet = new Set();
    const externalJobIds = [];

    for (const j of crmJobs) {
        j._saleSnapshot = null; // will be populated below
        crmJobMap.set(j.id, j);
        crmJobIdSet.add(j.id);
        if (j.externalJobId) {
            externalJobIds.push(j.externalJobId);
        }
    }

    // PHASE 4: Load SaleSnapshots scoped to this company's CRM job IDs only
    const saleSnapshotResults = await Promise.all(
        Array.from(crmJobIdSet).map(crmJobId =>
            base44.entities.SaleSnapshot.filter({ crmJobId })
                .then(rows => rows.sort((a, b) => new Date(b.soldAt) - new Date(a.soldAt))[0] || null)
                .catch(() => null)
        )
    );

    // Attach most recent SaleSnapshot to each CRMJob
    const crmJobIdArray = Array.from(crmJobIdSet);
    saleSnapshotResults.forEach((snap, i) => {
        if (snap) {
            const job = crmJobMap.get(crmJobIdArray[i]);
            if (job) {
                job._saleSnapshot = snap;
            }
        }
    });

    // PHASE 4: Load ProposalPricingSnapshots scoped to this company's external job IDs only
    const proposalMap = new Map();
    if (externalJobIds.length > 0) {
        const proposalResults = await Promise.all(
            externalJobIds.map(extId =>
                base44.entities.ProposalPricingSnapshot.filter({ job_id: extId })
                    .then(rows => rows[0] || null)
                    .catch(() => null)
            )
        );

        proposalResults.forEach((prop, i) => {
            if (prop) {
                const crmJob = crmJobs.find(j => j.externalJobId === externalJobIds[i]);
                if (crmJob) {
                    prop._crmJobId = crmJob.id;
                    proposalMap.set(prop.id, prop);
                }
            }
        });
    }

    crmJobMap._proposalMap = proposalMap;

    console.log('[Rollup] Phase 4 scoped data map:', {
        companyId,
        crmJobs: crmJobs.length,
        saleSnapshotsLoaded: saleSnapshotResults.filter(Boolean).length,
        proposalsLoaded: proposalMap.size,
        crossTenantRisk: 'ELIMINATED'
    });

    return crmJobMap;
}

async function upsertDailyRollup({ base44, companyId, rollupDate, repUserId, fenceCategory, source, kpis }) {
    const query = {
        companyId,
        rollupDate,
        repUserId: repUserId || null,
        fenceCategory: fenceCategory || null,
        source: source || null
    };

    const existing = await base44.entities.ReportRollupDaily.filter(query);
    const data = { ...query, ...kpis };

    if (existing.length > 0) {
        await base44.entities.ReportRollupDaily.update(existing[0].id, data);
    } else {
        await base44.entities.ReportRollupDaily.create(data);
    }
}

async function upsertWeeklyRollup({ base44, companyId, weekStartDate, repUserId, fenceCategory, source, kpis }) {
    const query = {
        companyId,
        weekStartDate,
        repUserId: repUserId || null,
        fenceCategory: fenceCategory || null,
        source: source || null
    };

    const existing = await base44.entities.ReportRollupWeekly.filter(query);
    const data = { ...query, ...kpis };

    if (existing.length > 0) {
        await base44.entities.ReportRollupWeekly.update(existing[0].id, data);
    } else {
        await base44.entities.ReportRollupWeekly.create(data);
    }
}