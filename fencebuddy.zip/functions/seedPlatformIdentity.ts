/**
 * SEED PLATFORM IDENTITY
 * 
 * One-time setup: seeds TenantCompany and PlatformMembership for FenceIQ owner.
 * 
 * Seeds:
 *   - TenantCompany: Privacy Fence Company
 *   - PlatformMembership: calling user → PLATFORM_SUPER_ADMIN
 *   - CompanyMembership: calling user → COMPANY_OWNER (Privacy Fence Company)
 * 
 * Admin only. Idempotent.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: admin only' }, { status: 403 });
    }

    // HARDENING: After initial bootstrap, require PLATFORM_SUPER_ADMIN membership
    // This prevents re-seeding or privilege escalation once the platform is initialized.
    const existingPlatformMemberships = await base44.asServiceRole.entities.PlatformMembership.filter({ status: 'active' });
    const callerIsPlatformSuperAdmin = existingPlatformMemberships.some(m => m.user_id === user.id && m.role === 'PLATFORM_SUPER_ADMIN');
    const isBootstrap = existingPlatformMemberships.length === 0;

    if (!isBootstrap && !callerIsPlatformSuperAdmin) {
      return Response.json({
        error: 'Forbidden: Platform already bootstrapped. PLATFORM_SUPER_ADMIN membership required to run seed again.',
        code: 'POST_BOOTSTRAP_REQUIRES_PLATFORM_SUPER_ADMIN'
      }, { status: 403 });
    }

    const results = { created: [], skipped: [] };

    // 1. Seed TenantCompany: Privacy Fence Company
    const existingCompanies = await base44.asServiceRole.entities.TenantCompany.filter({
      slug: 'privacy-fence-company'
    });

    let tenantCompany;
    if (existingCompanies.length > 0) {
      tenantCompany = existingCompanies[0];
      results.skipped.push('TenantCompany: Privacy Fence Company (already exists)');
    } else {
      tenantCompany = await base44.asServiceRole.entities.TenantCompany.create({
        company_name: 'Privacy Fence Company',
        slug: 'privacy-fence-company',
        status: 'active',
        notes: 'FenceIQ owner company — seeded by platform setup'
      });
      results.created.push(`TenantCompany: ${tenantCompany.company_name} (id: ${tenantCompany.id})`);
    }

    // 2. Seed PlatformMembership: user → PLATFORM_SUPER_ADMIN
    const existingPlatformMembership = await base44.asServiceRole.entities.PlatformMembership.filter({
      user_id: user.id,
      status: 'active'
    });

    if (existingPlatformMembership.length > 0) {
      results.skipped.push(`PlatformMembership: ${user.email} → PLATFORM_SUPER_ADMIN (already exists)`);
    } else {
      const pm = await base44.asServiceRole.entities.PlatformMembership.create({
        user_id: user.id,
        user_email: user.email,
        role: 'PLATFORM_SUPER_ADMIN',
        status: 'active',
        granted_by_user_id: user.id
      });
      results.created.push(`PlatformMembership: ${user.email} → PLATFORM_SUPER_ADMIN (id: ${pm.id})`);
    }

    // 3. Seed CompanyMembership: user → COMPANY_OWNER (Privacy Fence Company)
    const existingCompanyMembership = await base44.asServiceRole.entities.CompanyMembership.filter({
      user_id: user.id,
      tenant_company_id: tenantCompany.id,
      status: 'active'
    });

    if (existingCompanyMembership.length > 0) {
      results.skipped.push(`CompanyMembership: ${user.email} → COMPANY_OWNER (already exists)`);
    } else {
      const cm = await base44.asServiceRole.entities.CompanyMembership.create({
        user_id: user.id,
        user_email: user.email,
        tenant_company_id: tenantCompany.id,
        role: 'COMPANY_OWNER',
        status: 'active',
        invited_by_user_id: user.id
      });
      results.created.push(`CompanyMembership: ${user.email} → COMPANY_OWNER @ Privacy Fence Company (id: ${cm.id})`);
    }

    // 4. Log to audit
    await base44.asServiceRole.entities.PlatformAuditLog.create({
      actor_user_id: user.id,
      actor_email: user.email,
      actor_context_type: 'platform',
      actor_context_id: null,
      action: 'PLATFORM_SEED_IDENTITY',
      target_type: 'system',
      target_id: null,
      metadata: { results }
    });

    console.log('[seedPlatformIdentity] Seed complete:', results);

    return Response.json({
      status: 'ok',
      message: 'Platform identity seed complete.',
      tenantCompanyId: tenantCompany.id,
      results
    });

  } catch (error) {
    console.error('[seedPlatformIdentity] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});