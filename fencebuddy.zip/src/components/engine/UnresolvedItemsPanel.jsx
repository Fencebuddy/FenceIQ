/**
 * FENCEBUDDY V2 ENGINE — UNRESOLVED ITEMS PANEL
 * 
 * CONTRACT 0.2: Show blocking unresolved items with actionable fix steps
 */

import React from 'react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, ExternalLink, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function UnresolvedItemsPanel({ unresolvedItems, resolutionMetrics }) {
  if (!unresolvedItems || unresolvedItems.length === 0) {
    return null;
  }
  
  const blockingItems = unresolvedItems.filter(item => !item.allow_unresolved_but_nonblocking);
  const nonBlockingItems = unresolvedItems.filter(item => item.allow_unresolved_but_nonblocking);
  
  return (
    <Card className="border-red-500 bg-red-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-900">
          <AlertTriangle className="w-5 h-5" />
          Unresolved Materials ({unresolvedItems.length})
          {blockingItems.length > 0 && (
            <Badge className="bg-red-600 text-white ml-2">
              {blockingItems.length} Blocking Pricing
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Resolution metrics */}
        <div className="bg-white/50 p-3 rounded border space-y-1 text-sm">
          <div className="flex justify-between">
            <span>Mapping Rate:</span>
            <strong className={resolutionMetrics?.mapping_rate === 100 ? 'text-green-600' : 'text-red-600'}>
              {resolutionMetrics?.mapping_rate?.toFixed(1)}%
            </strong>
          </div>
          <div className="flex justify-between">
            <span>Resolved:</span>
            <strong className="text-green-600">{resolutionMetrics?.resolved || 0}</strong>
          </div>
          <div className="flex justify-between">
            <span>Unresolved:</span>
            <strong className="text-red-600">{resolutionMetrics?.unresolved || 0}</strong>
          </div>
          {resolutionMetrics?.unit_mismatches > 0 && (
            <div className="flex justify-between">
              <span>Unit Mismatches:</span>
              <strong className="text-amber-600">{resolutionMetrics.unit_mismatches}</strong>
            </div>
          )}
        </div>
        
        {/* Blocking items */}
        {blockingItems.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm text-red-900">
              Blocking Items (Must Fix Before Pricing)
            </h4>
            {blockingItems.map((item, idx) => (
              <Alert key={idx} className="border-red-300 bg-white">
                <Package className="w-4 h-4 text-red-600" />
                <AlertTitle className="text-sm font-semibold text-red-900">
                  {item.lineItemName || item.canonical_key}
                </AlertTitle>
                <AlertDescription className="text-sm text-red-700 space-y-2">
                  <div className="font-mono text-xs bg-red-100 p-2 rounded">
                    UCK: {item.canonical_key}
                  </div>
                  <div>
                    <strong>Reason:</strong> {item.unresolved_reason}
                  </div>
                  {item.actionHint && (
                    <div className="bg-red-100 p-2 rounded border border-red-300">
                      <strong>Fix:</strong> {item.actionHint}
                    </div>
                  )}
                  {item.resolution_status === 'UNIT_MISMATCH' && (
                    <div className="text-xs">
                      Takeoff unit: <code>{item.takeoff_unit}</code> → Catalog unit: <code>{item.catalog_unit}</code>
                    </div>
                  )}
                  <div className="text-xs text-slate-600">
                    Quantity needed: {item.quantityCalculated} {item.uom}
                  </div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}
        
        {/* Non-blocking items */}
        {nonBlockingItems.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm text-amber-900">
              Optional Items (Non-Blocking)
            </h4>
            {nonBlockingItems.map((item, idx) => (
              <Alert key={idx} className="border-amber-300 bg-amber-50">
                <Info className="w-4 h-4 text-amber-600" />
                <AlertTitle className="text-sm font-semibold text-amber-900">
                  {item.lineItemName || item.canonical_key}
                </AlertTitle>
                <AlertDescription className="text-sm text-amber-700">
                  <div className="font-mono text-xs">UCK: {item.canonical_key}</div>
                  <div className="text-xs mt-1">Optional accessory - pricing will proceed without this item</div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}
        
        {/* Fix action */}
        <div className="pt-3 border-t">
          <Link to={createPageUrl('FenceSystemConfig')}>
            <Button className="w-full bg-red-600 hover:bg-red-700">
              <ExternalLink className="w-4 h-4 mr-2" />
              Go to Fence System Config to Map Items
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}