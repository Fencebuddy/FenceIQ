/**
 * ⚠️ QUARANTINED FILE — DO NOT IMPORT ⚠️
 * 
 * Previously: components/engine/ResolverEngine.js
 * Quarantined: 2026-02-28
 * Reason: CRASH LANDMINE — resolveMaterials() references `variantConfig` which is
 *         undefined in scope (line ~192). Any caller would throw a ReferenceError.
 *         Also: this resolver is now superseded by universalResolver (GenesisResolver)
 *         which is the sole authorized resolution path via EngineAdapterV2.resolveTakeoff().
 * 
 * DO NOT restore this import. Use resolveLineItemsWithMappings from universalResolver instead.
 */

// Original content preserved below for reference only — NOT exported, NOT used.

/*
import { ENGINE_VERSIONS } from './versions';
import { logDiagnostic } from './diagnosticsService';
import { base44 } from '@/api/base44Client';

async function resolveMaterials_DEAD({ takeoffItems, companyId, variantId, jobId }) {
  // ... CRASHED HERE: generateTakeoffHash({ lineItems: takeoffItems, variantConfig })
  //     variantConfig is not defined in this scope → ReferenceError on every invocation
}

async function ensureCompanySkuMap_DEAD({ companyId, uck, materialCatalogId, materialCatalogName }) {
  // ... safe helper, but superseded by upsertCompanySkuMap in components/materials/upsertCompanySkuMap
}
*/