/**
 * JOB TO CRM JOB SYNC DIAGNOSTIC
 * Phase 3: Inspect data state before backfill
 * 
 * Diagnostic tool to:
 * - Count signed Jobs by company
 * - Count signed CRMJobs by company
 * - Identify unmatched signed Jobs
 * - Report potential duplicates
 */

import { base44 } from '@/api/base44Client';
import { isJobSigned } from '@/_shared/jobToCrmJobSyncHelpers';

/**
 * Run diagnostic on company data
 * Returns: {
 *   companyId,
 *   signedJobs: { count, sample: [] },
 *   signedCrmJobs: { count, sample: [] },
 *   unmatchedJobs: { count, sample: [] },
 *   potentialDuplicates: { count, examples: [] },
 *   coverage: { percent, message }
 * }
 */
export async function runSyncDiagnostic(companyId) {
  console.log('[SyncDiagnostic] Starting for company', companyId);

  try {
    // Fetch all Jobs
    const allJobs = await base44.entities.Job.filter({ companyId });
    console.log(`[SyncDiagnostic] Fetched ${allJobs.length} Jobs`);

    // Filter to signed
    const signedJobs = allJobs.filter(job => isJobSigned(job));
    console.log(`[SyncDiagnostic] Found ${signedJobs.length} signed Jobs`);

    // Fetch all CRMJobs
    const allCrmJobs = await base44.entities.CRMJob.filter({ companyId });
    console.log(`[SyncDiagnostic] Fetched ${allCrmJobs.length} CRMJobs`);

    // Filter to signed/won CRMJobs
    const signedCrmJobs = allCrmJobs.filter(
      crm => crm.contractStatus === 'signed' || crm.saleStatus === 'sold'
    );
    console.log(`[SyncDiagnostic] Found ${signedCrmJobs.length} signed CRMJobs`);

    // Find unmatched signed Jobs (not linked to any CRMJob)
    const linkedJobIds = new Set(
      allCrmJobs
        .filter(crm => crm.externalJobId)
        .map(crm => crm.externalJobId)
    );

    const unmatchedJobs = signedJobs.filter(job => !linkedJobIds.has(job.id));
    console.log(`[SyncDiagnostic] Found ${unmatchedJobs.length} unmatched signed Jobs`);

    // Check for duplicate CRMJob externalJobIds
    const externalIdCounts = {};
    allCrmJobs.forEach(crm => {
      if (crm.externalJobId) {
        externalIdCounts[crm.externalJobId] = (externalIdCounts[crm.externalJobId] || 0) + 1;
      }
    });

    const potentialDuplicates = Object.entries(externalIdCounts)
      .filter(([_, count]) => count > 1)
      .map(([jobId, count]) => ({ jobId, count }));

    console.log(`[SyncDiagnostic] Found ${potentialDuplicates.length} potential duplicates`);

    // Calculate coverage
    const coverage = signedJobs.length > 0
      ? Math.round((signedCrmJobs.length / signedJobs.length) * 100)
      : 0;

    const result = {
      companyId,
      timestamp: new Date().toISOString(),
      signedJobs: {
        count: signedJobs.length,
        sample: signedJobs.slice(0, 3).map(job => ({
          id: job.id,
          jobNumber: job.jobNumber,
          customerName: job.customerName,
          signedAt: job.signedAt
        }))
      },
      signedCrmJobs: {
        count: signedCrmJobs.length,
        sample: signedCrmJobs.slice(0, 3).map(crm => ({
          id: crm.id,
          jobNumber: crm.jobNumber,
          externalJobId: crm.externalJobId,
          contractStatus: crm.contractStatus
        }))
      },
      unmatchedJobs: {
        count: unmatchedJobs.length,
        sample: unmatchedJobs.slice(0, 3).map(job => ({
          id: job.id,
          jobNumber: job.jobNumber,
          customerName: job.customerName
        }))
      },
      potentialDuplicates: {
        count: potentialDuplicates.length,
        examples: potentialDuplicates.slice(0, 3)
      },
      coverage: {
        percent: coverage,
        message:
          coverage === 100
            ? 'All signed Jobs have CRMJob twins ✓'
            : coverage === 0
            ? 'No signed Jobs linked to CRMJobs - backfill needed'
            : `${coverage}% of signed Jobs linked - partial coverage`
      }
    };

    console.log('[SyncDiagnostic] Complete', result);
    return result;

  } catch (err) {
    console.error('[SyncDiagnostic] ERROR:', err);
    return {
      companyId,
      error: err.message
    };
  }
}