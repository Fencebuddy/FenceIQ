import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

function toUSD(cents) {
  const n = Number(cents || 0);
  return n / 100;
}

function monthKeyFromDate(isoDate) {
  const d = new Date(isoDate);
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

/**
 * Inline overhead rate resolver — mirrors _shared/pricingRates resolveOverheadRate truth ladder.
 * No local imports allowed in Deno functions, so this is inlined here.
 * Priority: OverheadSettings.manualOverridePct > OverheadSettings.computedOverheadPct > hardFallback
 */
async function resolveOverheadRateForCompany(base44, rollupCompanyId, hardFallback = 0.14) {
  try {
    const settings = await base44.entities.OverheadSettings.filter({ companyId: rollupCompanyId });
    if (settings && settings.length === 1) {
      const s = settings[0];
      const override = s.manualOverridePct != null ? Number(s.manualOverridePct) : null;
      if (override != null && isFinite(override) && override > 0) {
        const rate = override > 1 ? override / 100 : override;
        console.log(`[populateBreakevenMonthlyRollups] overheadRate resolved: manualOverridePct=${override} → ${rate}`);
        return rate;
      }
      const computed = s.computedOverheadPct != null ? Number(s.computedOverheadPct) : null;
      if (computed != null && isFinite(computed) && computed > 0) {
        const rate = computed > 1 ? computed / 100 : computed;
        console.log(`[populateBreakevenMonthlyRollups] overheadRate resolved: computedOverheadPct=${computed} → ${rate}`);
        return rate;
      }
    } else if (settings && settings.length > 1) {
      console.error(`[populateBreakevenMonthlyRollups] OVERHEAD_SETTINGS_DUPLICATE for companyId=${rollupCompanyId} — using hardFallback`);
    }
  } catch (e) {
    console.error(`[populateBreakevenMonthlyRollups] Error reading OverheadSettings for ${rollupCompanyId}: ${e.message}`);
  }
  console.warn(`[populateBreakevenMonthlyRollups] overheadRate hardFallback=${hardFallback} for companyId=${rollupCompanyId}`);
  return hardFallback;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Admin-only check (human invocations must be authenticated)
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    if (user.role !== "admin") {
      return Response.json({ error: "Forbidden: Admin access required" }, { status: 403 });
    }

    console.log("[populateBreakevenMonthlyRollups] Starting rollup population...");

    // Fetch all companies
    const companies = await base44.entities.CompanySettings.list();
    if (!companies || companies.length === 0) {
      return Response.json({
        success: true,
        companiesProcessed: 0,
        monthsProcessed: 0,
        rollupsCreated: 0,
        rollupsUpdated: 0,
        errors: []
      });
    }

    let totalCompaniesProcessed = 0;
    let totalMonthsProcessed = 0;
    let totalRollupsCreated = 0;
    let totalRollupsUpdated = 0;
    const errors = [];

    // For each company, scan CRM jobs and populate rollups
    for (const company of companies) {
      const rollupCompanyId = company.id;         // MongoDB id — matches live path rollup lookup
      const crmCompanyId = company.companyId;    // custom field — matches CRMJob.companyId records
      console.log(`[populateBreakevenMonthlyRollups] Processing company: rollupKey=${rollupCompanyId}, crmKey=${crmCompanyId}`);

      try {
        // Fetch won jobs scoped to this company only
        const allWonJobs = await base44.entities.CRMJob.filter({ status: "won", companyId: crmCompanyId });
        if (!allWonJobs || allWonJobs.length === 0) {
          console.log(`[populateBreakevenMonthlyRollups] No won jobs for crmKey=${crmCompanyId}`);
          continue;
        }

        // Group by monthKey
        const monthGroups = {};
        allWonJobs.forEach(job => {
          if (!job.wonAt) return;
          
          const monthKey = monthKeyFromDate(job.wonAt);
          if (!monthGroups[monthKey]) {
            monthGroups[monthKey] = [];
          }
          monthGroups[monthKey].push(job);
        });

        // Process each month group
        for (const [monthKey, jobs] of Object.entries(monthGroups)) {
          console.log(`[populateBreakevenMonthlyRollups] Processing ${rollupCompanyId}/${monthKey}: ${jobs.length} jobs`);

          // Compute metrics (same logic as live path)
          const jobsCount = jobs.length;
          const recognizedRevenueCents = jobs.reduce((acc, job) => {
            const revenue = Number(job.contractValueCents || job.recognizedRevenueCents || 0);
            return acc + revenue;
          }, 0);

          const overheadRate = await resolveOverheadRateForCompany(base44, rollupCompanyId);
          const overheadRecoveredCents = Math.floor(recognizedRevenueCents * overheadRate);

          try {
            // Check if rollup exists — keyed by rollupCompanyId (MongoDB id, matches live path lookup)
            const existing = await base44.entities.BreakevenMonthlyRollup.filter({
              companyId: rollupCompanyId,
              monthKey
            });

            if (existing && existing.length > 0) {
              // Update existing
              const rollupId = existing[0].id;
              await base44.asServiceRole.entities.BreakevenMonthlyRollup.update(rollupId, {
                jobsCount,
                recognizedRevenueCents,
                overheadRecoveredCents,
                lastComputedAt: new Date().toISOString()
              });
              totalRollupsUpdated++;
              console.log(`[populateBreakevenMonthlyRollups] Updated rollup: ${rollupCompanyId}/${monthKey}`);
            } else {
              // Create new — store with rollupCompanyId so live path lookup finds it
              await base44.asServiceRole.entities.BreakevenMonthlyRollup.create({
                companyId: rollupCompanyId,
                monthKey,
                jobsCount,
                recognizedRevenueCents,
                overheadRecoveredCents,
                lastComputedAt: new Date().toISOString()
              });
              totalRollupsCreated++;
              console.log(`[populateBreakevenMonthlyRollups] Created rollup: ${rollupCompanyId}/${monthKey}`);
            }
            totalMonthsProcessed++;
          } catch (e) {
            const msg = `Failed to upsert rollup ${rollupCompanyId}/${monthKey}: ${e.message}`;
            console.error(`[populateBreakevenMonthlyRollups] ${msg}`);
            errors.push(msg);
          }
          }

          totalCompaniesProcessed++;
          } catch (e) {
          const msg = `Failed processing company ${rollupCompanyId}: ${e.message}`;
          console.error(`[populateBreakevenMonthlyRollups] ${msg}`);
          errors.push(msg);
          }
    }

    console.log(`[populateBreakevenMonthlyRollups] Complete: ${totalCompaniesProcessed} companies, ${totalMonthsProcessed} months, ${totalRollupsCreated} created, ${totalRollupsUpdated} updated`);

    return Response.json({
      success: true,
      companiesProcessed: totalCompaniesProcessed,
      monthsProcessed: totalMonthsProcessed,
      rollupsCreated: totalRollupsCreated,
      rollupsUpdated: totalRollupsUpdated,
      errors
    });

  } catch (error) {
    console.error("[populateBreakevenMonthlyRollups] Unexpected error:", error);
    return Response.json({
      success: false,
      error: "INTERNAL_ERROR",
      message: error.message
    }, { status: 500 });
  }
});