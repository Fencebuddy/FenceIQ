/**
 * Helper function for executeSend in JobDetail
 * Sanitizes inputs and generates crew load sheet
 */

import { generateCrewLoadSheet } from './CrewLoadSheetGenerator';

/**
 * Sanitize fence lines to contain only valid numeric points
 */
function sanitizeFenceLines(fenceLines) {
  if (!Array.isArray(fenceLines)) return [];
  return (fenceLines || [])
    .map(line => {
      if (!line.points || !Array.isArray(line.points)) return null;
      const validPoints = line.points.filter(pt => 
        pt && typeof pt.x === 'number' && isFinite(pt.x) && 
        typeof pt.y === 'number' && isFinite(pt.y)
      );
      return validPoints.length > 1 ? { ...line, points: validPoints } : null;
    })
    .filter(Boolean);
}

/**
 * Validate data URL format (image/png or image/jpeg, min 100 bytes)
 */
function isValidMapImageDataUrl(s) {
  return typeof s === 'string' && s.startsWith('data:image/') && s.length > 100;
}

/**
 * Generate crew load sheet with sanitized inputs and debug logging
 */
export async function generateCrewLoadSheetSafe(job, runs, gates, materials, fenceLines, mapImageData) {
  // Sanitize inputs
  const fenceLinesSafe = sanitizeFenceLines(fenceLines);
  const mapImageSafe = isValidMapImageDataUrl(mapImageData) ? mapImageData : null;

  // Debug log (minimal, production-safe)
  console.log('[OFFICE_DOC] PDF generation payload', {
    jobId: job?.id,
    fenceLinesCount: fenceLinesSafe.length,
    hasMapImage: !!mapImageSafe,
    mapImageLen: mapImageSafe ? mapImageSafe.length : 0
  });

  // Generate with sanitized inputs
  return await generateCrewLoadSheet(job, runs, gates, materials, fenceLinesSafe, mapImageSafe);
}