/**
 * VALIDATE CONTEXT ACCESS — Server-side context enforcement
 *
 * Called by any backend function that needs to verify the current user's
 * active context server-side. Prevents client-side spoofing of context.
 *
 * Returns:
 *   { valid: true, context_type, context_id, role, userId }  — access granted
 *   { valid: false, error, code }                            — access denied
 *
 * Usage:
 *   const access = await validateContextAccess(base44, user, 'company', requestedCompanyId);
 *   if (!access.valid) return Response.json({ error: access.error }, { status: 403 });
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * Core validation function — importable by other backend functions via inline copy
 * (No local imports allowed in Deno — use this as reference)
 */
async function validateContextAccess(base44, user, requiredContextType, requiredContextId = null) {
  if (!user?.id) {
    return { valid: false, error: 'Unauthenticated', code: 'UNAUTHENTICATED' };
  }

  if (requiredContextType === 'platform') {
    // Must have active PlatformMembership — never derived from base44 role
    const memberships = await base44.asServiceRole.entities.PlatformMembership.filter({
      user_id: user.id,
      status: 'active'
    });
    if (memberships.length === 0) {
      return { valid: false, error: 'No platform membership', code: 'NO_PLATFORM_MEMBERSHIP' };
    }
    return {
      valid: true,
      context_type: 'platform',
      context_id: null,
      role: memberships[0].role,
      userId: user.id
    };
  }

  if (requiredContextType === 'company') {
    if (!requiredContextId) {
      return { valid: false, error: 'Missing company context_id', code: 'MISSING_CONTEXT_ID' };
    }

    // Must have active CompanyMembership for THIS specific company
    const memberships = await base44.asServiceRole.entities.CompanyMembership.filter({
      user_id: user.id,
      tenant_company_id: requiredContextId,
      status: 'active'
    });
    if (memberships.length === 0) {
      return { valid: false, error: 'No company membership', code: 'NO_COMPANY_MEMBERSHIP' };
    }

    // Confirm company exists and is active
    const companies = await base44.asServiceRole.entities.TenantCompany.filter({
      id: requiredContextId,
      status: 'active'
    });
    if (companies.length === 0) {
      return { valid: false, error: 'Company not found or inactive', code: 'COMPANY_INACTIVE' };
    }

    return {
      valid: true,
      context_type: 'company',
      context_id: requiredContextId,
      role: memberships[0].role,
      userId: user.id,
      company: companies[0]
    };
  }

  return { valid: false, error: 'Invalid context type', code: 'INVALID_CONTEXT_TYPE' };
}

/**
 * HTTP endpoint: Validate context access on-demand
 * Body: { context_type: "platform"|"company", context_id?: string }
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const { context_type, context_id } = body;

    if (!context_type) {
      return Response.json({ error: 'context_type required' }, { status: 400 });
    }

    const result = await validateContextAccess(base44, user, context_type, context_id || null);

    if (!result.valid) {
      return Response.json({ valid: false, error: result.error, code: result.code }, { status: 403 });
    }

    return Response.json({ valid: true, ...result });

  } catch (error) {
    console.error('[validateContextAccess] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});