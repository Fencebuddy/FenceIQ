import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * TEST: Gate Mapping Coverage
 * Tests all gate scenarios (4'-12', all colors, all material types)
 * Checks if each scenario has a mapping in the system
 * Reports unmapped gates and coverage statistics
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get company
    const companies = await base44.entities.CompanySettings.filter({});
    const company = companies[0];
    if (!company) {
      return Response.json({ error: 'No company found' }, { status: 400 });
    }

    const companyId = company.id;

    // Test parameters
    const heights = ['4', '5', '6', '8', '10', '12'];
    const colors = ['white', 'tan', 'khaki', 'grey'];
    const materialTypes = ['vinyl', 'chain_link', 'aluminum', 'wood'];

    // Fetch all mappings and catalog
    const [mappings, catalog] = await Promise.all([
      base44.entities.CompanySkuMap.filter({ companyId }),
      base44.entities.MaterialCatalog.filter({ active: true })
    ]);

    // Build canonical keys for all scenarios
    const scenarios = [];
    for (const material of materialTypes) {
      for (const height of heights) {
        for (const color of colors) {
          // Skip color variations for non-vinyl
          if (material !== 'vinyl' && color !== 'white') continue;

          const uck = `gate_single_${material}_${height}ft_${color}`;
          scenarios.push({
            material,
            height: `${height}'`,
            color,
            uck,
            isMapped: mappings.some(m => m.uck === uck),
            inCatalog: catalog.some(c => c.canonical_key === uck || c.fencebuddy_mapping === uck)
          });
        }
      }
    }

    // Analyze coverage by material type
    const coverageByMaterial = {};
    for (const material of materialTypes) {
      const scenariosForMaterial = scenarios.filter(s => s.material === material);
      const mapped = scenariosForMaterial.filter(s => s.isMapped).length;
      const inCat = scenariosForMaterial.filter(s => s.inCatalog).length;

      coverageByMaterial[material] = {
        total: scenariosForMaterial.length,
        mapped: mapped,
        inCatalog: inCat,
        coverage: `${Math.round((mapped / scenariosForMaterial.length) * 100)}%`,
        unmapped: scenariosForMaterial.filter(s => !s.isMapped).map(s => `${s.height} ${s.color}`)
      };
    }

    const totalScenarios = scenarios.length;
    const totalMapped = scenarios.filter(s => s.isMapped).length;
    const totalInCatalog = scenarios.filter(s => s.inCatalog).length;

    return Response.json({
      status: 'GATE_MAPPING_COVERAGE_TEST',
      timestamp: new Date().toISOString(),
      company: company.companyName,
      summary: {
        totalScenariosGenerated: totalScenarios,
        totalMapped: totalMapped,
        totalInCatalog: totalInCatalog,
        overallCoverageMapped: `${Math.round((totalMapped / totalScenarios) * 100)}%`,
        overallCoverageCatalog: `${Math.round((totalInCatalog / totalScenarios) * 100)}%`
      },
      coverageByMaterial,
      unmappedGates: scenarios
        .filter(s => !s.isMapped)
        .sort((a, b) => a.material.localeCompare(b.material))
        .slice(0, 20), // Show first 20 unmapped
      verdict: {
        allVinylMapped: coverageByMaterial['vinyl'].mapped === coverageByMaterial['vinyl'].total,
        allChainLinkMapped: coverageByMaterial['chain_link'].mapped === coverageByMaterial['chain_link'].total,
        allAluminumMapped: coverageByMaterial['aluminum'].mapped === coverageByMaterial['aluminum'].total,
        allWoodMapped: coverageByMaterial['wood'].mapped === coverageByMaterial['wood'].total,
        systemReady: totalMapped === totalScenarios
      },
      recommendations: generateRecommendations(coverageByMaterial, totalMapped, totalScenarios)
    });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});

function generateRecommendations(coverage, totalMapped, totalScenarios) {
  const recommendations = [];

  for (const [material, stats] of Object.entries(coverage)) {
    if (stats.mapped < stats.total) {
      recommendations.push({
        priority: material === 'vinyl' ? 'CRITICAL' : 'HIGH',
        issue: `${material}: ${stats.total - stats.mapped}/${stats.total} gates unmapped`,
        action: `Seed CompanySkuMap entries for unmapped ${material} gates`,
        unmapped: stats.unmapped
      });
    }
  }

  if (recommendations.length === 0) {
    recommendations.push({
      priority: 'NONE',
      issue: 'All gate scenarios fully mapped',
      action: 'System ready for production pricing',
      unmapped: []
    });
  }

  return recommendations;
}