/**
 * FENCEBUDDY V2 ENGINE — PROPOSAL BUILDER
 * 
 * CONTRACT 6: PROPOSAL SNAPSHOT GENERATION
 * Build immutable proposal documents from JobCostSnapshot
 */

import { ENGINE_VERSIONS, stampVersions } from './versions';
import { base44 } from '@/api/base44Client';

/**
 * Build proposal snapshot from pricing
 */
export async function buildProposal({
  jobCostSnapshot,
  variantConfig,
  displayOptions = {},
  jobId,
  variantId,
  companyId
}) {
  console.log('[ProposalBuilder] Building proposal...', {
    snapshot_id: jobCostSnapshot?.id,
    variant: variantConfig?.materialType
  });
  
  if (!jobCostSnapshot || !jobCostSnapshot.pricing_breakdown) {
    return {
      status: 'ERROR',
      error: 'Missing JobCostSnapshot or pricing breakdown'
    };
  }
  
  // Extract pricing data
  const pricing = jobCostSnapshot.pricing_breakdown;
  
  // Build proposal document structure
  const proposalDoc = {
    // Header
    title: `${variantConfig.materialType} Fence Proposal`,
    variant_tier: jobCostSnapshot.scenario_tier,
    material_description: `${variantConfig.materialType} ${variantConfig.heightFt}ft ${variantConfig.color || variantConfig.coating || ''}`,
    
    // Pricing summary
    retail_price: pricing.retail_price,
    sale_price: pricing.sale_price,
    discount_percentage: pricing.discount_percentage,
    discount_amount: pricing.discount_amount,
    
    // Line items
    materials_summary: jobCostSnapshot.materials_resolved || [],
    
    // Totals
    total_lf: jobCostSnapshot.total_lf,
    material_cost: pricing.material_cost,
    labor_cost: pricing.labor_cost,
    delivery_cost: pricing.delivery_cost,
    
    // Display options
    show_line_items: displayOptions.show_line_items !== false,
    show_breakdown: displayOptions.show_breakdown || false,
    
    // Snapshot references
    job_cost_snapshot_id: jobCostSnapshot.id,
    takeoff_snapshot_id: jobCostSnapshot.takeoff_snapshot_id
  };
  
  // Create or update ProposalSnapshot
  const existing = await base44.entities.ProposalSnapshot.filter({
    jobId,
    job_cost_snapshot_id: jobCostSnapshot.id
  });
  
  const proposalData = stampVersions({
    jobId,
    job_cost_snapshot_id: jobCostSnapshot.id,
    takeoff_snapshot_id: jobCostSnapshot.takeoff_snapshot_id,
    variant_tier: jobCostSnapshot.scenario_tier,
    proposal_doc: proposalDoc,
    retail_price: pricing.retail_price,
    sale_price: pricing.sale_price,
    status: 'DRAFT',
    locked: false
  });
  
  let snapshot;
  if (existing.length > 0) {
    snapshot = await base44.entities.ProposalSnapshot.update(existing[0].id, proposalData);
  } else {
    snapshot = await base44.entities.ProposalSnapshot.create(proposalData);
  }
  
  console.log('[ProposalBuilder] Proposal created:', snapshot.id);
  
  return {
    status: 'COMPLETE',
    proposal_snapshot: snapshot,
    proposal_doc: proposalDoc
  };
}

/**
 * Lock proposal after customer acceptance
 */
export async function lockProposal({ proposalSnapshotId, signatureData }) {
  await base44.entities.ProposalSnapshot.update(proposalSnapshotId, {
    locked: true,
    status: 'SIGNED',
    locked_at: new Date().toISOString()
  });
  
  // Create signature record
  const signature = await base44.entities.SignatureRecord.create({
    proposal_snapshot_id: proposalSnapshotId,
    customer_name: signatureData.customerName,
    customer_email: signatureData.customerEmail,
    signature_font: signatureData.signatureFont,
    signed_at: new Date().toISOString(),
    ip_address: signatureData.ipAddress || null
  });
  
  return signature;
}