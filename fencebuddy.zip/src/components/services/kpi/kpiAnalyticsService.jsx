/**
 * KPI ANALYTICS SERVICE
 * Master orchestrator for all KPI computations
 */

import { getCached, setCached, buildCacheKey } from './cache';
import { loadSnapshotMaps, buildSignedDealsTruthSet, buildAppointmentsTruthSet, buildProductionTruthSet } from './truthSetService';
import { computeRevenueKpis } from './compute/computeRevenueKpis';
import { computeMarginKpis } from './compute/computeMarginKpis';
import { computePricingDisciplineKpis } from './compute/computePricingDisciplineKpis';
import { computeFunnelKpis } from './compute/computeFunnelKpis';
import { computeProductionKpis } from './compute/computeProductionKpis';
import { computeDataIntegrityKpis } from './compute/computeDataIntegrityKpis';
import { base44 } from '@/api/base44Client';

/**
 * Get complete KPI dashboard packet
 */
export async function getKpiDashboard({ companyId, range, filters, groupBy, forceRefresh }) {
    // Check cache
    const cacheKey = buildCacheKey(companyId, range, filters, groupBy);
    
    if (!forceRefresh) {
        const cached = getCached(cacheKey);
        if (cached) {
            return { ...cached, cache: { hit: true, key: cacheKey } };
        }
    }
    
    console.log('[KPI Analytics] Computing dashboard:', { companyId, range, filters });
    
    // Fetch CRMJobs once, then load snapshots based on them
    const allJobs = await base44.entities.CRMJob.filter({ companyId }, '-created_date', 2000);
    const snapshotMaps = await loadSnapshotMaps(allJobs);

    // Build all truth sets synchronously from shared data
    const sharedCtx = { allJobs, ...snapshotMaps, dateStart: range.start, dateEnd: range.end };

    const signedDeals = buildSignedDealsTruthSet({ ...sharedCtx, ...filters });
    const appointments = buildAppointmentsTruthSet({ ...sharedCtx, repId: filters?.repId });
    const production = buildProductionTruthSet({ ...sharedCtx, crewId: filters?.crewId });

    // Pricing discipline: filter signedDeals (no extra fetch)
    const pricingDiscipline = signedDeals
        .filter(d => d.modelSellPrice > 0 && d.presentedSellPrice > 0)
        .map(deal => {
            const deviation = Math.abs((deal.presentedSellPrice - deal.modelSellPrice) / deal.modelSellPrice);
            return { ...deal, deviation: deviation * 100, isOverride: deviation > 0.02 };
        });
    
    // Compute KPI sections
    const revenueKpis = computeRevenueKpis(signedDeals, appointments);
    const marginKpis = computeMarginKpis(signedDeals);
    // pricingDiscipline truth set is already filtered to jobs with valid model prices
    // computePricingDisciplineKpis uses scalar fields (modelSellPrice, agreedSubtotal, overrideApplied)
    const pricingKpis = computePricingDisciplineKpis(pricingDiscipline);
    const funnelKpis = computeFunnelKpis(appointments, signedDeals);
    const productionKpis = computeProductionKpis(production);
    const integrityKpis = computeDataIntegrityKpis(signedDeals);
    
    // Build dashboard packet
    const dashboard = {
        summary: {
            signedRevenue: revenueKpis.totalRevenue,
            netProfit: marginKpis.totalNetProfit,
            netMarginPct: marginKpis.netMarginPct,
            profitPerApptRan: revenueKpis.profitPerApptRan,
            overrideRatePct: pricingKpis.overrideRatePct,
            modelCoveragePct: pricingKpis.modelCoveragePct
        },
        sections: {
            revenue: revenueKpis,
            margin: marginKpis,
            pricingDiscipline: pricingKpis,
            funnel: funnelKpis,
            production: productionKpis,
            dataIntegrity: integrityKpis
        },
        integrity: integrityKpis.summary,
        cache: { hit: false, key: cacheKey }
    };
    
    // Cache result
    setCached(cacheKey, dashboard);
    
    return dashboard;
}