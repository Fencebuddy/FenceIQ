import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405 });

  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user || user.role !== 'admin') return Response.json({ error: 'Admin required' }, { status: 403 });

  const { jobId } = await req.json();
  if (!jobId) return Response.json({ error: 'jobId required' }, { status: 400 });

  const jobs = await base44.asServiceRole.entities.CRMJob.filter({ id: jobId });
  if (!jobs.length) return Response.json({ error: 'Job not found' }, { status: 404 });
  const job = jobs[0];

  const bpOpportunityId = job.builderPrimeOpportunityId || job.externalOpportunityId;
  if (!bpOpportunityId) return Response.json({ error: 'Not a BP-sourced job (no builderPrimeOpportunityId)' }, { status: 400 });
  if (!job.leadDisposition) return Response.json({ error: 'No disposition recorded on this job yet' }, { status: 400 });

  // Fetch latest disposition event
  const allEvents = await base44.asServiceRole.entities.LeadDispositionEvent.filter({ jobId });
  allEvents.sort((a, b) => (b.dispositionRevision || 0) - (a.dispositionRevision || 0));
  const latestEvent = allEvents[0];

  // Fetch payment ledger
  const ledgerRows = await base44.asServiceRole.entities.PaymentLedgerEvent.filter({ jobId });

  const now = new Date().toISOString();
  const newRevision = (job.dispositionRevision || 0) + 1;
  const idempotencyKey = `bp_closeout::${bpOpportunityId}::rev::${newRevision}`;

  // Check no duplicate
  const existing = await base44.asServiceRole.entities.OutboundIntegrationEvent.filter({ idempotencyKey });
  if (existing.length > 0) {
    return Response.json({ status: 'already_exists', idempotencyKey, outboundEventId: existing[0].id });
  }

  const closeoutPayload = {
    eventType: 'bp_closeout_report',
    externalSource: 'builder_prime',
    companyId: job.companyId,
    jobId,
    builderPrimeOpportunityId: bpOpportunityId,
    builderPrimeClientId: job.builderPrimeClientId || job.externalCustomerId || null,
    customerName: job.customerName || null,
    disposition: job.leadDisposition,
    reason: job.leadDispositionReason || null,
    notes: job.leadDispositionNotes || null,
    dispositionAt: job.leadDispositionAt || now,
    isFinalDisposition: job.isFinalDisposition || false,
    salesRep: job.salesRepName || null,
    leadSetter: job.leadSetterName || null,
    rescheduledAppointmentStart: job.rescheduledAppointmentStart || null,
    rescheduledAppointmentEnd: job.rescheduledAppointmentEnd || null,
    contract: latestEvent ? {
      contractNumber: latestEvent.contractNumber || null,
      signedAt: latestEvent.contractSignedAt || null,
      contractValueCents: latestEvent.contractValueCents || 0,
      documentUrl: latestEvent.contractDocumentUrl || null,
      signedDocumentUrl: latestEvent.signedContractDocumentUrl || null,
      signatureCaptured: latestEvent.signatureCaptured || false,
      signatureProvider: latestEvent.signatureProvider || null,
    } : null,
    payments: {
      depositCollectedCents: job.depositCollectedCents || 0,
      totalCollectedCents: job.totalCollectedCents || 0,
      balanceRemainingCents: job.balanceRemainingCents || 0,
      paymentStatus: null,
      ledger: ledgerRows.map(r => ({
        paymentEventType: r.paymentEventType,
        paymentDate: r.paymentDate,
        amountCents: r.amountCents,
        paymentMethod: r.paymentMethod || null,
        processor: r.processor || null,
        referenceNumber: r.referenceNumber || null,
        notes: r.notes || null,
      })),
    },
    dispositionRevision: newRevision,
    reportedFrom: 'fenceiq',
    rebuiltByUserId: user.id,
    rebuiltAt: now,
  };

  // Increment revision on job
  await base44.asServiceRole.entities.CRMJob.update(jobId, {
    dispositionRevision: newRevision,
    bpOutcomeReportingStatus: 'pending',
  });

  const outboundEvent = await base44.asServiceRole.entities.OutboundIntegrationEvent.create({
    companyId: job.companyId,
    destination: 'builder_prime_closeout',
    eventType: 'bp_closeout_report',
    sourceEntity: 'CRMJob',
    sourceEntityId: jobId,
    jobId,
    builderPrimeOpportunityId: bpOpportunityId,
    builderPrimeClientId: job.builderPrimeClientId || job.externalCustomerId || null,
    payloadJson: JSON.stringify(closeoutPayload),
    status: 'pending',
    attemptCount: 0,
    nextAttemptAt: now,
    idempotencyKey,
    dispositionRevision: newRevision,
    triggeredByUserId: user.id,
    createdAt: now,
  });

  return Response.json({
    status: 'queued',
    outboundEventId: outboundEvent.id,
    idempotencyKey,
    dispositionRevision: newRevision,
  });
});