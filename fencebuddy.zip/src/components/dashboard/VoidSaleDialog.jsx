import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AlertTriangle } from "lucide-react";
import { toast } from "react-hot-toast";

export default function VoidSaleDialog({ job, onClose, onSuccess }) {
    const [reason, setReason] = useState("");
    const [loading, setLoading] = useState(false);

    const handleVoid = async () => {
        if (reason.trim().length < 5) {
            toast.error("Please provide a reason (min 5 characters)");
            return;
        }

        setLoading(true);
        try {
            const result = await base44.functions.invoke('sales/voidSale', {
                crmJobId: job.id,
                reason: reason.trim()
            });

            if (!result?.data?.ok) {
                throw new Error(result?.data?.error || 'Void failed');
            }

            toast.success(`Sale voided for ${job.customerName || job.jobNumber}`);
            onSuccess();
        } catch (err) {
            toast.error(err.message || 'Failed to void sale');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-md">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-red-400">
                        <AlertTriangle className="w-5 h-5" />
                        Void Sale
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                    <div className="bg-red-900/30 border border-red-500/30 rounded-lg p-3 text-sm text-red-200">
                        <p className="font-medium mb-1">{job.customerName || job.jobNumber}</p>
                        <p className="text-xs text-red-300">
                            Contract value: ${((job.contractValueCents || 0) / 100).toLocaleString()}
                        </p>
                        <p className="text-xs text-slate-400 mt-2">
                            This will immediately remove this job from all revenue reporting. This action cannot be automatically undone.
                        </p>
                    </div>

                    <div>
                        <Label className="text-slate-300 text-sm mb-1 block">Reason for voiding *</Label>
                        <Textarea
                            value={reason}
                            onChange={e => setReason(e.target.value)}
                            placeholder="e.g. Customer cancelled after signing, financing fell through..."
                            className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-500 min-h-[80px]"
                        />
                    </div>
                </div>

                <DialogFooter className="gap-2">
                    <Button variant="outline" onClick={onClose} className="border-slate-600 text-slate-300">
                        Cancel
                    </Button>
                    <Button
                        variant="destructive"
                        onClick={handleVoid}
                        disabled={loading || reason.trim().length < 5}
                    >
                        {loading ? "Voiding..." : "Void Sale"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}