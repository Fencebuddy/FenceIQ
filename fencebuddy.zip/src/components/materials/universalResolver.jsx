/**
 * GENESIS RESOLVER - STRICT DETERMINISTIC
 * 
 * ARCHITECTURAL RULES:
 * 1. ONLY CompanySkuMap is valid data source
 * 2. NO legacy paths, NO fallbacks, NO guessing
 * 3. PLAIN UCK STRING MATCH — no attributes hash needed
 *    (Confirmed: all production CompanySkuMap rows have attributes: null)
 * 4. Every unresolved item is returned (no creation of tracking records)
 * 
 * STEP 2 DECISION (2026-02-28): Option A confirmed from production data audit.
 * mappingKey hash was functionally equivalent to plain UCK match in all real rows.
 * Simplified to UCK-only lookup matching sharedCatalogResolver behavior.
 */

import { base44 } from '@/api/base44Client';
import { normalizeQuantity } from './normalizeQuantity';

export async function resolveLineItemsWithMappings({ companyId, lineItems, catalog, companySkuMap }) {
  if (!companyId) {
    throw new Error('[GenesisResolver] companyId is required');
  }

  if (!Array.isArray(lineItems) || lineItems.length === 0) {
    return {
      lineItems: [],
      summary: {
        resolved_count: 0,
        unresolved_count: 0,
        pricing_status: 'COMPLETE',
        unresolved: []
      }
    };
  }

  console.log('[GenesisResolver] START', {
    companyId,
    lineItems: lineItems.length,
    catalog: catalog?.length || 0,
    preloadedMappings: companySkuMap?.length || 0
  });

  // Use pre-fetched CompanySkuMap (ONLY valid source)
  const allMappings = companySkuMap !== undefined 
    ? companySkuMap 
    : await base44.entities.CompanySkuMap.filter({ companyId });

  // Build lookup by plain UCK string (Option A confirmed: no attributes on any production row)
  const mappingByUck = new Map();
  allMappings.forEach(m => {
    if (m.uck) mappingByUck.set(m.uck, m);
  });

  console.log('[GenesisResolver] Mapping Lookup', {
    totalMappings: mappingByUck.size
  });

  // Build catalog lookup by ID
  const catalogLookup = new Map();
  (catalog || []).forEach(c => {
    catalogLookup.set(c.id, c);
  });

  const enrichedItems = [];
  const unresolvedList = [];
  let resolvedCount = 0;
  let unresolvedCount = 0;

  // GENESIS RESOLVER: 3-step match for each item
  for (let i = 0; i < lineItems.length; i++) {
    const item = lineItems[i];
    
    try {
      const uck = item.uck;
      
      if (!uck) {
        unresolvedCount++;
        unresolvedList.push({
          displayName: item.displayName || item.lineItemName || 'Unknown',
          uck: null,
          qty: item.quantityCalculated || item.qty || 0,
          reason: 'MISSING_UCK'
        });
        continue;
      }

      // PLAIN UCK LOOKUP — matches sharedCatalogResolver behavior
      // (Option A confirmed 2026-02-28: all production rows have attributes: null)
      const mapping = mappingByUck.get(uck);
      const matchType = mapping ? 'mapped' : null;

      // No match = unresolved
      if (!mapping) {
        unresolvedCount++;
        unresolvedList.push({
          displayName: item.displayName || item.lineItemName || uck,
          uck,
          qty: item.quantityCalculated || item.qty || 0,
          reason: 'NO_MAPPING'
        });
        continue;
      }

      // Validate mapping points to valid catalog item
      if (!mapping.materialCatalogId) {
        unresolvedCount++;
        unresolvedList.push({
          displayName: item.displayName || item.lineItemName || uck,
          uck,
          qty: item.quantityCalculated || item.qty || 0,
          reason: 'BROKEN_MAPPING_NO_CATALOG_ID'
        });
        continue;
      }

      // Fetch catalog item
      const catalogItem = catalogLookup.get(mapping.materialCatalogId);
      if (!catalogItem) {
        unresolvedCount++;
        unresolvedList.push({
          displayName: item.displayName || item.lineItemName || uck,
          uck,
          qty: item.quantityCalculated || item.qty || 0,
          reason: 'BROKEN_MAPPING_DELETED_CATALOG'
        });
        continue;
      }

      // Normalize quantity
      const engineQty = item.quantityCalculated || item.qty || 0;
      const engineUnit = item.uom || item.unit || 'EA';
      
      const normalized = normalizeQuantity({
        qty: engineQty,
        engineUnit,
        catalogItem
      });

      // Calculate pricing
      const unitCost = catalogItem.cost || catalogItem.unit_cost || 0;
      const extendedCost = normalized.quantity * unitCost;

      resolvedCount++;
      enrichedItems.push({
        ...item,
        uck,
        resolved: true,
        mappingFound: true,
        matchType,
        quantity: normalized.quantity,
        unit: normalized.unit,
        unit_cost: unitCost,
        extended_cost: extendedCost,
        catalog_name: catalogItem.crm_name || catalogItem.name,
        catalog_id: catalogItem.id,
        mapping_id: mapping.id,
        wasNormalized: normalized.wasNormalized,
        resolverOutcome: 'RESOLVED'
      });

    } catch (error) {
      unresolvedCount++;
      console.error(`[GenesisResolver] ERROR resolving item ${i}:`, error);
      unresolvedList.push({
        displayName: item.displayName || item.lineItemName || 'Unknown',
        uck: item.uck,
        qty: item.quantityCalculated || item.qty || 0,
        reason: 'RESOLVER_ERROR',
        error: error.message
      });
    }
  }

  const pricingStatus = unresolvedCount > 0 ? 'INCOMPLETE' : 'COMPLETE';

  console.log('[GenesisResolver] COMPLETE', {
    resolved: resolvedCount,
    unresolved: unresolvedCount,
    pricingStatus
  });

  return {
    lineItems: enrichedItems,
    summary: {
      resolved_count: resolvedCount,
      unresolved_count: unresolvedCount,
      pricing_status: pricingStatus,
      unresolved: unresolvedList
    }
  };
}

/**
 * Split double gate into leaf line items for pricing (6/8/10/12 ft only)
 */
export function splitDoubleGateIntoLeaves(doubleWidthFt) {
  const splits = {
    6: 3,
    8: 4,
    10: 5,
    12: 6
  };
  
  const leafWidth = splits[doubleWidthFt];
  
  if (!leafWidth) {
    return null;
  }
  
  return { leafWidthFt: leafWidth, count: 2 };
}