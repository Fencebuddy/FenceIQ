/**
 * PRICING IQ v1.0 LOCKED (2026-01-19)
 * DO NOT MODIFY WITHOUT EXPLICIT v2 VERSIONING
 * 
 * Deterministic pricing engine with locked formulas
 */

const PRICING_VERSION = 'v1.0_locked';

// Default business constants (can be overridden via CompanySettings later)
const DEFAULTS = {
  max_discount: 0.15,
  overhead_rate: 0.14,
  commission_rate: 0.10,
  required_net_margin_non_wood: 0.20,
  required_net_margin_wood: 0.36,
};

function toNumber(val, fallback = 0) {
  const n = Number(val);
  return Number.isFinite(n) ? n : fallback;
}

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function computePricingV1Locked({
  // required inputs
  resolvedItems,
  total_lf,
  material_type, // 'WOOD' | 'VINYL' | 'CHAIN_LINK' | 'ALUMINUM' | etc

  // optional inputs
  discount_percentage = 0,
  tear_out_cost = 0,
  delivery_cost = 0,
  labor_per_lf = 0,

  // contracts
  takeoff_hash,
  retail_anchor_override = null, // { retail_price, divisor_inputs, takeoff_hash, pricing_version, createdAt }

  // allow future overrides
  pricingConstants = {},
}) {
  const C = { ...DEFAULTS, ...pricingConstants };

  const discount = Math.min(Math.max(toNumber(discount_percentage, 0), 0), C.max_discount);

  // STEP 1: material_cost
  // Expect each resolved item to provide a resolvedCost or (qty * unit_cost).
  // Your resolver should have already normalized units and flagged mismatches.
  const material_cost = round2(
    (resolvedItems || []).reduce((sum, item) => {
      // Prefer explicit computed value from resolver (recommended)
      if (Number.isFinite(Number(item?.extendedCost))) return sum + Number(item.extendedCost);

      const qty = toNumber(item?.quantity, 0);
      const unitCost = toNumber(item?.unit_cost ?? item?.cost ?? item?.catalogCost, 0);
      return sum + qty * unitCost;
    }, 0)
  );

  const totalLF = toNumber(total_lf, 0);
  const laborPerLF = toNumber(labor_per_lf, 0);
  const tearOut = toNumber(tear_out_cost, 0);
  const delivery = toNumber(delivery_cost, 0);

  const labor_cost = round2(totalLF * laborPerLF + tearOut);
  const direct_cost = round2(material_cost + labor_cost + delivery);

  // STEP 2: retail anchor divisor
  const isWood = String(material_type || '').toUpperCase() === 'WOOD';
  const required_net_margin = isWood ? C.required_net_margin_wood : C.required_net_margin_non_wood;

  const divisor_inputs = {
    max_discount: C.max_discount,
    overhead_rate: C.overhead_rate,
    commission_rate: C.commission_rate,
    required_net_margin,
  };

  const divisor = (1 - C.max_discount) * (1 - C.overhead_rate - C.commission_rate - required_net_margin);

  if (!(divisor > 0)) {
    return {
      pricingStatus: 'BLOCKED',
      blockedReasons: [
        {
          code: 'DIVISOR_INVALID',
          message: 'Pricing divisor computed <= 0. Check margin/overhead/commission constants.',
          details: { divisor, divisor_inputs },
        },
      ],
    };
  }

  // Retail anchor reuse rules
  let retail_price;
  let retail_anchor;

  const anchorOk =
    retail_anchor_override &&
    retail_anchor_override.pricing_version === PRICING_VERSION &&
    retail_anchor_override.takeoff_hash &&
    takeoff_hash &&
    retail_anchor_override.takeoff_hash === takeoff_hash &&
    Number.isFinite(Number(retail_anchor_override.retail_price)) &&
    Number(retail_anchor_override.retail_price) > 0;

  if (anchorOk) {
    retail_price = round2(Number(retail_anchor_override.retail_price));
    retail_anchor = retail_anchor_override;
  } else {
    retail_price = round2(direct_cost / divisor);
    retail_anchor = {
      retail_price,
      divisor_inputs,
      takeoff_hash: takeoff_hash || null,
      pricing_version: PRICING_VERSION,
      createdAt: new Date().toISOString(),
    };
  }

  // STEP 3: sale price
  const sale_price = round2(retail_price * (1 - discount));

  // STEP 4: allocations based on SALE price
  const overhead = round2(sale_price * C.overhead_rate);
  const commission = round2(sale_price * C.commission_rate);

  // STEP 5: profit
  const total_job_cost = round2(direct_cost + overhead + commission);
  const net_profit = round2(sale_price - total_job_cost);

  const net_margin = sale_price > 0 ? net_profit / sale_price : 0;
  const gross_margin = sale_price > 0 ? (sale_price - direct_cost) / sale_price : 0;

  return {
    pricingStatus: 'COMPLETE',
    pricing_breakdown: {
      pricing_version: PRICING_VERSION,

      inputs: {
        total_lf: totalLF,
        labor_per_lf: laborPerLF,
        tear_out_cost: tearOut,
        delivery_cost: delivery,
        discount_percentage: discount,
        material_type: material_type || null,
      },

      costs: {
        material_cost,
        labor_cost,
        delivery_cost: delivery,
        direct_cost,
      },

      retail: {
        divisor,
        divisor_inputs,
        retail_price,
        retail_anchor_reused: anchorOk,
      },

      sale: {
        sale_price,
      },

      allocations: {
        overhead_rate: C.overhead_rate,
        commission_rate: C.commission_rate,
        overhead,
        commission,
      },

      profit: {
        total_job_cost,
        net_profit,
        net_margin,
        gross_margin,
      },
    },
    retail_anchor,
  };
}