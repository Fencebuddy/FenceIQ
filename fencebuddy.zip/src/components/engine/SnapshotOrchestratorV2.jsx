/**
 * SNAPSHOT ORCHESTRATOR V2
 * 
 * CONTRACT 7: RETAIL ANCHOR STORAGE
 * Retail anchor computed once per (variantKey + takeoff_hash + pricing_version)
 * Stored immutably, reused automatically
 * 
 * Replaces:
 * - snapshotService.js
 * - simplePricingEngine.js
 */

import { ENGINE_VERSIONS, stampVersions } from './versions';
import { generateGeometryChecksum, generateTakeoffHash, generatePricingInputHash } from './checksums';
import { base44 } from '@/api/base44Client';

/**
 * Create or get TakeoffSnapshot with deduplication by takeoff_hash
 */
export async function getOrCreateTakeoffSnapshot({
  jobId,
  variantKey,
  geometryResult,
  takeoffResult,
  runs,
  gates
}) {
  const takeoff_hash = takeoffResult.takeoff_hash;
  
  // Check for existing snapshot with same hash
  const existing = await base44.entities.TakeoffSnapshot.filter({
    jobId,
    takeoff_hash
  });
  
  if (existing.length > 0) {
    console.log('[SnapshotOrchestrator] Reusing TakeoffSnapshot:', existing[0].id);
    return existing[0];
  }
  
  // Create new snapshot
  const snapshotData = stampVersions({
    jobId,
    geometry_checksum: geometryResult.geometry_checksum,
    takeoff_hash,
    material_type: takeoffResult.variantConfig?.materialType,
    total_lf: geometryResult.total_lf,
    line_items: takeoffResult.line_items,
    run_breakdown: runs?.map(r => ({
      runLabel: r.runLabel,
      lengthLF: r.lengthLF,
      materialType: r.materialType
    })) || [],
    gates_list: gates?.map(g => ({
      gateType: g.gateType,
      gateWidth_ft: g.gateWidth_ft,
      runId: g.runId
    })) || [],
    post_counts: takeoffResult.post_counts || {},
    locked: true,
    source: 'MAP_DRIVEN',
    status: 'complete'
  });
  
  const snapshot = await base44.entities.TakeoffSnapshot.create(snapshotData);
  
  console.log('[SnapshotOrchestrator] Created TakeoffSnapshot:', snapshot.id);
  
  return snapshot;
}

/**
 * Create or update JobCostSnapshot with retail anchor reuse
 * 
 * CONTRACT 7: Retail anchor frozen per takeoff_hash + pricing_version
 */
export async function getOrCreateJobCostSnapshot({
  jobId,
  variantKey,
  takeoffSnapshot,
  pricingResult,
  scenario_tier = 'CURRENT'
}) {
  const takeoff_hash = takeoffSnapshot.takeoff_hash;
  const pricing_version = ENGINE_VERSIONS.PRICING_VERSION;
  
  // Check for existing snapshot with same takeoff_hash + pricing_version
  const existing = await base44.entities.JobCostSnapshot.filter({
    jobId,
    takeoff_snapshot_id: takeoffSnapshot.id,
    scenario_tier,
    pricing_version
  });
  
  // Compute pricing input hash for anchor reuse validation
  const pricing_input_hash = generatePricingInputHash({
    material_cost: pricingResult.pricing_breakdown.material_cost,
    total_lf: pricingResult.pricing_breakdown.total_lf || takeoffSnapshot.total_lf,
    material_type: pricingResult.pricing_breakdown.material_type,
    labor_per_lf: pricingResult.pricing_breakdown.labor_per_lf || 10,
    delivery_cost: pricingResult.pricing_breakdown.delivery_cost || 75,
    tear_out_cost: pricingResult.pricing_breakdown.tear_out_cost || 0
  });
  
  if (existing.length > 0) {
    // Check if retail anchor can be reused
    const canReuseAnchor = 
      existing[0].retail_anchor && 
      existing[0].pricing_input_hash === pricing_input_hash;
    
    if (canReuseAnchor) {
      console.log('[SnapshotOrchestrator] Reusing retail anchor:', existing[0].retail_anchor);
      return existing[0];
    }

    // PHASE 4: Enforce locked flag — never mutate a locked snapshot
    // A locked snapshot was the basis for a customer proposal; overwriting it breaks reproducibility.
    // Instead, create a new versioned snapshot so the old one remains intact.
    if (existing[0].locked) {
      console.warn('[SnapshotOrchestrator] ⚠️ Existing JobCostSnapshot is locked — creating new version instead of mutating', {
        existingId: existing[0].id,
        jobId,
        scenario_tier,
        pricing_version
      });
      // Fall through to create a new snapshot below
    } else {
      // Unlocked — safe to update in place
      const updated = await base44.entities.JobCostSnapshot.update(existing[0].id, {
        pricing_breakdown: pricingResult.pricing_breakdown,
        retail_anchor: pricingResult.retail_anchor,
        retail_anchor_source: pricingResult.retail_anchor_source,
        pricing_input_hash,
        sell_price: pricingResult.pricing_breakdown.sale_price,
        material_cost: pricingResult.pricing_breakdown.material_cost,
        labor_cost: pricingResult.pricing_breakdown.labor_cost
      });
      
      console.log('[SnapshotOrchestrator] Updated JobCostSnapshot (unlocked):', updated.id);
      return updated;
    }
  }
  
  // Create new snapshot
  const snapshotData = stampVersions({
    jobId,
    takeoff_snapshot_id: takeoffSnapshot.id,
    scenario_tier,
    takeoff_hash,
    pricing_input_hash,
    retail_anchor: pricingResult.retail_anchor,
    retail_anchor_source: pricingResult.retail_anchor_source,
    total_lf: takeoffSnapshot.total_lf,
    material_cost: pricingResult.pricing_breakdown.material_cost,
    labor_cost: pricingResult.pricing_breakdown.labor_cost,
    delivery_cost: pricingResult.pricing_breakdown.delivery_cost || 75,
    direct_cost: pricingResult.pricing_breakdown.direct_cost,
    sell_price: pricingResult.pricing_breakdown.sale_price,
    net_margin: pricingResult.pricing_breakdown.net_margin / 100,
    pricing_breakdown: pricingResult.pricing_breakdown,
    locked: true,
    active: true,
    status: 'complete'
  });
  
  const snapshot = await base44.entities.JobCostSnapshot.create(snapshotData);
  
  console.log('[SnapshotOrchestrator] Created JobCostSnapshot:', snapshot.id);
  
  return snapshot;
}

/**
 * Invalidate downstream snapshots
 */
export async function invalidateDownstreamSnapshots({ jobId, reason }) {
  console.log('[SnapshotOrchestrator] Invalidating snapshots:', reason);
  
  await base44.entities.Job.update(jobId, {
    active_takeoff_snapshot_id: null,
    active_pricing_snapshot_id: null,
    pricing_status: 'NEEDS_RECALC',
    map_state_hash: null
  });
}