/**
 * SHARED CATALOG RESOLVER
 * 
 * Unified resolution path used by ALL flows:
 * - Resolvers (ResolverEngine, universalResolver)
 * - Pricing (computeCurrentPricing, pricingService)
 * - Reports/exports
 * 
 * Contract:
 * 1. ALWAYS use CompanySkuMap first (UCK → mapping → catalogId)
 * 2. NEVER fallback to direct canonical_key→catalog lookup
 * 3. FAIL explicitly if mapping missing (strict mode)
 * 4. No SKU involvement anywhere
 */

import { base44 } from '@/api/base44Client';

/**
 * Resolve a canonical_key to a MaterialCatalog item for a specific company
 * 
 * @param {object} params
 * @param {string} params.companyId - Company identifier (required)
 * @param {string} params.canonicalKey - UCK/canonical_key to resolve (required)
 * @param {object} params.preloadedMappings - Pre-fetched CompanySkuMap array (optional, for performance)
 * @param {object} params.preloadedCatalog - Pre-fetched MaterialCatalog array (optional, for performance)
 * @param {boolean} params.strictMode - If true, throw on missing mapping (default: true)
 * 
 * @returns {Promise<object>} {
 *   resolved: boolean,
 *   catalogItem: object | null,
 *   mapping: object | null,
 *   reason: string,
 *   cost: number | null
 * }
 */
export async function resolveCatalogItemForCompany({
  companyId,
  canonicalKey,
  preloadedMappings = null,
  preloadedCatalog = null,
  strictMode = true
}) {
  // Validate inputs
  if (!companyId) {
    throw new Error('[SharedResolver] companyId is required');
  }

  if (!canonicalKey) {
    return {
      resolved: false,
      catalogItem: null,
      mapping: null,
      reason: 'MISSING_CANONICAL_KEY',
      cost: null
    };
  }

  // STEP 1: Fetch or use preloaded CompanySkuMap
  let mappings = preloadedMappings;
  if (!mappings) {
    mappings = await base44.entities.CompanySkuMap.filter({ 
      companyId,
      uck: canonicalKey
    });
  }

  // STEP 2: Try to find mapping for this UCK
  const mapping = mappings?.find(m => m.uck === canonicalKey);

  if (!mapping) {
    const error = {
      resolved: false,
      catalogItem: null,
      mapping: null,
      reason: 'NO_MAPPING',
      cost: null,
      detail: `No CompanySkuMap entry for UCK: ${canonicalKey}`
    };

    if (strictMode) {
      console.warn('[SharedResolver] Mapping not found:', canonicalKey);
    }

    return error;
  }

  // STEP 3: Validate mapping has catalog ID
  if (!mapping.materialCatalogId) {
    return {
      resolved: false,
      catalogItem: null,
      mapping,
      reason: 'BROKEN_MAPPING_NO_CATALOG_ID',
      cost: null,
      detail: 'Mapping exists but materialCatalogId is missing'
    };
  }

  // STEP 4: Fetch or use preloaded MaterialCatalog
  let catalog = preloadedCatalog;
  if (!catalog) {
    catalog = await base44.entities.MaterialCatalog.filter({ 
      id: mapping.materialCatalogId 
    });
  }

  // STEP 5: Find catalog item
  const catalogItem = Array.isArray(catalog)
    ? catalog.find(c => c.id === mapping.materialCatalogId)
    : catalog?.id === mapping.materialCatalogId ? catalog : null;

  if (!catalogItem) {
    return {
      resolved: false,
      catalogItem: null,
      mapping,
      reason: 'CATALOG_ITEM_DELETED',
      cost: null,
      detail: `Catalog item deleted: ${mapping.materialCatalogId}`
    };
  }

  // STEP 6: Return resolved item with cost
  return {
    resolved: true,
    catalogItem,
    mapping,
    reason: 'RESOLVED',
    cost: catalogItem.cost || 0,
    unit_cost: catalogItem.cost || 0,
    catalog_id: catalogItem.id,
    catalog_name: catalogItem.crm_name
  };
}

/**
 * Batch resolve multiple canonical keys
 * More efficient than calling resolveCatalogItemForCompany in a loop
 */
export async function resolveBatchCatalogItems({
  companyId,
  canonicalKeys,
  strictMode = true
}) {
  // Fetch data once
  const [mappings, catalogItems] = await Promise.all([
    base44.entities.CompanySkuMap.filter({ companyId }),
    base44.entities.MaterialCatalog.filter({ active: true })
  ]);

  // Build lookup maps
  const mappingsByUck = {};
  mappings.forEach(m => {
    mappingsByUck[m.uck] = m;
  });

  const catalogById = {};
  catalogItems.forEach(c => {
    catalogById[c.id] = c;
  });

  // Resolve each key
  const results = [];
  for (const uck of canonicalKeys) {
    const result = await resolveCatalogItemForCompany({
      companyId,
      canonicalKey: uck,
      preloadedMappings: mappings,
      preloadedCatalog: catalogItems,
      strictMode
    });
    results.push({
      canonicalKey: uck,
      ...result
    });
  }

  return results;
}

/**
 * Health check: Verify resolver is working correctly for a company
 */
export async function verifyResolverHealth({
  companyId,
  sampleSize = 10
}) {
  try {
    // Get sample mappings
    const mappings = await base44.entities.CompanySkuMap.filter({ 
      companyId,
      status: 'mapped'
    });

    if (mappings.length === 0) {
      return {
        healthy: false,
        reason: 'NO_MAPPINGS',
        coverage: 0,
        sampleResults: []
      };
    }

    // Test sample
    const sampleMappings = mappings.slice(0, sampleSize);
    const sampleResults = [];

    for (const mapping of sampleMappings) {
      const result = await resolveCatalogItemForCompany({
        companyId,
        canonicalKey: mapping.uck,
        strictMode: false
      });

      sampleResults.push({
        uck: mapping.uck,
        resolved: result.resolved,
        reason: result.reason
      });
    }

    const successCount = sampleResults.filter(r => r.resolved).length;
    const coverage = successCount / sampleResults.length;

    return {
      healthy: coverage >= 0.9, // 90%+ success rate
      coverage: Math.round(coverage * 100),
      sampleResults,
      totalMappings: mappings.length
    };
  } catch (error) {
    return {
      healthy: false,
      reason: 'RESOLVER_ERROR',
      error: error.message
    };
  }
}