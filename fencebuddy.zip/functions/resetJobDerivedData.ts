import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * ADMIN-ONLY: Reset all job derived data (snapshots + cached data)
 * Triggered by "Reset Job Derived Data" button on JobCost page
 * Forces complete rebuild on next load
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { jobId } = await req.json();

    if (!jobId) {
      return Response.json({ error: 'jobId is required' }, { status: 400 });
    }

    console.log(`[resetJobDerivedData] Starting reset for job: ${jobId}`);

    // 1. Delete TakeoffSnapshot records
    const snapshots = await base44.entities.TakeoffSnapshot.filter({ jobId });
    for (const snap of snapshots) {
      await base44.entities.TakeoffSnapshot.delete(snap.id);
      console.log(`[resetJobDerivedData] Deleted TakeoffSnapshot: ${snap.id}`);
    }

    // 2. Delete JobCostSnapshot records
    const costSnapshots = await base44.entities.JobCostSnapshot.filter({ jobId });
    for (const snap of costSnapshots) {
      await base44.entities.JobCostSnapshot.delete(snap.id);
      console.log(`[resetJobDerivedData] Deleted JobCostSnapshot: ${snap.id}`);
    }

    // 3. Clear job references
    await base44.entities.Job.update(jobId, {
      active_takeoff_snapshot_id: null,
      active_pricing_snapshot_id: null,
      pricing_status: 'NEEDS_RECALC'
    });

    console.log(`[resetJobDerivedData] ✅ Reset complete for job: ${jobId}`);

    return Response.json({
      success: true,
      jobId,
      message: 'Job derived data reset - will rebuild on next load',
      deleted: {
        takeoff_snapshots: snapshots.length,
        cost_snapshots: costSnapshots.length
      }
    });
  } catch (error) {
    console.error('[resetJobDerivedData] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});