/**
 * TEST JOB TO CRM JOB SYNC
 * Phase 3: Run dry-run backfill on small test batch
 * 
 * Called via: base44.functions.invoke('testJobToCrmJobSync', {
 *   companyId: "...",
 *   limit: 5,
 *   dryRun: true
 * })
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import {
  isJobSigned,
  backfillSignedJobsToCrmJobs
} from './_shared/jobToCrmJobSyncHelpers.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json(
        { error: 'Admin access required' },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { companyId, limit = 5, dryRun = true } = body;

    if (!companyId) {
      return Response.json(
        { error: 'companyId required' },
        { status: 400 }
      );
    }

    console.log('[testJobToCrmJobSync] Starting', {
      companyId,
      limit,
      dryRun,
      user: user.email
    });

    // Run backfill
    const result = await backfillSignedJobsToCrmJobs({
      companyId,
      dryRun,
      limit
    });

    return Response.json({
      success: true,
      dryRun,
      summary: {
        scanned: result.scanned,
        created: result.created,
        updated: result.updated,
        skipped: result.skipped,
        failed: result.failed
      },
      details: result.details,
      message: dryRun
        ? 'DRY RUN: Review results above. No changes committed.'
        : 'Changes committed to database.'
    });

  } catch (error) {
    console.error('[testJobToCrmJobSync] ERROR:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});