import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * TRIGGER: Data Integrity Check
 * Called by entity automations when snapshots/selection sets change
 * Orchestrates the data integrity agent with proper logging
 */

Deno.serve(async (req) => {
  const startTime = Date.now();
  
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data, old_data } = payload;
    
    // Get feature flags (in production, fetch from CompanySettings)
    const dryRunMode = true; // SAFE DEFAULT
    const agentEnabled = true;
    
    if (!agentEnabled) {
      console.log('[DataIntegrity] Agent disabled by feature flag');
      return Response.json({ skipped: true, reason: 'Agent disabled' });
    }
    
    const companyId = data?.companyId || "PrivacyFenceCo49319";
    const triggerType = event.type === 'create' ? 'entity_create' : 'entity_update';
    
    // Call the data integrity agent
    let result;
    try {
      const response = await base44.asServiceRole.functions.invoke('dataIntegrityAgent', {
        companyId,
        triggerType,
        entityType: event.entity_name,
        entityId: event.entity_id,
        dryRunMode
      });
      result = response.data;
    } catch (error) {
      // Log failure but don't block entity operation
      await base44.asServiceRole.entities.AgentRunLog.create({
        companyId,
        agentName: 'dataIntegrityAgent',
        triggerType,
        triggerEntityType: event.entity_name,
        triggerEntityId: event.entity_id,
        status: 'error',
        dryRun: dryRunMode,
        durationMs: Date.now() - startTime,
        errorMessage: error.message,
        ranAt: new Date().toISOString()
      });
      
      throw error;
    }
    
    // Log successful run
    await base44.asServiceRole.entities.AgentRunLog.create({
      companyId,
      agentName: 'dataIntegrityAgent',
      triggerType,
      triggerEntityType: event.entity_name,
      triggerEntityId: event.entity_id,
      status: 'success',
      dryRun: dryRunMode,
      durationMs: Date.now() - startTime,
      findings: result,
      ranAt: new Date().toISOString()
    });
    
    return Response.json({ 
      success: true,
      dryRun: dryRunMode,
      result 
    });
    
  } catch (error) {
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});