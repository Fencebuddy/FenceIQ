/**
 * Phase 12.5: Correlation ID Middleware
 * 
 * Generates or propagates x-correlation-id across all requests.
 * Attaches to MetricsEvent, AlertEvent, ReportRunLog for end-to-end tracing.
 * 
 * Thread into Base44 context (serviceRole + normal auth) to make it available
 * across all writes: MetricsEvent, AlertEvent, ReportRunLog, AutomationRunLog.
 */

/**
 * Global context for correlation ID (per-request storage).
 * In a production system, use AsyncLocalStorage or similar.
 * For now, thread as parameter.
 */
let currentCorrelationId: string | null = null;

/**
 * Generate or extract correlation ID from request.
 */
export function getOrCreateCorrelationId(req: Request): string {
  const existingId = req.headers.get('x-correlation-id');
  if (existingId) {
    return existingId;
  }

  // Generate UUID v4
  const uuid = crypto.randomUUID();
  return uuid;
}

/**
 * Set current correlation ID (called at request entry).
 */
export function setCorrelationId(id: string): void {
  currentCorrelationId = id;
}

/**
 * Get current correlation ID.
 */
export function getCorrelationId(): string {
  return currentCorrelationId || crypto.randomUUID();
}

/**
 * Attach correlation ID to response headers.
 */
export function attachCorrelationIdToResponse(response: Response, correlationId: string): Response {
  response.headers.set('x-correlation-id', correlationId);
  return response;
}

/**
 * Wrap a request handler with correlation ID support.
 */
export function withCorrelationId(handler: (req: Request, correlationId: string) => Promise<Response>) {
  return async (req: Request): Promise<Response> => {
    const correlationId = getOrCreateCorrelationId(req);
    try {
      const response = await handler(req, correlationId);
      return attachCorrelationIdToResponse(response, correlationId);
    } catch (error) {
      const errorResponse = Response.json(
        { error: error.message, correlationId },
        { status: 500 }
      );
      return attachCorrelationIdToResponse(errorResponse, correlationId);
    }
  };
}

/**
 * Log event with correlation ID.
 */
export interface LogEventWithCorrelationId {
  correlationId: string;
  eventName: string;
  severity?: 'info' | 'warn' | 'error' | 'critical';
  details?: Record<string, any>;
}

export function formatLogWithCorrelationId(event: LogEventWithCorrelationId): string {
  const { correlationId, eventName, severity, details } = event;
  const severityTag = severity ? `[${severity.toUpperCase()}]` : '[INFO]';
  const detailsStr = details ? ` ${JSON.stringify(details)}` : '';
  return `${severityTag} [${correlationId}] ${eventName}${detailsStr}`;
}