/**
 * REPAIR TOOL: Normalize vinyl UCKs to canonical token order
 * 
 * Enforces: vinyl_{component...}_{height}_{system}_{color}
 * 
 * Example:
 * vinyl_panel_privacy_6ft_white_savannah_white => vinyl_panel_privacy_6ft_savannah_white
 * vinyl_hardware_galvanized_post_6ft => vinyl_hardware_galvanized_post_6ft_savannah_white
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Inline parser (duplicate from vinylUckCanonicalizer for backend use)
const VINYL_HEIGHTS = ['3ft', '4ft', '5ft', '6ft', '8ft', '10ft', '12ft'];
const VINYL_SYSTEMS = ['savannah', 'lakeshore', 'yorktown'];
const VINYL_COLORS = ['white', 'tan', 'khaki', 'grey', 'coastal_grey', 'cedar_tone', 'black'];

function parseVinylUck(uck) {
  if (!uck || !uck.startsWith('vinyl_')) {
    return { valid: false, reason: 'Not a vinyl UCK' };
  }

  const tokens = uck.split('_').slice(1);
  
  if (tokens.length < 3) {
    return { valid: false, reason: 'Too few tokens' };
  }

  const heightIndex = tokens.findIndex(t => VINYL_HEIGHTS.includes(t));
  if (heightIndex === -1) {
    return { valid: false, reason: 'No height token found' };
  }
  const height = tokens[heightIndex];

  const tokensAfterHeight = tokens.slice(heightIndex + 1);
  const systemIndex = tokensAfterHeight.findIndex(t => VINYL_SYSTEMS.includes(t));
  const system = systemIndex !== -1 ? tokensAfterHeight[systemIndex] : 'savannah';

  const tokensAfterSystem = systemIndex !== -1 
    ? tokensAfterHeight.slice(systemIndex + 1) 
    : tokensAfterHeight;
  const colorIndex = tokensAfterSystem.findIndex(t => VINYL_COLORS.includes(t));
  const color = colorIndex !== -1 ? tokensAfterSystem[colorIndex] : 'white';

  const componentTokens = tokens.slice(0, heightIndex);

  return {
    valid: true,
    componentTokens,
    height,
    system,
    color
  };
}

function buildVinylUckCanonical(parsed) {
  if (!parsed.valid || !parsed.componentTokens || !parsed.height) {
    return null;
  }

  return `vinyl_${parsed.componentTokens.join('_')}_${parsed.height}_${parsed.system}_${parsed.color}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ 
        error: 'Forbidden: Admin access required' 
      }, { status: 403 });
    }
    
    const { companyId = 'PrivacyFenceCo49319', mode = 'dry_run' } = await req.json();
    const dryRun = mode === 'dry_run';
    
    console.log(`[repairVinylCanonicalUcks] Starting repair for company: ${companyId}, mode: ${mode}`);
    
    const allMappings = await base44.asServiceRole.entities.CompanySkuMap.filter({
      companyId,
      status: 'mapped'
    });
    
    console.log(`[repairVinylCanonicalUcks] Found ${allMappings.length} mapped rows`);
    
    const results = {
      totalChecked: allMappings.length,
      vinylCount: 0,
      needsRepair: 0,
      repaired: 0,
      collisions: 0,
      errors: [],
      repairs: []
    };
    
    // Process in batches to avoid rate limits
    const BATCH_SIZE = 10;
    const BATCH_DELAY_MS = 2000;
    
    let batchCount = 0;
    
    for (let i = 0; i < allMappings.length; i++) {
      const mapping = allMappings[i];
      const uck = mapping.uck;
      
      if (!uck.startsWith('vinyl_')) continue;
      
      results.vinylCount++;
      
      const parsed = parseVinylUck(uck);
      
      if (!parsed.valid) {
        console.log(`[repairVinylCanonicalUcks] ⚠️  Cannot parse: ${uck} (${parsed.reason})`);
        results.errors.push({
          uck,
          error: parsed.reason
        });
        continue;
      }
      
      const canonical = buildVinylUckCanonical(parsed);
      
      if (canonical === uck) {
        // Already canonical
        continue;
      }
      
      results.needsRepair++;
      console.log(`[repairVinylCanonicalUcks] [${i + 1}/${allMappings.length}] ${uck} => ${canonical}`);
      
      results.repairs.push({
        originalUck: uck,
        canonicalUck: canonical,
        mappingId: mapping.id
      });
      
      // Check for collision
      const existingCanonical = await base44.asServiceRole.entities.CompanySkuMap.filter({
        companyId,
        uck: canonical
      });
      
      if (existingCanonical.length > 0) {
        console.log(`[repairVinylCanonicalUcks] ⚠️  Collision: ${canonical} already exists`);
        results.collisions++;
        continue;
      }
      
      if (!dryRun) {
        try {
          // Create new canonical mapping
          await base44.asServiceRole.entities.CompanySkuMap.create({
            companyId: mapping.companyId,
            uck: canonical,
            uckVersion: mapping.uckVersion || 1,
            materialCatalogId: mapping.materialCatalogId,
            materialCatalogName: mapping.materialCatalogName,
            materialType: mapping.materialType,
            fenceSystem: mapping.fenceSystem || 'savannah',
            attributes: {
              ...mapping.attributes,
              meta: {
                source: 'vinyl_uck_canonical_repair_v1',
                fromUck: uck,
                repairedAt: new Date().toISOString()
              }
            },
            displayName: mapping.displayName,
            status: 'mapped',
            notes: `Canonicalized from ${uck}`,
            lastSeenAt: new Date().toISOString()
          });
          
          // Mark old mapping as deprecated
          await base44.asServiceRole.entities.CompanySkuMap.update(mapping.id, {
            status: 'deprecated',
            notes: `Deprecated: Canonicalized to ${canonical}`
          });
          
          results.repaired++;
          console.log(`[repairVinylCanonicalUcks] ✅ Repaired: ${uck} => ${canonical}`);
          
          batchCount++;
          if (batchCount % BATCH_SIZE === 0) {
            console.log(`[repairVinylCanonicalUcks] Batch complete, waiting ${BATCH_DELAY_MS}ms...`);
            await new Promise(resolve => setTimeout(resolve, BATCH_DELAY_MS));
          }
          
        } catch (error) {
          console.error(`[repairVinylCanonicalUcks] Error repairing ${uck}:`, error);
          results.errors.push({
            uck,
            error: error.message
          });
        }
      }
    }
    
    console.log(`[repairVinylCanonicalUcks] Repair complete:`, results);
    
    return Response.json({
      success: true,
      mode,
      results,
      message: dryRun 
        ? `Dry run: Found ${results.needsRepair} UCKs needing repair, ${results.collisions} collisions`
        : `Repair complete: Fixed ${results.repaired} UCKs, ${results.collisions} collisions, ${results.errors.length} errors`
    });
    
  } catch (error) {
    console.error('[repairVinylCanonicalUcks] Fatal error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});