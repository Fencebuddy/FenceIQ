/**
 * FENCEBUDDY V2 ENGINE — TAKEOFF ENGINE
 * 
 * CONTRACT 4: TAKEOFF GENERATION
 * Generate UCK list from geometry + variant config
 */

import { ENGINE_VERSIONS } from './versions';
import { generateTakeoffHash } from './checksums';
import { logDiagnostic } from './diagnosticsService';
import { generateContextualUck } from '../materials/generateContextualUck';

/**
 * Build takeoff from geometry result + variant config
 * 
 * CONTRACT 0.3: COLOR AUTHORITY
 * Color/coating must come from variant config and be encoded in UCKs
 */
export async function buildTakeoff({
  geometryResult,
  variantConfig,
  runs,
  jobPosts,
  jobId,
  variantId,
  companyId
}) {
  console.log('[TakeoffEngine] Building takeoff...', {
    geometry_status: geometryResult?.status,
    variant_material: variantConfig?.materialType,
    run_count: runs?.length
  });
  
  // Validate inputs
  if (!geometryResult || geometryResult.status !== 'VALID') {
    await logDiagnostic({
      phase: 'TAKEOFF',
      severity: 'BLOCKING',
      code: 'INVALID_GEOMETRY_INPUT',
      message: 'Cannot build takeoff from invalid geometry',
      jobId,
      variantId,
      companyId
    });
    
    return {
      status: 'BLOCKED',
      error: 'Invalid geometry input',
      line_items: [],
      takeoff_hash: null
    };
  }
  
  // Validate variant config has required attributes
  if (!variantConfig || !variantConfig.materialType) {
    await logDiagnostic({
      phase: 'TAKEOFF',
      severity: 'BLOCKING',
      code: 'MISSING_VARIANT_CONFIG',
      message: 'Variant config missing or incomplete',
      actionHint: 'Set material type, height, and finish attributes',
      jobId,
      variantId,
      companyId
    });
    
    return {
      status: 'BLOCKED',
      error: 'Missing variant config',
      line_items: [],
      takeoff_hash: null
    };
  }
  
  // Validate color authority (CONTRACT 0.3)
  const colorRequired = ['Vinyl', 'Aluminum'].includes(variantConfig.materialType);
  const coatingRequired = variantConfig.materialType === 'Chain Link';
  
  if (colorRequired && !variantConfig.color) {
    await logDiagnostic({
      phase: 'TAKEOFF',
      severity: 'BLOCKING',
      code: 'MISSING_COLOR_AUTHORITY',
      message: `${variantConfig.materialType} requires color attribute`,
      actionHint: 'Set fence color in variant config',
      jobId,
      variantId,
      companyId
    });
    
    return {
      status: 'BLOCKED',
      error: 'Missing color authority',
      line_items: [],
      takeoff_hash: null
    };
  }
  
  if (coatingRequired && !variantConfig.coating) {
    await logDiagnostic({
      phase: 'TAKEOFF',
      severity: 'BLOCKING',
      code: 'MISSING_COATING_AUTHORITY',
      message: 'Chain Link requires coating attribute',
      actionHint: 'Set coating (Galvanized/Aluminized/Black Vinyl)',
      jobId,
      variantId,
      companyId
    });
    
    return {
      status: 'BLOCKED',
      error: 'Missing coating authority',
      line_items: [],
      takeoff_hash: null
    };
  }
  
  // Build line items with UCKs
  const lineItems = [];
  
  // Use existing canonicalTakeoffEngine logic but with V2 contracts
  try {
    // Generate UCKs for all required parts using variant context
    const uckContext = {
      materialType: variantConfig.materialType,
      fenceSystem: variantConfig.fenceSystem || 'standard',
      heightFt: variantConfig.heightFt,
      color: variantConfig.color,
      coating: variantConfig.coating,
      finish: variantConfig.finish
    };
    
    // For each run, generate required parts
    for (const run of runs) {
      if (!run.lengthLF || run.lengthLF <= 0) continue;
      if (run.isExisting) continue; // Skip existing fence
      
      // Generate panels/fabric
      const panelUck = generateContextualUck({
        role: 'panel',
        materialType: variantConfig.materialType,
        heightFt: variantConfig.heightFt,
        color: variantConfig.color,
        coating: variantConfig.coating,
        context: uckContext
      });
      
      lineItems.push({
        canonical_key: panelUck,
        lineItemName: `${variantConfig.materialType} Panel ${variantConfig.heightFt}ft ${variantConfig.color || variantConfig.coating || ''}`,
        quantityCalculated: run.lengthLF, // Simplified - real logic more complex
        uom: 'lf',
        source: 'takeoff_engine',
        runId: run.id
      });
    }
    
    // Add posts from jobPosts
    if (jobPosts && jobPosts.length > 0) {
      const postCounts = jobPosts.reduce((acc, post) => {
        const key = `${post.kind}_${post.terminalType || 'standard'}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});
      
      for (const [postKey, count] of Object.entries(postCounts)) {
        const [kind, terminalType] = postKey.split('_');
        
        const postUck = generateContextualUck({
          role: 'post',
          materialType: variantConfig.materialType,
          heightFt: variantConfig.heightFt,
          postType: kind,
          terminalType,
          color: variantConfig.color,
          context: uckContext
        });
        
        lineItems.push({
          canonical_key: postUck,
          lineItemName: `${variantConfig.materialType} ${kind} Post ${variantConfig.heightFt}ft`,
          quantityCalculated: count,
          uom: 'each',
          source: 'takeoff_engine'
        });
      }
    }
    
    // Generate takeoff hash
    const takeoff_hash = generateTakeoffHash({
      lineItems,
      variantConfig
    });
    
    console.log('[TakeoffEngine] Takeoff built:', {
      item_count: lineItems.length,
      takeoff_hash
    });
    
    return {
      status: 'COMPLETE',
      line_items: lineItems,
      takeoff_hash,
      takeoff_version: ENGINE_VERSIONS.TAKEOFF_VERSION,
      geometry_checksum: geometryResult.geometry_checksum,
      total_lf: geometryResult.total_lf,
      post_counts: jobPosts?.length || 0,
      computed_at: new Date().toISOString()
    };
    
  } catch (error) {
    console.error('[TakeoffEngine] Build failed:', error);
    
    await logDiagnostic({
      phase: 'TAKEOFF',
      severity: 'BLOCKING',
      code: 'TAKEOFF_BUILD_FAILED',
      message: error.message,
      jobId,
      variantId,
      companyId,
      context: { error: error.toString() }
    });
    
    return {
      status: 'ERROR',
      error: error.message,
      line_items: [],
      takeoff_hash: null
    };
  }
}

/**
 * Validate takeoff meets requirements
 */
export function validateTakeoff(takeoffResult) {
  const errors = [];
  
  if (!takeoffResult || takeoffResult.status !== 'COMPLETE') {
    errors.push({
      code: 'INVALID_TAKEOFF',
      message: 'Takeoff build failed or incomplete',
      severity: 'BLOCKING'
    });
    return { valid: false, errors };
  }
  
  if (!takeoffResult.line_items || takeoffResult.line_items.length === 0) {
    errors.push({
      code: 'NO_TAKEOFF_ITEMS',
      message: 'No line items generated from takeoff',
      severity: 'BLOCKING'
    });
  }
  
  if (!takeoffResult.takeoff_hash) {
    errors.push({
      code: 'MISSING_TAKEOFF_HASH',
      message: 'Takeoff hash not generated',
      severity: 'BLOCKING'
    });
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}