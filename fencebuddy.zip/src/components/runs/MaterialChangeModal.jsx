import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Package } from "lucide-react";

/**
 * MATERIAL CHANGE MODAL
 * Handles user decision when changing material properties on a run
 * - Option 1: Apply to ALL runs (triggers job-level material switch)
 * - Option 2: Only this run (shows warning about mixed materials)
 */
export default function MaterialChangeModal({ 
  isOpen, 
  onClose, 
  originalRun, 
  newRunData,
  onApplyToAll,
  onApplyToThisRunOnly,
  isLoading,
  isMaterialTypeChange,
  isStyleChange,
  isHeightChange,
  isColorChange,
  isPrivacyTypeChange,
  isSlatColorChange
}) {
  if (!originalRun || !newRunData) return null;

  // Build changes array from flags
  const changes = [];
  if (isMaterialTypeChange) {
    changes.push(`Material: ${originalRun.materialType} → ${newRunData.materialType}`);
  }
  if (isHeightChange) {
    changes.push(`Height: ${originalRun.fenceHeight} → ${newRunData.fenceHeight}`);
  }
  if (isStyleChange) {
    changes.push(`Style: ${originalRun.style} → ${newRunData.style}`);
  }
  if (isColorChange) {
    changes.push(`Color: ${originalRun.fenceColor || 'None'} → ${newRunData.fenceColor || 'None'}`);
  }
  if (isPrivacyTypeChange) {
    changes.push(`Privacy: ${originalRun.chainLinkPrivacyType || 'None'} → ${newRunData.chainLinkPrivacyType || 'None'}`);
  }
  if (isSlatColorChange) {
    changes.push(`Slat Color: ${originalRun.vinylSlatColor || 'None'} → ${newRunData.vinylSlatColor || 'None'}`);
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-600" />
            {isMaterialTypeChange ? 'Material Type Change' : 'Fence Specification Changed'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <p className="text-sm text-slate-600">
            You've changed material properties on <strong>{originalRun.runLabel}</strong>:
          </p>

          <div className="bg-slate-50 rounded-lg p-3 space-y-1">
            {changes.map((change, idx) => (
              <div key={idx} className="text-sm text-slate-700">
                • {change}
              </div>
            ))}
          </div>

          <div className="space-y-3">
            <p className="text-sm font-medium text-slate-900">
              How would you like to apply these changes?
            </p>

            <div className="space-y-2">
              <Button
                onClick={onApplyToAll}
                disabled={isLoading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 justify-start"
              >
                <Package className="w-4 h-4 mr-2" />
                Apply to All Runs (Recommended)
              </Button>
              <p className="text-xs text-slate-500 pl-6">
                {isMaterialTypeChange 
                  ? `All runs will switch to ${newRunData.materialType}` 
                  : 'All runs will use the same specifications'}
              </p>
            </div>

            <div className="space-y-2">
              <Button
                onClick={onApplyToThisRunOnly}
                disabled={isLoading}
                variant="outline"
                className="w-full justify-start"
              >
                Only This Run
              </Button>
              <Alert className="border-amber-500 bg-amber-50">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <AlertDescription className="text-xs text-amber-800">
                  {isMaterialTypeChange 
                    ? 'This will create a mixed-material job, which may complicate ordering and installation.'
                    : 'Other runs will keep their current specifications. This may create inconsistencies.'}
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={isLoading}>
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}