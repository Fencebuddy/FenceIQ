import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import { PricingTruthError, requireUniqueOrNull } from "./_shared/truthSetIntegrity.js";
import { resolveCompanyContext } from "./_shared/resolveCompanyContext.js";
import {
  normalizeRateInput,
  requireSafeRate,
  requireNonBlankString,
  assertDivisorSafe,
  getMaxRequiredNetPctFromCompany
} from "./_shared/rateValidation.js";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const payload = await req.json();
    const {
      // Accept percent or decimal; normalize
      defaultOverheadRate,
      defaultCommissionRate,
      allowInternalPricingOverrides = false,
      version = "pricingDefaults@1.0.0"
    } = payload || {};

    // Resolve tenant context deterministically
    const ctx = await resolveCompanyContext({ base44, req });
    if (ctx.error) {
      return Response.json(
        { success: false, error: ctx.error.code, message: ctx.error.message },
        { status: 500 }
      );
    }
    const { companyId, company } = ctx;

    // Validate companyId non-blank
    const safeCompanyId = requireNonBlankString(String(companyId ?? ""), "companyId");

    // Normalize inputs (allow null to mean "leave unset")
    const overheadNorm = defaultOverheadRate == null ? null : normalizeRateInput(defaultOverheadRate);
    const commissionNorm = defaultCommissionRate == null ? null : normalizeRateInput(defaultCommissionRate);

    // If provided, must be safe
    const overheadRate = overheadNorm == null ? null : requireSafeRate(overheadNorm, "defaultOverheadRate");
    const commissionRate = commissionNorm == null ? null : requireSafeRate(commissionNorm, "defaultCommissionRate");

    // Divisor safety check using worst-case required net from company discount policy
    // Only enforce divisor check if BOTH overhead+commission are provided (otherwise we can't assert config)
    if (overheadRate != null && commissionRate != null) {
      const maxRequiredNetPct = getMaxRequiredNetPctFromCompany(company);
      assertDivisorSafe({
        overheadRate,
        commissionRate,
        requiredNetPct: maxRequiredNetPct,
        minDivisor: 0.02
      });
    }

    // STRICT uniqueness enforcement: one PricingDefaults per companyId
    const existing = await base44.entities.PricingDefaults.filter({ companyId: safeCompanyId });
    const one = requireUniqueOrNull({
      records: existing,
      code: "PRICING_DEFAULTS_DUPLICATE",
      message: "Multiple PricingDefaults records found for this companyId (uniqueness violated)",
      details: { companyId: safeCompanyId }
    });

    const data = {
      companyId: safeCompanyId,
      defaultOverheadRate: overheadRate,       // may be null
      defaultCommissionRate: commissionRate,   // may be null
      allowInternalPricingOverrides: allowInternalPricingOverrides === true,
      version
    };

    let record;
    if (!one) {
      record = await base44.entities.PricingDefaults.create(data);
    } else {
      record = await base44.entities.PricingDefaults.update(one.id, data);
    }

    return Response.json({ success: true, record });
  } catch (error) {
    console.error("[upsertPricingDefaults] Error:", error);

    if (error && (error.name === "PricingTruthError" || error instanceof PricingTruthError)) {
      return Response.json(
        { success: false, error: error.code, message: error.message, details: error.details },
        { status: 500 }
      );
    }

    return Response.json({ success: false, error: "UNKNOWN_ERROR", message: error.message }, { status: 500 });
  }
});