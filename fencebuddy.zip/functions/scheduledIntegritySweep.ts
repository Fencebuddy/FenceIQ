import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * SCHEDULED: Nightly Integrity Sweep
 * Runs comprehensive data integrity checks
 * Designed to run at 2 AM local time when system is idle
 */

Deno.serve(async (req) => {
  const startTime = Date.now();
  
  try {
    const base44 = createClientFromRequest(req);
    
    // This is a scheduled task - no user context needed
    // Use service role for all operations
    
    const companyId = "PrivacyFenceCo49319";
    const dryRunMode = true; // SAFE DEFAULT
    
    console.log(`[IntegritySweep] Starting nightly sweep for ${companyId} (dryRun: ${dryRunMode})`);
    
    // Call data integrity agent with full scan mode
    const response = await base44.asServiceRole.functions.invoke('dataIntegrityAgent', {
      companyId,
      triggerType: 'scheduled',
      fullScan: true,
      dryRunMode
    });
    
    const result = response.data;
    
    // Log the sweep
    await base44.asServiceRole.entities.AgentRunLog.create({
      companyId,
      agentName: 'dataIntegrityAgent',
      triggerType: 'scheduled',
      status: result.success ? 'success' : 'error',
      dryRun: dryRunMode,
      durationMs: Date.now() - startTime,
      findings: {
        checks: result.checks,
        totalErrors: result.totalErrors,
        totalWarnings: result.totalWarnings
      },
      ranAt: new Date().toISOString()
    });
    
    console.log(`[IntegritySweep] Completed in ${Date.now() - startTime}ms`);
    console.log(`Found ${result.totalErrors} errors, ${result.totalWarnings} warnings`);
    
    return Response.json({
      success: true,
      companyId,
      dryRun: dryRunMode,
      checksRun: result.checks?.length || 0,
      totalErrors: result.totalErrors,
      totalWarnings: result.totalWarnings,
      durationMs: Date.now() - startTime
    });
    
  } catch (error) {
    console.error('[IntegritySweep] Failed:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});