import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * USAGE TRACKING AGENT
 * Foundation for SaaS billing - tracks key usage events without blocking business logic
 * Called from entity automations and key business processes
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    const { eventType, jobId, userId, metadata } = payload;

    if (!eventType) {
      return Response.json({ error: 'eventType required' }, { status: 400 });
    }

    const companyId = "PrivacyFenceCo49319"; // TODO: Get from tenant context

    // Store usage event (append-only, non-blocking)
    await base44.asServiceRole.entities.UsageEvent.create({
      companyId,
      userId: userId || 'system',
      eventType,
      jobId,
      metadata: metadata || {},
      timestamp: new Date().toISOString()
    });

    return Response.json({ 
      success: true,
      eventType,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    // Don't fail parent operation if usage tracking fails
    console.error('Usage tracking error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 200 }); // Return 200 so parent operation doesn't fail
  }
});