import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Ruler, ChevronDown, ChevronUp, Zap } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function RunsList({ runs, onAdd, onEdit, onDelete, totalLF }) {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="border-b bg-slate-50 cursor-pointer hover:bg-slate-100">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  Fence Runs
                  {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </CardTitle>
                <p className="text-sm text-slate-500 mt-1">
                  {runs.length} run{runs.length !== 1 ? 's' : ''} • Total: <span className="font-bold text-emerald-700">{totalLF} LF</span>
                </p>
              </div>
              <Button onClick={(e) => { e.stopPropagation(); onAdd(); }} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Run
              </Button>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="p-0">
        {runs.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Ruler className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>No runs added yet</p>
            <p className="text-sm">Click "Add Run" to measure your first fence section</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Run</TableHead>
                <TableHead>Material / Height / Style</TableHead>
                <TableHead className="text-right">Length</TableHead>
                <TableHead>Gates</TableHead>
                <TableHead>Posts</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {runs.map(run => (
                <TableRow key={run.id} className={run.hasTearout ? 'bg-red-50' : ''}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {run.runLabel}
                      {run.hasTearout && (
                        <Badge className="bg-red-600 hover:bg-red-700 text-white text-xs gap-1">
                          <Zap className="w-3 h-3" />
                          Tear Out
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {run.materialType && run.fenceHeight && run.style ? (
                      <div className="space-y-0.5">
                        <div className="font-medium">{run.materialType}</div>
                        <div className="text-slate-600">{run.fenceHeight} • {run.style}</div>
                        {run.materialType === 'Chain Link' && run.chainLinkCoating && (
                          <div className="text-xs text-slate-500">{run.chainLinkCoating}</div>
                        )}
                        {run.fenceColor && (
                          <div className="text-xs text-slate-500">
                            {run.fenceColor === 'Two Tone' && run.railsAndPostColor && run.picketColor
                              ? `${run.railsAndPostColor}/${run.picketColor}`
                              : run.fenceColor}
                          </div>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-400">Not specified</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-bold text-emerald-700">{run.lengthLF} LF</TableCell>
                  <TableCell className="text-sm text-slate-600">
                    {(run.singleGateCount > 0 || run.doubleGateCount > 0) ? (
                      <div className="space-y-0.5">
                        {run.singleGateCount > 0 && (
                          <div className="text-amber-700 font-medium">{run.singleGateCount} Single</div>
                        )}
                        {run.doubleGateCount > 0 && (
                          <div className="text-orange-700 font-medium">{run.doubleGateCount} Double</div>
                        )}
                        {run.gateWidth > 0 && (
                          <div className="text-xs text-slate-500">{run.gateWidth}' total</div>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-400">None</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs">
                   <div className="flex gap-1 flex-wrap">
                     {run.cornerPostCount > 0 && (
                       <Badge variant="outline" className="border-blue-300 text-blue-700 text-xs">Corner ({run.cornerPostCount})</Badge>
                     )}
                     {run.endPostCount > 0 && (
                       <Badge variant="outline" className="border-purple-300 text-purple-700 text-xs">End ({run.endPostCount})</Badge>
                     )}
                     {(!run.cornerPostCount || run.cornerPostCount === 0) && (!run.endPostCount || run.endPostCount === 0) && (
                       <span className="text-slate-400">Line</span>
                     )}
                   </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="icon" variant="ghost" onClick={() => onEdit(run)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => onDelete(run)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}