/**
 * SEED UNIT CONVERSIONS
 * 
 * Populate UnitConversionMap with common conversions
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const CONVERSIONS = [
  // Roll to LF
  { from_unit: 'roll', to_unit: 'lf', multiplier: 50, notes: 'Chain link fabric: 50 ft/roll' },
  { from_unit: 'roll', to_unit: 'lf', multiplier: 100, notes: 'Tension wire: 100 ft/roll' },
  
  // Stick to LF
  { from_unit: 'stick', to_unit: 'lf', multiplier: 21, notes: 'Top rail: 21 ft/stick' },
  { from_unit: 'stick', to_unit: 'lf', multiplier: 8, notes: '2x4x8 board: 8 ft/stick' },
  
  // Bundle to LF
  { from_unit: 'bundle', to_unit: 'lf', multiplier: 10, notes: 'Privacy slats: 10 ft/bundle' },
  
  // Each to Pieces
  { from_unit: 'each', to_unit: 'pcs', multiplier: 1, notes: 'Direct equivalence' },
  
  // Bag conversions
  { from_unit: 'bag', to_unit: 'each', multiplier: 1, notes: 'Concrete: 1 bag = 1 unit' },
  
  // LF to 100LF
  { from_unit: 'lf', to_unit: '100lf', multiplier: 0.01, notes: 'Tension wire unit conversion' }
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Admin only
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }
    
    let created = 0;
    let skipped = 0;
    
    for (const conversion of CONVERSIONS) {
      // Check if already exists
      const existing = await base44.asServiceRole.entities.UnitConversionMap.filter({
        from_unit: conversion.from_unit,
        to_unit: conversion.to_unit
      });
      
      if (existing.length > 0) {
        skipped++;
        continue;
      }
      
      // Create conversion
      await base44.asServiceRole.entities.UnitConversionMap.create({
        ...conversion,
        size_based: false,
        active: true
      });
      
      created++;
    }
    
    return Response.json({
      success: true,
      conversions_created: created,
      conversions_skipped: skipped,
      total_conversions: CONVERSIONS.length
    });
    
  } catch (error) {
    console.error('[Seed] Error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});