import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * TRIGGER: Usage Tracking
 * Called by entity automations on key business events
 * Non-blocking, append-only usage recording
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data } = payload;
    
    // Get feature flags
    const agentEnabled = true;
    const dryRunMode = true;
    
    if (!agentEnabled) {
      return Response.json({ skipped: true });
    }
    
    const companyId = data?.companyId || "PrivacyFenceCo49319";
    
    // Map entity event to usage event type
    const eventTypeMap = {
      'CRMJob_create': 'job_created',
      'ProposalPricingSnapshot_create': 'pricing_computed',
      'ProposalSnapshot_create': 'proposal_sent',
      'SignatureRecord_create': 'proposal_signed'
    };
    
    const eventKey = `${event.entity_name}_${event.type}`;
    const usageEventType = eventTypeMap[eventKey];
    
    if (!usageEventType) {
      // Not a tracked event type
      return Response.json({ skipped: true, reason: 'Event type not tracked' });
    }
    
    if (dryRunMode) {
      console.log(`[DRY RUN] Would track usage: ${usageEventType}`, { companyId, entityId: event.entity_id });
      return Response.json({ 
        dryRun: true,
        wouldTrack: usageEventType
      });
    }
    
    // Call usage tracking agent
    await base44.asServiceRole.functions.invoke('usageTrackingAgent', {
      eventType: usageEventType,
      jobId: data.jobId || data.id,
      userId: data.created_by || 'system',
      metadata: {
        entityType: event.entity_name,
        entityId: event.entity_id
      }
    });
    
    return Response.json({ success: true, tracked: usageEventType });
    
  } catch (error) {
    // Don't fail parent operation if usage tracking fails
    console.error('[UsageTracking] Error:', error);
    return Response.json({ 
      success: false, 
      error: error.message 
    }, { status: 200 }); // Return 200 to not block parent operation
  }
});