import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }
        
        // Get company settings
        const settings = await base44.entities.CompanySettings.filter({});
        const company = settings[0];
        
        if (!company) {
            return Response.json({ error: 'Company settings not found' }, { status: 404 });
        }
        
        // Check CRM and reporting enabled
        if (!company.crmEnabled || !company.reportingEnabled) {
            return Response.json({ error: 'Reporting not enabled' }, { status: 403 });
        }
        
        const companyId = company.id;
        
        // Parse query params
        const url = new URL(req.url);
        const start = url.searchParams.get('start');
        const end = url.searchParams.get('end');
        const repUserId = url.searchParams.get('repUserId') || undefined;
        const fenceCategory = url.searchParams.get('fenceCategory') || undefined;
        const source = url.searchParams.get('source') || undefined;
        
        if (!start || !end) {
            return Response.json({ error: 'Missing required params: start, end' }, { status: 400 });
        }
        
        // Log report run
        const logEntry = await base44.asServiceRole.entities.ReportRunLog.create({
            companyId,
            reportType: 'dashboard_query',
            status: 'started',
            startedAt: new Date().toISOString(),
            rangeStart: start,
            rangeEnd: end,
            triggeredBy: 'api',
            triggeredByUserId: user.id
        });
        
        try {
            // Compute KPIs using snapshot-truth logic
            const signedRecords = await base44.asServiceRole.entities.SignatureRecord.filter({ companyId });
            const filteredSigs = signedRecords.filter(sig => {
                const signedAt = new Date(sig.signedAt);
                return signedAt >= new Date(start) && signedAt <= new Date(end);
            });
            
            const truthRows = [];
            for (const sig of filteredSigs) {
                const pricingSnapshots = sig.pricingSnapshotId 
                    ? await base44.asServiceRole.entities.PricingSnapshot.filter({ id: sig.pricingSnapshotId })
                    : [];
                const pricingSnapshot = pricingSnapshots[0];
                if (!pricingSnapshot) continue;
                
                const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: sig.jobId });
                const crmJob = crmJobs[0];
                if (!crmJob) continue;
                
                if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
                if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                if (source && crmJob.source !== source) continue;
                
                truthRows.push({
                    totalPrice: pricingSnapshot.totalPrice,
                    netProfitAmount: pricingSnapshot.netProfitAmount
                });
            }
            
            const signedCount = truthRows.length;
            const wonRevenue = truthRows.reduce((sum, row) => sum + (row.totalPrice || 0), 0);
            const netProfitAmount = truthRows.reduce((sum, row) => sum + (row.netProfitAmount || 0), 0);
            const avgTicket = signedCount > 0 ? wonRevenue / signedCount : 0;
            const netMarginPercentWeighted = wonRevenue > 0 ? (netProfitAmount / wonRevenue) * 100 : 0;
            
            // Get proposal close set
            const allProposals = await base44.asServiceRole.entities.ProposalSnapshot.filter({ companyId });
            const filteredProps = allProposals.filter(prop => {
                if (!prop.sentAt) return false;
                const sentAt = new Date(prop.sentAt);
                return sentAt >= new Date(start) && sentAt <= new Date(end);
            });
            
            const proposalRows = [];
            for (const prop of filteredProps) {
                const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: prop.jobId });
                const crmJob = crmJobs[0];
                if (!crmJob) continue;
                
                if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
                if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                if (source && crmJob.source !== source) continue;
                
                proposalRows.push({ status: prop.status });
            }
            
            const validStatuses = ['sent', 'viewed', 'signed'];
            const proposalsSentCount = proposalRows.filter(p => validStatuses.includes(p.status)).length;
            const proposalsSignedCount = proposalRows.filter(p => p.status === 'signed').length;
            const closeRatePercent = proposalsSentCount > 0 ? (proposalsSignedCount / proposalsSentCount) * 100 : 0;
            
            const kpis = {
                signedCount,
                wonRevenue,
                netProfitAmount,
                netMarginPercentWeighted,
                avgTicket,
                proposalsSentCount,
                proposalsSignedCount,
                closeRatePercent
            };
            
            // Mark log as success
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'success',
                finishedAt: new Date().toISOString()
            });
            
            return Response.json({
                range: { start, end },
                filters: { repUserId, fenceCategory, source },
                kpis
            });
        } catch (error) {
            // Mark log as failed
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'failed',
                finishedAt: new Date().toISOString(),
                errorMessage: error.message,
                errorStack: error.stack
            });
            
            throw error;
        }
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});