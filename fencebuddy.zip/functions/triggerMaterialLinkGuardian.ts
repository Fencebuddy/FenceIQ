import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * TRIGGER: Material Link Guardian
 * Called when SelectionSets or MaterialCatalog items change
 * Validates catalog links and creates alerts/suggestions
 */

Deno.serve(async (req) => {
  const startTime = Date.now();
  
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data } = payload;
    
    const companyId = data?.companyId || "PrivacyFenceCo49319";
    const triggerType = event.type === 'create' ? 'entity_create' : 'entity_update';
    const triggerRef = `${event.entity_name}:${event.entity_id}`;
    
    console.log(`[MaterialLinkGuardian] Triggered by ${triggerRef}`);
    
    // Import agent runner dynamically (Deno doesn't support direct imports from components)
    // For now, inline the agent logic or call via service role
    
    // Use service role to run agent
    const response = await fetch(`${Deno.env.get('BASE44_API_URL')}/functions/materialLinkGuardianExecutor`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': req.headers.get('Authorization')
      },
      body: JSON.stringify({
        companyId,
        triggerType,
        triggerRef
      })
    });
    
    if (!response.ok) {
      throw new Error(`Agent execution failed: ${response.statusText}`);
    }
    
    const result = await response.json();
    
    console.log(`[MaterialLinkGuardian] Completed in ${Date.now() - startTime}ms:`, result.summary);
    
    return Response.json({
      success: true,
      result,
      durationMs: Date.now() - startTime
    });
    
  } catch (error) {
    console.error('[MaterialLinkGuardian] Error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});