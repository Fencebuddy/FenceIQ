import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }
        
        // Get company settings
        const settings = await base44.entities.CompanySettings.filter({});
        const company = settings[0];
        
        if (!company) {
            return Response.json({ error: 'Company settings not found' }, { status: 404 });
        }
        
        // Check CRM and reporting enabled
        if (!company.crmEnabled || !company.reportingEnabled) {
            return Response.json({ error: 'Reporting not enabled' }, { status: 403 });
        }
        
        const companyId = company.id;
        
        // Parse query params
        const url = new URL(req.url);
        const type = url.searchParams.get('type') || 'rep-scoreboard';
        const start = url.searchParams.get('start');
        const end = url.searchParams.get('end');
        const repUserId = url.searchParams.get('repUserId') || undefined;
        const fenceCategory = url.searchParams.get('fenceCategory') || undefined;
        const source = url.searchParams.get('source') || undefined;
        
        if (!start || !end) {
            return Response.json({ error: 'Missing required params: start, end' }, { status: 400 });
        }
        
        // Log export run
        const logEntry = await base44.asServiceRole.entities.ReportRunLog.create({
            companyId,
            reportType: 'csv_export',
            status: 'started',
            startedAt: new Date().toISOString(),
            rangeStart: start,
            rangeEnd: end,
            triggeredBy: 'api',
            triggeredByUserId: user.id,
            metadata: { exportType: type }
        });
        
        try {
            let csvContent = '';
            
            if (type === 'signed-deals') {
                // Signed deals export
                const signedRecords = await base44.asServiceRole.entities.SignatureRecord.filter({ companyId });
                const filteredSigs = signedRecords.filter(sig => {
                    const signedAt = new Date(sig.signedAt);
                    return signedAt >= new Date(start) && signedAt <= new Date(end);
                });
                
                csvContent = 'Job Number,Signed At,Rep Name,Fence Category,Source,Total Price,Net Profit %,Discount %,Pricing Snapshot ID\n';
                
                for (const sig of filteredSigs) {
                    const pricingSnapshots = sig.pricingSnapshotId 
                        ? await base44.asServiceRole.entities.PricingSnapshot.filter({ id: sig.pricingSnapshotId })
                        : [];
                    const pricingSnapshot = pricingSnapshots[0];
                    if (!pricingSnapshot) continue;
                    
                    const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: sig.jobId });
                    const crmJob = crmJobs[0];
                    if (!crmJob) continue;
                    
                    if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
                    if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                    if (source && crmJob.source !== source) continue;
                    
                    // Load rep name
                    let repName = 'Unassigned';
                    if (crmJob.assignedRepUserId) {
                        const users = await base44.asServiceRole.entities.User.filter({ id: crmJob.assignedRepUserId });
                        if (users.length > 0) {
                            repName = users[0].full_name || users[0].email;
                        }
                    }
                    
                    csvContent += `${crmJob.jobNumber || ''},${sig.signedAt},${repName},${crmJob.fenceCategory || ''},${crmJob.source || ''},${pricingSnapshot.totalPrice || 0},${pricingSnapshot.netProfitPercent || 0},${pricingSnapshot.discountPercent || 0},${sig.pricingSnapshotId}\n`;
                }
            } else if (type === 'proposals') {
                // Proposals export
                const allProposals = await base44.asServiceRole.entities.ProposalSnapshot.filter({ companyId });
                const filteredProps = allProposals.filter(prop => {
                    if (!prop.sentAt) return false;
                    const sentAt = new Date(prop.sentAt);
                    return sentAt >= new Date(start) && sentAt <= new Date(end);
                });
                
                csvContent = 'Proposal Number,Sent At,Status,Rep Name,Total Price,View Count,Job Number\n';
                
                for (const prop of filteredProps) {
                    const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: prop.jobId });
                    const crmJob = crmJobs[0];
                    if (!crmJob) continue;
                    
                    if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
                    if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
                    if (source && crmJob.source !== source) continue;
                    
                    // Load rep name
                    let repName = 'Unassigned';
                    if (crmJob.assignedRepUserId) {
                        const users = await base44.asServiceRole.entities.User.filter({ id: crmJob.assignedRepUserId });
                        if (users.length > 0) {
                            repName = users[0].full_name || users[0].email;
                        }
                    }
                    
                    // Load total price from PricingSnapshot
                    let totalPrice = '';
                    if (prop.pricingSnapshotId) {
                        const pricingSnapshots = await base44.asServiceRole.entities.PricingSnapshot.filter({ id: prop.pricingSnapshotId });
                        if (pricingSnapshots.length > 0) {
                            totalPrice = pricingSnapshots[0].totalPrice || 0;
                        }
                    }
                    
                    csvContent += `${prop.proposalNumber || ''},${prop.sentAt},${prop.status},${repName},${totalPrice},${prop.viewCount || 0},${crmJob.jobNumber || ''}\n`;
                }
            } else {
                // Default: rep-scoreboard
                const signedRecords = await base44.asServiceRole.entities.SignatureRecord.filter({ companyId });
                const filteredSigs = signedRecords.filter(sig => {
                    const signedAt = new Date(sig.signedAt);
                    return signedAt >= new Date(start) && signedAt <= new Date(end);
                });
                
                const allProposals = await base44.asServiceRole.entities.ProposalSnapshot.filter({ companyId });
                const filteredProps = allProposals.filter(prop => {
                    if (!prop.sentAt) return false;
                    const sentAt = new Date(prop.sentAt);
                    return sentAt >= new Date(start) && sentAt <= new Date(end);
                });
                
                const repMap = new Map();
                
                // Aggregate signed deals
                for (const sig of filteredSigs) {
                    const pricingSnapshots = sig.pricingSnapshotId 
                        ? await base44.asServiceRole.entities.PricingSnapshot.filter({ id: sig.pricingSnapshotId })
                        : [];
                    const pricingSnapshot = pricingSnapshots[0];
                    if (!pricingSnapshot) continue;
                    
                    const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: sig.jobId });
                    const crmJob = crmJobs[0];
                    if (!crmJob) continue;
                    
                    const repId = crmJob.assignedRepUserId || 'unassigned';
                    if (!repMap.has(repId)) {
                        repMap.set(repId, {
                            wonRevenue: 0,
                            signedCount: 0,
                            netProfitAmount: 0,
                            proposalsSentCount: 0,
                            proposalsSignedCount: 0
                        });
                    }
                    
                    const rep = repMap.get(repId);
                    rep.wonRevenue += pricingSnapshot.totalPrice || 0;
                    rep.signedCount += 1;
                    rep.netProfitAmount += pricingSnapshot.netProfitAmount || 0;
                }
                
                // Aggregate proposals
                for (const prop of filteredProps) {
                    const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ id: prop.jobId });
                    const crmJob = crmJobs[0];
                    if (!crmJob) continue;
                    
                    const repId = crmJob.assignedRepUserId || 'unassigned';
                    if (!repMap.has(repId)) {
                        repMap.set(repId, {
                            wonRevenue: 0,
                            signedCount: 0,
                            netProfitAmount: 0,
                            proposalsSentCount: 0,
                            proposalsSignedCount: 0
                        });
                    }
                    
                    const rep = repMap.get(repId);
                    const validStatuses = ['sent', 'viewed', 'signed'];
                    if (validStatuses.includes(prop.status)) {
                        rep.proposalsSentCount += 1;
                    }
                    if (prop.status === 'signed') {
                        rep.proposalsSignedCount += 1;
                    }
                }
                
                // Load user names
                const users = await base44.asServiceRole.entities.User.filter({});
                const userMap = new Map(users.map(u => [u.id, u.full_name || u.email]));
                
                csvContent = 'Rep,Won Revenue,# Signed,Avg Ticket,Net Margin %,# Sent,Close Rate %\n';
                
                Array.from(repMap.entries()).forEach(([repId, data]) => {
                    const repName = repId === 'unassigned' ? 'Unassigned' : userMap.get(repId) || 'Unknown';
                    const avgTicket = data.signedCount > 0 ? data.wonRevenue / data.signedCount : 0;
                    const netMarginPercent = data.wonRevenue > 0 ? (data.netProfitAmount / data.wonRevenue) * 100 : 0;
                    const closeRatePercent = data.proposalsSentCount > 0 
                        ? (data.proposalsSignedCount / data.proposalsSentCount) * 100 
                        : 0;
                    
                    csvContent += `${repName},${data.wonRevenue.toFixed(2)},${data.signedCount},${avgTicket.toFixed(2)},${netMarginPercent.toFixed(1)},${data.proposalsSentCount},${closeRatePercent.toFixed(1)}\n`;
                });
            }
            
            // Mark log as success
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'success',
                finishedAt: new Date().toISOString()
            });
            
            return new Response(csvContent, {
                headers: {
                    'Content-Type': 'text/csv',
                    'Content-Disposition': `attachment; filename="fencebuddy-${type}-${start}-to-${end}.csv"`
                }
            });
        } catch (error) {
            // Mark log as failed
            await base44.asServiceRole.entities.ReportRunLog.update(logEntry.id, {
                status: 'failed',
                finishedAt: new Date().toISOString(),
                errorMessage: error.message,
                errorStack: error.stack
            });
            
            throw error;
        }
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});