import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

/**
 * SINGLE COMPANY READINESS AUDIT
 * 
 * Comprehensive health check for single-company production launch.
 * Verifies: company configuration, data integrity, critical automations, and revenue pipeline.
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== "admin") {
      return Response.json({ error: "Admin access required" }, { status: 403 });
    }

    console.log("[singleCompanyReadinessAudit] Starting audit...");

    const audit = {
      timestamp: new Date().toISOString(),
      overallStatus: "PASS",
      sections: {}
    };

    // SECTION 1: Company Configuration
    audit.sections.companyConfiguration = await checkCompanyConfiguration(base44);
    if (audit.sections.companyConfiguration.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 2: Critical Settings
    audit.sections.criticalSettings = await checkCriticalSettings(base44);
    if (audit.sections.criticalSettings.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 3: Data Integrity
    audit.sections.dataIntegrity = await checkDataIntegrity(base44);
    if (audit.sections.dataIntegrity.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 4: Revenue Recognition Pipeline
    audit.sections.revenueRecognition = await checkRevenueRecognition(base44);
    if (audit.sections.revenueRecognition.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 5: Breakeven & Reporting
    audit.sections.breakeven = await checkBreakevenHealth(base44);
    if (audit.sections.breakeven.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 6: Critical Automations
    audit.sections.automations = await checkAutomations(base44);
    if (audit.sections.automations.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    // SECTION 7: Material Catalog
    audit.sections.materialCatalog = await checkMaterialCatalog(base44);
    if (audit.sections.materialCatalog.status !== "PASS") {
      audit.overallStatus = "FAIL";
    }

    console.log(`[singleCompanyReadinessAudit] Complete: ${audit.overallStatus}`);
    return Response.json(audit);

  } catch (error) {
    return Response.json({
      error: error.message,
      timestamp: new Date().toISOString(),
      overallStatus: "ERROR"
    }, { status: 500 });
  }
});

async function checkCompanyConfiguration(base44) {
  const issues = [];
  const warnings = [];

  const companies = await base44.asServiceRole.entities.CompanySettings.list();
  
  if (companies.length === 0) {
    issues.push("No company configured");
  } else if (companies.length > 1) {
    issues.push(`Multiple companies detected (${companies.length}). Single-company mode requires exactly 1.`);
  }

  const company = companies[0];
  if (!company) {
    return { status: "FAIL", issues, checks: [] };
  }

  const checks = [];

  // Required fields
  if (!company.companyName) {
    issues.push("Company name not set");
  } else {
    checks.push({ name: "Company name", status: "OK", value: company.companyName });
  }

  if (!company.email) {
    warnings.push("Company email not set");
  } else {
    checks.push({ name: "Contact email", status: "OK", value: company.email });
  }

  if (!company.phone) {
    warnings.push("Company phone not set");
  } else {
    checks.push({ name: "Contact phone", status: "OK", value: company.phone });
  }

  checks.push({ name: "Company ID (internal)", status: "OK", value: company.id });
  checks.push({ name: "Company ID (CRM key)", status: "OK", value: company.companyId });

  return {
    status: issues.length > 0 ? "FAIL" : (warnings.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}

async function checkCriticalSettings(base44) {
  const issues = [];
  const warnings = [];
  const checks = [];

  const companies = await base44.asServiceRole.entities.CompanySettings.list();
  const company = companies[0];
  if (!company) {
    return { status: "FAIL", issues: ["No company to check"], checks: [] };
  }

  // Overhead Settings
  const overhead = await base44.asServiceRole.entities.OverheadSettings.filter({ companyId: company.id });
  if (!overhead || overhead.length === 0) {
    issues.push("OverheadSettings not configured");
  } else if (overhead.length > 1) {
    issues.push(`Duplicate OverheadSettings (${overhead.length} records)`);
  } else {
    const os = overhead[0];
    if (!os.projectedAnnualRevenue || os.projectedAnnualRevenue === 0) {
      warnings.push("Projected annual revenue not set in OverheadSettings");
    } else {
      checks.push({ name: "Overhead - Projected Revenue", status: "OK", value: `$${os.projectedAnnualRevenue.toLocaleString()}` });
    }
    if (os.computedOverheadPct != null) {
      checks.push({ name: "Overhead - Rate", status: "OK", value: `${os.computedOverheadPct.toFixed(1)}%` });
    }
  }

  // Breakeven Settings
  const breakeven = await base44.asServiceRole.entities.BreakevenSettings.filter({ companyId: company.id });
  if (!breakeven || breakeven.length === 0) {
    issues.push("BreakevenSettings not configured");
  } else if (breakeven.length > 1) {
    issues.push(`Duplicate BreakevenSettings (${breakeven.length} records)`);
  } else {
    const bs = breakeven[0];
    checks.push({ name: "Breakeven - Target Margin", status: "OK", value: `${bs.targetContributionMarginPct}%` });
    checks.push({ name: "Breakeven - Net Profit Goal", status: "OK", value: `${bs.targetNetProfitPct}%` });
  }

  // Discount Policy
  if (company.discountPolicy?.enabled) {
    checks.push({ name: "Discount Policy", status: "OK", value: "Enabled" });
    if (company.discountPolicy.maxEffectiveDiscountPct != null) {
      checks.push({ name: "Max Discount", status: "OK", value: `${company.discountPolicy.maxEffectiveDiscountPct}%` });
    }
  } else {
    warnings.push("Discount policy not enabled");
  }

  // Terms
  if (company.termsCurrentVersion) {
    checks.push({ name: "Terms Version", status: "OK", value: company.termsCurrentVersion });
  }

  return {
    status: issues.length > 0 ? "FAIL" : (warnings.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}

async function checkDataIntegrity(base44) {
  const issues = [];
  const warnings = [];
  const checks = [];

  const companies = await base44.asServiceRole.entities.CompanySettings.list();
  const company = companies[0];
  if (!company) {
    return { status: "FAIL", issues: ["No company to check"], checks: [] };
  }

  // Count entities
  const jobs = await base44.asServiceRole.entities.Job.filter({ companyId: company.companyId });
  const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ companyId: company.companyId });
  const wonJobs = crmJobs.filter(j => j.status === "won");
  const materialCatalog = await base44.asServiceRole.entities.MaterialCatalog.filter({});
  const saleSnapshots = await base44.asServiceRole.entities.SaleSnapshot.filter({});

  checks.push({ name: "Jobs (legacy)", status: "OK", value: jobs.length });
  checks.push({ name: "CRM Jobs (operational)", status: "OK", value: crmJobs.length });
  checks.push({ name: "Won Jobs", status: "OK", value: wonJobs.length });
  checks.push({ name: "Material Catalog Items", status: "OK", value: materialCatalog.length });

  // Check for orphaned CRM jobs
  const orphanedCrmJobs = crmJobs.filter(j => !j.jobNumber || j.jobNumber.length === 0);
  if (orphanedCrmJobs.length > 0) {
    warnings.push(`${orphanedCrmJobs.length} CRM jobs missing jobNumber`);
  }

  // Check for won jobs without revenue
  const unrecognizedWon = wonJobs.filter(j => j.recognitionStatus !== "RECOGNIZED");
  if (unrecognizedWon.length > 0 && wonJobs.length > 0) {
    const percent = Math.round((unrecognizedWon.length / wonJobs.length) * 100);
    if (percent > 50) {
      warnings.push(`${percent}% of won jobs not yet recognized for revenue`);
    }
  }

  // Check sale snapshots
  if (wonJobs.length > 0 && saleSnapshots.length === 0) {
    warnings.push("Won jobs exist but no SaleSnapshots found");
  }

  return {
    status: issues.length > 0 ? "FAIL" : (warnings.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}

async function checkRevenueRecognition(base44) {
  const issues = [];
  const warnings = [];
  const checks = [];

  const companies = await base44.asServiceRole.entities.CompanySettings.list();
  const company = companies[0];
  if (!company) {
    return { status: "FAIL", issues: ["No company to check"], checks: [] };
  }

  const crmJobs = await base44.asServiceRole.entities.CRMJob.filter({ companyId: company.companyId });
  const wonJobs = crmJobs.filter(j => j.status === "won");

  if (wonJobs.length === 0) {
    checks.push({ name: "Won Jobs Pending", status: "OK", value: "0 (no jobs to recognize)" });
    return { status: "PASS", issues: [], warnings: [], checks };
  }

  // Check recognition status
  const recognized = wonJobs.filter(j => j.recognitionStatus === "RECOGNIZED");
  const unrecognized = wonJobs.filter(j => j.recognitionStatus === "UNRECOGNIZED" || !j.recognitionStatus);

  checks.push({ name: "Won Jobs Total", status: "OK", value: wonJobs.length });
  checks.push({ name: "Won Jobs Recognized", status: "OK", value: recognized.length });
  checks.push({ name: "Won Jobs Pending", status: unrecognized.length > 0 ? "WARN" : "OK", value: unrecognized.length });

  // Check revenue values
  const withRevenue = recognized.filter(j => j.recognizedRevenueCents && j.recognizedRevenueCents > 0);
  if (recognized.length > 0 && withRevenue.length === 0) {
    issues.push("Recognized jobs exist but no revenue captured");
  } else if (withRevenue.length > 0) {
    const totalRevenue = withRevenue.reduce((acc, j) => acc + (j.recognizedRevenueCents || 0), 0);
    checks.push({ name: "Total Recognized Revenue", status: "OK", value: `$${(totalRevenue / 100).toLocaleString()}` });
  }

  return {
    status: issues.length > 0 ? "FAIL" : (unrecognized.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}

async function checkBreakevenHealth(base44) {
  const issues = [];
  const warnings = [];
  const checks = [];

  const companies = await base44.asServiceRole.entities.CompanySettings.list();
  const company = companies[0];
  if (!company) {
    return { status: "FAIL", issues: ["No company to check"], checks: [] };
  }

  // Check monthly rollups
  const rollups = await base44.asServiceRole.entities.BreakevenMonthlyRollup.filter({ companyId: company.id });
  if (rollups.length === 0) {
    warnings.push("No BreakevenMonthlyRollup records created yet");
  } else {
    const sorted = rollups.sort((a, b) => new Date(b.monthKey) - new Date(a.monthKey));
    const latest = sorted[0];
    const currentMonth = new Date().toISOString().slice(0, 7);
    
    checks.push({ name: "Rollup Records", status: "OK", value: rollups.length });
    checks.push({ name: "Latest Month", status: "OK", value: latest.monthKey });

    if (latest.monthKey !== currentMonth) {
      warnings.push(`Latest rollup is ${latest.monthKey}, current month is ${currentMonth}`);
    }

    if (latest.jobsCount > 0) {
      const totalRevenue = latest.recognizedRevenueCents || 0;
      const overhead = latest.overheadRecoveredCents || 0;
      checks.push({ name: "Latest Month - Jobs", status: "OK", value: latest.jobsCount });
      checks.push({ name: "Latest Month - Revenue", status: "OK", value: `$${(totalRevenue / 100).toLocaleString()}` });
      checks.push({ name: "Latest Month - Overhead", status: "OK", value: `$${(overhead / 100).toLocaleString()}` });
    }
  }

  // Check reporting
  const reportLogs = await base44.asServiceRole.entities.ReportRunLog.filter({ companyId: company.companyId });
  if (reportLogs.length === 0) {
    warnings.push("No ReportRunLog entries found");
  } else {
    const recent = reportLogs.sort((a, b) => new Date(b.startedAt) - new Date(a.startedAt))[0];
    if (recent.status === "failed") {
      issues.push(`Last report run failed: ${recent.errorMessage}`);
    } else {
      checks.push({ name: "Last Report Status", status: "OK", value: recent.status });
    }
  }

  return {
    status: issues.length > 0 ? "FAIL" : (warnings.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}

async function checkAutomations(base44) {
  const issues = [];
  const checks = [];

  // Check critical automations (would be verified via agent run logs)
  const agentLogs = await base44.asServiceRole.entities.AgentRunLog.filter({});
  const dataIntegrityRuns = agentLogs.filter(l => l.agentName === "dataIntegrityAgent");
  const reportLogs = await base44.asServiceRole.entities.ReportRunLog.filter({});

  if (dataIntegrityRuns.length === 0) {
    issues.push("Data Integrity Agent has never run");
  } else {
    const recent = dataIntegrityRuns.sort((a, b) => new Date(b.ranAt) - new Date(a.ranAt))[0];
    checks.push({ 
      name: "Data Integrity Agent", 
      status: recent.status === "success" ? "OK" : "WARN", 
      value: recent.status 
    });
  }

  if (reportLogs.length === 0) {
    issues.push("Daily Reporting Automation has never run");
  } else {
    const recent = reportLogs.sort((a, b) => new Date(b.startedAt) - new Date(a.startedAt))[0];
    checks.push({ 
      name: "Daily Reporting Automation", 
      status: recent.status === "success" ? "OK" : "WARN", 
      value: recent.status 
    });
  }

  return {
    status: issues.length > 0 ? "FAIL" : "PASS",
    issues,
    checks
  };
}

async function checkMaterialCatalog(base44) {
  const issues = [];
  const warnings = [];
  const checks = [];

  const catalog = await base44.asServiceRole.entities.MaterialCatalog.filter({});
  if (catalog.length === 0) {
    issues.push("Material catalog is empty");
  } else {
    checks.push({ name: "Catalog Items", status: "OK", value: catalog.length });
    
    const byType = {};
    catalog.forEach(m => {
      byType[m.material_type || "unknown"] = (byType[m.material_type || "unknown"] || 0) + 1;
    });
    
    for (const [type, count] of Object.entries(byType)) {
      checks.push({ name: `Catalog - ${type}`, status: "OK", value: count });
    }

    // Check for unmapped items
    const unmapped = catalog.filter(m => !m.cost || m.cost === 0);
    if (unmapped.length > 0) {
      warnings.push(`${unmapped.length} catalog items without cost`);
    }
  }

  return {
    status: issues.length > 0 ? "FAIL" : (warnings.length > 0 ? "WARN" : "PASS"),
    issues,
    warnings,
    checks
  };
}