import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * SCHEDULED: Hourly Performance Rollup
 * Analyzes usage patterns and detects performance issues
 * Runs at top of every hour
 */

Deno.serve(async (req) => {
  const startTime = Date.now();
  
  try {
    const base44 = createClientFromRequest(req);
    const companyId = "PrivacyFenceCo49319";
    const dryRunMode = true;
    
    console.log(`[PerformanceRollup] Starting hourly analysis (dryRun: ${dryRunMode})`);
    
    // Call performance insights agent
    const response = await base44.asServiceRole.functions.invoke('performanceInsightsAgent', {
      companyId,
      triggerType: 'scheduled',
      dryRunMode
    });
    
    const result = response.data;
    
    // Log the rollup
    await base44.asServiceRole.entities.AgentRunLog.create({
      companyId,
      agentName: 'performanceInsightsAgent',
      triggerType: 'scheduled',
      status: 'success',
      dryRun: dryRunMode,
      durationMs: Date.now() - startTime,
      findings: {
        metrics: result.metrics,
        concerns: result.concerns,
        insights: result.insights
      },
      ranAt: new Date().toISOString()
    });
    
    console.log(`[PerformanceRollup] Found ${result.concerns?.length || 0} concerns`);
    
    return Response.json({
      success: true,
      companyId,
      dryRun: dryRunMode,
      concernsFound: result.concerns?.length || 0,
      durationMs: Date.now() - startTime
    });
    
  } catch (error) {
    console.error('[PerformanceRollup] Failed:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});