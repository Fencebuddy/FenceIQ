import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * PRODUCTION CUTOVER / CERTIFICATION
 * 
 * Gates KPI display switch to V2 (repaired metrics) only after:
 * 1. Phase 6 dual-run comparison passes all thresholds
 * 2. Phase 5 appointment coverage ≥ 85%
 * 3. Admin explicitly signs off on cutover
 * 4. Audit trail logged with timestamp and approver
 * 
 * Once certified, KPI display switches from V1 to V2 permanently.
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const companies = await base44.entities.CompanySettings.filter({});
    const companyId = companies[0]?.id;
    if (!companyId) {
      return Response.json({ error: 'No company found' }, { status: 400 });
    }

    const { action } = await req.json();

    if (action === 'checkReadiness') {
      return await checkCutoverReadiness(base44, companyId);
    } else if (action === 'certify') {
      return await executeCertification(base44, companyId, user);
    } else if (action === 'status') {
      return await getCertificationStatus(base44, companyId);
    } else {
      return Response.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});

// ============================================================
// CHECK CUTOVER READINESS
// ============================================================
async function checkCutoverReadiness(base44, companyId) {
  const readiness = {
    ready: false,
    timestamp: new Date().toISOString(),
    checks: [],
    blockers: [],
    warnings: []
  };

  try {
    // === CHECK 1: Phase 6 Dual-Run Acceptance Thresholds ===
    const dualRunCheck = await validatePhase6Thresholds(base44, companyId);
    readiness.checks.push(dualRunCheck);
    if (!dualRunCheck.passed) {
      readiness.blockers.push(dualRunCheck.message);
    }

    // === CHECK 2: Phase 5 Appointment Coverage ===
    const appointmentCoverageCheck = await validateAppointmentCoverage(base44, companyId);
    readiness.checks.push(appointmentCoverageCheck);
    if (!appointmentCoverageCheck.passed) {
      readiness.blockers.push(appointmentCoverageCheck.message);
    }

    // === CHECK 3: Cost Source Canonical ===
    const costSourceCheck = await validateCanonicalCostSource(base44, companyId);
    readiness.checks.push(costSourceCheck);
    if (!costSourceCheck.passed) {
      readiness.blockers.push(costSourceCheck.message);
    }

    // === CHECK 4: No Recent Errors in AutoFixLog ===
    const errorLogCheck = await validateNoRecentErrors(base44, companyId);
    readiness.checks.push(errorLogCheck);
    if (!errorLogCheck.passed) {
      readiness.warnings.push(errorLogCheck.message);
    }

    // === FINAL DECISION ===
    readiness.ready = readiness.blockers.length === 0;

    readiness.recommendation = readiness.ready
      ? 'All checks passed. Ready to certify production cutover.'
      : `${readiness.blockers.length} blocker(s) prevent cutover. Address and retry.`;

  } catch (error) {
    readiness.blockers.push(`Readiness check error: ${error.message}`);
    readiness.ready = false;
  }

  return Response.json(readiness);
}

async function validatePhase6Thresholds(base44, companyId) {
  const check = {
    name: 'Phase 6 Dual-Run Thresholds',
    passed: false,
    details: {},
    message: ''
  };

  try {
    // Query recent dual-run comparison
    const logs = await base44.entities.AutoFixLog.filter({
      companyId,
      operationType: 'dual_run_comparison'
    });

    if (logs.length === 0) {
      check.message = 'No dual-run comparison found. Run Phase 6 first.';
      return check;
    }

    const latestRun = logs.sort((a, b) => 
      new Date(b.appliedAt) - new Date(a.appliedAt)
    )[0];

    const confidence = latestRun.confidence || 'HOLD';
    check.details.latestRun = latestRun.appliedAt;
    check.details.status = confidence;

    if (confidence === 'GO') {
      check.passed = true;
      check.message = 'Dual-run comparison passed all thresholds.';
    } else {
      check.message = `Dual-run status: ${confidence}. Re-run Phase 6 to verify thresholds.`;
    }
  } catch (error) {
    check.message = `Phase 6 validation error: ${error.message}`;
  }

  return check;
}

async function validateAppointmentCoverage(base44, companyId) {
  const check = {
    name: 'Appointment Truth Coverage (Phase 5)',
    passed: false,
    details: { threshold: 85 },
    message: ''
  };

  try {
    const crmJobs = await base44.entities.CRMJob.filter({ companyId });
    const calendarEvents = await base44.entities.CalendarEvent.filter({ companyId });

    const jobsWithAppointments = new Set(
      calendarEvents
        .filter(e => e.crmJobId && e.type === 'appointment')
        .map(e => e.crmJobId)
    );

    const coveragePct = crmJobs.length > 0
      ? (jobsWithAppointments.size / crmJobs.length) * 100
      : 0;

    check.details.totalJobs = crmJobs.length;
    check.details.jobsWithAppointments = jobsWithAppointments.size;
    check.details.coveragePct = Math.round(coveragePct * 100) / 100;

    if (coveragePct >= 85) {
      check.passed = true;
      check.message = `Appointment coverage: ${coveragePct.toFixed(2)}% (meets 85% threshold).`;
    } else {
      check.message = `Appointment coverage: ${coveragePct.toFixed(2)}% (needs 85%). Sync more appointments or enable fallback.`;
    }
  } catch (error) {
    check.message = `Appointment coverage check error: ${error.message}`;
  }

  return check;
}

async function validateCanonicalCostSource(base44, companyId) {
  const check = {
    name: 'Canonical Cost Source (Phase 3)',
    passed: false,
    details: {},
    message: ''
  };

  try {
    const companies = await base44.entities.CompanySettings.filter({ id: companyId });
    const company = companies[0];

    if (!company || !company.canonicalCostSource) {
      check.message = 'No canonical cost source set. Configure CompanySettings.canonicalCostSource.';
      return check;
    }

    const validSources = ['proposal', 'jobcost'];
    if (!validSources.includes(company.canonicalCostSource)) {
      check.message = `Invalid cost source: ${company.canonicalCostSource}. Must be 'proposal' or 'jobcost'.`;
      return check;
    }

    check.details.costSource = company.canonicalCostSource;
    check.passed = true;
    check.message = `Canonical cost source: ${company.canonicalCostSource}`;
  } catch (error) {
    check.message = `Cost source check error: ${error.message}`;
  }

  return check;
}

async function validateNoRecentErrors(base44, companyId) {
  const check = {
    name: 'Recent Error Log',
    passed: false,
    details: { lookbackMinutes: 60 },
    message: ''
  };

  try {
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const recentErrors = await base44.entities.DiagnosticsLog.filter({
      companyId,
      severity: 'BLOCKING'
    });

    const recentBlockers = recentErrors.filter(e => e.timestamp > oneHourAgo);

    check.details.blockingErrors = recentBlockers.length;

    if (recentBlockers.length === 0) {
      check.passed = true;
      check.message = 'No blocking errors in last hour.';
    } else {
      check.message = `${recentBlockers.length} blocking error(s) in last hour. Review diagnostics.`;
    }
  } catch (error) {
    check.passed = true; // Don't block if we can't check
    check.message = 'Error log check skipped (diagnostics not available).';
  }

  return check;
}

// ============================================================
// EXECUTE CERTIFICATION
// ============================================================
async function executeCertification(base44, companyId, user) {
  const certification = {
    status: 'CERTIFICATION_FAILED',
    timestamp: new Date().toISOString(),
    approver: user.email,
    message: ''
  };

  try {
    // First, validate readiness
    const readinessResult = await checkCutoverReadiness(base44, companyId);
    const readiness = await readinessResult.json();

    if (!readiness.ready) {
      certification.message = `Cannot certify: ${readiness.blockers.join('; ')}`;
      certification.status = 'BLOCKED';
      return Response.json(certification, { status: 400 });
    }

    // Enable KPI V2 in company settings
    const companies = await base44.entities.CompanySettings.filter({ id: companyId });
    const company = companies[0];

    await base44.entities.CompanySettings.update(company.id, {
      kpiLiveInvalidateEnabled: true // Signals production KPI V2 is active
    });

    // Create certification record
    const certLog = await base44.entities.AutoFixLog.create({
      companyId,
      operationType: 'production_cutover_certification',
      confidence: 'CERTIFIED',
      reasoning: `Production cutover certified by ${user.email}. All Phase 0-7 checks passed. KPI display switched to V2.`,
      reversible: true, // Can be reversed if issues arise
      appliedAt: new Date().toISOString()
    });

    certification.status = 'CERTIFIED';
    certification.message = 'Production cutover certified. KPI V2 now active.';
    certification.certificationId = certLog.id;
    certification.effectiveAt = new Date().toISOString();

  } catch (error) {
    certification.message = `Certification error: ${error.message}`;
    certification.status = 'ERROR';
  }

  return Response.json(certification);
}

// ============================================================
// GET CERTIFICATION STATUS
// ============================================================
async function getCertificationStatus(base44, companyId) {
  const status = {
    certified: false,
    timestamp: new Date().toISOString(),
    certificationDate: null,
    approver: null,
    kpiVersion: 'V1_LEGACY' // Default to legacy
  };

  try {
    // Check if company has KPI V2 enabled
    const companies = await base44.entities.CompanySettings.filter({ id: companyId });
    const company = companies[0];

    if (company?.kpiLiveInvalidateEnabled) {
      status.certified = true;
      status.kpiVersion = 'V2_REPAIRED';
    }

    // Find certification log
    const certLogs = await base44.entities.AutoFixLog.filter({
      companyId,
      operationType: 'production_cutover_certification'
    });

    if (certLogs.length > 0) {
      const latestCert = certLogs.sort((a, b) => 
        new Date(b.appliedAt) - new Date(a.appliedAt)
      )[0];
      status.certificationDate = latestCert.appliedAt;
    }

  } catch (error) {
    status.error = error.message;
  }

  return Response.json(status);
}