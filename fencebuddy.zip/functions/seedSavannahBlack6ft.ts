import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Material Catalog entries for Black Savannah 6' vinyl system
    const catalogItems = [
      // Panels
      {
        crm_name: 'Savannah Vinyl Privacy Panel 6H x 8W Black',
        canonical_key: 'savannah_vinyl_6ft_privacy_panel_black',
        aliases: ['Savannah 6 Privacy Panel Black', 'Savannah Privacy Panel 8W'],
        keywords: ['savannah', 'vinyl', 'privacy', 'panel', '6ft', 'black'],
        category: 'panel',
        sub_category: 'privacy_panel',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 8\'W',
        unit: 'pcs',
        cost: 329.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl privacy panel',
        source: 'manual',
        active: true
      },
      // Single Gates
      {
        crm_name: 'Savannah Vinyl Single Gate 6H x 38.5W Black',
        canonical_key: 'savannah_vinyl_6ft_single_gate_38p5w_black',
        aliases: ['Savannah Single Gate 38.5W Black'],
        keywords: ['savannah', 'vinyl', 'single', 'gate', '6ft', 'black', '38.5'],
        category: 'gate',
        sub_category: 'single_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 38.5"W',
        unit: 'pcs',
        cost: 585.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl single gate 38.5" wide',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Single Gate 6H x 44.5W Black',
        canonical_key: 'savannah_vinyl_6ft_single_gate_44p5w_black',
        aliases: ['Savannah Single Gate 44.5W Black'],
        keywords: ['savannah', 'vinyl', 'single', 'gate', '6ft', 'black', '44.5'],
        category: 'gate',
        sub_category: 'single_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 44.5"W',
        unit: 'pcs',
        cost: 589.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl single gate 44.5" wide',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Single Gate 6H x 62.5W Black',
        canonical_key: 'savannah_vinyl_6ft_single_gate_62p5w_black',
        aliases: ['Savannah Single Gate 62.5W Black'],
        keywords: ['savannah', 'vinyl', 'single', 'gate', '6ft', 'black', '62.5'],
        category: 'gate',
        sub_category: 'single_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 62.5"W',
        unit: 'pcs',
        cost: 599.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl single gate 62.5" wide',
        source: 'manual',
        active: true
      },
      // Double Gates
      {
        crm_name: 'Savannah Vinyl Double Gate 6H x 38.5W Black',
        canonical_key: 'savannah_vinyl_6ft_double_gate_38p5w_black',
        aliases: ['Savannah Double Gate 38.5W Black'],
        keywords: ['savannah', 'vinyl', 'double', 'gate', '6ft', 'black', '38.5'],
        category: 'gate',
        sub_category: 'double_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 38.5"W',
        unit: 'pcs',
        cost: 1179.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl double gate 38.5" wide',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Double Gate 6H x 44.5W Black',
        canonical_key: 'savannah_vinyl_6ft_double_gate_44p5w_black',
        aliases: ['Savannah Double Gate 44.5W Black'],
        keywords: ['savannah', 'vinyl', 'double', 'gate', '6ft', 'black', '44.5'],
        category: 'gate',
        sub_category: 'double_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 44.5"W',
        unit: 'pcs',
        cost: 1189.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl double gate 44.5" wide',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Double Gate 6H x 62.5W Black',
        canonical_key: 'savannah_vinyl_6ft_double_gate_62p5w_black',
        aliases: ['Savannah Double Gate 62.5W Black'],
        keywords: ['savannah', 'vinyl', 'double', 'gate', '6ft', 'black', '62.5'],
        category: 'gate',
        sub_category: 'double_gate',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '6\'H x 62.5"W',
        unit: 'pcs',
        cost: 1199.99,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl double gate 62.5" wide',
        source: 'manual',
        active: true
      },
      // Posts
      {
        crm_name: 'Savannah Vinyl Line Post 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_line_post_black',
        aliases: ['Savannah Line Post Black', 'Savannah 5x5 Post'],
        keywords: ['savannah', 'vinyl', 'line', 'post', '6ft', 'black', '5x5'],
        category: 'post',
        sub_category: 'line_post',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5" x 105"',
        unit: 'pcs',
        cost: 65.00,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl line post 5x5x105"',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl End Post 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_end_post_black',
        aliases: ['Savannah End Post Black', 'Savannah 5x5 End Post'],
        keywords: ['savannah', 'vinyl', 'end', 'post', '6ft', 'black', '5x5'],
        category: 'post',
        sub_category: 'end_post',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5" x 105"',
        unit: 'pcs',
        cost: 65.00,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl end post 5x5x105"',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Corner Post 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_corner_post_black',
        aliases: ['Savannah Corner Post Black', 'Savannah 5x5 Corner Post'],
        keywords: ['savannah', 'vinyl', 'corner', 'post', '6ft', 'black', '5x5'],
        category: 'post',
        sub_category: 'corner_post',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5" x 105"',
        unit: 'pcs',
        cost: 65.00,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl corner post 5x5x105"',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl Blank Post 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_blank_post_black',
        aliases: ['Savannah Blank Post Black', 'Savannah 5x5 Blank'],
        keywords: ['savannah', 'vinyl', 'blank', 'post', '6ft', 'black', '5x5'],
        category: 'post',
        sub_category: 'line_post',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5" x 105"',
        unit: 'pcs',
        cost: 65.00,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl blank post 5x5x105"',
        source: 'manual',
        active: true
      },
      {
        crm_name: 'Savannah Vinyl 3-Way Post 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_3way_post_black',
        aliases: ['Savannah 3-Way Post Black', 'Savannah 5x5 3-Way'],
        keywords: ['savannah', 'vinyl', '3way', 'post', '6ft', 'black', '5x5'],
        category: 'post',
        sub_category: 'line_post',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5" x 105"',
        unit: 'pcs',
        cost: 65.00,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl 3-way post 5x5x105"',
        source: 'manual',
        active: true
      },
      // Post Caps
      {
        crm_name: 'Savannah Vinyl Post Cap 5x5 Black',
        canonical_key: 'savannah_vinyl_6ft_post_cap_black',
        aliases: ['Savannah Post Cap Black', 'Savannah 5x5 Cap'],
        keywords: ['savannah', 'vinyl', 'post', 'cap', '6ft', 'black', '5x5'],
        category: 'hardware',
        sub_category: 'post_cap',
        material_type: 'vinyl',
        finish: 'black_vinyl',
        size: '5" x 5"',
        unit: 'pcs',
        cost: 5.67,
        brand: 'Savannah',
        notes: 'Black Savannah vinyl external post cap 5x5"',
        source: 'manual',
        active: true
      }
    ];

    // Create all MaterialCatalog entries
    const createdCatalogItems = await base44.asServiceRole.entities.MaterialCatalog.bulkCreate(catalogItems);
    
    console.log(`Created ${createdCatalogItems.length} catalog items`);

    // Create CatalogLinkMap entries linking to canonical keys for takeoff matching
    const catalogLinks = createdCatalogItems.map(item => ({
      canonical_key: item.canonical_key,
      catalog_item_id: item.id,
      priority: 1,
      active: true,
      notes: `Black Savannah 6' vinyl system - ${item.crm_name}`
    }));

    const createdLinks = await base44.asServiceRole.entities.CatalogLinkMap.bulkCreate(catalogLinks);

    console.log(`Created ${createdLinks.length} catalog links`);

    return Response.json({
      success: true,
      catalogItemsCreated: createdCatalogItems.length,
      catalogLinksCreated: createdLinks.length,
      message: 'Black Savannah 6\' vinyl system seeded successfully'
    });
  } catch (error) {
    console.error('Seed error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});