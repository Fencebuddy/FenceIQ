import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * TEST DETERMINISTIC PRICING
 * Runs mandatory test cases for discount enforcement
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }
    
    const results = [];
    
    // Test inputs
    const baseInputs = {
      materialCost: 5000,
      laborCost: 3000,
      deliveryCost: 75,
      resolvedLineItems: [
        { name: 'Vinyl Post 6ft White', material_type: 'Vinyl', quantity: 50, unitCost: 40 },
        { name: 'Vinyl Panel 6ft White', material_type: 'Vinyl', quantity: 45, unitCost: 70 }
      ],
      overheadRate: 0.14,
      commissionRate: 0.10
    };
    
    // TEST 1: Full tokens (2+3+5+5 = 15%) - Non-wood material
    results.push({
      test: 'Test 1: Full tokens (15%) on Vinyl',
      input: {
        ...baseInputs,
        selectedTokensPct: [2, 3, 5, 5]
      }
    });
    
    const test1 = await base44.functions.invoke('computeDeterministicPricing', {
      ...baseInputs,
      selectedTokensPct: [2, 3, 5, 5]
    });
    
    results[0].output = test1.data;
    results[0].passed = test1.data.success && 
                        test1.data.snapshot.netPctAfterDiscount >= 25;
    
    // TEST 2: Attempt third 5% token (invalid)
    results.push({
      test: 'Test 2: Invalid tokens (2+5+5+5 = 17%, third 5%)',
      input: {
        ...baseInputs,
        selectedTokensPct: [2, 5, 5, 5]
      }
    });
    
    const test2 = await base44.functions.invoke('computeDeterministicPricing', {
      ...baseInputs,
      selectedTokensPct: [2, 5, 5, 5]
    });
    
    results[1].output = test2.data;
    results[1].passed = !test2.data.success && 
                        test2.data.error === 'DISCOUNT_TOKENS_INVALID';
    
    // TEST 3: Wood material requires 30% net
    results.push({
      test: 'Test 3: Wood material with full discount (30% floor)',
      input: {
        ...baseInputs,
        selectedTokensPct: [2, 3, 5, 5],
        resolvedLineItems: [
          { name: 'Wood Post 6ft Cedar', material_type: 'Wood', quantity: 50, unitCost: 30 },
          { name: 'Wood Picket 6ft Cedar', material_type: 'Wood', quantity: 200, unitCost: 15 }
        ]
      }
    });
    
    const test3 = await base44.functions.invoke('computeDeterministicPricing', {
      ...baseInputs,
      selectedTokensPct: [2, 3, 5, 5],
      resolvedLineItems: [
        { name: 'Wood Post 6ft Cedar', material_type: 'Wood', quantity: 50, unitCost: 30 },
        { name: 'Wood Picket 6ft Cedar', material_type: 'Wood', quantity: 200, unitCost: 15 }
      ]
    });
    
    results[2].output = test3.data;
    results[2].passed = test3.data.success && 
                        test3.data.snapshot.netPctAfterDiscount >= 30;
    
    // TEST 4: Reproducibility - same inputs produce identical cents
    results.push({
      test: 'Test 4: Reproducibility (same hash, same cents)',
      input: baseInputs
    });
    
    const test4a = await base44.functions.invoke('computeDeterministicPricing', {
      ...baseInputs,
      selectedTokensPct: [2, 3]
    });
    
    const test4b = await base44.functions.invoke('computeDeterministicPricing', {
      ...baseInputs,
      selectedTokensPct: [2, 3]
    });
    
    results[3].output = {
      run1: test4a.data.snapshot,
      run2: test4b.data.snapshot
    };
    
    results[3].passed = 
      test4a.data.snapshot.pricingInputsHash === test4b.data.snapshot.pricingInputsHash &&
      test4a.data.snapshot.retailPriceCents === test4b.data.snapshot.retailPriceCents &&
      test4a.data.snapshot.discountedPriceCents === test4b.data.snapshot.discountedPriceCents;
    
    // Summary
    const allPassed = results.every(r => r.passed);
    
    return Response.json({
      success: allPassed,
      summary: {
        total: results.length,
        passed: results.filter(r => r.passed).length,
        failed: results.filter(r => !r.passed).length
      },
      results
    });
    
  } catch (error) {
    console.error('[testDeterministicPricing] Error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});