import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }
    
    const { mapping } = await req.json();
    
    if (!mapping || !Array.isArray(mapping)) {
      return Response.json({ error: 'mapping array required' }, { status: 400 });
    }
    
    // Fetch all catalog items
    const catalog = await base44.asServiceRole.entities.MaterialCatalog.list('-last_updated', 500);
    
    const updates = [];
    const notFound = [];
    
    // Process each mapping entry
    for (const entry of mapping) {
      const crmNames = [entry.primary_crm_name, ...(entry.alternate_crm_names || [])].filter(Boolean);
      const keywords = entry.match_keywords || [];
      
      // Find and update all matching catalog items
      for (const crmName of crmNames) {
        const catalogItem = catalog.find(item => 
          item.crm_name && item.crm_name.trim() === crmName.trim()
        );
        
        if (catalogItem) {
          await base44.asServiceRole.entities.MaterialCatalog.update(catalogItem.id, {
            keywords: keywords,
            last_updated: new Date().toISOString()
          });
          updates.push({ crm_name: crmName, keywords: keywords.length });
        } else {
          notFound.push(crmName);
        }
      }
    }
    
    return Response.json({
      success: true,
      updated: updates.length,
      not_found: notFound.length,
      updates,
      notFound: notFound.slice(0, 20) // First 20 for review
    });
    
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});