import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Scheduled audit runner with alert notifications.
 * Runs audit functions and sends email alerts on failures or critical issues.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow platform scheduler (no user token) and admin users
    let isAuthorized = false;
    try {
      const user = await base44.auth.me();
      if (user?.role === 'admin') isAuthorized = true;
    } catch (_) {
      // No user token = platform scheduler — allow
      isAuthorized = true;
    }

    if (!isAuthorized) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { auditType = 'system', recipientEmail } = payload;

    console.log(`[scheduledAuditWithAlerts] Starting ${auditType} audit`);

    let auditResult;

    // Run appropriate audit — use service role entities directly (no cross-function invoke)
    let auditData;
    if (auditType === 'system' || auditType === 'company') {
      auditData = await runInlineAudit(base44.asServiceRole);
    console.log('[audit] inline audit completed:', JSON.stringify(auditData));
    } else {
      return Response.json({ error: 'Invalid auditType' }, { status: 400 });
    }

    const hasCriticalIssues = auditData.overallStatus === 'FAIL';

    // Prepare alert email if critical issues detected
    if (hasCriticalIssues && recipientEmail) {
      const emailBody = generateAuditAlertEmail(auditType, auditData);

      try {
        await fetch('https://api.postmarkapp.com/email', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Postmark-Server-Token': Deno.env.get('POSTMARK_API_TOKEN')
          },
          body: JSON.stringify({
            From: 'info@fencebuddy.com',
            To: recipientEmail,
            Subject: `⚠️ CRITICAL: ${auditType} Audit Failed - ${new Date().toISOString().split('T')[0]}`,
            TextBody: emailBody
          })
        });

        console.log(`[scheduledAuditWithAlerts] Alert email sent to ${recipientEmail}`);
      } catch (emailError) {
        console.error('[scheduledAuditWithAlerts] Email send failed:', emailError);
        // Don't fail the audit, just log the email error
      }
    }

    return Response.json({
      success: true,
      auditType,
      status: auditData.overallStatus,
      hasCriticalIssues,
      checks: auditData.checks,
      summary: auditData.summary,
      timestamp: new Date().toISOString(),
      alertSent: hasCriticalIssues && !!recipientEmail
    });

  } catch (error) {
    console.error('[scheduledAuditWithAlerts] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

/**
 * Lightweight inline audit — checks CRM data health without cross-function invocation.
 * Returns { overallStatus, checks[], summary }
 */
async function runInlineAudit(db) {
  const checks = [];
  let hasFail = false;

  try {
    const companies = await db.entities.CompanySettings.filter({});
    const company = companies[0];
    // companyId is the custom string field used as FK (e.g. "PrivacyFenceCo49319")
    const companyId = company?.companyId;

    if (!company) {
      return { overallStatus: 'FAIL', checks: [{ name: 'Company', status: 'MISSING' }], summary: 'No company found' };
    }

    // Check 1: CRM jobs exist — list all (single-tenant, no filter needed)
    const crmJobs = await db.entities.CRMJob.list(undefined, 200);
    checks.push({ name: 'CRMJob count', status: crmJobs.length > 0 ? 'PASS' : 'WARN', value: crmJobs.length });

    // Check 2: Rollup freshness — list all daily rollups, take the latest
    const rollups = await db.entities.ReportRollupDaily.list('-rollupDate', 10);
    const latestRollup = rollups[0];
    // rollupDate is "YYYY-MM-DD" — treat as start of that day UTC
    const rollupAgeHours = latestRollup?.rollupDate
      ? (Date.now() - new Date(latestRollup.rollupDate + 'T00:00:00Z').getTime()) / 3600000
      : Infinity;
    const rollupStatus = rollupAgeHours < 26 ? 'PASS' : rollupAgeHours < 48 ? 'WARN' : 'FAIL';
    if (rollupStatus === 'FAIL') hasFail = true;
    checks.push({ name: 'Rollup freshness', status: rollupStatus, ageHours: Math.round(rollupAgeHours) });

    // Check 3: SaleSnapshot integrity
    const soldJobs = crmJobs.filter(j => j.saleStatus === 'sold');
    const snapshots = await Promise.all(
      soldJobs.slice(0, 20).map(j => db.entities.SaleSnapshot.filter({ crmJobId: j.id }).catch(() => []))
    );
    const missingSnaps = soldJobs.slice(0, 20).filter((_, i) => snapshots[i].length === 0).length;
    const snapStatus = missingSnaps === 0 ? 'PASS' : missingSnaps > 2 ? 'FAIL' : 'WARN';
    if (snapStatus === 'FAIL') hasFail = true;
    checks.push({ name: 'SaleSnapshot coverage', status: snapStatus, missingSampled: missingSnaps });

    // Check 4: Reporting enabled
    const reportingStatus = company?.reportingEnabled ? 'PASS' : 'WARN';
    checks.push({ name: 'Reporting enabled', status: reportingStatus });

    return {
      overallStatus: hasFail ? 'FAIL' : 'PASS',
      checks,
      companyId,
      summary: `${checks.filter(c => c.status === 'PASS').length}/${checks.length} checks passed`
    };
  } catch (error) {
    console.error('[audit] runInlineAudit error:', error.message, error.stack);
    return { overallStatus: 'FAIL', checks, summary: error.message };
  }
}

/**
 * Generate formatted email body for audit alerts
 */
function generateAuditAlertEmail(auditType, auditData) {
  const timestamp = new Date().toISOString();
  const failedSections = Object.entries(auditData.sections || {})
    .filter(([_, section]) => section.status === 'FAIL')
    .map(([name, section]) => ({
      name,
      issues: section.issues || [],
      warnings: section.warnings || []
    }));

  const issuesList = failedSections
    .flatMap(s => [
      ...s.issues.map(i => `• ${s.name}: ${i}`),
      ...s.warnings.map(w => `⚠ ${s.name}: ${w}`)
    ])
    .join('\n');

  return `
AUDIT ALERT: ${auditType.toUpperCase()} AUDIT FAILED
Timestamp: ${timestamp}
Status: ${auditData.overallStatus}

CRITICAL ISSUES DETECTED:

${issuesList || 'No specific issues logged'}

ACTION REQUIRED:
1. Review the full audit report in the admin dashboard
2. Address the issues listed above
3. Re-run the audit to confirm resolution

Company: ${auditData.company?.id || 'N/A'}
Region: ${auditData.company?.timezone || 'N/A'}

---
This is an automated alert from FenceIQ. Do not reply to this email.
  `.trim();
}