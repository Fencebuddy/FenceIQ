import { base44 } from '@/api/base44Client';
import { isSoldForReporting } from './jobStatusService';

/**
 * Owner Dashboard Service
 * REWRITTEN: Simplified pricing logic to use ProposalPricingSnapshot.direct_cost as PRIMARY truth
 */

/**
 * Get owner goals from CompanySettings
 */
export async function getOwnerGoals(companyId) {
    // CRITICAL: filter by companyId (business key), NOT id (database key)
    const settings = await base44.entities.CompanySettings.filter({ companyId });
    if (!settings.length) {
        return {
            goalNetMarginPercent: 25,
            goalCloseRatePercent: 30,
            goalAvgTicket: 18000,
            staleProposalDays: 3
        };
    }
    
    const s = settings[0];
    return {
        goalNetMarginPercent: s.goalNetMarginPercent ?? 25,
        goalCloseRatePercent: s.goalCloseRatePercent ?? 30,
        goalAvgTicket: s.goalAvgTicket ?? 18000,
        staleProposalDays: s.staleProposalDays ?? 3,
        // Resolve overhead/commission from whichever field is populated
        defaultOverheadRate: s.defaultOverheadRate ?? (s.overheadPct ? s.overheadPct / 100 : 0.14),
        defaultCommissionRate: s.defaultCommissionRate ?? (s.commissionPct ? s.commissionPct / 100 : 0.10)
    };
}

/**
 * Get signed deals truth set (SIMPLIFIED: ProposalPricingSnapshot is primary truth)
 */
/**
 * Helper: Get all rollup data for a date range, including malformed buckets
 * This provides dual-format fallback to handle both YYYY-MM-DD and YYYY-DD-MM keys
 */
async function getRollupDataForDateRange(companyId, dateStart, dateEnd, repUserId, fenceCategory, source) {
    const rollupRows = [];
    
    // Generate all expected date buckets (YYYY-MM-DD)
    const current = new Date(dateStart);
    const end = new Date(dateEnd);
    const expectedBuckets = [];
    
    while (current <= end) {
        const year = current.getFullYear();
        const month = String(current.getMonth() + 1).padStart(2, '0');
        const day = String(current.getDate()).padStart(2, '0');
        expectedBuckets.push(`${year}-${month}-${day}`);
        current.setDate(current.getDate() + 1);
    }
    
    // Query ALL rollups for this company in the date range
    const allRollups = await base44.entities.ReportRollupDaily.filter({ companyId });
    
    // Group by (correctedDate, repUserId, fenceCategory, source) and merge malformed/correct pairs
    const rollupMap = new Map();
    
    for (const rollup of allRollups) {
        if (rollup.isRepaired) continue; // Skip already-repaired marked rows
        
        let correctedDateBucket = rollup.rollupDate;
        
        // Detect malformed (YYYY-DD-MM): month > 12
        const parts = rollup.rollupDate.split('-');
        if (parts.length === 3) {
            const [year, monthOrDay, dayOrMonth] = parts;
            const m = parseInt(monthOrDay);
            const d = parseInt(dayOrMonth);
            
            // If month is impossible (>12) and day is plausible (<=12), it's swapped
            if (m > 12 && d <= 12) {
                correctedDateBucket = `${year}-${dayOrMonth}-${monthOrDay}`;
            }
        }
        
        // Only include if corrected date is in expected range
        if (!expectedBuckets.includes(correctedDateBucket)) continue;
        
        // Build composite key for merging
        const key = `${correctedDateBucket}|${rollup.repUserId || 'null'}|${rollup.fenceCategory || 'null'}|${rollup.source || 'null'}`;
        
        if (!rollupMap.has(key)) {
            rollupMap.set(key, {
                companyId: rollup.companyId,
                rollupDate: correctedDateBucket,
                repUserId: rollup.repUserId,
                fenceCategory: rollup.fenceCategory,
                source: rollup.source,
                signedCount: 0,
                wonRevenue: 0,
                netProfitAmount: 0,
                netMarginPercentWeighted: 0,
                avgTicket: 0,
                proposalsSentCount: 0,
                proposalsSignedCount: 0
            });
        }
        
        const merged = rollupMap.get(key);
        
        // Merge numeric fields
        merged.signedCount += rollup.signedCount || 0;
        merged.wonRevenue += rollup.wonRevenue || 0;
        merged.netProfitAmount += rollup.netProfitAmount || 0;
        merged.proposalsSentCount += rollup.proposalsSentCount || 0;
        merged.proposalsSignedCount += rollup.proposalsSignedCount || 0;
    }
    
    // Recompute weighted margins after merge
    for (const merged of rollupMap.values()) {
        if (merged.wonRevenue > 0) {
            merged.netMarginPercentWeighted = (merged.netProfitAmount / merged.wonRevenue) * 100;
        }
        if (merged.signedCount > 0) {
            merged.avgTicket = merged.wonRevenue / merged.signedCount;
        }
    }
    
    return Array.from(rollupMap.values());
}

export async function getSignedDealsTruthSet({ companyId, dateStart, dateEnd, repUserId, fenceCategory, source }) {
    // Load company settings for default rates (Phase 11.1)
    const companySettingsRows = await base44.entities.CompanySettings.filter({ companyId });
    const companySettings = companySettingsRows?.[0] || {};
    const defaultOverheadRate = companySettings.defaultOverheadRate 
        ?? (companySettings.overheadPct ? companySettings.overheadPct / 100 : 0.14);
    const defaultCommissionRate = companySettings.defaultCommissionRate 
        ?? (companySettings.commissionPct ? companySettings.commissionPct / 100 : 0.10);
    
    // Query ALL CRMJobs in company (use companyId business identifier, NOT database id)
    const allJobs = await base44.entities.CRMJob.filter({ companyId });
    
    console.log('[OwnerDashboard] Total CRMJobs:', allJobs.length);
    console.log('[OwnerDashboard] Date range:', { dateStart, dateEnd });
    
    // PHASE 5a: Scoped SaleSnapshot + ProposalPricingSnapshot loading
    // Step 1: Build ID sets for scoped snapshot loading
    const snapshotIdSet = new Set();
    const externalJobIdToFetch = [];
    const crmJobIdSet = new Set();
    
    for (const job of allJobs) {
        crmJobIdSet.add(job.id);
        if (job.currentProposalSnapshotId) {
            snapshotIdSet.add(job.currentProposalSnapshotId);
        } else if (job.externalJobId) {
            externalJobIdToFetch.push(job.externalJobId);
        }
    }

    // Step 2: Fetch SaleSnapshot (scoped by crmJobId), ProposalPricingSnapshot (by ID + job_id), in parallel
    const [snapshotFetchResults, fallbackFetchResults, saleSnapshotResults] = await Promise.all([
        Promise.all(
            Array.from(snapshotIdSet).map(sid =>
                base44.entities.ProposalPricingSnapshot.filter({ id: sid })
                    .then(rows => rows[0] || null)
                    .catch(() => null)
            )
        ),
        Promise.all(
            externalJobIdToFetch.map(extId =>
                base44.entities.ProposalPricingSnapshot.filter({ job_id: extId })
                    .then(rows => rows[0] || null)
                    .catch(() => null)
            )
        ),
        // PHASE 5a: Fetch SaleSnapshot per crmJobId (scoped, no cross-tenant load)
        Promise.all(
            Array.from(crmJobIdSet).map(crmJobId =>
                base44.entities.SaleSnapshot.filter({ crmJobId })
                    .then(rows => rows.sort((a, b) => new Date(b.soldAt) - new Date(a.soldAt))[0] || null)
                    .catch(() => null)
            )
        )
    ]);

    // Deduplicate ProposalPricingSnapshots
    const fetchedSnapshots = [...snapshotFetchResults, ...fallbackFetchResults].filter(Boolean);
    const seenIds = new Set();
    const dedupedSnapshots = fetchedSnapshots.filter(s => {
        if (seenIds.has(s.id)) return false;
        seenIds.add(s.id);
        return true;
    });
    const totalProposalSnapshotsLoaded = dedupedSnapshots.length;
    const allFetchedSnapshots = dedupedSnapshots;

    // Map SaleSnapshots by crmJobId
    const saleSnapshotMap = new Map();
    const crmJobIdArray = Array.from(crmJobIdSet);
    saleSnapshotResults.forEach((ss, i) => {
        if (ss) saleSnapshotMap.set(crmJobIdArray[i], ss);
    });
    const totalSaleSnapshotsLoaded = saleSnapshotMap.size;

    console.log('[OwnerDashboard] PHASE 5a Snapshot loading (scoped, no cross-tenant):', {
        crmJobsTotal: allJobs.length,
        proposalSnapshotIdsRequested: snapshotIdSet.size,
        proposalSnapshotsFetched: totalProposalSnapshotsLoaded,
        saleSnapshotsFetched: totalSaleSnapshotsLoaded,
        crossTenantRisk: 'ELIMINATED'
    });

    // Step 3: Build proposalSnapMap keyed by snapshot id ONLY
    // job_id fallback is keyed as `${companyId}:${job_id}` to prevent cross-tenant collision
    const proposalSnapMap = new Map();
    const jobIdKeyCount = new Map(); // track collisions within this tenant's fetched set

    for (const pps of allFetchedSnapshots) {
        // Primary key: snapshot id (already scoped — we only fetched ids from this company's jobs)
        proposalSnapMap.set(pps.id, pps);

        // SNAPSHOT MISMATCH guard: verify the fetched snapshot id matches what we requested
        if (!snapshotIdSet.has(pps.id)) {
            console.error('[OwnerDashboard] 🚨 SNAPSHOT_MISMATCH: fetched snapshot id not in requested set', {
                fetchedId: pps.id,
                companyId
            });
            await base44.entities.AlertEvent.create({
                rule: 'SNAPSHOT_MISMATCH',
                severity: 'CRITICAL',
                title: 'ProposalPricingSnapshot id mismatch on dashboard load',
                description: `Fetched snapshot ${pps.id} was not in the requested id set for companyId=${companyId}`,
                metric: 'snapshot_integrity',
                value: 1,
                threshold: 0,
                tags: { companyId, environment: 'production' },
                timestamp: new Date().toISOString()
            }).catch(() => {});
            proposalSnapMap.delete(pps.id); // do not use mismatched snapshot
            continue;
        }

        // Secondary key: `${companyId}:${job_id}` — only if job_id exists (for externalJobId fallback)
        if (pps.job_id) {
            const scopedJobKey = `${companyId}:${pps.job_id}`;
            if (jobIdKeyCount.has(scopedJobKey)) {
                // HARD ERROR: two snapshots share same job_id within this company's fetched set
                const existingId = jobIdKeyCount.get(scopedJobKey);
                console.error('[OwnerDashboard] 🚨 JOB_ID_COLLISION: two snapshots share job_id within company', {
                    companyId,
                    job_id: pps.job_id,
                    snapshot1: existingId,
                    snapshot2: pps.id
                });
                await base44.entities.AlertEvent.create({
                    rule: 'JOB_ID_COLLISION',
                    severity: 'CRITICAL',
                    title: 'ProposalPricingSnapshot job_id collision detected',
                    description: `Two snapshots (${existingId}, ${pps.id}) share job_id=${pps.job_id} for companyId=${companyId}`,
                    metric: 'snapshot_job_id_uniqueness',
                    value: 2,
                    threshold: 1,
                    tags: { companyId, environment: 'production' },
                    timestamp: new Date().toISOString()
                }).catch(() => {});
                // Remove the scoped key — do not use either for fallback
                proposalSnapMap.delete(scopedJobKey);
                jobIdKeyCount.set(scopedJobKey, '__COLLISION__');
            } else {
                jobIdKeyCount.set(scopedJobKey, pps.id);
                proposalSnapMap.set(scopedJobKey, pps);
            }
        }
    }

    // Diagnostic: direct_cost coverage
    const snapshotsWithDirectCost = allFetchedSnapshots.filter(s => s.direct_cost && s.direct_cost > 0);
    const snapshotsWithRevenue = allFetchedSnapshots.filter(s => s.agreed_subtotal && s.agreed_subtotal > 0);
    console.log('[OwnerDashboard] Snapshot diagnostic (scoped):', {
        fetched: totalProposalSnapshotsLoaded,
        withRevenue: snapshotsWithRevenue.length,
        withDirectCost: snapshotsWithDirectCost.length
    });
    if (snapshotsWithRevenue.length > 0 && snapshotsWithDirectCost.length === 0) {
        console.error('[OwnerDashboard] 🚨 CRITICAL: ProposalPricingSnapshot has NO direct_cost data!');
    }
    
    const truthRows = [];
    
    for (const crmJob of allJobs) {
         // MASTER RULE: Must pass isSoldForReporting check
                 const isSold = isSoldForReporting(crmJob);
                 if (!isSold) {
                     continue;
                 }

                 // Date filter: use wonAt if available (when sold), else saleStatusUpdatedAt, else created_date
                 const dateToCheck = crmJob.wonAt || crmJob.saleStatusUpdatedAt || crmJob.created_date;
                 const jobDate = new Date(dateToCheck);
                 const start = new Date(dateStart);
                 const end = new Date(dateEnd);

                 // Add 1 day to end to include jobs from today
                 end.setDate(end.getDate() + 1);

                 if (jobDate < start || jobDate > end) {
                     continue;
                 }
        
        // Apply optional filters
        if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
        if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
        if (source && crmJob.source !== source) continue;
        
        // PHASE 5a: Prefer SaleSnapshot (immutable locked truth) over ProposalPricingSnapshot
        let totalPrice = 0;
        let netProfitAmount = null;
        let netProfitPercent = null;
        let directCost = null;
        let modelSellPrice = null;
        let presentedSellPrice = null;
        let overrideApplied = false;
        let overheadPercent = defaultOverheadRate;
        let commissionPercent = defaultCommissionRate;
        let overheadRateSource = 'company_default';
        let commissionRateSource = 'company_default';
        let isEstimated = false;
        let estimateReason = null;
        let revenueSource = 'unknown'; // 'sale_snapshot' | 'proposal_snapshot' | 'fallback_contract'

        // Get ProposalPricingSnapshot for model/override data
        let proposalPricingSnapshot = null;
        
        if (crmJob.currentProposalSnapshotId) {
            proposalPricingSnapshot = proposalSnapMap.get(crmJob.currentProposalSnapshotId);
        }
        
        if (!proposalPricingSnapshot && crmJob.externalJobId) {
            const scopedJobKey = `${companyId}:${crmJob.externalJobId}`;
            const candidate = proposalSnapMap.get(scopedJobKey);
            if (candidate && candidate !== '__COLLISION__') {
                proposalPricingSnapshot = candidate;
            }
        }

        if (proposalPricingSnapshot && crmJob.currentProposalSnapshotId) {
            if (proposalPricingSnapshot.id !== crmJob.currentProposalSnapshotId) {
                console.error('[OwnerDashboard] 🚨 SNAPSHOT_MISMATCH per-job:', {
                    jobNumber: crmJob.jobNumber,
                    expected: crmJob.currentProposalSnapshotId,
                    got: proposalPricingSnapshot.id
                });
                proposalPricingSnapshot = null;
            }
        }

        // ────────────────────────────────────────────────────────────────────────
        // PHASE 5a: REVENUE & PROFIT RESOLUTION (prefer SaleSnapshot)
        // ────────────────────────────────────────────────────────────────────────

        const saleSnapshot = saleSnapshotMap.get(crmJob.id);

        if (saleSnapshot && saleSnapshot.contractValueCents > 0) {
            // PRIMARY PATH: SaleSnapshot is the canonical locked truth
            totalPrice = saleSnapshot.contractValueCents / 100;
            revenueSource = 'sale_snapshot';

            if (saleSnapshot.direct_cost_cents > 0) {
                directCost = saleSnapshot.direct_cost_cents / 100;
                netProfitAmount = saleSnapshot.net_profit_cents / 100;
                netProfitPercent = totalPrice > 0 ? (netProfitAmount / totalPrice) * 100 : 0;

                console.log('[OwnerDashboard] ✅ SUCCESS (SaleSnapshot):', {
                    jobNumber: crmJob.jobNumber,
                    contractValue: totalPrice,
                    directCost,
                    netProfitAmount,
                    netProfitPercent
                });
            } else {
                // Cost unavailable at lock time
                isEstimated = true;
                estimateReason = 'sale_snapshot_no_cost';
                directCost = null;
                netProfitAmount = null;
                netProfitPercent = null;

                console.warn('[OwnerDashboard] ESTIMATED (SaleSnapshot, no cost):', {
                    jobNumber: crmJob.jobNumber,
                    contractValue: totalPrice
                });
            }

            // Model/override data from ProposalSnapshot (not frozen in SaleSnapshot)
            if (proposalPricingSnapshot) {
                modelSellPrice = proposalPricingSnapshot.model_sell_price;
                presentedSellPrice = proposalPricingSnapshot.presented_sell_price;
                overrideApplied = proposalPricingSnapshot.override_applied || false;
                overheadPercent = proposalPricingSnapshot.overhead_percent || defaultOverheadRate;
                commissionPercent = proposalPricingSnapshot.commission_percent || defaultCommissionRate;
                overheadRateSource = proposalPricingSnapshot.overhead_percent ? 'snapshot' : 'company_default';
                commissionRateSource = proposalPricingSnapshot.commission_percent ? 'snapshot' : 'company_default';
            }

        } else if (proposalPricingSnapshot) {
            // FALLBACK: ProposalPricingSnapshot (live estimate)
            revenueSource = 'proposal_snapshot';
            const agreedSubtotal = proposalPricingSnapshot.agreed_subtotal || 0;
            totalPrice = agreedSubtotal;
            modelSellPrice = proposalPricingSnapshot.model_sell_price;
            presentedSellPrice = proposalPricingSnapshot.presented_sell_price;
            overrideApplied = proposalPricingSnapshot.override_applied || false;
            overheadPercent = proposalPricingSnapshot.overhead_percent || defaultOverheadRate;
            commissionPercent = proposalPricingSnapshot.commission_percent || defaultCommissionRate;
            overheadRateSource = proposalPricingSnapshot.overhead_percent ? 'snapshot' : 'company_default';
            commissionRateSource = proposalPricingSnapshot.commission_percent ? 'snapshot' : 'company_default';

            directCost = proposalPricingSnapshot.direct_cost || 0;
            
            if (directCost > 0) {
                const overhead = agreedSubtotal * overheadPercent;
                const commission = agreedSubtotal * commissionPercent;
                netProfitAmount = agreedSubtotal - directCost - overhead - commission;
                netProfitPercent = agreedSubtotal > 0 ? (netProfitAmount / agreedSubtotal) * 100 : 0;

                console.log('[OwnerDashboard] ✅ SUCCESS (ProposalSnapshot):', {
                    jobNumber: crmJob.jobNumber,
                    agreedSubtotal,
                    directCost,
                    netProfitAmount,
                    netProfitPercent
                });
            } else {
                isEstimated = true;
                estimateReason = 'proposal_snapshot_no_cost';
                directCost = null;
                netProfitAmount = null;
                netProfitPercent = null;

                console.warn('[OwnerDashboard] ESTIMATED (ProposalSnapshot, no cost):', {
                    jobNumber: crmJob.jobNumber,
                    agreedSubtotal: totalPrice
                });
            }
        } else if (crmJob.contractValueCents > 0) {
            // FALLBACK: No ProposalPricingSnapshot linked, but job has a locked contract value.
            // This covers jobs sold via mark-sold dropdown or CRM-native jobs without a legacy proposal.
            totalPrice = crmJob.contractValueCents / 100;
            isEstimated = true;
            estimateReason = 'no_proposal_snapshot_fallback_to_contract_value';
            directCost = null;
            netProfitAmount = null;
            netProfitPercent = null;
            console.warn('[OwnerDashboard] FALLBACK - No snapshot, using contractValueCents:', {
                jobNumber: crmJob.jobNumber,
                contractValueCents: crmJob.contractValueCents,
                totalPrice
            });
        } else {
            console.warn('[OwnerDashboard] ❌ SKIP - No ProposalPricingSnapshot and no contractValueCents:', {
                jobNumber: crmJob.jobNumber,
                currentProposalSnapshotId: crmJob.currentProposalSnapshotId,
                externalJobId: crmJob.externalJobId,
                contractValueCents: crmJob.contractValueCents
            });
            continue;
        }
        
        truthRows.push({
            jobId: crmJob.id,
            jobNumber: crmJob.jobNumber,
            repUserId: crmJob.assignedRepUserId,
            fenceCategory: crmJob.fenceCategory,
            source: crmJob.source,
            signedAt: crmJob.wonAt || crmJob.created_date,
            pricingSnapshotId: crmJob.currentProposalSnapshotId,
            totalPrice,
            sellPriceSubtotal: totalPrice,
            agreedSubtotal: totalPrice,
            netProfitAmount,
            netProfitPercent,
            directCost,
            discountPercent: 0,
            // Estimated flag — row excluded from profit KPIs when true
            isEstimated,
            estimateReason,
            // Rate source disclosure (PHASE 10.3B)
            overheadRateSource,
            commissionRateSource,
            // Upsell tracking
            modelSellPrice,
            presentedSellPrice,
            overrideApplied,
            overheadPercent,
            commissionPercent,
            // Pricing discipline
            proposalPricingSnapshot,
            contractValueCents: crmJob.contractValueCents || totalPrice * 100,
            // PHASE 5a: Revenue source tracking
            revenueSource,
            hasSaleSnapshot: !!saleSnapshot
        });
    }
    
    const estimatedRows = truthRows.filter(r => r.isEstimated);
    const estimateReasonCounts = estimatedRows.reduce((acc, r) => {
        acc[r.estimateReason] = (acc[r.estimateReason] || 0) + 1;
        return acc;
    }, {});

    const defaultOverheadRateCount = truthRows.filter(r => !r.isEstimated && r.overheadRateSource === 'default').length;
    const defaultCommissionRateCount = truthRows.filter(r => !r.isEstimated && r.commissionRateSource === 'default').length;

    // PHASE 5a Diagnostic
    const revenueSourceBreakdown = {
        saleSnapshot: truthRows.filter(r => r.revenueSource === 'sale_snapshot').length,
        proposalSnapshot: truthRows.filter(r => r.revenueSource === 'proposal_snapshot').length,
        fallback: truthRows.filter(r => r.revenueSource === 'fallback_contract').length
    };

    console.log('[OwnerDashboard] ========================================');
    console.log('[OwnerDashboard] FINAL SUMMARY (PHASE 5a):');
    console.log('[OwnerDashboard] Total jobs checked:', allJobs.length);
    console.log('[OwnerDashboard] Final truth rows (all):', truthRows.length);
    console.log('[OwnerDashboard] Revenue source breakdown:', revenueSourceBreakdown);
    console.log('[OwnerDashboard] Estimated rows (excluded from profit):', estimatedRows.length);
    console.log('[OwnerDashboard] Estimate reason counts:', estimateReasonCounts);
    console.log('[OwnerDashboard] Default overhead rate used:', defaultOverheadRateCount);
    console.log('[OwnerDashboard] Default commission rate used:', defaultCommissionRateCount);
    console.log('[OwnerDashboard] Cross-tenant isolation: ENFORCED (no full-table snapshot loads)');
    console.log('[OwnerDashboard] ========================================');

    // Attach rate disclosure summary to rows array for use by computeWonKpis
    truthRows._rateSummary = { defaultOverheadRateCount, defaultCommissionRateCount };
    return truthRows;
}

/**
 * Compute won KPIs from truth rows
 */
export function computeWonKpis(truthRows) {
    const signedCount = truthRows.length;
    const wonRevenue = truthRows.reduce((sum, row) => sum + (row.totalPrice || 0), 0);
    const avgTicket = signedCount > 0 ? wonRevenue / signedCount : 0;

    // PHASE 10.3B: Rate source disclosure — pull from attached summary or recompute
    const rateSummary = truthRows._rateSummary || {};
    const defaultOverheadRateCount = rateSummary.defaultOverheadRateCount ?? 
        truthRows.filter(r => !r.isEstimated && r.overheadRateSource === 'default').length;
    const defaultCommissionRateCount = rateSummary.defaultCommissionRateCount ??
        truthRows.filter(r => !r.isEstimated && r.commissionRateSource === 'default').length;

    // PHASE 10.3A: Exclude estimated rows from ALL profit calculations
    const knownCostRows = truthRows.filter(r => !r.isEstimated);
    const estimatedRows = truthRows.filter(r => r.isEstimated);

    const estimatedCount = estimatedRows.length;
    const estimatedRevenueSubtotal = estimatedRows.reduce((sum, r) => sum + (r.totalPrice || 0), 0);
    const estimateReasonCounts = estimatedRows.reduce((acc, r) => {
        acc[r.estimateReason] = (acc[r.estimateReason] || 0) + 1;
        return acc;
    }, {});

    const totalNetProfit = knownCostRows.reduce((sum, row) => sum + (row.netProfitAmount || 0), 0);
    const totalDirectCost = knownCostRows.reduce((sum, row) => sum + (row.directCost || 0), 0);
    // Margin denominator: only revenue from rows with known cost
    const knownCostRevenue = knownCostRows.reduce((sum, row) => sum + (row.totalPrice || 0), 0);
    const totalRevenue = wonRevenue; // keep for legacy consumers

    const netMarginPercentWeighted = knownCostRevenue > 0 ? (totalNetProfit / knownCostRevenue) * 100 : 0;
    const grossMarginPercentWeighted = knownCostRevenue > 0 ? ((knownCostRevenue - totalDirectCost) / knownCostRevenue) * 100 : 0;
    
    // Upsell metrics (Model vs Presented Price)
    // CRITICAL: Only count jobs with VALID (non-zero) model prices
    const jobsWithModel = truthRows.filter(r => {
        const model = r.modelSellPrice;
        return model !== undefined && model !== null && model > 0;
    });
    
    // CORRECTED: atModel = within penny tolerance, override = anything else
    const jobsWithOverride = jobsWithModel.filter(r => {
        const model = r.modelSellPrice || 0;
        const presented = r.presentedSellPrice || 0;
        const atModel = Math.abs(presented - model) < 0.01;
        return !atModel; // Override if NOT at model
    });
    
    // Separate positive and negative overrides
    const positiveOverrides = jobsWithOverride.filter(r => {
        const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
        return delta > 0.01; // Positive upsell only
    });

    const negativeOverrides = jobsWithOverride.filter(r => {
        const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
        return delta < -0.01; // Downsell only
    });

    // Upsell delta (positive only - when presented > model)
    const totalUpsellDelta = positiveOverrides.reduce((sum, row) => {
        const delta = (row.presentedSellPrice || 0) - (row.modelSellPrice || 0);
        return sum + delta;
    }, 0);

    // Downsell delta (negative - when presented < model)
    const totalDownsellDelta = negativeOverrides.reduce((sum, row) => {
        const delta = (row.modelSellPrice || 0) - (row.presentedSellPrice || 0);
        return sum + delta;
    }, 0);
    
    // Net upside calculation (skip rows without known directCost)
    const totalUpsellNetUpside = jobsWithOverride.reduce((sum, row) => {
        if (row.isEstimated || row.directCost === null) return sum;
        const modelSell = row.modelSellPrice || 0;
        const presentedSell = row.presentedSellPrice || 0;
        const directCost = row.directCost || 0;
        const overheadRate = row.overheadPercent || 0.14;
        const commissionRate = row.commissionPercent || 0.10;
        
        // Model net
        const modelOverhead = modelSell * overheadRate;
        const modelCommission = modelSell * commissionRate;
        const modelNet = modelSell - directCost - modelOverhead - modelCommission;
        
        // Actual net (presented price)
        const actualOverhead = presentedSell * overheadRate;
        const actualCommission = presentedSell * commissionRate;
        const actualNet = presentedSell - directCost - actualOverhead - actualCommission;
        
        // Upside = additional net profit captured
        const netUpside = Math.max(0, actualNet - modelNet);
        return sum + netUpside;
    }, 0);
    
    const overrideRate = jobsWithModel.length > 0 
        ? (jobsWithOverride.length / jobsWithModel.length) * 100 
        : 0;

    // CRITICAL: Avg Upsell = average of POSITIVE deltas only (exclude downsells)
    const avgUpsellPerOverride = positiveOverrides.length > 0
        ? totalUpsellDelta / positiveOverrides.length
        : 0;
    
    return {
        signedCount,
        wonRevenue,
        avgTicket,
        netMarginPercentWeighted,
        grossMarginPercentWeighted,
        // Estimation summary (PHASE 10.3A)
        estimatedCount,
        estimatedRevenueSubtotal,
        estimateReasonCounts,
        knownCostCount: knownCostRows.length,
        // Rate source disclosure (PHASE 10.3B)
        defaultOverheadRateCount,
        defaultCommissionRateCount,
        // Upsell metrics
        totalUpsellDelta,
        totalDownsellDelta,
        totalUpsellNetUpside,
        overrideRate,
        avgUpsellPerOverride,
        jobsWithModelCount: jobsWithModel.length,
        jobsWithOverrideCount: jobsWithOverride.length,
        positiveOverrideCount: positiveOverrides.length,
        negativeOverrideCount: negativeOverrides.length
    };
}

/**
 * Get appointments count (for dashboard KPI)
 * Counts ALL jobs in date range, not just appointment syncs
 */
export async function getAppointmentsCount({ companyId, dateStart, dateEnd, repUserId }) {
    const allJobs = await base44.entities.CRMJob.filter({ companyId });
    
    const filteredJobs = allJobs.filter(job => {
        // Use created_date for date filtering
        const jobDate = new Date(job.created_date);
        const start = new Date(dateStart);
        const end = new Date(dateEnd);
        
        if (jobDate < start || jobDate > end) return false;
        
        // Exclude cancelled jobs
        if (job.stage === 'cancelled' || job.appointmentStatus === 'cancelled') return false;
        
        if (repUserId && job.assignedRepUserId !== repUserId) return false;
        
        return true;
    });
    
    return filteredJobs.length;
}

/**
 * Get demos/close rate set (counts all appointments except cancelled/no show)
 */
export async function getProposalCloseSet({ companyId, dateStart, dateEnd, repUserId, fenceCategory, source, _allJobs }) {
    // Query ALL CRMJobs in date range (appointments = demos)
    // Accept pre-loaded allJobs to avoid redundant fetches (L4 fix)
    const allJobs = _allJobs || await base44.entities.CRMJob.filter({ companyId });
    
    // Batch-load legacy jobs for exclusion checks — scoped to this company only
    const externalJobIds = allJobs.map(j => j.externalJobId).filter(Boolean);
    const allLegacyJobs = externalJobIds.length > 0 ? await base44.entities.Job.filter({ companyId }) : [];
    const legacyJobMap = new Map();
    allLegacyJobs.forEach(lj => legacyJobMap.set(lj.id, lj));

    const proposalRows = [];

    for (const crmJob of allJobs) {
        // Date filter: prefer appointmentDateTime, fall back to wonAt/saleStatusUpdatedAt, then created_date
        const dateToCheck = crmJob.appointmentDateTime 
            || crmJob.wonAt 
            || crmJob.saleStatusUpdatedAt 
            || crmJob.created_date;
        const jobDate = new Date(dateToCheck);
        const start = new Date(dateStart);
        const end = new Date(dateEnd);
        end.setDate(end.getDate() + 1);

        if (jobDate < start || jobDate > end) continue;

        // Apply optional filters
        if (repUserId && crmJob.assignedRepUserId !== repUserId) continue;
        if (fenceCategory && crmJob.fenceCategory !== fenceCategory) continue;
        if (source && crmJob.source !== source) continue;

        // CRITICAL: Exclude cancelled and no-show appointments (never had a demo)
        if (crmJob.appointmentStatus === 'cancelled') {
            continue;
        }

        // Check legacy Job status for additional exclusions (use lookup map)
        if (crmJob.externalJobId) {
            const legacyJob = legacyJobMap.get(crmJob.externalJobId);

            // Exclude Cancelled and No Show from close rate
            if (legacyJob?.status === 'Cancelled' || legacyJob?.status === 'No Show') {
                continue;
            }
        }

        // This is a valid demo - check if it's signed
        const isSigned = isSoldForReporting(crmJob);

        // Determine status for close rate
        let status = 'demo_no_sale';
        if (isSigned) {
            status = 'signed';
        } else if (crmJob.lossType === 'demo_no_sale') {
            status = 'demo_no_sale';
        } else if (crmJob.lossType === 'sale_lost') {
            status = 'sale_lost';
        }

        proposalRows.push({
            jobId: crmJob.id,
            jobNumber: crmJob.jobNumber,
            repUserId: crmJob.assignedRepUserId,
            status,
            sentAt: crmJob.created_date,
            viewCount: 0,
            totalPrice: 0
        });
    }

    return proposalRows;
}

/**
 * Compute close rate from demos (all appointments except cancelled/no show)
 */
export function computeCloseRate(proposalRows) {
    // Denominator: ALL demos (all appointments that weren't cancelled/no show)
    const demosRunCount = proposalRows.length;
    
    // Numerator: signed demos only
    const signedProposals = proposalRows.filter(p => p.status === 'signed');
    const proposalsSignedCount = signedProposals.length;
    
    const closeRatePercent = demosRunCount > 0 
        ? (proposalsSignedCount / demosRunCount) * 100 
        : 0;
    
    return {
        proposalsSentCount: demosRunCount, // Renamed for backward compatibility (really demos run)
        proposalsSignedCount,
        closeRatePercent
    };
}

/**
 * Get KPI details for drawer
 */
export async function getKpiDetails({ companyId, kpiKey, dateStart, dateEnd, repUserId }) {
    // C3 fix: Load allJobs once. For KPI keys that need the truth pipeline, load signedRows once.
    const TRUTH_SET_KEYS = ['sold', 'revenue', 'margin', 'upsell', 'upsell_upside', 'price_integrity', 'override_rate', 'avg_upsell', 'net_reliability'];
    const needsTruthSet = TRUTH_SET_KEYS.includes(kpiKey);

    const [allJobs, signedRows] = await Promise.all([
        base44.entities.CRMJob.filter({ companyId }),
        needsTruthSet ? getSignedDealsTruthSet({ companyId, dateStart, dateEnd, repUserId }) : Promise.resolve(null)
    ]);

    const start = new Date(dateStart);
    const end = new Date(dateEnd);
    end.setDate(end.getDate() + 1);

    if (kpiKey === 'appointments') {
        const appointments = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            if (jobDate < start || jobDate > end) return false;
            if (repUserId && job.assignedRepUserId !== repUserId) return false;
            if (job.stage === 'cancelled' || job.appointmentStatus === 'cancelled') return false;
            return true;
        });

        const cancelled = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            return jobDate >= start && jobDate <= end && 
                   (job.stage === 'cancelled' || job.appointmentStatus === 'cancelled');
        });

        return {
            totalAppointments: appointments.length,
            scheduledCount: appointments.filter(j => j.appointmentStatus === 'scheduled').length,
            completedCount: appointments.filter(j => j.appointmentStatus === 'completed').length,
            rescheduledCount: appointments.filter(j => j.appointmentStatus === 'rescheduled').length,
            cancelledCount: cancelled.length,
            upcomingList: appointments
                .filter(j => j.appointmentDateTime && new Date(j.appointmentDateTime) > new Date())
                .sort((a, b) => new Date(a.appointmentDateTime) - new Date(b.appointmentDateTime))
                .slice(0, 5)
                .map(j => ({
                    customerName: j.customerName || 'N/A',
                    appointmentTime: j.appointmentDateTime ? new Date(j.appointmentDateTime).toLocaleDateString() : 'N/A',
                    repName: j.assignedRepName || 'Unassigned'
                }))
        };
    }

    if (kpiKey === 'demos') {
        // Batch-load legacy jobs for exclusion checks — scoped to this company only
        const externalJobIds = allJobs.map(j => j.externalJobId).filter(Boolean);
        const allLegacyJobs = externalJobIds.length > 0 ? await base44.entities.Job.filter({ companyId }) : [];
        const legacyJobMap = new Map();
        allLegacyJobs.forEach(lj => legacyJobMap.set(lj.id, lj));

        const demosRun = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            if (jobDate < start || jobDate > end) return false;
            if (repUserId && job.assignedRepUserId !== repUserId) return false;
            
            // Exclude cancelled appointments
            if (job.appointmentStatus === 'cancelled') return false;
            
            // Exclude legacy cancelled/no-show
            if (job.externalJobId) {
                const legacyJob = legacyJobMap.get(job.externalJobId);
                if (legacyJob?.status === 'Cancelled' || legacyJob?.status === 'No Show') return false;
            }
            
            return true;
        });

        const wonCount = demosRun.filter(j => isSoldForReporting(j)).length;
        const demoToSalePercent = demosRun.length > 0 ? (wonCount / demosRun.length) * 100 : 0;

        const noShows = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            if (jobDate < start || jobDate > end) return false;
            if (job.externalJobId) {
                const legacyJob = legacyJobMap.get(job.externalJobId);
                return legacyJob?.status === 'No Show';
            }
            return false;
        });

        const cancelled = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            if (jobDate < start || jobDate > end) return false;
            return job.appointmentStatus === 'cancelled';
        });

        return {
            demosRunCount: demosRun.length,
            noShowCount: noShows.length,
            cancelledCount: cancelled.length,
            demoToSalePercent,
            recentDemos: demosRun
                .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
                .slice(0, 5)
                .map(j => ({
                    jobNumber: j.jobNumber,
                    customerName: j.customerName || 'N/A',
                    sold: isSoldForReporting(j)
                }))
        };
    }

    if (kpiKey === 'sold' || kpiKey === 'revenue' || kpiKey === 'margin') {

        const voidedJobs = allJobs.filter(j => j.saleVoidedAt);

        const signedCount = signedRows.filter(r => {
            const job = allJobs.find(j => j.id === r.jobId);
            return job && job.saleStatus === 'sold' && !job.installStatus && !job.paymentStatus;
        }).length;

        const installedCount = signedRows.filter(r => {
            const job = allJobs.find(j => j.id === r.jobId);
            return job && job.installStatus === 'installed';
        }).length;

        const paidOnlyCount = signedRows.filter(r => {
            const job = allJobs.find(j => j.id === r.jobId);
            return job && job.paymentStatus === 'payment_received' && !job.installStatus;
        }).length;

        const topJobsByRevenue = signedRows
            .sort((a, b) => (b.totalPrice || 0) - (a.totalPrice || 0))
            .slice(0, 5)
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    totalPrice: r.totalPrice || 0
                };
            });

        if (kpiKey === 'sold') {
            return {
                jobsSoldCount: signedRows.length,
                signedCount,
                installedCount,
                paidOnlyCount,
                voidedCount: voidedJobs.length,
                topJobsByRevenue
            };
        }

        const totalRevenue = signedRows.reduce((sum, r) => sum + (r.totalPrice || 0), 0);
        const totalNetProfit = signedRows.reduce((sum, r) => sum + (r.netProfitAmount || 0), 0);
        const avgTicket = signedRows.length > 0 ? totalRevenue / signedRows.length : 0;

        if (kpiKey === 'revenue') {
            return {
                totalRevenue,
                avgTicket,
                jobsCount: signedRows.length,
                goalRevenue: 0,
                percentToGoal: 0,
                topJobsByRevenue
            };
        }

        if (kpiKey === 'margin') {
            const netMarginPercent = totalRevenue > 0 ? (totalNetProfit / totalRevenue) * 100 : 0;
            
            const worstMarginJobs = signedRows
                .map(r => {
                    const job = allJobs.find(j => j.id === r.jobId);
                    const marginPercent = r.totalPrice > 0 ? (r.netProfitAmount / r.totalPrice) * 100 : 0;
                    return {
                        jobNumber: r.jobNumber,
                        customerName: job?.customerName || 'N/A',
                        totalPrice: r.totalPrice || 0,
                        netProfitAmount: r.netProfitAmount || 0,
                        marginPercent
                    };
                })
                .sort((a, b) => a.marginPercent - b.marginPercent)
                .slice(0, 3);

            return {
                totalRevenue,
                totalNetProfit,
                netMarginPercent,
                jobsCount: signedRows.length,
                worstMarginJobs,
                fallbackSourceCount: 0
            };
        }
    }

    if (kpiKey === 'close_rate') {
        // Match main dashboard logic - use created_date and exclude cancelled/no-show
        // Scoped to this company only — no full table scan
        const externalJobIds = allJobs.map(j => j.externalJobId).filter(Boolean);
        const allLegacyJobs = externalJobIds.length > 0 ? await base44.entities.Job.filter({ companyId }) : [];
        const legacyJobMap = new Map();
        allLegacyJobs.forEach(lj => legacyJobMap.set(lj.id, lj));

        const demosRun = allJobs.filter(job => {
            const jobDate = new Date(job.created_date);
            if (jobDate < start || jobDate > end) return false;
            if (repUserId && job.assignedRepUserId !== repUserId) return false;
            
            // Exclude cancelled appointments
            if (job.appointmentStatus === 'cancelled') return false;
            
            // Exclude legacy cancelled/no-show
            if (job.externalJobId) {
                const legacyJob = legacyJobMap.get(job.externalJobId);
                if (legacyJob?.status === 'Cancelled' || legacyJob?.status === 'No Show') return false;
            }
            
            return true;
        });

        const wonJobs = demosRun.filter(j => isSoldForReporting(j));
        const wonCount = wonJobs.length;
        const closeRatePercent = demosRun.length > 0 ? (wonCount / demosRun.length) * 100 : 0;

        const lostDemoJobs = demosRun.filter(job => {
            return job.lossType === 'demo_no_sale' && !isSoldForReporting(job);
        });

        const lostAfterDemoJobs = demosRun.filter(job => {
            return job.lossType === 'sale_lost' && !isSoldForReporting(job);
        });

        const recentLosses = [...lostDemoJobs, ...lostAfterDemoJobs]
            .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
            .slice(0, 5)
            .map(j => ({
                jobNumber: j.jobNumber,
                customerName: j.customerName || 'N/A',
                lossStage: j.lossType === 'demo_no_sale' ? 'Demo' : 'After Demo',
                lossReason: j.lossReason || 'No reason provided'
            }));

        return {
            closeRatePercent,
            demosRunCount: demosRun.length,
            wonCount,
            lostDemoCount: lostDemoJobs.length,
            lostAfterDemoCount: lostAfterDemoJobs.length,
            recentLosses
        };
    }

    if (kpiKey === 'upsell') {

        const jobsWithOverride = signedRows.filter(r => {
            if (r.modelSellPrice === undefined || r.modelSellPrice === null) return false;
            const model = r.modelSellPrice || 0;
            const presented = r.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            return !atModel;
        });

        const positiveOverrides = jobsWithOverride.filter(r => {
            const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
            return delta > 0.01;
        });

        const totalUpsellDelta = positiveOverrides.reduce((sum, r) => {
            return sum + ((r.presentedSellPrice || 0) - (r.modelSellPrice || 0));
        }, 0);

        const avgUpsellPerOverride = positiveOverrides.length > 0 
            ? totalUpsellDelta / positiveOverrides.length 
            : 0;

        const topUpsellJobs = positiveOverrides
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    modelPrice: r.modelSellPrice || 0,
                    presentedPrice: r.presentedSellPrice || 0,
                    upsellDelta: (r.presentedSellPrice || 0) - (r.modelSellPrice || 0)
                };
            })
            .sort((a, b) => b.upsellDelta - a.upsellDelta)
            .slice(0, 5);

        return {
            totalUpsellDelta,
            jobsWithOverrideCount: jobsWithOverride.length,
            positiveOverrideCount: positiveOverrides.length,
            avgUpsellPerOverride,
            topUpsellJobs
        };
    }

    if (kpiKey === 'upsell_upside') {

        const jobsWithOverride = signedRows.filter(r => {
            if (r.modelSellPrice === undefined || r.modelSellPrice === null) return false;
            const model = r.modelSellPrice || 0;
            const presented = r.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            return !atModel;
        });

        const totalUpsellNetUpside = jobsWithOverride.reduce((sum, row) => {
            const modelSell = row.modelSellPrice || 0;
            const presentedSell = row.presentedSellPrice || 0;
            const directCost = row.directCost || 0;
            const overheadRate = row.overheadPercent || 0.14;
            const commissionRate = row.commissionPercent || 0.10;
            
            const modelOverhead = modelSell * overheadRate;
            const modelCommission = modelSell * commissionRate;
            const modelNet = modelSell - directCost - modelOverhead - modelCommission;
            
            const actualOverhead = presentedSell * overheadRate;
            const actualCommission = presentedSell * commissionRate;
            const actualNet = presentedSell - directCost - actualOverhead - actualCommission;
            
            const netUpside = Math.max(0, actualNet - modelNet);
            return sum + netUpside;
        }, 0);

        const avgNetUpsidePerOverride = jobsWithOverride.length > 0 
            ? totalUpsellNetUpside / jobsWithOverride.length 
            : 0;

        const topNetUpsideJobs = jobsWithOverride
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                const modelSell = r.modelSellPrice || 0;
                const presentedSell = r.presentedSellPrice || 0;
                const directCost = r.directCost || 0;
                const overheadRate = r.overheadPercent || 0.14;
                const commissionRate = r.commissionPercent || 0.10;
                
                const modelOverhead = modelSell * overheadRate;
                const modelCommission = modelSell * commissionRate;
                const modelNet = modelSell - directCost - modelOverhead - modelCommission;
                
                const actualOverhead = presentedSell * overheadRate;
                const actualCommission = presentedSell * commissionRate;
                const actualNet = presentedSell - directCost - actualOverhead - actualCommission;
                
                const netUpside = Math.max(0, actualNet - modelNet);

                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    netUpside
                };
            })
            .sort((a, b) => b.netUpside - a.netUpside)
            .slice(0, 5);

        return {
            totalUpsellNetUpside,
            jobsWithOverrideCount: jobsWithOverride.length,
            avgNetUpsidePerOverride,
            topNetUpsideJobs
        };
    }

    if (kpiKey === 'price_integrity') {

        const jobsWithModel = signedRows.filter(r => r.modelSellPrice !== undefined && r.modelSellPrice !== null);
        
        const jobsAtModel = jobsWithModel.filter(r => {
            const model = r.modelSellPrice || 0;
            const presented = r.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            return atModel;
        });

        const jobsWithOverride = jobsWithModel.filter(r => {
            const model = r.modelSellPrice || 0;
            const presented = r.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            return !atModel;
        });

        const priceIntegrityPercent = jobsWithModel.length > 0 
            ? (jobsAtModel.length / jobsWithModel.length) * 100 
            : 0;

        const atModelJobs = jobsAtModel
            .sort((a, b) => new Date(b.signedAt) - new Date(a.signedAt))
            .slice(0, 5)
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    soldPrice: r.presentedSellPrice || 0
                };
            });

        return {
            priceIntegrityPercent,
            jobsAtModelCount: jobsAtModel.length,
            totalJobsCount: jobsWithModel.length,
            jobsWithOverrideCount: jobsWithOverride.length,
            atModelJobs
        };
    }

    if (kpiKey === 'override_rate') {

        const jobsWithModel = signedRows.filter(r => r.modelSellPrice !== undefined && r.modelSellPrice !== null);
        
        const jobsWithOverride = jobsWithModel.filter(r => {
            const model = r.modelSellPrice || 0;
            const presented = r.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            return !atModel;
        });

        const positiveOverrides = jobsWithOverride.filter(r => {
            const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
            return delta > 0.01;
        });

        const negativeOverrides = jobsWithOverride.filter(r => {
            const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
            return delta < -0.01;
        });

        const overrideRate = jobsWithModel.length > 0 
            ? (jobsWithOverride.length / jobsWithModel.length) * 100 
            : 0;

        const recentOverrides = jobsWithOverride
            .sort((a, b) => new Date(b.signedAt) - new Date(a.signedAt))
            .slice(0, 5)
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    modelPrice: r.modelSellPrice || 0,
                    presentedPrice: r.presentedSellPrice || 0,
                    delta
                };
            });

        return {
            overrideRate,
            jobsWithOverrideCount: jobsWithOverride.length,
            totalJobsCount: jobsWithModel.length,
            positiveOverrideCount: positiveOverrides.length,
            negativeOverrideCount: negativeOverrides.length,
            recentOverrides
        };
    }

    if (kpiKey === 'avg_upsell') {

        const jobsWithModel = signedRows.filter(r => r.modelSellPrice !== undefined && r.modelSellPrice !== null);
        
        const positiveOverrides = jobsWithModel.filter(r => {
            const delta = (r.presentedSellPrice || 0) - (r.modelSellPrice || 0);
            return delta > 0.01;
        });

        const totalUpsellDelta = positiveOverrides.reduce((sum, r) => {
            return sum + ((r.presentedSellPrice || 0) - (r.modelSellPrice || 0));
        }, 0);

        const avgUpsellPerOverride = positiveOverrides.length > 0 
            ? totalUpsellDelta / positiveOverrides.length 
            : 0;

        const topUpsellJobs = positiveOverrides
            .sort((a, b) => {
                const deltaA = (a.presentedSellPrice || 0) - (a.modelSellPrice || 0);
                const deltaB = (b.presentedSellPrice || 0) - (b.modelSellPrice || 0);
                return deltaB - deltaA;
            })
            .slice(0, 5)
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    modelPrice: r.modelSellPrice || 0,
                    presentedPrice: r.presentedSellPrice || 0,
                    upsellDelta: (r.presentedSellPrice || 0) - (r.modelSellPrice || 0)
                };
            });

        return {
            avgUpsellPerOverride,
            positiveOverrideCount: positiveOverrides.length,
            totalUpsellDelta,
            topUpsellJobs
        };
    }

    if (kpiKey === 'net_reliability') {

        const totalRevenue = signedRows.reduce((sum, r) => sum + (r.totalPrice || 0), 0);
        const totalNetProfit = signedRows.reduce((sum, r) => sum + (r.netProfitAmount || 0), 0);
        const netMarginPercent = totalRevenue > 0 ? (totalNetProfit / totalRevenue) * 100 : 0;

        const reliabilityScore = netMarginPercent >= 30 ? 'HIGH' : netMarginPercent >= 20 ? 'MED' : 'LOW';

        const jobsAbove30 = signedRows.filter(r => {
            const margin = r.totalPrice > 0 ? (r.netProfitAmount / r.totalPrice) * 100 : 0;
            return margin >= 30;
        });

        const jobsAbove20 = signedRows.filter(r => {
            const margin = r.totalPrice > 0 ? (r.netProfitAmount / r.totalPrice) * 100 : 0;
            return margin >= 20 && margin < 30;
        });

        const jobsBelow20 = signedRows.filter(r => {
            const margin = r.totalPrice > 0 ? (r.netProfitAmount / r.totalPrice) * 100 : 0;
            return margin < 20;
        });

        const marginDistribution = signedRows
            .map(r => {
                const job = allJobs.find(j => j.id === r.jobId);
                const marginPercent = r.totalPrice > 0 ? (r.netProfitAmount / r.totalPrice) * 100 : 0;
                return {
                    jobNumber: r.jobNumber,
                    customerName: job?.customerName || 'N/A',
                    marginPercent
                };
            })
            .sort((a, b) => a.marginPercent - b.marginPercent)
            .slice(0, 5);

        return {
            netMarginPercent,
            reliabilityScore,
            jobsAbove30Count: jobsAbove30.length,
            jobsAbove20Count: jobsAbove20.length,
            jobsBelow20Count: jobsBelow20.length,
            totalJobsCount: signedRows.length,
            marginDistribution
        };
    }

    return {};
}

/**
 * Get rep scoreboard
 */
export async function getRepScoreboard({ companyId, dateStart, dateEnd, fenceCategory, source }) {
    // Load CRMJobs once and share across both pipelines (L4 fix: eliminates double scan)
    const allCrmJobs = await base44.entities.CRMJob.filter({ companyId });

    // Get signed truth set and proposal close set in parallel, sharing the same CRMJob list
    const [signedRows, proposalRows] = await Promise.all([
        getSignedDealsTruthSet({ companyId, dateStart, dateEnd, fenceCategory, source }),
        getProposalCloseSet({ companyId, dateStart, dateEnd, fenceCategory, source, _allJobs: allCrmJobs })
    ]);
    
    // Group by repUserId
    const repMap = new Map();
    
    // Aggregate signed deals
    for (const row of signedRows) {
        const repId = row.repUserId || 'unassigned';
        if (!repMap.has(repId)) {
            repMap.set(repId, {
                repUserId: repId,
                wonRevenue: 0,
                signedCount: 0,
                netProfitAmount: 0,
                proposalsSentCount: 0,
                proposalsSignedCount: 0
            });
        }
        
        const rep = repMap.get(repId);
        rep.wonRevenue += row.totalPrice || 0;
        rep.signedCount += 1;
        rep.netProfitAmount += row.netProfitAmount || 0;
    }
    
    // Aggregate proposals
    for (const row of proposalRows) {
        const repId = row.repUserId || 'unassigned';
        if (!repMap.has(repId)) {
            repMap.set(repId, {
                repUserId: repId,
                wonRevenue: 0,
                signedCount: 0,
                netProfitAmount: 0,
                proposalsSentCount: 0,
                proposalsSignedCount: 0
            });
        }
        
        const rep = repMap.get(repId);
        const validStatuses = ['sent', 'viewed', 'signed'];
        if (validStatuses.includes(row.status)) {
            rep.proposalsSentCount += 1;
        }
        if (row.status === 'signed') {
            rep.proposalsSignedCount += 1;
        }
    }
    
    // Load user display names — fetch only the rep IDs we actually need, not full table
    const repUserIds = Array.from(repMap.keys()).filter(id => id !== 'unassigned');
    const users = repUserIds.length > 0
        ? (await Promise.all(repUserIds.map(id =>
            base44.entities.User.filter({ id }).then(rows => rows[0] || null).catch(() => null)
          ))).filter(Boolean)
        : [];
    const userMap = new Map(users.map(u => [u.id, u.full_name || u.email]));
    
    // Aggregate upsell metrics per rep
    const repUpsellMap = new Map();
    for (const row of signedRows) {
        const repId = row.repUserId || 'unassigned';
        if (!repUpsellMap.has(repId)) {
            repUpsellMap.set(repId, {
                totalUpsellDelta: 0,
                totalUpsellNetUpside: 0,
                overrideCount: 0,
                positiveOverrideCount: 0,
                modelCount: 0
            });
        }
        
        const upsell = repUpsellMap.get(repId);
        
        if (row.modelSellPrice !== undefined && row.modelSellPrice !== null) {
            upsell.modelCount += 1;

            // CORRECTED: atModel = within penny tolerance, override = anything else
            const model = row.modelSellPrice || 0;
            const presented = row.presentedSellPrice || 0;
            const atModel = Math.abs(presented - model) < 0.01;
            const isOverride = !atModel;

            if (isOverride) {
                upsell.overrideCount += 1;

                // Track positive overrides for Avg Upsell
                const delta = (row.presentedSellPrice || 0) - (row.modelSellPrice || 0);
                if (delta > 0.01) {
                    upsell.positiveOverrideCount = (upsell.positiveOverrideCount || 0) + 1;
                    upsell.totalUpsellDelta += delta;
                }
                
                // Net upside
                const modelSell = row.modelSellPrice || 0;
                const presentedSell = row.presentedSellPrice || 0;
                const directCost = row.directCost || 0;
                const overheadRate = row.overheadPercent || 0.14;
                const commissionRate = row.commissionPercent || 0.10;
                
                const modelOverhead = modelSell * overheadRate;
                const modelCommission = modelSell * commissionRate;
                const modelNet = modelSell - directCost - modelOverhead - modelCommission;
                
                const actualOverhead = presentedSell * overheadRate;
                const actualCommission = presentedSell * commissionRate;
                const actualNet = presentedSell - directCost - actualOverhead - actualCommission;
                
                const netUpside = Math.max(0, actualNet - modelNet);
                upsell.totalUpsellNetUpside += netUpside;
            }
        }
    }
    
    // Compute final metrics
    const scoreboard = Array.from(repMap.values()).map(rep => {
        const upsellData = repUpsellMap.get(rep.repUserId) || {
            totalUpsellDelta: 0,
            totalUpsellNetUpside: 0,
            overrideCount: 0,
            positiveOverrideCount: 0,
            modelCount: 0
        };

        return {
            repUserId: rep.repUserId,
            repName: rep.repUserId === 'unassigned' 
                ? 'Unassigned' 
                : userMap.get(rep.repUserId) || 'Unknown',
            wonRevenue: rep.wonRevenue,
            signedCount: rep.signedCount,
            avgTicket: rep.signedCount > 0 ? rep.wonRevenue / rep.signedCount : 0,
            netMarginPercent: rep.wonRevenue > 0 
                ? (rep.netProfitAmount / rep.wonRevenue) * 100 
                : 0,
            proposalsSentCount: rep.proposalsSentCount,
            closeRatePercent: rep.proposalsSentCount > 0 
                ? (rep.proposalsSignedCount / rep.proposalsSentCount) * 100 
                : 0,
            // Upsell metrics
            totalUpsellDelta: upsellData.totalUpsellDelta,
            totalUpsellNetUpside: upsellData.totalUpsellNetUpside,
            overrideRate: upsellData.modelCount > 0 
                ? (upsellData.overrideCount / upsellData.modelCount) * 100 
                : 0,
            // CRITICAL: Avg Upsell = average of POSITIVE deltas only
            avgUpsellPerOverride: upsellData.positiveOverrideCount > 0
                ? upsellData.totalUpsellDelta / upsellData.positiveOverrideCount
                : 0
        };
    });
    
    // Sort by net margin desc, then close rate desc, then avg ticket desc
    scoreboard.sort((a, b) => {
        if (Math.abs(a.netMarginPercent - b.netMarginPercent) > 0.01) {
            return b.netMarginPercent - a.netMarginPercent;
        }
        if (Math.abs(a.closeRatePercent - b.closeRatePercent) > 0.01) {
            return b.closeRatePercent - a.closeRatePercent;
        }
        return b.avgTicket - a.avgTicket;
    });
    
    return scoreboard;
}