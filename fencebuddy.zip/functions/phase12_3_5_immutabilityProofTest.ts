/**
 * Phase 12.3.5: Immutability Enforcement Proof Test
 *
 * Validates that snapshot immutability is enforced at the SDK layer.
 * Must pass before ENFORCE_MODE can be considered production-ready.
 *
 * Tests:
 *   1. Direct update on immutable snapshot throws
 *   2. Restore exception allows update
 *   3. Non-immutable entity update still works
 *   4. asServiceRole path is also enforced
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const mode = body.mode || 'run_all'; // run_all | test_1 | test_2 | test_3 | test_4

    const results: any = {};

    // ──────────────────────────────────────────────────────────────────────────
    // Test 1: Direct update on immutable snapshot should throw
    // ──────────────────────────────────────────────────────────────────────────
    if (mode === 'run_all' || mode === 'test_1') {
      results.test_1_direct_update_throws = await (async () => {
        try {
          // Try to update a ProposalPricingSnapshot (immutable entity)
          // Note: Using wrapped base44 from lib/base44ClientWrapper would be ideal,
          // but for this test we verify via raw SDK + log what *should* be enforced
          const snapshots = await base44.asServiceRole.entities.ProposalPricingSnapshot?.filter?.({}, '-updated_date', 1).catch(() => []);

          if (!snapshots?.length) {
            return {
              status: 'skipped',
              reason: 'No ProposalPricingSnapshot found in database'
            };
          }

          const snapshotId = snapshots[0].id;

          // This should throw if wrapped client is in use
          try {
            await base44.asServiceRole.entities.ProposalPricingSnapshot?.update?.(snapshotId, {
              test_field: 'should_fail'
            });

            // If we get here, update succeeded (wrapper not enforced yet OR ENFORCE_MODE=false)
            return {
              status: 'FAIL',
              message: 'Update succeeded but should have thrown (immutability not enforced)',
              snapshotId
            };
          } catch (updateError: any) {
            // Expected: update throws with IMMUTABILITY_VIOLATION
            const errorMsg = updateError.message || '';
            if (errorMsg.includes('IMMUTABILITY_VIOLATION') || errorMsg.includes('write-once')) {
              return {
                status: 'PASS',
                message: 'Update correctly threw immutability violation',
                error: errorMsg,
                snapshotId
              };
            } else {
              return {
                status: 'FAIL',
                message: 'Update threw, but error is not immutability-related',
                error: errorMsg,
                snapshotId
              };
            }
          }
        } catch (error: any) {
          return {
            status: 'ERROR',
            message: error.message
          };
        }
      })();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Test 2: Restore exception should allow update
    // ──────────────────────────────────────────────────────────────────────────
    if (mode === 'run_all' || mode === 'test_2') {
      results.test_2_restore_exception = await (async () => {
        try {
          // Enable maintenance mode
          const maintenanceRecords = await base44.asServiceRole.entities.MaintenanceMode?.filter?.({}).catch(() => []);
          let maintenanceId = maintenanceRecords?.[0]?.id;

          if (!maintenanceId) {
            // Create one
            const created = await base44.asServiceRole.entities.MaintenanceMode?.create?.({
              phase11Enabled: true,
              activatedAt: new Date().toISOString(),
              notes: 'Restore test harness'
            });
            maintenanceId = created?.id;
          } else {
            // Update existing
            await base44.asServiceRole.entities.MaintenanceMode?.update?.(maintenanceId, {
              phase11Enabled: true
            });
          }

          // Now try snapshot update with maintenance mode enabled
          // This test is advisory — the wrapped client would check maintenance state
          return {
            status: 'SKIPPED',
            reason: 'Requires wrapped client to read MaintenanceMode state during mutation',
            note: 'This test validates the wrapper logic, not raw SDK'
          };
        } catch (error: any) {
          return {
            status: 'ERROR',
            message: error.message
          };
        }
      })();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Test 3: Non-immutable entity update should still work
    // ──────────────────────────────────────────────────────────────────────────
    if (mode === 'run_all' || mode === 'test_3') {
      results.test_3_non_immutable_works = await (async () => {
        try {
          const crmJobs = await base44.asServiceRole.entities.CRMJob?.filter?.({}, '-updated_date', 1).catch(() => []);

          if (!crmJobs?.length) {
            return {
              status: 'skipped',
              reason: 'No CRMJob found in database'
            };
          }

          const jobId = crmJobs[0].id;

          // Try to update CRMJob (non-immutable)
          const updated = await base44.asServiceRole.entities.CRMJob?.update?.(jobId, {
            notes: 'Test update ' + new Date().toISOString()
          });

          if (updated) {
            return {
              status: 'PASS',
              message: 'Non-immutable entity update succeeded as expected',
              jobId
            };
          } else {
            return {
              status: 'FAIL',
              message: 'Non-immutable update failed unexpectedly',
              jobId
            };
          }
        } catch (error: any) {
          return {
            status: 'FAIL',
            message: 'Non-immutable update threw (should not happen)',
            error: error.message
          };
        }
      })();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Test 4: Service role path is also enforced
    // ──────────────────────────────────────────────────────────────────────────
    if (mode === 'run_all' || mode === 'test_4') {
      results.test_4_service_role_enforced = await (async () => {
        try {
          const snapshots = await base44.asServiceRole.entities.ProposalPricingSnapshot?.filter?.({}, '-updated_date', 1).catch(() => []);

          if (!snapshots?.length) {
            return {
              status: 'skipped',
              reason: 'No ProposalPricingSnapshot found'
            };
          }

          const snapshotId = snapshots[0].id;

          // Try via asServiceRole (wrapped client should still enforce)
          try {
            await base44.asServiceRole.entities.ProposalPricingSnapshot?.update?.(snapshotId, {
              test: 'via_service_role'
            });

            return {
              status: 'FAIL',
              message: 'asServiceRole update succeeded but should have thrown',
              snapshotId
            };
          } catch (updateError: any) {
            const errorMsg = updateError.message || '';
            if (errorMsg.includes('IMMUTABILITY_VIOLATION') || errorMsg.includes('write-once')) {
              return {
                status: 'PASS',
                message: 'asServiceRole correctly enforced immutability',
                error: errorMsg,
                snapshotId
              };
            } else {
              return {
                status: 'FAIL',
                message: 'asServiceRole threw, but not immutability-related',
                error: errorMsg,
                snapshotId
              };
            }
          }
        } catch (error: any) {
          return {
            status: 'ERROR',
            message: error.message
          };
        }
      })();
    }

    return Response.json({
      status: 'ok',
      mode,
      timestamp: new Date().toISOString(),
      results
    });

  } catch (error: any) {
    console.error('[ImmutabilityProofTest] Fatal error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});