/**
 * SEED PFC COMPANY SKU MAPPINGS
 * Creates initial CompanySkuMap entries for PFC using existing MaterialCatalog
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized - admin only' }, { status: 403 });
    }

    // Get company settings
    const companies = await base44.asServiceRole.entities.CompanySettings.list();
    const company = companies[0];
    
    if (!company) {
      return Response.json({ error: 'No company settings found' }, { status: 404 });
    }
    
    const companyId = company.companyId || 'default';

    // Fetch material catalog
    const catalog = await base44.asServiceRole.entities.MaterialCatalog.filter({ active: true });

    // Define UCK → Catalog Name mappings
    const mappings = [
      // Fabric
      { uck: 'cl:fabric:4ft:galv:roll_50', catalogName: "4' Chain Link Fabric (Galvanized) - 50ft Roll" },
      { uck: 'cl:fabric:4ft:black_vinyl:roll_50', catalogName: "4' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll" },
      { uck: 'cl:fabric:5ft:galv:roll_50', catalogName: "5' Chain Link Fabric (Galvanized) - 50ft Roll" },
      { uck: 'cl:fabric:5ft:black_vinyl:roll_50', catalogName: "5' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll" },
      { uck: 'cl:fabric:6ft:galv:roll_50', catalogName: "6' Chain Link Fabric (Galvanized) - 50ft Roll" },
      { uck: 'cl:fabric:6ft:black_vinyl:roll_50', catalogName: "6' Chain Link Fabric (Black Vinyl Coated) - 50ft Roll" },
      
      // Rails
      { uck: 'cl:rail:top:1.375in:galv:stick_21ft', catalogName: "GALV Top Rail 1-3/8in - 21ft Stick" },
      { uck: 'cl:rail:top:1.375in:black_vinyl:stick_21ft', catalogName: "BLK Top Rail 1-3/8in - 21ft Stick" },
      
      // Hardware
      { uck: 'cl:hardware:loop_cap:1_5_8in:galv', catalogName: "GALV Loop Cap 1-5/8in (Line)" },
      { uck: 'cl:hardware:loop_cap:1_5_8in:black_vinyl', catalogName: "BLK Loop Cap 1-5/8in (Line)" },
      { uck: 'cl:hardware:dome_cap:2_1_2in:galv', catalogName: "GALV Dome Cap 2-1/2in (Terminal)" },
      { uck: 'cl:hardware:dome_cap:2_1_2in:black_vinyl', catalogName: "BLK Dome Cap 2-1/2in (Terminal)" },
      
      // Posts
      { uck: 'cl:post:terminal:end:4ft:galv', catalogName: "GALV Terminal Post 2-1/2in - 8ft (4' Chain Link)" },
      { uck: 'cl:post:terminal:end:4ft:black_vinyl', catalogName: "BLK Terminal Post 2-1/2in - 8ft (4' Chain Link)" },
      { uck: 'cl:post:terminal:end:6ft:galv', catalogName: "GALV Terminal Post 2-1/2in - 8ft (6' Chain Link)" },
      { uck: 'cl:post:terminal:end:6ft:black_vinyl', catalogName: "BLK Terminal Post 2-1/2in - 8ft (6' Chain Link)" },
      { uck: 'cl:post:line:4ft:galv', catalogName: "GALV Line Post 1-5/8in - 7ft" },
      { uck: 'cl:post:line:4ft:black_vinyl', catalogName: "BLK Line Post 1-5/8in - 7ft" },
      { uck: 'cl:post:line:6ft:galv', catalogName: "GALV Line Post 1-5/8in - 9ft" },
      { uck: 'cl:post:line:6ft:black_vinyl', catalogName: "BLK Line Post 1-5/8in - 9ft" }
    ];

    const results = [];
    let mappedCount = 0;
    let notFoundCount = 0;

    for (const mapping of mappings) {
      // Find catalog item by name (deterministic - pick highest cost if duplicates)
      const matches = catalog.filter(c => 
        (c.crm_name === mapping.catalogName || c.name === mapping.catalogName)
      );
      
      let catalogItem = null;
      if (matches.length > 0) {
        // Pick highest cost (deterministic)
        catalogItem = matches.reduce((best, curr) => {
          const bestCost = best.cost || best.unit_cost || 0;
          const currCost = curr.cost || curr.unit_cost || 0;
          return currCost > bestCost ? curr : best;
        });
      }

      if (!catalogItem) {
        notFoundCount++;
        results.push({
          uck: mapping.uck,
          status: 'NOT_FOUND',
          catalogName: mapping.catalogName
        });
        continue;
      }

      // Parse attributes from UCK
      const parts = mapping.uck.split(':');
      const attributes = {};
      
      if (parts[2]) attributes.height_ft = parts[2].replace('ft', '');
      if (parts[3]) attributes.finish = parts[3];
      if (parts[4]) attributes.packaging = parts[4];

      // Check if already exists
      const existing = await base44.asServiceRole.entities.CompanySkuMap.filter({
        companyId,
        uck: mapping.uck
      });

      if (existing.length > 0) {
        // Update existing
        await base44.asServiceRole.entities.CompanySkuMap.update(existing[0].id, {
          status: 'mapped',
          materialCatalogId: catalogItem.id,
          materialCatalogName: catalogItem.crm_name || catalogItem.name,
          attributes
        });
        
        results.push({
          uck: mapping.uck,
          status: 'UPDATED',
          catalogId: catalogItem.id
        });
      } else {
        // Create new
        await base44.asServiceRole.entities.CompanySkuMap.create({
          companyId,
          uck: mapping.uck,
          displayName: mapping.catalogName,
          materialCatalogId: catalogItem.id,
          materialCatalogName: catalogItem.crm_name || catalogItem.name,
          materialType: 'chain_link',
          fenceSystem: 'chainlink_residential',
          attributes,
          status: 'mapped',
          lastSeenAt: new Date().toISOString()
        });
        
        results.push({
          uck: mapping.uck,
          status: 'CREATED',
          catalogId: catalogItem.id
        });
      }
      
      mappedCount++;
    }

    return Response.json({
      success: true,
      companyId,
      total: mappings.length,
      mapped: mappedCount,
      not_found: notFoundCount,
      results
    });

  } catch (error) {
    console.error('[seedPfcCompanySkuMaps] Error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});