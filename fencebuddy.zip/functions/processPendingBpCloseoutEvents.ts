import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Retry delay schedule (milliseconds)
const RETRY_DELAYS_MS = [0, 5 * 60 * 1000, 30 * 60 * 1000, 2 * 60 * 60 * 1000, 12 * 60 * 60 * 1000];
const MAX_ATTEMPTS = RETRY_DELAYS_MS.length;

Deno.serve(async (req) => {
  if (req.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405 });

  const base44 = createClientFromRequest(req);

  // Allow admin users or service-role calls (no user = scheduled automation)
  let isAdmin = false;
  try {
    const user = await base44.auth.me();
    isAdmin = user?.role === 'admin';
  } catch { isAdmin = true; } // scheduled / service call

  const webhookUrl = Deno.env.get('BP_CLOSEOUT_WEBHOOK_URL');
  const authToken = Deno.env.get('BP_CLOSEOUT_WEBHOOK_AUTH_TOKEN');
  const now = new Date();

  // Fetch pending/failed events
  const allEvents = await base44.asServiceRole.entities.OutboundIntegrationEvent.filter({
    destination: 'builder_prime_closeout',
  });

  const readyEvents = allEvents.filter(e => {
    if (!['pending', 'failed'].includes(e.status)) return false;
    if (!e.nextAttemptAt) return true;
    return new Date(e.nextAttemptAt) <= now;
  });

  const results = [];

  for (const event of readyEvents) {
    const attemptCount = (event.attemptCount || 0) + 1;
    const nowIso = new Date().toISOString();

    // Mark processing
    await base44.asServiceRole.entities.OutboundIntegrationEvent.update(event.id, {
      status: 'processing',
      lastAttemptAt: nowIso,
      attemptCount,
    });

    let success = false;
    let lastError = null;

    if (!webhookUrl) {
      lastError = 'BP_CLOSEOUT_WEBHOOK_URL not configured';
    } else {
      try {
        const payload = JSON.parse(event.payloadJson || '{}');
        const headers = { 'Content-Type': 'application/json' };
        if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
        if (event.idempotencyKey) headers['Idempotency-Key'] = event.idempotencyKey;

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        const response = await fetch(webhookUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify(payload),
          signal: controller.signal,
        });
        clearTimeout(timeout);

        if (response.ok) {
          success = true;
        } else {
          const text = await response.text().catch(() => '');
          lastError = `HTTP ${response.status}: ${text.slice(0, 300)}`;
        }
      } catch (err) {
        lastError = err.message || 'Unknown fetch error';
      }
    }

    if (success) {
      await base44.asServiceRole.entities.OutboundIntegrationEvent.update(event.id, {
        status: 'succeeded',
        processedAt: new Date().toISOString(),
        lastError: null,
      });

      // Update LeadDispositionEvent if linked
      if (event.sourceEntityId) {
        await base44.asServiceRole.entities.LeadDispositionEvent.update(event.sourceEntityId, {
          syncStatus: 'succeeded',
          processedAt: new Date().toISOString(),
          lastSyncAt: new Date().toISOString(),
          lastSyncError: null,
        }).catch(() => {});
      }

      // Update job
      if (event.jobId) {
        await base44.asServiceRole.entities.CRMJob.update(event.jobId, {
          bpOutcomeReportingStatus: 'succeeded',
          bpOutcomeReportedAt: new Date().toISOString(),
          bpOutcomeReportingError: null,
          bpLastReportedDispositionRevision: event.dispositionRevision || 0,
        }).catch(() => {});
      }

      results.push({ id: event.id, status: 'succeeded' });
    } else {
      const isDead = attemptCount >= MAX_ATTEMPTS;
      const newStatus = isDead ? 'dead_letter' : 'failed';

      // Compute next attempt time
      let nextAttemptAt = null;
      if (!isDead && RETRY_DELAYS_MS[attemptCount]) {
        nextAttemptAt = new Date(Date.now() + RETRY_DELAYS_MS[attemptCount]).toISOString();
      }

      await base44.asServiceRole.entities.OutboundIntegrationEvent.update(event.id, {
        status: newStatus,
        lastError,
        nextAttemptAt,
        attemptCount,
      });

      if (event.sourceEntityId) {
        await base44.asServiceRole.entities.LeadDispositionEvent.update(event.sourceEntityId, {
          syncStatus: newStatus,
          lastSyncAt: new Date().toISOString(),
          lastSyncError: lastError,
          syncAttemptCount: attemptCount,
        }).catch(() => {});
      }

      if (event.jobId) {
        await base44.asServiceRole.entities.CRMJob.update(event.jobId, {
          bpOutcomeReportingStatus: newStatus,
          bpOutcomeReportingError: lastError,
        }).catch(() => {});
      }

      results.push({ id: event.id, status: newStatus, error: lastError });
    }
  }

  return Response.json({ processed: readyEvents.length, results });
});