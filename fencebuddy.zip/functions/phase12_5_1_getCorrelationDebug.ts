import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Phase 12.5.1: Correlation Debug Endpoint
 * 
 * Echo endpoint to verify correlation ID propagation end-to-end.
 * Returns the correlation ID that was received, for verification in dashboards.
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const correlationId = req.headers.get('x-correlation-id') || crypto.randomUUID();
    
    // Optional: verify it's present in request
    const user = await base44.auth.me().catch(() => null);

    return Response.json({
      status: 'ok',
      correlationId,
      receivedAt: new Date().toISOString(),
      userEmail: user?.email || 'unauthenticated',
      message: 'Correlation ID successfully propagated'
    }, {
      headers: { 'x-correlation-id': correlationId }
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});