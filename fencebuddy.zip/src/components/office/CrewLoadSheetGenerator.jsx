/**
 * Crew Load Sheet Generator
 * Generates truck load list - no prices, just quantities
 * 
 * DETERMINISTIC & PRODUCTION-SAFE:
 * - Never blank yard map (always renders image or geometry or message)
 * - Dynamic page sizing (no hardcoded 210/297)
 * - Auto-paginated footer/audit (never cut off)
 * - Materials list wraps long text, paginates, repeats header
 */

import jsPDF from 'jspdf';
import { buildTakeoff } from '../materials/canonicalTakeoffEngine';

// ============================================================================
// LAYOUT & PAGINATION HELPERS
// ============================================================================

/**
 * Get standard layout with dynamic page sizing
 */
function getLayout(pdf) {
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margins = { top: 14, right: 14, bottom: 14, left: 14 };
  return {
    pageWidth,
    pageHeight,
    margins,
    contentW: pageWidth - margins.left - margins.right,
    contentH: pageHeight - margins.top - margins.bottom,
    bottomY: pageHeight - margins.bottom
  };
}

/**
 * Ensure there is enough vertical space; add new page if needed
 * @param {jsPDF} pdf
 * @param {Object} layout - from getLayout()
 * @param {number} y - current Y position
 * @param {number} neededHeight - space required for next content
 * @param {Function} drawHeader - optional function to redraw header on new page: (pdf, layout) => newY
 * @returns {number} updated Y position (either current or on new page)
 */
function ensureSpace(pdf, layout, y, neededHeight, drawHeader = null) {
  if (y + neededHeight > layout.bottomY) {
    pdf.addPage();
    let newY = layout.margins.top;
    if (drawHeader) {
      newY = drawHeader(pdf, layout);
    }
    return newY;
  }
  return y;
}

/**
 * Validate data URL format (basic check)
 */
function isValidDataUrl(s) {
  return typeof s === 'string' && s.startsWith('data:image/') && s.length > 100;
}

/**
 * Sanitize fence lines to contain only valid numeric points
 */
function sanitizeFenceLines(lines) {
  if (!Array.isArray(lines)) return [];
  return lines
    .map(line => {
      if (!line.points || !Array.isArray(line.points)) return null;
      const validPoints = line.points.filter(pt => 
        pt && typeof pt.x === 'number' && isFinite(pt.x) && 
        typeof pt.y === 'number' && isFinite(pt.y)
      );
      return validPoints.length > 1 ? { ...line, points: validPoints } : null;
    })
    .filter(Boolean);
}

/**
 * Compute bounding box of fence lines (returns null if invalid)
 */
function computeBounds(fenceLines) {
  if (!Array.isArray(fenceLines) || fenceLines.length === 0) return null;
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  fenceLines.forEach(line => {
    if (line.points && line.points.length > 0) {
      line.points.forEach(pt => {
        minX = Math.min(minX, pt.x);
        maxX = Math.max(maxX, pt.x);
        minY = Math.min(minY, pt.y);
        maxY = Math.max(maxY, pt.y);
      });
    }
  });
  const width = maxX - minX;
  const height = maxY - minY;
  return (isFinite(width) && isFinite(height) && width > 0 && height > 0) 
    ? { minX, maxX, minY, maxY, width, height } 
    : null;
}

/**
 * Render scaled fence line diagram; returns boolean (true if drawn)
 */
function renderFenceLinesDiagram(pdf, x, y, w, h, fenceLines) {
  const bounds = computeBounds(fenceLines);
  if (!bounds) return false;

  // Draw border
  pdf.setDrawColor(200, 200, 200);
  pdf.setLineWidth(0.5);
  pdf.rect(x, y, w, h);

  // Draw fence lines scaled to fit
  pdf.setDrawColor(16, 113, 84);
  pdf.setLineWidth(1);

  const scale = Math.min(w * 0.9 / bounds.width, h * 0.9 / bounds.height);
  fenceLines.forEach(line => {
    if (line.points && line.points.length > 1) {
      for (let i = 0; i < line.points.length - 1; i++) {
        const x1 = x + w * 0.05 + (line.points[i].x - bounds.minX) * scale;
        const y1 = y + h * 0.05 + (line.points[i].y - bounds.minY) * scale;
        const x2 = x + w * 0.05 + (line.points[i + 1].x - bounds.minX) * scale;
        const y2 = y + h * 0.05 + (line.points[i + 1].y - bounds.minY) * scale;
        pdf.line(x1, y1, x2, y2);
      }
    }
  });

  return true;
}

// ============================================================================
// MAIN GENERATOR
// ============================================================================

export async function generateCrewLoadSheet(job, runs, gates, materials, fenceLines = [], mapImageData = null) {
  const pdf = new jsPDF();
  const layout = getLayout(pdf);

  // Sanitize inputs
  const fenceLinesSafe = sanitizeFenceLines(fenceLines);
  const mapImageSafe = isValidDataUrl(mapImageData) ? mapImageData : null;

  let yPos = layout.margins.top;

  // Get canonical takeoff for consistent post counts
  const takeoff = buildTakeoff(job, fenceLinesSafe, runs, gates);
  const { postCounts } = takeoff;

  // Aggregate materials by line item name
  const aggregatedMaterials = materials.reduce((acc, item) => {
    const qty = item.manualOverrideQty || item.quantityCalculated || item.calculatedQty || item.quantity || 0;
    const key = item.materialDescription || item.lineItemName;

    if (!acc[key]) {
      acc[key] = {
        lineItemName: item.materialDescription || item.lineItemName,
        totalQty: 0,
        unit: item.uom || item.unit,
        calculationDetails: item.notes || item.calculationDetails || ''
      };
    }

    acc[key].totalQty += qty;
    return acc;
  }, {});

  const aggregatedMaterialsList = Object.values(aggregatedMaterials);

  // Header
  pdf.setFillColor(16, 113, 84);
  pdf.rect(0, 0, layout.pageWidth, 40, 'F');

  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(24);
  pdf.setFont(undefined, 'bold');
  pdf.text('CREW LOAD SHEET', layout.pageWidth / 2, 20, { align: 'center' });

  pdf.setFontSize(16);
  pdf.text(job.jobNumber, layout.pageWidth / 2, 30, { align: 'center' });

  pdf.setTextColor(0, 0, 0);
  yPos = 50;

  // Job Info
  pdf.setFontSize(10);
  pdf.setFont(undefined, 'bold');
  pdf.text('Customer:', layout.margins.left, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(job.customerName, 60, yPos);
  yPos += 6;

  pdf.setFont(undefined, 'bold');
  pdf.text('Address:', layout.margins.left, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(`${job.addressLine1}, ${job.city}, ${job.state}`, 60, yPos);
  yPos += 6;

  pdf.setFont(undefined, 'bold');
  pdf.text('Total LF:', layout.margins.left, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(String(job.totalLF), 60, yPos);
  yPos += 12;

  // Fence Specifications
  pdf.setFontSize(9);
  pdf.setFont(undefined, 'normal');
  pdf.setTextColor(0, 0, 0);
  
  const specs = [
    `Material: ${job.materialType}`,
    `Height: ${job.fenceHeight}`,
    `Style: ${job.style}`,
    ...(job.railsAndPostColor ? [`Post & Rail Color: ${job.railsAndPostColor}`] : []),
    ...(job.picketColor ? [`Picket Color: ${job.picketColor}`] : []),
    ...(job.fenceColor && !job.railsAndPostColor ? [`Fence Color: ${job.fenceColor}`] : [])
  ];

  specs.forEach(spec => {
    if (spec.trim()) {
      yPos = ensureSpace(pdf, layout, yPos, 4);
      pdf.text(spec, layout.margins.left, yPos);
      yPos += 4;
    }
  });
  yPos += 5;

  // A) POSTS
  yPos = addSection(pdf, yPos, 'POSTS', aggregatedMaterialsList.filter(m => 
    /postmaster/i.test(m.lineItemName) || 
    (/post/i.test(m.lineItemName) && !/cap/i.test(m.lineItemName))
  ), layout);

  // B) PANELS / PICKETS / SECTIONS
  yPos = addSection(pdf, yPos, 'PANELS / PICKETS / SECTIONS', aggregatedMaterialsList.filter(m => 
    /picket/i.test(m.lineItemName) || 
    /panel/i.test(m.lineItemName) ||
    /board.*board/i.test(m.lineItemName) ||
    /furring/i.test(m.lineItemName) ||
    /cap.*strip/i.test(m.lineItemName)
  ), layout);

  // C) GATES
  yPos = addGatesSection(pdf, yPos, gates, runs, aggregatedMaterialsList, layout);

  // D) FASTENERS
  yPos = addSection(pdf, yPos, 'FASTENERS', aggregatedMaterialsList.filter(m => 
    /screw/i.test(m.lineItemName) || 
    /nail/i.test(m.lineItemName) ||
    /fastener/i.test(m.lineItemName)
  ), layout);

  // E) CONCRETE / FOOTINGS
  yPos = addSection(pdf, yPos, 'CONCRETE / FOOTINGS', aggregatedMaterialsList.filter(m => 
    /concrete/i.test(m.lineItemName) || 
    /bag/i.test(m.lineItemName)
  ), layout);

  // ========================================================================
  // FOOTER + TAKEOFF AUDIT (never cut off)
  // ========================================================================

  const auditLine = `Takeoff Audit: End: ${postCounts.endPosts} | Corner: ${postCounts.cornerPosts} | Gate: ${postCounts.gatePosts} | Line: ${postCounts.linePosts} | Total: ${postCounts.totalVinylPosts}`;
  const wrappedAudit = pdf.splitTextToSize(auditLine, layout.contentW);
  const auditHeight = wrappedAudit.length * 3 + 15; // divider + padding

  yPos = ensureSpace(pdf, layout, yPos, auditHeight);

  yPos += 10;
  pdf.setDrawColor(200, 200, 200);
  pdf.line(layout.margins.left, yPos, layout.pageWidth - layout.margins.right, yPos);
  yPos += 5;

  pdf.setFontSize(8);
  pdf.setTextColor(120, 120, 120);
  pdf.text('✓ All quantities validated and include waste allowance', layout.pageWidth / 2, yPos, { align: 'center' });
  yPos += 4;
  pdf.text('Generated by FenceBuddy | No prices shown - load sheet only', layout.pageWidth / 2, yPos, { align: 'center' });
  yPos += 4;
  pdf.setFontSize(7);
  pdf.text(wrappedAudit, layout.pageWidth / 2, yPos, { align: 'center' });

  // ========================================================================
  // YARD MAP PAGE (NEVER BLANK)
  // ========================================================================

  if (mapImageSafe || (Array.isArray(fenceLinesSafe) && fenceLinesSafe.length > 0)) {
    pdf.addPage();
    const mapLayout = getLayout(pdf);
    let mapYPos = mapLayout.margins.top;

    // Title section
    pdf.setFillColor(240, 240, 240);
    pdf.rect(0, 0, mapLayout.pageWidth, 30, 'F');

    pdf.setFontSize(14);
    pdf.setFont(undefined, 'bold');
    pdf.setTextColor(16, 113, 84);
    pdf.text('YARD MAP', mapLayout.pageWidth / 2, 20, { align: 'center' });

    pdf.setTextColor(0, 0, 0);
    mapYPos = 40;

    // Map dimensions (dynamic based on page size)
    const mapBoxW = mapLayout.contentW - 10;
    const mapBoxH = mapLayout.pageHeight - mapYPos - mapLayout.margins.bottom - 10;
    const mapBoxX = mapLayout.margins.left + 5;
    const mapBoxY = mapYPos;

    let mapDrawn = false;

    // Try to use image first
    if (mapImageSafe) {
      try {
        // Draw border box
        pdf.setDrawColor(200, 200, 200);
        pdf.setLineWidth(0.5);
        pdf.rect(mapBoxX - 2, mapBoxY - 2, mapBoxW + 4, mapBoxH + 4);

        // Add image (auto-scale to fit box)
        pdf.addImage(mapImageSafe, 'PNG', mapBoxX, mapBoxY, mapBoxW, mapBoxH);
        mapDrawn = true;
      } catch (err) {
        console.warn('[OFFICE_DOC] Map image failed, falling back to geometry', err.message);
        mapDrawn = false;
      }
    }

    // Fallback to geometry diagram if no image
    if (!mapDrawn && fenceLinesSafe.length > 0) {
      // Draw border
      pdf.setDrawColor(200, 200, 200);
      pdf.setLineWidth(0.5);
      pdf.rect(mapBoxX, mapBoxY, mapBoxW, mapBoxH);

      mapDrawn = renderFenceLinesDiagram(pdf, mapBoxX, mapBoxY, mapBoxW, mapBoxH, fenceLinesSafe);
    }

    // If still not drawn, show message
    if (!mapDrawn) {
      pdf.setDrawColor(200, 200, 200);
      pdf.setLineWidth(0.5);
      pdf.rect(mapBoxX, mapBoxY, mapBoxW, mapBoxH);

      pdf.setFontSize(10);
      pdf.setTextColor(120, 120, 120);
      pdf.setFont(undefined, 'italic');
      pdf.text('Map unavailable (no valid image data or renderable fence geometry)', mapLayout.pageWidth / 2, mapBoxY + mapBoxH / 2, {
        align: 'center',
        maxWidth: mapBoxW - 10
      });
    }
  }

  return pdf;
}

// ============================================================================
// SECTION HELPERS
// ============================================================================

function addSection(pdf, yPos, title, items, layout) {
  if (items.length === 0) return yPos;

  yPos = ensureSpace(pdf, layout, yPos, 15, (p, l) => {
    p.setFillColor(16, 113, 84);
    p.rect(l.margins.left, l.margins.top - 5, l.contentW, 8, 'F');
    p.setTextColor(255, 255, 255);
    p.setFontSize(11);
    p.setFont(undefined, 'bold');
    p.text(title, l.margins.left + 3, l.margins.top);
    p.setTextColor(0, 0, 0);
    return l.margins.top + 8;
  });

  // Section header
  pdf.setFillColor(16, 113, 84);
  pdf.rect(layout.margins.left, yPos - 5, layout.contentW, 8, 'F');
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(11);
  pdf.setFont(undefined, 'bold');
  pdf.text(title, layout.margins.left + 3, yPos);
  pdf.setTextColor(0, 0, 0);
  yPos += 8;

  // Items
  pdf.setFontSize(9);
  pdf.setFont(undefined, 'normal');

  items.forEach((item, idx) => {
    const qty = item.totalQty || item.manualOverrideQty || item.calculatedQty || item.quantity || 0;
    const splitText = pdf.splitTextToSize(item.lineItemName, 120);
    const rowHeight = splitText.length > 1 ? splitText.length * 3.5 + 3 : 7;

    yPos = ensureSpace(pdf, layout, yPos, rowHeight, (p, l) => {
      p.setFillColor(16, 113, 84);
      p.rect(l.margins.left, l.margins.top - 5, l.contentW, 8, 'F');
      p.setTextColor(255, 255, 255);
      p.setFontSize(11);
      p.setFont(undefined, 'bold');
      p.text(title, l.margins.left + 3, l.margins.top);
      p.setTextColor(0, 0, 0);
      return l.margins.top + 8;
    });

    if (idx % 2 === 0) {
      pdf.setFillColor(250, 250, 250);
      pdf.rect(layout.margins.left, yPos - 4, layout.contentW, rowHeight, 'F');
    }

    pdf.setFont(undefined, 'bold');
    pdf.text(String(qty), layout.margins.left + 3, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.text(item.unit, layout.margins.left + 20, yPos);
    pdf.text(splitText, layout.margins.left + 40, yPos);
    yPos += rowHeight;
  });

  yPos += 5;
  return yPos;
}

function addGatesSection(pdf, yPos, gates, runs, materials, layout) {
  if (gates.length === 0) return yPos;

  yPos = ensureSpace(pdf, layout, yPos, 15, (p, l) => {
    p.setFillColor(16, 113, 84);
    p.rect(l.margins.left, l.margins.top - 5, l.contentW, 8, 'F');
    p.setTextColor(255, 255, 255);
    p.setFontSize(11);
    p.setFont(undefined, 'bold');
    p.text('GATES', l.margins.left + 3, l.margins.top);
    p.setTextColor(0, 0, 0);
    return l.margins.top + 8;
  });

  // Section header
  pdf.setFillColor(16, 113, 84);
  pdf.rect(layout.margins.left, yPos - 5, layout.contentW, 8, 'F');
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(11);
  pdf.setFont(undefined, 'bold');
  pdf.text('GATES', layout.margins.left + 3, yPos);
  pdf.setTextColor(0, 0, 0);
  yPos += 8;

  pdf.setFontSize(9);

  gates.forEach((gate, idx) => {
    const run = runs.find(r => r.id === gate.runId);
    const location = run ? run.runLabel : 'Unknown';

    const gateRowHeight = 18;
    yPos = ensureSpace(pdf, layout, yPos, gateRowHeight, (p, l) => {
      p.setFillColor(16, 113, 84);
      p.rect(l.margins.left, l.margins.top - 5, l.contentW, 8, 'F');
      p.setTextColor(255, 255, 255);
      p.setFontSize(11);
      p.setFont(undefined, 'bold');
      p.text('GATES', l.margins.left + 3, l.margins.top);
      p.setTextColor(0, 0, 0);
      return l.margins.top + 8;
    });

    if (idx % 2 === 0) {
      pdf.setFillColor(250, 250, 250);
      pdf.rect(layout.margins.left, yPos - 4, layout.contentW, gateRowHeight, 'F');
    }

    pdf.setFont(undefined, 'bold');
    pdf.text(`${gate.gateType} Gate - ${gate.gateWidth}`, layout.margins.left + 3, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.setTextColor(100, 100, 100);
    pdf.setFontSize(8);
    pdf.text(`Location: ${location}`, layout.margins.left + 3, yPos + 4);
    pdf.setFontSize(9);
    pdf.setTextColor(0, 0, 0);

    const leafCount = gate.gateType === 'Double' ? 2 : 1;
    yPos += 8;
    pdf.text(`• ${leafCount} handle${leafCount > 1 ? 's' : ''} (1 per leaf)`, layout.margins.left + 5, yPos);
    yPos += 4;

    if (gate.gateType === 'Double') {
      pdf.text(`• 2 cane bolts/drop rods (1 per leaf)`, layout.margins.left + 5, yPos);
      yPos += 4;
    }

    pdf.text(`• Hinges per standard`, layout.margins.left + 5, yPos);
    yPos += 8;
  });

  yPos += 5;
  return yPos;
}