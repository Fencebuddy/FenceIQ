import React from 'react';
import RunForm from '@/components/runs/RunForm';
import GateForm from '@/components/gates/GateForm';
import MaterialForm from '@/components/materials/MaterialForm';
import MaterialChangeModal from '@/components/runs/MaterialChangeModal';
import AssignLineToRunDialog from '@/components/fence/AssignLineToRunDialog';
import SurfaceMountModal from '@/components/fence/SurfaceMountModal';
import PdfImporter from '@/components/fence/PdfImporter';
import { BlockedModal, ConfirmModal } from '@/components/office/SendToOfficeModal';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { toast } from 'react-hot-toast';
import { base44 } from '@/api/base44Client';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function JobDetailModals({
  // Run form
  showRunForm, editingRun, jobId, job, assigningLine, saveRunMutation, handleLineLengthUpdate,
  setShowRunForm, setEditingRun, setAssigningLine,
  // Gate form
  showGateForm, editingGate, runs, saveGateMutation, setShowGateForm, setEditingGate,
  // Material form
  showMaterialForm, editingMaterial, saveMaterialMutation, setShowMaterialForm, setEditingMaterial,
  // Delete dialogs
  deleteRun, deleteRunMutation, setDeleteRun,
  deleteMaterial, deleteMaterialMutation, setDeleteMaterial,
  deleteGate, deleteGateMutation, setDeleteGate,
  // PDF importer
  showPdfImporter, setShowPdfImporter, handlePdfImport, zoom, fenceLines,
  // Send to office
  showBlockedModal, setShowBlockedModal, validation, handleAutoFix, isAutoFixing,
  showConfirmModal, setShowConfirmModal, handleConfirmSend, isSending,
  sendError, setSendError,
  // Assign line dialog
  assignLineDialog, setAssignLineDialog, trees, rotation, setFenceLines, setMapSaveStatus,
  queryClient,
  // Material change dialog
  materialChangeDialog, setMaterialChangeDialog, applyMaterialChangeToAllRuns,
  // Surface mount
  showSurfaceMountModal, setShowSurfaceMountModal, setSelectedPost,
  handleSurfaceMountAll, handleSurfaceMountOne, isUpdatingPosts,
}) {
  return (
    <>
      {showRunForm && (
        <RunForm
          run={editingRun} jobId={jobId} job={job} assigningLine={assigningLine}
          onSave={(data) => saveRunMutation.mutate(data)}
          onLineLengthUpdate={handleLineLengthUpdate}
          onClose={() => { setShowRunForm(false); setEditingRun(null); setAssigningLine(null); }}
          isLoading={saveRunMutation.isPending}
        />
      )}

      {showGateForm && (
        <GateForm
          gate={editingGate} jobId={jobId} runs={runs} job={job}
          onSave={(data) => saveGateMutation.mutate(data)}
          onClose={() => { setShowGateForm(false); setEditingGate(null); }}
          isLoading={saveGateMutation.isPending}
        />
      )}

      {showMaterialForm && (
        <MaterialForm
          material={editingMaterial} jobId={jobId} job={job}
          onSave={(data) => saveMaterialMutation.mutate(data)}
          onClose={() => { setShowMaterialForm(false); setEditingMaterial(null); }}
          isLoading={saveMaterialMutation.isPending}
        />
      )}

      <AlertDialog open={!!deleteRun} onOpenChange={() => setDeleteRun(null)}>
        <AlertDialogContent className="max-w-[90vw] sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base sm:text-lg">Delete Run?</AlertDialogTitle>
            <AlertDialogDescription className="text-sm">
              Are you sure you want to delete "{deleteRun?.runLabel}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel className="w-full sm:w-auto">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteRunMutation.mutate(deleteRun.id)} className="bg-red-600 hover:bg-red-700 w-full sm:w-auto">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteMaterial} onOpenChange={() => setDeleteMaterial(null)}>
        <AlertDialogContent className="max-w-[90vw] sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base sm:text-lg">Delete Material?</AlertDialogTitle>
            <AlertDialogDescription className="text-sm">
              Are you sure you want to delete "{deleteMaterial?.lineItemName}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel className="w-full sm:w-auto">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMaterialMutation.mutate(deleteMaterial.id)} className="bg-red-600 hover:bg-red-700 w-full sm:w-auto">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteGate} onOpenChange={() => setDeleteGate(null)}>
        <AlertDialogContent className="max-w-[90vw] sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base sm:text-lg">Delete Gate?</AlertDialogTitle>
            <AlertDialogDescription className="text-sm">
              Are you sure you want to delete this {deleteGate?.gateType} gate? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel className="w-full sm:w-auto">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteGateMutation.mutate(deleteGate.id)} className="bg-red-600 hover:bg-red-700 w-full sm:w-auto">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <PdfImporter isOpen={showPdfImporter} onClose={() => setShowPdfImporter(false)} onImport={handlePdfImport} currentZoom={zoom} currentFenceLines={fenceLines} />

      <BlockedModal isOpen={showBlockedModal} onClose={() => setShowBlockedModal(false)} issues={validation?.issues || []} onAutoFix={handleAutoFix} isFixing={isAutoFixing} />

      <ConfirmModal isOpen={showConfirmModal} onClose={() => setShowConfirmModal(false)} issues={validation?.issues || []} onConfirm={handleConfirmSend} isSending={isSending} />

      {sendError && (
        <Alert className="fixed bottom-4 right-4 w-96 border-red-500 bg-red-50 z-50">
          <AlertDescription className="flex items-center justify-between">
            <span className="text-red-800">{sendError}</span>
            <Button size="sm" variant="ghost" onClick={() => setSendError(null)}>✕</Button>
          </AlertDescription>
        </Alert>
      )}

      {assignLineDialog && (
        <AssignLineToRunDialog
          isOpen={true}
          onClose={() => setAssignLineDialog(null)}
          fenceLine={assignLineDialog.line}
          runs={runs}
          onAssign={async (runId) => {
            const newLines = [...fenceLines];
            newLines[assignLineDialog.lineIndex] = {
              ...newLines[assignLineDialog.lineIndex],
              assignedRunId: runId === '__none__' ? null : runId,
            };
            const canvasItems = {
              gates: window.gates || [], doubleGates: window.doubleGates || [],
              houses: window.houses || [], pools: window.pools || [],
              garages: window.garages || [], dogs: window.dogs || [],
              driveways: window.driveways || [], decks: window.decks || [],
              bushes: window.bushes || [], porches: window.porches || [],
              grasses: window.grasses || [], endPosts: window.endPosts || [],
              beds: window.beds || [],
            };
            await base44.entities.Job.update(jobId, {
              mapData: { fenceLines: newLines, trees, rotation, ...canvasItems },
            });
            setFenceLines(newLines);
            setMapSaveStatus('saved');
            setAssignLineDialog(null);
            toast.success('Run assigned');
          }}
          onCreateRun={() => {
            setAssigningLine({
              lineIndex: assignLineDialog.lineIndex,
              drawnLengthFt: assignLineDialog.line.manualLengthFt || assignLineDialog.line.length || 0,
              line: assignLineDialog.line,
            });
            setAssignLineDialog(null);
            setShowRunForm(true);
          }}
        />
      )}

      {materialChangeDialog && (
        <MaterialChangeModal
          isOpen={true}
          onClose={() => setMaterialChangeDialog(null)}
          originalRun={materialChangeDialog.originalRun}
          newRunData={materialChangeDialog.runData}
          onApplyToAll={() => applyMaterialChangeToAllRuns(true)}
          onApplyToThisRunOnly={() => applyMaterialChangeToAllRuns(false)}
          isLoading={saveRunMutation.isPending}
          isMaterialTypeChange={materialChangeDialog.isMaterialTypeChange}
          isStyleChange={materialChangeDialog.isStyleChange}
          isHeightChange={materialChangeDialog.isHeightChange}
          isColorChange={materialChangeDialog.isColorChange}
          isPrivacyTypeChange={materialChangeDialog.isPrivacyTypeChange}
          isSlatColorChange={materialChangeDialog.isSlatColorChange}
        />
      )}

      {showSurfaceMountModal && (
        <SurfaceMountModal
          isOpen={true}
          onClose={() => { setShowSurfaceMountModal(false); setSelectedPost(null); }}
          onApplyToAll={handleSurfaceMountAll}
          onApplyToOne={handleSurfaceMountOne}
          isUpdating={isUpdatingPosts}
        />
      )}
    </>
  );
}