import { useState } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { CheckCircle, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import toast from 'react-hot-toast';

const SEVERITY_CONFIG = {
  critical: { label: 'Critical', color: 'bg-red-100 text-red-700', icon: AlertCircle },
  warn: { label: 'Warning', color: 'bg-amber-100 text-amber-700', icon: AlertTriangle },
  info: { label: 'Info', color: 'bg-blue-100 text-blue-700', icon: Info }
};

const TYPE_LABELS = {
  MARGIN_FLOOR_BREACH: 'Margin Breach',
  DISCOUNT_OVER_THRESHOLD: 'Discount',
  REWORK_RISK: 'Rework Risk',
  CHANGE_ORDER_RISK: 'Change Order',
  LOW_NET_MARGIN_BY_REP: 'Low Margin / Rep',
  LOW_NET_MARGIN_BY_ZONE: 'Low Margin / Zone',
  LOW_NET_MARGIN_BY_CREW: 'Low Margin / Crew',
  HIGH_CANCELLATION_ZONE: 'High Cancel Zone'
};

export default function ProfitSignalsTab({ signals, user }) {
  const queryClient = useQueryClient();
  const [filterSeverity, setFilterSeverity] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [showAcked, setShowAcked] = useState(false);

  const ackMutation = useMutation({
    mutationFn: (id) => base44.entities.ProfitSignal.update(id, {
      acknowledgedAt: new Date().toISOString(),
      acknowledgedBy: user?.email || 'unknown'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profitSignals'] });
      toast.success('Signal acknowledged');
    }
  });

  const filtered = signals.filter(s => {
    if (!showAcked && s.acknowledgedAt) return false;
    if (filterSeverity !== 'all' && s.severity !== filterSeverity) return false;
    if (filterType !== 'all' && s.type !== filterType) return false;
    return true;
  }).sort((a, b) => {
    const order = { critical: 0, warn: 1, info: 2 };
    return (order[a.severity] ?? 3) - (order[b.severity] ?? 3);
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <Select value={filterSeverity} onValueChange={setFilterSeverity}>
          <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severities</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="warn">Warning</SelectItem>
            <SelectItem value="info">Info</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="h-8 w-48 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button
          size="sm"
          variant={showAcked ? 'default' : 'outline'}
          className="h-8 text-xs"
          onClick={() => setShowAcked(v => !v)}
        >
          {showAcked ? 'Hiding Acked' : 'Show Acked'}
        </Button>
        <span className="ml-auto text-xs text-slate-400">{filtered.length} signals</span>
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center">
          <CheckCircle className="w-10 h-10 text-green-400 mx-auto mb-2" />
          <p className="text-slate-500">No signals match current filters</p>
        </div>
      )}

      <div className="space-y-2">
        {filtered.map(signal => {
          const sc = SEVERITY_CONFIG[signal.severity] || SEVERITY_CONFIG.info;
          const Icon = sc.icon;
          return (
            <div key={signal.id} className={`bg-white rounded-xl border shadow-sm p-4 ${signal.acknowledgedAt ? 'opacity-50' : ''}`}>
              <div className="flex items-start gap-3">
                <Icon className={`w-5 h-5 mt-0.5 flex-shrink-0 ${signal.severity === 'critical' ? 'text-red-500' : signal.severity === 'warn' ? 'text-amber-500' : 'text-blue-400'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <Badge className={`text-xs ${sc.color}`}>{sc.label}</Badge>
                    <Badge variant="secondary" className="text-xs">{TYPE_LABELS[signal.type] || signal.type}</Badge>
                    {signal.dateBucket && <span className="text-xs text-slate-400">{signal.dateBucket}</span>}
                  </div>
                  <p className="text-sm text-slate-800">{signal.message}</p>
                  {signal.evidence && Object.keys(signal.evidence).length > 0 && (
                    <details className="mt-1">
                      <summary className="text-xs text-slate-400 cursor-pointer">Evidence</summary>
                      <pre className="text-xs text-slate-500 mt-1 bg-slate-50 rounded p-2 overflow-x-auto">
                        {JSON.stringify(signal.evidence, null, 2)}
                      </pre>
                    </details>
                  )}
                  {signal.acknowledgedAt && (
                    <p className="text-xs text-slate-400 mt-1">Acked by {signal.acknowledgedBy} · {signal.acknowledgedAt?.slice(0, 10)}</p>
                  )}
                </div>
                {!signal.acknowledgedAt && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs flex-shrink-0"
                    onClick={() => ackMutation.mutate(signal.id)}
                    disabled={ackMutation.isPending}
                  >
                    <CheckCircle className="w-3 h-3 mr-1" />Ack
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}