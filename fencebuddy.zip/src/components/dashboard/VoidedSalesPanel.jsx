import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, XCircle, ChevronDown, ChevronUp } from "lucide-react";
import VoidSaleDialog from "@/components/dashboard/VoidSaleDialog";

export default function VoidedSalesPanel({ companyId, dateStart, dateEnd }) {
    const [expanded, setExpanded] = useState(false);
    const [voidDialogJob, setVoidDialogJob] = useState(null);
    const queryClient = useQueryClient();

    const { data: allJobs = [] } = useQuery({
        queryKey: ['crmJobs', companyId],
        queryFn: () => base44.entities.CRMJob.filter({ companyId }),
        enabled: !!companyId,
        staleTime: 60000
    });

    // Sold jobs in range
    const soldInRange = allJobs.filter(j => {
        if (!j.wonAt && !j.saleStatusUpdatedAt) return false;
        const d = new Date(j.wonAt || j.saleStatusUpdatedAt);
        return d >= new Date(dateStart) && d <= new Date(dateEnd) && 
               (j.saleStatus === 'sold' || j.contractStatus === 'signed');
    });

    // Voided jobs (any time, not just in range — they were previously counted)
    const voidedJobs = allJobs.filter(j => j.saleVoidedAt);

    // Voided jobs whose original wonAt was in the current range
    const voidedInRange = voidedJobs.filter(j => {
        const d = new Date(j.wonAt || j.saleStatusUpdatedAt || j.saleVoidedAt);
        return d >= new Date(dateStart) && d <= new Date(dateEnd);
    });

    const voidedRevenueInRange = voidedInRange.reduce((sum, j) => sum + ((j.contractValueCents || 0) / 100), 0);

    if (voidedJobs.length === 0 && soldInRange.length === 0) return null;

    return (
        <>
            <Card className="bg-slate-800 border-red-500/30">
                <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-sm uppercase tracking-wider text-white font-semibold flex items-center gap-2">
                            <XCircle className="w-4 h-4 text-red-400" />
                            <span>VOIDED SALES</span>
                        </CardTitle>
                        <div className="flex items-center gap-2">
                            {voidedInRange.length > 0 && (
                                <Badge className="bg-red-600 text-white text-xs">
                                    {voidedInRange.length} voided
                                </Badge>
                            )}
                            <button
                                onClick={() => setExpanded(v => !v)}
                                className="text-slate-400 hover:text-white"
                            >
                                {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                            <div className="text-xs text-slate-400 mb-1">Voided This Period</div>
                            <div className="text-2xl font-bold text-red-400">{voidedInRange.length}</div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-400 mb-1">Revenue Pulled Back</div>
                            <div className="text-2xl font-bold text-red-400">
                                ${voidedRevenueInRange.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </div>
                        </div>
                    </div>

                    {expanded && (
                        <div className="space-y-3 pt-3 border-t border-slate-700">
                            {/* Active sold jobs — can be voided */}
                            <div>
                                <div className="text-xs text-slate-400 mb-2 uppercase tracking-wider">Active Sold Jobs (This Period)</div>
                                {soldInRange.filter(j => !j.saleVoidedAt).length === 0 ? (
                                    <p className="text-xs text-slate-500">No active sold jobs in this period.</p>
                                ) : (
                                    <div className="space-y-2">
                                        {soldInRange.filter(j => !j.saleVoidedAt).map(job => (
                                            <div key={job.id} className="flex items-center justify-between bg-slate-900/50 rounded p-2">
                                                <div>
                                                    <div className="text-xs font-medium text-white">{job.customerName || job.jobNumber}</div>
                                                    <div className="text-xs text-slate-400">{job.jobNumber} · ${((job.contractValueCents || 0) / 100).toLocaleString()}</div>
                                                </div>
                                                <Button
                                                    size="sm"
                                                    variant="destructive"
                                                    className="text-xs h-7 px-2"
                                                    onClick={() => setVoidDialogJob(job)}
                                                >
                                                    Void Sale
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Already voided jobs */}
                            {voidedJobs.length > 0 && (
                                <div>
                                    <div className="text-xs text-slate-400 mb-2 uppercase tracking-wider">Previously Voided (All Time)</div>
                                    <div className="space-y-2">
                                        {voidedJobs.slice(0, 10).map(job => (
                                            <div key={job.id} className="flex items-center justify-between bg-red-900/20 rounded p-2 border border-red-500/20">
                                                <div>
                                                    <div className="text-xs font-medium text-red-300">{job.customerName || job.jobNumber}</div>
                                                    <div className="text-xs text-slate-400">
                                                        {job.jobNumber} · ${((job.contractValueCents || 0) / 100).toLocaleString()} · Voided {new Date(job.saleVoidedAt).toLocaleDateString()}
                                                    </div>
                                                    {job.saleVoidedReason && (
                                                        <div className="text-xs text-slate-500 italic mt-0.5">"{job.saleVoidedReason}"</div>
                                                    )}
                                                </div>
                                                <Badge className="bg-red-900 text-red-300 text-xs">Voided</Badge>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </CardContent>
            </Card>

            {voidDialogJob && (
                <VoidSaleDialog
                    job={voidDialogJob}
                    onClose={() => setVoidDialogJob(null)}
                    onSuccess={() => {
                        setVoidDialogJob(null);
                        queryClient.invalidateQueries(['crmJobs', companyId]);
                        queryClient.invalidateQueries(['executiveState']);
                    }}
                />
            )}
        </>
    );
}