/**
 * REPAIR TOOL: Fix duplicated system_color suffixes in vinyl UCKs
 * 
 * Example:
 * vinyl_panel_privacy_5ft_savannah_grey_savannah_white
 * => vinyl_panel_privacy_5ft_savannah_grey
 * 
 * Removes trailing _<defaultSystem>_<defaultColor> when system_color already exists
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify admin access
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ 
        error: 'Forbidden: Admin access required' 
      }, { status: 403 });
    }
    
    const { companyId = 'PrivacyFenceCo49319', mode = 'dry_run' } = await req.json();
    const dryRun = mode === 'dry_run';
    
    console.log(`[repairDuplicatedVinylSuffixes] Starting repair for company: ${companyId}, mode: ${mode}`);
    
    // Known vinyl systems and colors
    const vinylSystems = ['savannah', 'lakeshore', 'yorktown'];
    const vinylColors = ['white', 'tan', 'khaki', 'grey', 'coastal_grey', 'cedar_tone', 'black'];
    
    /**
     * Detect if UCK has duplicated system_color suffix
     * Returns { isDuplicated: boolean, repairedUck: string }
     */
    function detectDuplicatedSuffix(uck) {
      const tokens = uck.split('_');
      if (tokens.length < 4) return { isDuplicated: false };
      
      const last2 = tokens.slice(-2); // e.g., ['savannah', 'white']
      const prev2 = tokens.slice(-4, -2); // e.g., ['savannah', 'grey']
      
      // Check if both pairs are system_color
      const lastIsSystemColor = vinylSystems.includes(last2[0]) && vinylColors.includes(last2[1]);
      const prevIsSystemColor = vinylSystems.includes(prev2[0]) && vinylColors.includes(prev2[1]);
      
      if (lastIsSystemColor && prevIsSystemColor) {
        // Remove last 2 tokens (duplicated suffix)
        const repairedUck = tokens.slice(0, -2).join('_');
        return { isDuplicated: true, repairedUck };
      }
      
      return { isDuplicated: false };
    }
    
    // Fetch all mapped CompanySkuMap rows
    const allMappings = await base44.asServiceRole.entities.CompanySkuMap.filter({
      companyId,
      status: 'mapped'
    });
    
    console.log(`[repairDuplicatedVinylSuffixes] Found ${allMappings.length} mapped rows`);
    
    const results = {
      totalChecked: allMappings.length,
      duplicatesFound: 0,
      repaired: 0,
      collisions: 0,
      errors: [],
      badRows: []
    };
    
    for (const mapping of allMappings) {
      const uck = mapping.uck;
      
      // Only check vinyl UCKs
      if (!uck.startsWith('vinyl_')) continue;
      
      const detection = detectDuplicatedSuffix(uck);
      
      if (detection.isDuplicated) {
        results.duplicatesFound++;
        console.log(`[repairDuplicatedVinylSuffixes] Found duplicate: ${uck} => ${detection.repairedUck}`);
        
        results.badRows.push({
          originalUck: uck,
          repairedUck: detection.repairedUck,
          mappingId: mapping.id
        });
        
        // Check for collision
        const existingRepaired = await base44.asServiceRole.entities.CompanySkuMap.filter({
          companyId,
          uck: detection.repairedUck
        });
        
        if (existingRepaired.length > 0) {
          console.log(`[repairDuplicatedVinylSuffixes] ⚠️  Collision: ${detection.repairedUck} already exists - DELETING DUPLICATE`);
          results.collisions++;
          
          // Delete the duplicated row (keep the original non-duplicated one)
          if (!dryRun) {
            try {
              await base44.asServiceRole.entities.CompanySkuMap.delete(mapping.id);
              console.log(`[repairDuplicatedVinylSuffixes] 🗑️  Deleted duplicate row: ${uck}`);
            } catch (error) {
              console.error(`[repairDuplicatedVinylSuffixes] Error deleting duplicate ${uck}:`, error);
              results.errors.push({
                uck,
                error: error.message
              });
            }
          }
          continue;
        }
        
        if (!dryRun) {
          try {
            // Update the mapping with repaired UCK
            await base44.asServiceRole.entities.CompanySkuMap.update(mapping.id, {
              uck: detection.repairedUck,
              notes: `Repaired from duplicated suffix: ${uck} => ${detection.repairedUck}`,
              attributes: {
                ...mapping.attributes,
                meta: {
                  source: 'uck_repair_v1',
                  fromUck: uck,
                  repairedAt: new Date().toISOString()
                }
              }
            });
            
            results.repaired++;
            console.log(`[repairDuplicatedVinylSuffixes] ✅ Repaired: ${uck} => ${detection.repairedUck}`);
          } catch (error) {
            console.error(`[repairDuplicatedVinylSuffixes] Error repairing ${uck}:`, error);
            results.errors.push({
              uck,
              error: error.message
            });
          }
        }
      }
    }
    
    console.log(`[repairDuplicatedVinylSuffixes] Repair complete:`, results);
    
    return Response.json({
      success: true,
      mode,
      results,
      message: dryRun 
        ? `Dry run complete: Found ${results.duplicatesFound} duplicates, ${results.collisions} collisions`
        : `Repair complete: Fixed ${results.repaired} duplicates, ${results.collisions} collisions, ${results.errors.length} errors`
    });
    
  } catch (error) {
    console.error('[repairDuplicatedVinylSuffixes] Fatal error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});