/**
 * Send to Office PDF Generator
 * Deterministic, paginated, never-blank layout with fallbacks
 */

// ═══════════════════════════════════════════════════════════════════════════════
// LAYOUT HELPERS
// ═══════════════════════════════════════════════════════════════════════════════
export function getLayout(pdf) {
  const w = pdf.internal.pageSize.getWidth();
  const h = pdf.internal.pageSize.getHeight();
  const m = { top: 15, right: 15, bottom: 15, left: 15 };
  return { w, h, m, contentW: w - m.left - m.right, bottomY: h - m.bottom };
}

export function ensureSpace(pdf, layout, y, neededHeight, onNewPage) {
  if (y + neededHeight > layout.bottomY) {
    pdf.addPage();
    y = layout.m.top;
    if (onNewPage) y = onNewPage(pdf, layout, y) || y;
  }
  return y;
}

const isValidDataUrl = (s) =>
  typeof s === 'string' && s.startsWith('data:image/') && s.length > 100;

export function normalizeFenceLines(lines) {
  if (!Array.isArray(lines)) return [];
  return lines
    .map(l => {
      if (Array.isArray(l.points) && l.points.length) return l;
      if ([l.x1, l.y1, l.x2, l.y2].every(v => typeof v === 'number' && Number.isFinite(v))) {
        return { ...l, points: [{ x: l.x1, y: l.y1 }, { x: l.x2, y: l.y2 }] };
      }
      return null;
    })
    .filter(Boolean);
}

export function renderFenceLinesDiagram(pdf, x, y, w, h, fenceLines) {
  if (!Array.isArray(fenceLines) || fenceLines.length === 0) return false;

  const pts = [];
  for (const line of fenceLines) {
    for (const pt of (line?.points || [])) {
      const px = Number(pt?.x);
      const py = Number(pt?.y);
      if (Number.isFinite(px) && Number.isFinite(py)) pts.push({ x: px, y: py });
    }
  }
  if (pts.length < 2) return false;

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    minX = Math.min(minX, p.x);
    maxX = Math.max(maxX, p.x);
    minY = Math.min(minY, p.y);
    maxY = Math.max(maxY, p.y);
  }
  const srcW = maxX - minX;
  const srcH = maxY - minY;
  if (!(srcW > 0 && srcH > 0)) return false;

  const pad = 8;
  const drawW = w - pad * 2;
  const drawH = h - pad * 2;

  const scale = Math.min(drawW / srcW, drawH / srcH);
  if (!Number.isFinite(scale) || scale <= 0) return false;

  const offsetX = x + pad + (drawW - srcW * scale) / 2;
  const offsetY = y + pad + (drawH - srcH * scale) / 2;

  pdf.setDrawColor(16, 113, 84);
  pdf.setLineWidth(1);

  for (const line of fenceLines) {
    const lp = (line?.points || [])
      .map(p => ({ x: Number(p?.x), y: Number(p?.y) }))
      .filter(p => Number.isFinite(p.x) && Number.isFinite(p.y));

    for (let i = 0; i < lp.length - 1; i++) {
      const x1 = offsetX + (lp[i].x - minX) * scale;
      const y1 = offsetY + (lp[i].y - minY) * scale;
      const x2 = offsetX + (lp[i + 1].x - minX) * scale;
      const y2 = offsetY + (lp[i + 1].y - minY) * scale;
      if ([x1, y1, x2, y2].every(Number.isFinite)) pdf.line(x1, y1, x2, y2);
    }
  }
  return true;
}

function drawMaterialsTableHeader(pdf, layout, y) {
  pdf.setFillColor(255, 215, 0);
  pdf.rect(layout.m.left, y - 5, layout.contentW, 8, 'F');
  pdf.setFontSize(9);
  pdf.setFont(undefined, 'bold');
  pdf.setTextColor(16, 113, 84);
  pdf.text('QTY', layout.m.left + 2, y);
  pdf.text('ITEM', layout.m.left + 15, y);
  pdf.text('UNIT', layout.w - layout.m.right - 20, y);
  pdf.setTextColor(0, 0, 0);
  return y + 8;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN PDF GENERATOR
// ═══════════════════════════════════════════════════════════════════════════════
export async function generateSendToOfficePdf(
  pdf,
  job,
  runs,
  gates,
  allMaterials,
  fenceLines,
  mapImageData,
  validation,
  takeoffSource,
  aggregatedMaterials,
  takeoff,
  user
) {
  const layout = getLayout(pdf);
  let yPos = layout.m.top;

  // ─────────────────────────────────────────────────────────────────────────────
  // LOGO + HEADER
  // ─────────────────────────────────────────────────────────────────────────────
  const logoUrl =
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6934c2aad8d7afa0d77a1bfa/78e2a3294_logo_high_resolution.png';
  try {
    const response = await fetch(logoUrl);
    const blob = await response.blob();
    const logoDataUrl = await new Promise(resolve => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
    pdf.addImage(logoDataUrl, 'PNG', layout.m.left, yPos, 70, 20);
  } catch (err) {
    console.log('Logo load failed:', err);
  }

  pdf.setFillColor(16, 113, 84);
  pdf.rect(0, 40, layout.w, 15, 'F');

  pdf.setFillColor(255, 215, 0);
  pdf.rect(0, 55, layout.w, 10, 'F');

  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(20);
  pdf.setFont(undefined, 'bold');
  pdf.text('MATERIALS TAKEOFF', layout.w / 2, 51, { align: 'center' });

  pdf.setFontSize(12);
  pdf.setFont(undefined, 'bold');
  pdf.setTextColor(16, 113, 84);
  pdf.text(job.jobNumber, layout.w / 2, 61.5, { align: 'center' });

  yPos = 75;
  pdf.setTextColor(0, 0, 0);

  // ─────────────────────────────────────────────────────────────────────────────
  // TAKEOFF SOURCE BANNER
  // ─────────────────────────────────────────────────────────────────────────────
  const sourceText =
    takeoffSource === 'MAP_DRIVEN'
      ? 'Material quantities generated from saved Yard Map geometry'
      : 'Material quantities generated from manual run entries';

  pdf.setFillColor(240, 240, 240);
  pdf.rect(layout.m.left, yPos, layout.contentW, 8, 'F');
  pdf.setFontSize(8);
  pdf.setTextColor(80, 80, 80);
  pdf.setFont(undefined, 'italic');
  pdf.text(sourceText, layout.w / 2, yPos + 5, { align: 'center' });
  pdf.setFont(undefined, 'normal');
  pdf.setTextColor(0, 0, 0);
  yPos += 13;

  // ─────────────────────────────────────────────────────────────────────────────
  // VALIDATION BADGE
  // ─────────────────────────────────────────────────────────────────────────────
  if (validation) {
    const badges = {
      PASS: { icon: '✓', text: 'Validation Passed' },
      PASS_WITH_NOTES: { icon: '⚠', text: 'Passed with Notes' },
      NEEDS_REVIEW: { icon: 'ⓘ', text: 'Needs Review' },
      BLOCKED: { icon: '✕', text: 'Blocked' }
    };
    const badge = badges[validation.validationStatus] || badges.PASS;

    let bgColor = [220, 252, 231];
    if (validation.validationStatus === 'PASS_WITH_NOTES') bgColor = [254, 249, 195];
    if (validation.validationStatus === 'NEEDS_REVIEW') bgColor = [255, 237, 213];
    if (validation.validationStatus === 'BLOCKED') bgColor = [254, 226, 226];

    pdf.setFillColor(...bgColor);
    pdf.rect(layout.m.left, yPos, layout.contentW, 8, 'F');
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'bold');
    pdf.text(`${badge.icon} ${badge.text}`, layout.w / 2, yPos + 5, { align: 'center' });
    pdf.setFont(undefined, 'normal');
    yPos += 10;

    if (validation.requiresConfirm) {
      pdf.setFontSize(7);
      pdf.setTextColor(120, 120, 120);
      pdf.text('Sent with acknowledged warnings.', layout.w / 2, yPos, { align: 'center' });
      yPos += 5;
    }
    pdf.setTextColor(0, 0, 0);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // JOB INFORMATION
  // ─────────────────────────────────────────────────────────────────────────────
  yPos = ensureSpace(pdf, layout, yPos, 70);

  pdf.setFillColor(245, 245, 245);
  pdf.roundedRect(layout.m.left, yPos, layout.contentW, 65, 3, 3, 'F');

  pdf.setFontSize(11);
  pdf.setFont(undefined, 'bold');
  pdf.setTextColor(16, 113, 84);
  pdf.text('JOB INFORMATION', layout.m.left + 5, yPos + 8);
  pdf.setTextColor(0, 0, 0);
  yPos += 15;

  pdf.setFontSize(9);
  pdf.setFont(undefined, 'bold');
  pdf.text('Customer:', layout.m.left + 5, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(job.customerName, layout.m.left + 30, yPos);

  pdf.setFont(undefined, 'bold');
  pdf.text('Phone:', layout.w / 2, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(job.customerPhone, layout.w / 2 + 18, yPos);
  yPos += 6;

  if (job.customerEmail) {
    pdf.setFont(undefined, 'bold');
    pdf.text('Email:', layout.m.left + 5, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.text(job.customerEmail, layout.m.left + 30, yPos);
    yPos += 6;
  }

  pdf.setFont(undefined, 'bold');
  pdf.text('Address:', layout.m.left + 5, yPos);
  pdf.setFont(undefined, 'normal');
  const addr = `${job.addressLine1}, ${job.city}, ${job.state} ${job.zip}`;
  pdf.text(addr, layout.m.left + 30, yPos, { maxWidth: layout.contentW - 35 });
  yPos += 6;

  if (job.repName) {
    pdf.setFont(undefined, 'bold');
    pdf.text('Field Rep:', layout.m.left + 5, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.text(job.repName, layout.m.left + 30, yPos);
    yPos += 6;
  }

  yPos += 3;
  pdf.setFont(undefined, 'bold');
  pdf.text('Material:', layout.m.left + 5, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(job.materialType, layout.m.left + 30, yPos);

  pdf.setFont(undefined, 'bold');
  pdf.text('Height:', layout.w / 2, yPos);
  pdf.setFont(undefined, 'normal');
  pdf.text(job.fenceHeight, layout.w / 2 + 15, yPos);
  yPos += 6;

  pdf.setFont(undefined, 'bold');
  pdf.text('Style:', layout.m.left + 5, yPos);
  pdf.setFont(undefined, 'normal');
  const styleText = `${job.style}${job.style === 'Ranch Style' && job.ranchStyleType ? ` - ${job.ranchStyleType}` : ''}`;
  pdf.text(styleText, layout.m.left + 30, yPos, { maxWidth: layout.contentW - 35 });
  yPos += 6;

  if (job.fenceColor) {
    pdf.setFont(undefined, 'bold');
    pdf.text('Color:', layout.m.left + 5, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.text(job.fenceColor, layout.m.left + 30, yPos);
    yPos += 6;
  }

  pdf.setFillColor(255, 215, 0);
  pdf.rect(layout.m.left + 5, yPos, 50, 8, 'F');
  pdf.setTextColor(16, 113, 84);
  pdf.setFont(undefined, 'bold');
  pdf.setFontSize(10);
  pdf.text('TOTAL LF:', layout.m.left + 7, yPos + 5.5);
  pdf.setFontSize(11);
  pdf.text(String(job.totalLF), layout.m.left + 30, yPos + 5.5);
  pdf.setTextColor(0, 0, 0);
  yPos += 15;

  if (job.jobNotes) {
    pdf.setFont(undefined, 'italic');
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Notes: ${job.jobNotes}`, layout.m.left + 5, yPos, { maxWidth: layout.contentW - 10 });
    yPos += 8;
    pdf.setTextColor(0, 0, 0);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // FENCE RUNS
  // ─────────────────────────────────────────────────────────────────────────────
  yPos += 8;
  yPos = ensureSpace(pdf, layout, yPos, 15);

  pdf.setFontSize(11);
  pdf.setFont(undefined, 'bold');
  pdf.setTextColor(16, 113, 84);
  pdf.text('FENCE RUNS', layout.m.left + 5, yPos);
  pdf.setDrawColor(16, 113, 84);
  pdf.setLineWidth(0.5);
  pdf.line(layout.m.left + 5, yPos + 2, layout.m.left + 45, yPos + 2);
  pdf.setTextColor(0, 0, 0);
  yPos += 8;

  pdf.setFontSize(9);
  pdf.setFont(undefined, 'normal');
  for (let i = 0; i < runs.length; i++) {
    const r = runs[i];
    yPos = ensureSpace(pdf, layout, yPos, 6);

    if (i % 2 === 0) {
      pdf.setFillColor(250, 250, 250);
      pdf.rect(layout.m.left, yPos - 3, layout.contentW, 6, 'F');
    }

    pdf.setFont(undefined, 'bold');
    pdf.text(r.runLabel, layout.m.left + 3, yPos);
    pdf.setFont(undefined, 'normal');
    pdf.text(`${r.lengthLF} LF`, layout.m.left + 50, yPos);
    pdf.setTextColor(100, 100, 100);
    pdf.setFontSize(8);
    pdf.text(`Slope: ${r.slope || 'None'}`, layout.m.left + 75, yPos);
    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(9);
    yPos += 6;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // GATES
  // ─────────────────────────────────────────────────────────────────────────────
  if (gates.length > 0) {
    yPos += 8;
    yPos = ensureSpace(pdf, layout, yPos, 15);

    pdf.setFontSize(11);
    pdf.setFont(undefined, 'bold');
    pdf.setTextColor(16, 113, 84);
    pdf.text('GATES', layout.m.left + 5, yPos);
    pdf.setDrawColor(16, 113, 84);
    pdf.setLineWidth(0.5);
    pdf.line(layout.m.left + 5, yPos + 2, layout.m.left + 30, yPos + 2);
    pdf.setTextColor(0, 0, 0);
    yPos += 8;

    pdf.setFontSize(9);
    pdf.setFont(undefined, 'normal');
    for (let i = 0; i < gates.length; i++) {
      const g = gates[i];
      yPos = ensureSpace(pdf, layout, yPos, 6);

      if (i % 2 === 0) {
        pdf.setFillColor(250, 250, 250);
        pdf.rect(layout.m.left, yPos - 3, layout.contentW, 6, 'F');
      }

      const run = runs.find(r => r.id === g.runId);
      const runLabel = run ? run.runLabel : 'Unknown';

      pdf.setFont(undefined, 'bold');
      pdf.text(`${g.gateType} Gate`, layout.m.left + 3, yPos);
      pdf.setFont(undefined, 'normal');
      pdf.text(g.gateWidth, layout.m.left + 40, yPos);
      pdf.setTextColor(100, 100, 100);
      pdf.setFontSize(8);
      pdf.text(`${g.placement} • ${runLabel}`, layout.m.left + 60, yPos);
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(9);
      yPos += 6;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // MATERIALS
  // ─────────────────────────────────────────────────────────────────────────────
  yPos += 8;
  yPos = ensureSpace(pdf, layout, yPos, 18);

  pdf.setFillColor(16, 113, 84);
  pdf.rect(layout.m.left, yPos, layout.contentW, 10, 'F');
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(12);
  pdf.setFont(undefined, 'bold');
  pdf.text('MATERIALS NEEDED', layout.w / 2, yPos + 7, { align: 'center' });
  pdf.setTextColor(0, 0, 0);
  yPos += 18;

  // Draw header
  yPos = drawMaterialsTableHeader(pdf, layout, yPos);

  // Materials rows with proper wrapping
  const qtyColW = 18;
  const unitColW = 22;
  const itemColW = layout.contentW - qtyColW - unitColW - 10;

  pdf.setFontSize(9);
  pdf.setFont(undefined, 'normal');
  let itemIndex = 0;

  for (let i = 0; i < aggregatedMaterials.length; i++) {
    const m = aggregatedMaterials[i];

    // Handle section headers
    if (m.lineItemName?.startsWith('__SECTION__')) {
      yPos = ensureSpace(pdf, layout, yPos, 12);
      const sectionName = m.lineItemName.replace('__SECTION__', '');
      yPos += 5;
      pdf.setFillColor(255, 215, 0);
      pdf.rect(layout.m.left, yPos - 4, layout.contentW, 7, 'F');
      pdf.setFont(undefined, 'bold');
      pdf.setTextColor(16, 113, 84);
      pdf.text(sectionName, layout.m.left + 3, yPos);
      pdf.setTextColor(0, 0, 0);
      yPos += 7;
      itemIndex = 0;
      // Re-draw table header after section
      yPos = drawMaterialsTableHeader(pdf, layout, yPos);
      continue;
    }

    // Calculate row height based on text wrapping
    const itemName = m.lineItemName || '';
    const wrappedLines = pdf.splitTextToSize(itemName, itemColW);
    const lineHeight = 4;
    const rowH = Math.max(7, wrappedLines.length * lineHeight + 2);

    yPos = ensureSpace(pdf, layout, yPos, rowH, (p, l, y) => drawMaterialsTableHeader(p, l, y));

    // Row background
    if (itemIndex % 2 === 1) {
      pdf.setFillColor(250, 250, 250);
      pdf.rect(layout.m.left, yPos - 4, layout.contentW, rowH, 'F');
    }

    // Qty
    const qty = m.totalQty || m.manualOverrideQty || m.calculatedQty || m.quantity || 0;
    pdf.setFont(undefined, 'bold');
    pdf.text(String(qty), layout.m.left + 2, yPos);

    // Item name (wrapped)
    pdf.setFont(undefined, 'normal');
    pdf.text(wrappedLines, layout.m.left + 15, yPos, { maxWidth: itemColW });

    // Unit
    pdf.setTextColor(100, 100, 100);
    pdf.text(m.unit || '', layout.w - layout.m.right - 20, yPos);
    pdf.setTextColor(0, 0, 0);

    yPos += rowH;
    itemIndex++;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // TAKEOFF AUDIT
  // ─────────────────────────────────────────────────────────────────────────────
  if (takeoff && takeoff.postCounts) {
    yPos += 8;
    yPos = ensureSpace(pdf, layout, yPos, 50);

    pdf.setFillColor(16, 113, 84);
    pdf.rect(layout.m.left, yPos, layout.contentW, 10, 'F');
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(12);
    pdf.setFont(undefined, 'bold');
    pdf.text('TAKEOFF AUDIT', layout.w / 2, yPos + 7, { align: 'center' });
    pdf.setTextColor(0, 0, 0);
    yPos += 18;

    const { endPosts, cornerPosts, gatePosts, linePosts, totalVinylPosts } = takeoff.postCounts;

    const aggregated = (allMaterials || []).reduce((acc, item) => {
      const key = item.lineItemName;
      const qty = item.quantity || 0;
      if (!acc[key]) acc[key] = { name: key, totalQty: 0 };
      acc[key].totalQty += qty;
      return acc;
    }, {});

    const panelEntry = Object.values(aggregated).find(item => {
      const name = (item.name || '').toLowerCase();
      return (
        name.includes('privacy') &&
        name.includes('vinyl') &&
        name.includes('panel') &&
        !name.includes('gate')
      );
    });
    const totalPanels = Math.round(panelEntry?.totalQty || 0);

    // Post counts grid
    pdf.setFillColor(255, 215, 0);
    pdf.rect(layout.m.left, yPos - 5, layout.contentW, 8, 'F');
    pdf.setFontSize(9);
    pdf.setFont(undefined, 'bold');
    pdf.setTextColor(16, 113, 84);
    pdf.text('End Posts', layout.m.left + 3, yPos);
    pdf.text('Corner Posts', layout.m.left + 45, yPos);
    pdf.text('Gate Posts', layout.m.left + 95, yPos);
    pdf.text('Line Posts', layout.m.left + 135, yPos);
    pdf.setTextColor(0, 0, 0);
    yPos += 8;

    pdf.setFillColor(250, 250, 250);
    pdf.rect(layout.m.left, yPos - 4, layout.contentW, 8, 'F');
    pdf.setFontSize(11);
    pdf.text(String(endPosts), layout.m.left + 3, yPos);
    pdf.text(String(cornerPosts), layout.m.left + 45, yPos);
    pdf.text(String(gatePosts), layout.m.left + 95, yPos);
    pdf.text(String(linePosts), layout.m.left + 135, yPos);
    yPos += 12;

    // Totals
    pdf.setFontSize(10);
    pdf.setFont(undefined, 'bold');
    pdf.text('Total Vinyl Posts:', layout.m.left + 3, yPos);
    pdf.text(String(totalVinylPosts), layout.m.left + 50, yPos);
    yPos += 6;
    pdf.text('Total Vinyl Panels:', layout.m.left + 3, yPos);
    pdf.setTextColor(16, 113, 84);
    pdf.text(String(totalPanels), layout.m.left + 50, yPos);
    pdf.setTextColor(0, 0, 0);
    yPos += 10;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // YARD MAP (Never Blank)
  // ─────────────────────────────────────────────────────────────────────────────
  const fenceLinesSafe = normalizeFenceLines(fenceLines);
  const hasMapImage = isValidDataUrl(mapImageData);
  const hasFenceLines = fenceLinesSafe.length > 0;

  if (hasMapImage || hasFenceLines) {
    pdf.addPage();
    yPos = layout.m.top;

    pdf.setFontSize(14);
    pdf.setFont(undefined, 'bold');
    pdf.setTextColor(16, 113, 84);
    pdf.text('YARD MAP', layout.w / 2, yPos, { align: 'center' });
    pdf.setDrawColor(16, 113, 84);
    pdf.setLineWidth(0.5);
    pdf.line(layout.w / 2 - 35, yPos + 2, layout.w / 2 + 35, yPos + 2);
    pdf.setTextColor(0, 0, 0);
    yPos += 15;

    const mapBoxW = layout.contentW;
    const mapBoxH = layout.bottomY - yPos - 20;

    // Draw border
    pdf.setDrawColor(200, 200, 200);
    pdf.setLineWidth(0.5);
    pdf.rect(layout.m.left, yPos, mapBoxW, mapBoxH);

    let mapDrawn = false;

    // Try image
    if (hasMapImage) {
      try {
        pdf.addImage(mapImageData, 'PNG', layout.m.left, yPos, mapBoxW, mapBoxH);
        mapDrawn = true;
      } catch (err) {
        console.warn('Map image rendering failed:', err);
      }
    }

    // Fallback to diagram
    if (!mapDrawn && hasFenceLines) {
      mapDrawn = renderFenceLinesDiagram(pdf, layout.m.left, yPos, mapBoxW, mapBoxH, fenceLinesSafe);
    }

    // Fallback to message
    if (!mapDrawn) {
      pdf.setFontSize(10);
      pdf.setTextColor(100, 100, 100);
      pdf.text('Map unavailable', layout.w / 2, yPos + mapBoxH / 2, { align: 'center' });
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // FOOTER (Smart placement)
  // ─────────────────────────────────────────────────────────────────────────────
  const footerH = 12;
  let footerY = layout.bottomY - footerH;

  // Check if we're too close to end of page
  if (yPos > footerY) {
    // Add new page for footer
    pdf.addPage();
    footerY = layout.m.top + 5;
  }

  pdf.setDrawColor(200, 200, 200);
  pdf.setLineWidth(0.3);
  pdf.line(layout.m.left, footerY, layout.w - layout.m.right, footerY);

  pdf.setFontSize(8);
  pdf.setTextColor(120, 120, 120);
  pdf.setFont(undefined, 'italic');
  pdf.text('Generated by Privacy Fence Company Field App', layout.w / 2, footerY + 5, {
    align: 'center'
  });
  pdf.text(
    `Date: ${new Date().toLocaleDateString()} | Rep: ${job.repName || user.full_name}`,
    layout.w / 2,
    footerY + 9,
    { align: 'center' }
  );

  return pdf;
}