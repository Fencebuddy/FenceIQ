import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import { resolveCompanyContext } from "./_shared/resolveCompanyContext.js";
import { PricingTruthError, requireUniqueOrNull } from "./_shared/truthSetIntegrity.js";

/**
 * Recompute overhead totals from active line items
 * Stores both dollar and cent values for compatibility
 */

function annualizeExpense(amount, cadence) {
  const multipliers = {
    MONTHLY: 12,
    WEEKLY: 52,
    QUARTERLY: 4,
    ANNUAL: 1,
    ONE_TIME: 0
  };
  return Number(amount || 0) * (multipliers[cadence] || 0);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const ctx = await resolveCompanyContext({ base44, req });
    if (ctx.error) {
      return Response.json({ success: false, error: ctx.error.code, message: ctx.error.message }, { status: 500 });
    }
    const { companyId } = ctx;

    // Get all active line items for company
    const lineItems = await base44.entities.OverheadLineItem.filter({ companyId, isActive: true });

    // Sum to annual overhead
    const totalAnnualOverhead = lineItems.reduce((sum, item) => {
      return sum + annualizeExpense(item.amount, item.cadence);
    }, 0);

    const monthlyOverhead = totalAnnualOverhead / 12;

    // Store in cents for breakeven system, dollars for legacy
    const annualOverheadCents = Math.round(totalAnnualOverhead * 100);
    const monthlyOverheadCents = Math.round(monthlyOverhead * 100);

    // Compute overhead % if projectedRevenue exists
    const existing = await base44.entities.OverheadSettings.filter({ companyId });
    const one = requireUniqueOrNull({
      records: existing,
      code: "OVERHEAD_SETTINGS_DUPLICATE",
      message: "Multiple OverheadSettings records found (uniqueness violated).",
      details: { companyId }
    });

    const projectedRevenue = one?.projectedAnnualRevenue || 1000000;
    const computedOverheadPct = projectedRevenue > 0 
      ? (totalAnnualOverhead / projectedRevenue) * 100 
      : 0;

    // Upsert via truth set function (calls upsertOverheadSettings but we need to handle totals first)
    const payload = await req.json();
    
    // Update OverheadSettings directly (this function IS the totals authority)
    const data = {
      companyId,
      totalAnnualOverhead,
      annualOverheadCents,
      monthlyOverheadCents,
      computedOverheadPct,
      lastComputedAt: new Date().toISOString(),
      projectedAnnualRevenue: payload?.projectedAnnualRevenue ?? projectedRevenue,
      manualOverridePct: one?.manualOverridePct ?? null,
      lockOverride: one?.lockOverride ?? false
    };

    let record;
    if (!one) {
      record = await base44.entities.OverheadSettings.create(data);
    } else {
      record = await base44.entities.OverheadSettings.update(one.id, data);
    }

    return Response.json({
      success: true,
      companyId,
      totalAnnualOverhead,
      monthlyOverhead,
      annualOverheadCents,
      monthlyOverheadCents,
      computedOverheadPct,
      lineItemsCount: lineItems.length,
      record
    });
  } catch (error) {
    console.error("[recomputeOverheadTotals] Error:", error);

    if (error && error.name === "PricingTruthError") {
      return Response.json(
        { success: false, error: error.code, message: error.message, details: error.details },
        { status: 500 }
      );
    }

    return Response.json({ success: false, error: "UNKNOWN_ERROR", message: error.message }, { status: 500 });
  }
});